﻿using AutoMapper;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.ExcelManager;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/EmcAssetRequests")]
    public class EmcAssetRequestsController : Controller
    {
        #region Member Variables
        private static readonly DataTable _emcTaxCodeTable = _emcTaxCodeTable ?? GetEmcTaxCodeTable("Templates/EmcTaxCode.xlsx");
        private readonly ILogger _logger;
        private readonly IOptions<Settings> _settings;
        private readonly IMailService _mailService;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly IMapper _mapper;
        #endregion

        /// <summary>
        /// This method retreives Emc tax code from excel.
        /// </summary>
        /// <param name="excelPath"></param>
        /// <returns></returns>
        private static DataTable GetEmcTaxCodeTable(string excelPath) => ExcelHelper.GetDataTableFromExcel(excelPath);

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public EmcAssetRequestsController(IOptions<Settings> settings, ILogger<EmcAssetRequestsController> logger,
            IMailService mailService, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _settings = settings;
            _mailService = mailService;
            _dataContext = mongoDataContext;
            _mapper = mapper;
        }

        /// <summary>
        /// This method searches EmcAssetRequests for given invoice numbers
        /// </summary>
        /// <param name="pipelinesource"></param>
        /// <param name="invoiceNos"></param>
        /// <returns></returns>
        [Route("{pipelinesource}/{invoiceNos}")]
        [HttpGet]
        #region GetEMCAssets
        public IActionResult GetEMCAssets(string pipelinesource, string invoiceNos)
        {
            _logger.LogDebug($"GetEMCAssets({pipelinesource},{invoiceNos})");

            try
            {
                if (string.IsNullOrEmpty(pipelinesource))
                    ModelState.AddModelError("pipeline", "Invalid Pipeline Source.");

                if (string.IsNullOrEmpty(invoiceNos))
                    ModelState.AddModelError("invoiceNos", "Invalid Invoice number(s).");

                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = FindAssets(pipelinesource, invoiceNos);

                if (result == null || !result.Any())
                {
                    _logger.LogWarning($"GetEMCAssets({pipelinesource},{invoiceNos}) - NOT FOUND");
                    return NotFound();
                }

                var finalResult = EnrichAssets(result);

                return Ok(finalResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetEMCAssets({pipelinesource},{invoiceNos}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// This method searches assets for given invoiceno's
        /// </summary>
        /// <param name="pipeline"></param>
        /// <param name="invoiceNos"></param>
        /// <returns></returns>
        private IList<Assets> FindAssets(string pipeline, string invoiceNos)
        {
            var invoicesList = invoiceNos.Split(',').ToList() as IEnumerable<string>;

            var filter = Builders<Assets>.Filter.Where(x => invoicesList.Contains(x.InvoiceNo)) &
                Builders<Assets>.Filter.Eq(c => c.PipelineSource, pipeline);

            return _dataContext.EmcAssetRequests.Find(filter)?.ToList();
        }

        /// <summary>
        /// Map IEnumerable(Assets) to IEnumerable(InvoiceAssetsResponseDto) using AutoMapper
        /// Incrementing the TieNo so that no two invoices have same TieNo.
        /// </summary>
        private IEnumerable<InvoiceAssetsResponseDto> EnrichAssets(IEnumerable<Assets> assets)
        {
            var result = new List<InvoiceAssetsResponseDto>();
            var tieNoIncrementor = 0;
            var dupFinancingProduct = string.Empty;

            foreach (var asset in assets)
            {
                var tieNoInUse = tieNoIncrementor;

                foreach (var item in asset.AssetItems.OrderBy(u => u.TieNo))
                {
                    var tempDto = _mapper.Map<InvoiceAssetsResponseDto>(item);

                    var financingProductCode = string.IsNullOrEmpty(tempDto.FinancingProductCode) ? string.Empty : tempDto.FinancingProductCode.Substring(0, 5);

                    var emcTaxRow = (from DataRow row in _emcTaxCodeTable.Rows
                                     where
                                     Convert.ToString(row["Material AAG"]).ToUpper() == financingProductCode
                                     select row).FirstOrDefault();
                    
                    if (emcTaxRow is null &&
                        (!string.IsNullOrEmpty(tempDto.FinancingProductCode) && tempDto.FinancingProductCode != "NA" && dupFinancingProduct != tempDto.FinancingProductCode))
                    {
                        NotifyUser($"New EMC Tax Code received - {tempDto.FinancingProductCode}");
                        dupFinancingProduct = tempDto.FinancingProductCode;
                    }

                    tempDto.TieNo = tieNoIncrementor = tieNoInUse + tempDto.TieNo;

                    ApplyEmcTaxRow(ref tempDto, asset, emcTaxRow);

                    result.Add(tempDto);
                }
            }

            return result.OrderBy(x => x.TieNo).ThenByDescending(x => x.AssetFlag);
        }

        /// <summary>
        /// This method applies emc tax fields for asset
        /// </summary>
        /// <param name="tempDto"></param>
        /// <param name="asset"></param>
        /// <param name="emcTaxRow"></param>
        private void ApplyEmcTaxRow(ref InvoiceAssetsResponseDto tempDto, Assets asset, DataRow emcTaxRow)
        {            
            tempDto.PipelineSource = asset.PipelineSource;
            tempDto.InvoiceNo = asset.InvoiceNo;            

            if (emcTaxRow != null)
            {                
                if (tempDto.CostType == "RealTime")
                    ApplyCostType(ref tempDto, emcTaxRow);

                if (tempDto.EquipmentType == "RealTime")
                    ApplyEquipmentType(ref tempDto, emcTaxRow);

                if (tempDto.ProductCode == "RealTime")
                    ApplyProductCode(ref tempDto, emcTaxRow);

                if (tempDto.ProgramType == "RealTime")
                    ApplyProgramType(ref tempDto, emcTaxRow);
            }
            else
                ApplyDefaultTaxValues(ref tempDto);
        }

        /// <summary>
        /// Applies costtype
        /// </summary>
        /// <param name="tempDto"></param>
        /// <param name="emcTaxRow"></param>
        private void ApplyCostType(ref InvoiceAssetsResponseDto tempDto, DataRow emcTaxRow)
        {
            tempDto.CostType = string.Empty;
            if (emcTaxRow["CostType"] != null)
                tempDto.CostType = emcTaxRow["CostType"].ToString();
        }

        /// <summary>
        /// Applies equipmentype
        /// </summary>
        /// <param name="tempDto"></param>
        /// <param name="emcTaxRow"></param>
        private void ApplyEquipmentType(ref InvoiceAssetsResponseDto tempDto, DataRow emcTaxRow)
        {
            tempDto.EquipmentType = string.Empty;
            if (emcTaxRow["Equipment Type"] != null)
                tempDto.EquipmentType = emcTaxRow["Equipment Type"].ToString();
        }

        /// <summary>
        /// Applies programcode
        /// </summary>
        /// <param name="tempDto"></param>
        /// <param name="emcTaxRow"></param>
        private void ApplyProductCode(ref InvoiceAssetsResponseDto tempDto, DataRow emcTaxRow)
        {
            tempDto.ProductCode = string.Empty;
            if (emcTaxRow["Product Code"] != null)
                tempDto.ProductCode = emcTaxRow["Product Code"].ToString();
        }

        /// <summary>
        /// Applies programtype
        /// </summary>
        /// <param name="tempDto"></param>
        /// <param name="emcTaxRow"></param>
        private void ApplyProgramType(ref InvoiceAssetsResponseDto tempDto, DataRow emcTaxRow)
        {
            tempDto.ProgramType = string.Empty;
            if (emcTaxRow["Program Type"] != null)
                tempDto.ProgramType = emcTaxRow["Program Type"].ToString();
        }

        /// <summary>
        /// This method applies default values when tax row is not found
        /// </summary>
        /// <param name="tempDto"></param>
        private void ApplyDefaultTaxValues(ref InvoiceAssetsResponseDto tempDto)
        {
            if (tempDto.CostType == "RealTime")
                tempDto.CostType = string.Empty;

            if (tempDto.EquipmentType == "RealTime")
                tempDto.EquipmentType = string.Empty;

            if (tempDto.ProductCode == "RealTime")
                tempDto.ProductCode = string.Empty;

            if (tempDto.ProgramType == "RealTime")
                tempDto.ProgramType = string.Empty;
        }

        /// <summary>
        /// This method sends email to group of users when there is no matching row in EMCTaxCode table for a given FinancingProductCode
        /// </summary>
        private void NotifyUser(string subject)
        {
            var body = string.Empty;

            var to = _settings.Value.EMAIL_BUZ_ADMIN.Split(',').ToList();

            var message = new MailMessage
            {
                Subject = subject,
                Body = body,
                ToList = to,
                IsBodyHtml = true,
                OperatingEnv = _settings.Value.ASPNETCORE_ENVIRONMENT
            };

            _mailService.SendMail(message);
        }
        #endregion
    }
}