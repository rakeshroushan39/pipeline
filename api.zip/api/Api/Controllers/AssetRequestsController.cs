﻿using DFS.Banzai.Asset.Library.Entities;
using DFS.Banzai.Asset.Library.Interfaces;
using DFS.Banzai.Asset.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Diagnostics.CodeAnalysis;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/AssetRequests")]
    [ExcludeFromCodeCoverage]
    public class AssetRequestsController : Controller
    {
        #region Member Variables
        #endregion    

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public AssetRequestsController(IOptions<Settings> settings, ILogger<AssetRequestsController> logger,
            IAssetMailService mailService, IAssetDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {   
        }
    }
}

