using AutoMapper;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/Errors")]
    public class ErrorsController : Controller
    {
        #region MemberVariables
        private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
		private readonly IMapper _mapper;
		#endregion

		/// <summary>
		/// Parameter constructor to initialize default objects
		/// </summary>
		public ErrorsController(IOptions<Settings> settings, ILogger<ErrorsController> logger,
			IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _dataContext = mongoDataContext;
			_logger = logger;
			_mapper = mapper;
		}

		/// <summary>
		/// This method gets Strategy Errors for a given date range
		/// </summary>        
		[HttpGet]
        #region GetError
        public IActionResult GetError(DateTime dateStart, DateTime dateEnd) {
		    _logger.LogDebug($"GetError({dateStart},{dateEnd}items.");

		    try {
			    if (!ModelState.IsValid)
				    return BadRequest(ModelState);

			    var days = (dateEnd - dateStart).TotalDays;

				if (days > 30) {
					_logger.LogWarning($"GetError({dateStart},{dateEnd}) - Date Range is more then 30 days.");
					return BadRequest("Date range is greater than 30 days.");
				}
				
				var result = FindErrorsForDateRange(dateStart, dateEnd.AddDays(1));

				if (result == null) {
				    _logger.LogWarning($"GetError({dateStart},{dateEnd}) - NOT FOUND");
				    return NotFound();
			    }

			    var finalResult = _mapper.Map<IEnumerable<ErrorResponseDto>>(result);

			    return Ok(finalResult);
		    }
		    catch (Exception ex) {
			    _logger.LogError(ex, $"GetError({dateStart},{dateEnd}) - EXCEPTION");
			    return StatusCode(500, "A problem happened while handling your request.");
		    }
	    }

        /// <summary>
        /// Finds errors records for a given date range
        /// </summary>
        /// <param name="dateStart"></param>
        /// <param name="dateEnd"></param>
        /// <returns></returns>
		private IEnumerable<ErrorLog> FindErrorsForDateRange(DateTime dateStart, DateTime dateEnd) {
			var builder = Builders<ErrorLog>.Filter;
			var filter = builder.Gte(u => u.LastModifiedOn, dateStart)
						 & builder.Lte(u => u.LastModifiedOn, dateEnd);
			return _dataContext.ErrorLogs.Find(filter);
		}
        #endregion
    }
}
