using AutoMapper;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.StatusCombos;
using DFS.Banzai.Library.Queries;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/StatusCombos")]
	public class StatusCombosController : Controller {
		private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
		private readonly IMapper _mapper;

        public StatusCombosController(ILogger<StatusCombosController> logger, 
			IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _dataContext = mongoDataContext;
			_logger = logger;
			_mapper = mapper;
		}

		[HttpGet]
		public IActionResult GetAll() {
			_logger.LogDebug("GetAll items.");

			try {
				var items = _dataContext.StatusCombos.GetAll();

				if (items == null || !items.Any()) {
					_logger.LogWarning("GetAll() - NOT FOUND");
					return NotFound();
				}

				return Ok(items);
			}
			catch (Exception ex) {
				_logger.LogError($"GetAll() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

		[HttpGet("GetStatusCodes/{pipelineSource}/{pipelineStage}")]
		public IActionResult GetStatusCodes(string pipelineSource, string pipelineStage) {
			_logger.LogDebug("GetStatusCodes");

			try {
                var statusCodes = _dataContext.StatusCombos.Find(StatusCombosQuery.StatusCodesFilter(pipelineSource, pipelineStage));

				if (statusCodes == null || !statusCodes.Any()) {
					_logger.LogWarning("GetStatusCodes() - NOT FOUND");
					return NotFound();
				}

                var resultSet = (from code in statusCodes select code)?.OrderBy(i => i.BanzaiStatusSequence)?.Select(i=>i.BanzaiStatusCode)?.Distinct();

                return Ok(resultSet); //Rap result with Ok (200) status code
			}
			catch (Exception ex) {
				_logger.LogError($"GetStatusCodes() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

        [HttpGet("GetStatusCombos/{pipelineSource}/{pipelineStage}")]
        public IActionResult GetStatusCombos(string pipelineSource, string pipelineStage)
        {
            _logger.LogDebug("GetStatusCombos");

            try
            {
                var statusCombos = _dataContext.StatusCombos.Find(StatusCombosQuery.StatusCodesFilter(pipelineSource, pipelineStage));

                if (statusCombos == null || !statusCombos.Any())
                {
                    _logger.LogWarning("GetStatusCombos() - NOT FOUND");
                    return NotFound();
                }

                var resultSet = (from combo in statusCombos select combo)?.OrderBy(i => i.BanzaiStatusSequence)?.Distinct();

                return Ok(resultSet); //Rap result with Ok (200) status code
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetStatusCombos() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        //Name = "GetById" is used by subsequenct controllers to generate URI for a given object ID..
        [HttpGet("{id:length(24)}", Name = "GetStatusComboById")]
		public IActionResult GetById(string id) {
			_logger.LogDebug($"GetById({id}) items.");

			try {
				var query = _dataContext.StatusCombos.QueryId(id);

				var item = _dataContext.StatusCombos.Find(query);

				if (item == null) {
					_logger.LogWarning($"GetById({id}) - NOT FOUND");

					return NotFound();
				}

				return Ok(item);
			}
			catch (Exception ex) {
				_logger.LogError($"GetById({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

		[HttpPost]
		public IActionResult Create([FromBody] StatusComboForDmlDto item) {
			_logger.LogDebug("Create() items.");

			try {
				if (!ModelState.IsValid) {
					return BadRequest(ModelState);
				}

				var finalItem = _mapper.Map<StatusCombo>(item);

				finalItem.LastModifiedOn = DateTime.UtcNow;

				_dataContext.StatusCombos.InsertOne(finalItem);

				var createdItemToReturn = _mapper.Map<StatusComboForDmlDto>(finalItem);

				return CreatedAtRoute("GetStatusComboById", new { id = finalItem.Id }, createdItemToReturn);
			}
			catch (Exception ex) {
				_logger.LogError($"Create() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

		[HttpPut("{id:length(24)}")]
		public IActionResult Replace(string id, [FromBody] StatusComboForDmlDto item) {
			_logger.LogDebug(LoggingEvents.GetItem, $"Replace({id}) items.");

			try {
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var finalItem = _mapper.Map<StatusCombo>(item);

				finalItem.Id = id;
				finalItem.LastModifiedOn = DateTime.UtcNow;
				
				if (!Update(finalItem))
					return NotFound();

				return NoContent();
			}
			catch (Exception ex) {
				_logger.LogError($"Replace({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

		[HttpDelete("{id:length(24)}")]
		public IActionResult Delete(string id) {
			_logger.LogDebug($"Delete({id}) items.");

			try {
				if (_dataContext.StatusCombos.Remove(id)) {

					_logger.LogWarning(LoggingEvents.GetItemNotFound, $"Delete({id}) - NOT FOUND");

					return NoContent(); // 204 No Content
				}

				return NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"Delete({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
		}

		#region Private methods
		private bool Update(StatusCombo item) {
			var query = Builders<StatusCombo>.Filter.Eq(e => e.Id, item.Id);

			return _dataContext.StatusCombos.ReplaceOneAsync(query, item);
		}
		#endregion
	}
}