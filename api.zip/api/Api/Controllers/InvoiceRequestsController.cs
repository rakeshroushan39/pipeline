using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/InvoiceRequests")]
	public class InvoiceRequestsController : Controller
	{
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public InvoiceRequestsController(IOptions<Settings> settings, ILogger<InvoiceRequestsController> logger, IDataContext mongoDataContext,
            IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
			_logger = logger;
			_dataContext = mongoDataContext;
		}

		/// <summary>
		/// This method returns Invoice messages Id from InvoiceRequest
		/// </summary>
		/// <param name = "id" ></ param >
		/// < returns > Content xml from collection</returns>
		[Route("{id:length(24)}")]
		[HttpGet]
		#region GetInvoiceRequest
		public IActionResult GetInvoiceRequest(string id)
		{
			_logger.LogDebug(LoggingEvents.GetItem, $"GetInvoiceRequest({id}) items.");

			try
			{
				var idFilter = Builders<InvoiceRequest>.Filter.Eq(u => u.Id, id);
				return Ok(_dataContext.InvoiceRequests.Find(idFilter)?.FirstOrDefault()?.Content ?? string.Empty);
			}
			catch (XmlException e)
			{
				_logger.LogError($"GetInvoiceRequest({id}) - EXCEPTION. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return NotFound();
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetInvoiceRequest({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, ex.Message ?? "Internal Server Error");
			}
		}
		#endregion

		/// <summary>
		/// This region performs all operations related to MissingInvoiceRequests
		/// </summary>
		/// <returns></returns>
		#region MissingInvoiceRequests
		/// <summary>
		/// This method searches for all Invoices present in MissingInvoiceRequests
		/// collection
		/// </summary>
		/// <returns></returns>
		[Route("Missing")]
		[HttpGet]
		public IActionResult GetMissingInvoiceRequests()
		{
			_logger.LogDebug("GetMissingInvoiceRequests items.");

			try
			{
				var filter = Builders<MissingInvoiceRequest>.Filter.Exists(u => u.ReferenceID, true);
				var projection = Builders<MissingInvoiceRequest>.Projection
								.Include(u => u.PipelineSource)
								.Include(u => u.PipelineSource)
								.Include(u => u.MessageType)
								.Include(u => u.DecisionSource)
								.Include(u => u.DecisionSourceDateTime)
								.Include(u => u.DecisionSourceStatusCode)
								.Include(u => u.InvoiceNo)
								.Include(u => u.SourceBusinessUnitID)
								.Include(u => u.ReferenceID)
								.Include(u => u.CorrelationID)
								.Include(u => u.CreateDateTime)
								.Include(u => u.MessageID)
								.Exclude(u => u.Id);

				var sortInvoice = Builders<MissingInvoiceRequest>.Sort.Ascending(u => u.CreateDateTime);

				var missingInvoiceRequests = _dataContext.MissingInvoiceRequests.FindAndSort(filter, projection, sortInvoice);

				if (missingInvoiceRequests == null || !missingInvoiceRequests.Any())
				{
					_logger.LogWarning("GetMissingInvoiceRequests() - NOT FOUND");
					return NotFound();
				}

				var missingInvoiceRequestsDtoList = new List<MissingInvoiceRequestsDto>();

				foreach (var obj in missingInvoiceRequests)
					missingInvoiceRequestsDtoList.Add(BsonSerializer.Deserialize<MissingInvoiceRequestsDto>(obj));

				return Ok(missingInvoiceRequestsDtoList);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetMissingInvoiceRequests() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, ex.Message);
			}
		}

		/// <summary>
		/// This method resubmits missing invoice requests
		/// </summary>
		/// <returns></returns>
		[Route("Missing/Resubmit/{messageIdList}")]
		[HttpGet]
		#region ResubmitMissingInvoiceRequests
		public IActionResult ResubmitMissingInvoiceRequests(string messageIdList)
		{
			_logger.LogDebug("ResubmitMissingInvoiceRequests items.");
			try
			{
				XDocument pipelineDocument = null;
				var messageIds = messageIdList?.Split(",");

                if (messageIds != null)
                {
                    foreach (var messageId in messageIds)
                    {
                        pipelineDocument = GetPipelineDocument(messageId);
                        if (pipelineDocument != null)
                        {
                            _rabbitMQueuePublisher.Publish(pipelineDocument.ToString(), "q.messagebridge.dell.invoice.notifications.banzai.invoice.dell");
                            _dataContext.MissingInvoiceRequests.DeleteOne(Builders<MissingInvoiceRequest>.Filter.Eq(u => u.MessageID, messageId));
                        }
                    }
                }

				return Ok();
			}
			catch (Exception ex)
			{
				_logger.LogError($"ResubmitMissingInvoiceRequests() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, ex.Message);
			}
		}

		/// <summary>
		/// This method retreives pipeline store document based on DocumentID
		/// </summary>
		/// <returns></returns>
		private XDocument GetPipelineDocument(string messageId)
		{
			var filter = Builders<PipelineRequest>.Filter.Eq(u => u.Id, messageId);

			var pipelineRequest = _dataContext.PipelineRequests.Find(filter)?.FirstOrDefault();

			var messageDocument = pipelineRequest == null ? null : XDocument.Parse(pipelineRequest.Content) ?? null;

			return messageDocument;
		}
		#endregion
		#endregion
	}
}