﻿using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Invoice.Library.Models.InvoiceEnrichments;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.Models.InvoiceEnrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Buffers;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/InvoiceEnrichedRequests")]
    public class InvoiceEnrichedRequestsController : Controller
    {
        #region Member Variables
        private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly List<string> _pipelineSourceList = new List<string>() { "DELL", "EMC", "CHANNEL" };
        private readonly List<string> _searchByList = new List<string>() { "InvoiceNo", "OrderNo", "OriginalInvoiceNo" , "OriginalOrderNo" };
        private const string INVOICE = "INVOICE";
        private readonly IPublisher _rabbitMQueuePublisher;
        #endregion                

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public InvoiceEnrichedRequestsController(IOptions<Settings> settings, ILogger<InvoiceEnrichedRequestsController> logger,
            IMailService mailService, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _dataContext = mongoDataContext;
        }

        /// <summary>
        /// This method returns the Invoice details along with Invoice Lines and Sublines
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <returns></returns>        
        [Route("Invoice")]
        [HttpPost]
        #region GetInvoice
        public IActionResult GetInvoice([FromBody] InvoiceRequestDto invoiceRequest)
        {
            var settings = new JsonSerializerSettings { Formatting = Formatting.Indented };
            OkObjectResult result;
            try
            {
                _logger.LogDebug($"Invoices/GetInvoice-Search by ({invoiceRequest.SearchBy}:{invoiceRequest.SearchValue},BUID:{invoiceRequest.SourceBusinessUnit ?? string.Empty}," +
                    $"VendorId:{invoiceRequest.VendorId})");

                var response = GenerateInvoiceResponse(invoiceRequest);
                result = Ok(response);
                var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
                result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Invoices/GetInvoice-Search by ({invoiceRequest.SearchBy}:{invoiceRequest.SearchValue},BUID:{invoiceRequest.SourceBusinessUnit ?? string.Empty}," +
                    $"VendorId:{invoiceRequest.VendorId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                var error = new InvoiceError()
                {
                    Code = 500,
                    State = "ERROR",
                    Detail = $"Unhandled Exception : {ex.Message}"
                };
                result = Ok(new InvoiceResponseDto() { Error = error, InvoiceQuantityFound = 0, Invoices = new List<InvoiceResponse>() });
                var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
                result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

                return result;
            }
        }

        /// <summary>
        /// This method returns the Invoice Response object
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <returns></returns>
        private InvoiceResponseDto GenerateInvoiceResponse(InvoiceRequestDto invoiceRequest)
        {
            var invoiceResponseDto = new InvoiceResponseDto
            {
                Invoices = new List<InvoiceResponse>()
            };

            var invoiceError = ValidateInvoiceInputRequest(invoiceRequest);
            if (invoiceError != null)
            {
                invoiceResponseDto.Error = invoiceError;
                return invoiceResponseDto;
            }

            var enrichedRequestsList = GetEnrichedRequestList(invoiceRequest);
            if (enrichedRequestsList != null && enrichedRequestsList.Any())
            {
                invoiceResponseDto.Invoices = GetInvoices(enrichedRequestsList, invoiceRequest);
                invoiceResponseDto.InvoiceQuantityFound = invoiceResponseDto.Invoices == null ? 0 : invoiceResponseDto.Invoices.Count;
                return invoiceResponseDto;
            }
           
            invoiceResponseDto.Error = SetInvoiceError(invoiceRequest);

            return invoiceResponseDto;
        }

        /// <summary>
        /// This method validates the Invoice input request and returns a InvoiceResponse Error if not valid
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <returns>InvoiceResponseDto</returns>       
        private InvoiceError ValidateInvoiceInputRequest(InvoiceRequestDto invoiceRequest)
        {
            var errorDetail = new System.Text.StringBuilder();

            if (string.IsNullOrEmpty(invoiceRequest.ClientName))
            {
                errorDetail.Append("ClientName is BLANK ");
            }
            if (string.IsNullOrEmpty(invoiceRequest.PipelineSource))
            {
                errorDetail.Append(";PipelineSource is BLANK");
            }
            else if (!_pipelineSourceList.Contains(invoiceRequest.PipelineSource, StringComparer.InvariantCultureIgnoreCase))
            {
                errorDetail.Append(";Pipeline Source is Invalid");
            }
            if (string.IsNullOrEmpty(invoiceRequest.SearchBy))
            {
                errorDetail.Append(";SearchBy is BLANK");
            }
            else if (!_searchByList.Contains(invoiceRequest.SearchBy, StringComparer.InvariantCultureIgnoreCase))
            {
                errorDetail.Append(";SearchBy is Invalid");
            }
            if (string.IsNullOrEmpty(invoiceRequest.SearchValue))
            {
                errorDetail.Append(";SearchByValue is BLANK");
            }
            if (string.IsNullOrEmpty(invoiceRequest.ReturnInvoiceLines.ToString()))
            {
                errorDetail.Append(";ReturnInvoiceLines is BLANK");
            }
            if (string.IsNullOrEmpty(invoiceRequest.ReturnInvoiceSubLines.ToString()))
            {
                errorDetail.Append(";ReturnInvoiceSubLines is BLANK");
            }

            if (!string.IsNullOrEmpty(errorDetail.ToString()))
            {
                var error = new InvoiceError()
                {
                    Code = 400,
                    State = "ERROR",
                    Detail = "BadRequest: " + errorDetail.ToString()
                };

                return error;
            }
            else
                return null;
        }

        /// <summary>
        /// This method queries Invoice Enriched Requests with corresponding SearchBy and
        /// SearchValue to form the query and returns a list of matching EnrichedRequest documents
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <returns></returns>
        private IEnumerable<InvoiceEnrichedRequest> GetEnrichedRequestList(InvoiceRequestDto invoiceRequest)
        {
            var builder = Builders<InvoiceEnrichedRequest>.Filter;
            var filter = builder.Eq(u => u.Common.PipelineSource, invoiceRequest.PipelineSource); 

            switch (invoiceRequest.SearchBy.ToUpper())
            {
                case "INVOICENO":
                    filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo.ToUpper() == invoiceRequest.SearchValue.ToUpper());
                    break;
                case "ORDERNO":
                    filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.OrderNo.ToUpper() == invoiceRequest.SearchValue.ToUpper());
                    break;
                case "ORIGINALINVOICENO":
                    filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.OriginalInvoiceNo.ToUpper() == invoiceRequest.SearchValue.ToUpper());
                    break;
                case "ORIGINALORDERNO":
                    filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.OriginalOrderNo.ToUpper() == invoiceRequest.SearchValue.ToUpper());
                    break;
                default:
                    filter = null;
                    break;
            }
            if (filter == null)
                return new List<InvoiceEnrichedRequest>();

            if (!string.IsNullOrEmpty(invoiceRequest.SourceBusinessUnit))
                filter = filter & builder.Eq(u => u.Common.SourceBusinessUnit, invoiceRequest.SourceBusinessUnit);

            if (!string.IsNullOrEmpty(invoiceRequest.VendorId))
                filter = filter & builder.Eq(u => u.Common.VendorId, invoiceRequest.VendorId);

            return _dataContext.InvoiceEnrichedRequestsV2.FindByFilter(filter);
        }
        
        /// <summary>
        /// This method populates the Invoice data in the response
        /// </summary>
        /// <param name="enrichedRequestsList"></param>
        /// <param name="invoiceRequest"></param>
        /// <returns></returns>
        private ICollection<InvoiceResponse> GetInvoices(IEnumerable<InvoiceEnrichedRequest> enrichedRequestsList, InvoiceRequestDto invoiceRequest)
        {
            var invoices = new List<InvoiceResponse>();
            foreach (var enrichedRequest in enrichedRequestsList)
            {
                InvoiceResponse invoiceResponse = null;

                if (enrichedRequest?.InvoiceStage?.Invoices != null && enrichedRequest.InvoiceStage.Invoices.Any())
                {
                    var invoice = enrichedRequest.InvoiceStage?.Invoices[0];

                    if (invoice != null)
                    {
                        ApplyInvoiceLinesAndStatus(invoiceRequest, ref invoice, enrichedRequest);

                        invoiceResponse = new InvoiceResponse
                        {
                            Common = enrichedRequest?.Common,
                            Invoice = invoice
                        };
                    }
                }

                if(invoiceResponse != null)
                    invoices.Add(invoiceResponse);
            }

            return invoices;
        }

        /// <summary>
        /// This method applies invoicelines and status history
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <param name="invoice"></param>
        /// <param name="enrichedRequest"></param>
        private void ApplyInvoiceLinesAndStatus(InvoiceRequestDto invoiceRequest, ref Invoice.Library.Entities.Invoice invoice, InvoiceEnrichedRequest enrichedRequest)
        {
            if (invoiceRequest.ReturnInvoiceLines)
            {
                invoice.InvoiceProductItem = GetInvoiceProductItem(invoice.InvoiceNo,
                                                    enrichedRequest.Common.PipelineSource,
                                                    enrichedRequest.Common.SourceBusinessUnit,
                                                    enrichedRequest.Common.VendorId,
                                                    invoiceRequest.ReturnInvoiceSubLines);
            }

            if (!invoiceRequest.ReturnStatusHistory)
                invoice.StatusHistory = null;
        }

        /// <summary>
        /// This method searches InvoiceProductItems collection based on InvoiceNo, PipelineSource and SourceBusinessUnit
        /// </summary>
        /// <param name="invoiceNo"></param>
        /// <param name="pipelineSource"></param>
        /// <param name="buid"></param>
        /// <param name="vendorId"></param>
        /// <param name="returnInvoiceSubLines"></param>
        /// <returns></returns>
        private InvoiceProductItem GetInvoiceProductItem(string invoiceNo, string pipelineSource, string buid,string vendorId, bool returnInvoiceSubLines)
        {
            var builder = Builders<InvoiceProductItem>.Filter;
            var filter = builder.Eq(c => c.InvoiceNo, invoiceNo) &
                builder.Eq(u => u.PipelineSource, pipelineSource);

            if (!string.IsNullOrEmpty(buid))
                filter = filter & builder.Eq(u => u.SourceBusinessUnit, buid);

            if (!string.IsNullOrEmpty(vendorId))
                filter = filter & builder.Eq(u => u.VendorId, vendorId);

            var invoiceProductItem = _dataContext.InvoiceProductItems.Find(filter)?.FirstOrDefault();

            if (!returnInvoiceSubLines)
            {
                foreach(var invoiceLine in invoiceProductItem?.InvoiceLines)
                    invoiceLine.InvoiceSubLines = null;
            }

            return invoiceProductItem;
        }

        /// <summary>
        /// Generic method to set the Invoice Error detail
        /// </summary>
        /// <param name="invoiceRequest"></param>
        /// <returns></returns>
        private InvoiceError SetInvoiceError(InvoiceRequestDto invoiceRequest)
        {
            var invoiceError = new InvoiceError()
            {
                Code = 404,
                State = "ERROR"
            };
            invoiceError.Detail = $"Not Found : {invoiceRequest.SearchBy}-{invoiceRequest.SearchValue}";

            if (!string.IsNullOrEmpty(invoiceRequest.SourceBusinessUnit))
                invoiceError.Detail += $";BusinessUnitID-{invoiceRequest.SourceBusinessUnit}";

            return invoiceError;
        }
        #endregion

        /// <summary>
        /// This method searches EnrichedRequests based on invoicelookupinformation
        /// </summary>
        /// <param name="invoiceLookupInfo"></param>
        /// <returns></returns>
        [Route("EMC/Invoice")]
        [HttpPost]
        #region GetEMCInvoice
        public IActionResult GetEMCInvoice([FromBody] SearchInvoiceRequestDto invoiceLookupInfo)
        {
            _logger.LogDebug("GetEMCInvoice");

            if (invoiceLookupInfo == null)
            {
                ModelState.AddModelError("GetEMCInvoice", "Invalid input");
                return BadRequest(ModelState);
            }

            try
            {
                var result = SearchInvoiceData(invoiceLookupInfo)?.ToList();

                if (result == null || !result.Any())
                {
                    _logger.LogWarning("GetEMCInvoice - NOT FOUND");
                    return NotFound();
                }

                var finalResult = InvoiceResponseMapper(result);

                if (!finalResult.Any())
                {
                    _logger.LogWarning("GetEMCInvoice - NOT FOUND");
                    return NotFound();
                }

                return Ok(finalResult);
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetEMCInvoice - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// This method creates filter based on invoiceinfo and finds the required document from EnrichedRequests collection
        /// </summary>
        /// <param name="invoiceInfo"></param>
        /// <returns></returns>
        private IEnumerable<InvoiceEnrichedRequest> SearchInvoiceData(SearchInvoiceRequestDto invoiceInfo)
        {
            var builder = Builders<InvoiceEnrichedRequest>.Filter;

            var filter = builder.Eq(u => u.Common.PipelineSource, invoiceInfo.PipelineSource);

            filter = !string.IsNullOrEmpty(invoiceInfo.SourceCustomerID) ? filter & builder.Eq(u => u.Common.SourceCustomerID, invoiceInfo.SourceCustomerID) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.DFSCountryCode) ? filter & builder.Eq(u => u.Common.SourceCountry, invoiceInfo.DFSCountryCode) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.ShippingCountry) ? filter & builder.Eq(u => u.Common.ShippingCountry, invoiceInfo.ShippingCountry) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.BanzaiStatus) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.Status.BanzaiStatusCode == invoiceInfo.BanzaiStatus) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.InvoiceNo) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo == invoiceInfo.InvoiceNo) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.EndUserQuoteID) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.EndUserQuoteID == invoiceInfo.EndUserQuoteID) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.SourceDealId) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.SourceDealId == invoiceInfo.SourceDealId) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.OrderNo) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.OrderNo == invoiceInfo.OrderNo) : filter;
            filter = !string.IsNullOrEmpty(invoiceInfo.InvoiceType) ? filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceType == invoiceInfo.InvoiceType) : filter;

            filter = !string.IsNullOrEmpty(invoiceInfo.SourceCustomerName) ? filter & builder.Regex(u => u.Common.SourceCustomerName, new BsonRegularExpression($".*{invoiceInfo.SourceCustomerName}.*", "i")) : filter;

            var enrichedDocuments = _dataContext.InvoiceEnrichedRequestsV2.Find(filter);
            return enrichedDocuments;
        }

        /// <summary>
        /// This mehtod maps invoice response with enriched request and pulls only required fields
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        private static IEnumerable<SearchInvoiceResponseDto> InvoiceResponseMapper(IEnumerable<InvoiceEnrichedRequest> result)
            => (from eDoc in result
                where eDoc?.InvoiceStage != null
                from invoice in eDoc.InvoiceStage?.Invoices
                select new SearchInvoiceResponseDto
                {
                    Id = eDoc.Id,

                    //Common
                    PipelineSource = eDoc.Common.PipelineSource,
                    SourceCustomerID = eDoc.Common.SourceCustomerID,
                    SourceCustomerName = eDoc.Common.SourceCustomerName,
                    DFSUnbookedExposureID = eDoc.Common.DFSUnbookedExposureID,
                    SourcePaymentTerms = eDoc.Common.SourcePaymentTerms,
                    ShippingCountry = eDoc.Common.ShippingCountry,
                    DFSCountryCode = eDoc.Common.DFSCountryCode,

                    //Invoice
                    InvoiceNo = invoice.InvoiceNo,
                    EndUserQuoteID = invoice.EndUserQuoteID,
                    SourceDealId = invoice.SourceDealId,
                    InvoiceType = invoice.InvoiceType,
                    OrderNo = invoice.OrderNo,
                    OriginalInvoiceNo = invoice.OriginalInvoiceNo,
                    OriginalOrderNo = invoice.OriginalOrderNo,
                    InvoiceDate = invoice.InvoiceDate,
                    TotalDFSFinanceAmount = invoice.TotalDFSFinanceAmount,
                    TagCount = invoice.TagCount,
                    TagVariance = invoice.TagVariance,
                    ContractNum = invoice.ContractNum,
                    BookingDate = invoice.BookingDate,

                    //Invoice Status
                    BanzaiStatusCode = invoice.Status.BanzaiStatusCode
                }).ToList();
        #endregion

        /// <summary>
        /// This method searches EnrichedRequests collection to retreive a document based on pipelinesoure, documenttype and id.
        /// </summary>
        /// <param name="pipelineSource"></param>
        /// <param name="docType"></param>
        /// <param name="id"></param>
        /// <param name="buid"></param>
        /// <returns></returns>
        [Route("{pipelineSource}/{docType}/{id}")]
        [Route("{pipelineSource}/{docType}/{id}/{buid}")]
        [HttpGet]
        #region GetInvoiceEnrichedRequest
        public IActionResult GetInvoiceEnrichedRequest(string pipelineSource, string docType, string id, string buid="")
        {
            _logger.LogDebug($"GetInvoiceEnrichedRequest({pipelineSource},{docType},{id})");

            try
            {
                InvoiceEnrichedRequest result;

                if (INVOICE.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
                    result = SearchInvoiceEnrichedRequest(id, pipelineSource, buid);
                else
                {
                    ModelState.AddModelError("docType", "Invalid Document Type.");
                    return BadRequest(ModelState);
                }

                if (result == null)
                {
                    _logger.LogWarning($"GetInvoiceEnrichedRequest({pipelineSource},{docType},{id},{buid}) - NOT FOUND");
                    return NotFound();
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetInvoiceEnrichedRequest({pipelineSource},{docType},{id},{buid}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }    

        /// <summary>
        /// This method searches InvoiceEnrichedRequests collection based on InvoiceNo, Pipeline and Buid
        /// </summary>
        /// <param name="invoiceNo"></param>
        /// <param name="pipelineSource"></param>
        /// <param name="buid"></param>
        /// <returns></returns>
        private InvoiceEnrichedRequest SearchInvoiceEnrichedRequest(string invoiceNo, string pipelineSource, string buid = "")
        {
            var pipelineFilter = Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

            if (!string.IsNullOrEmpty(buid))
                pipelineFilter = pipelineFilter & Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);

            var invoiceFilter = Builders<InvoiceEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo.ToUpper() == invoiceNo.ToUpper());
            var filter = Builders<InvoiceEnrichedRequest>.Filter.And(invoiceFilter, pipelineFilter);

            var invoiceEnrichedRequest = _dataContext.InvoiceEnrichedRequestsV2.Find(filter)?.FirstOrDefault();

            if (invoiceEnrichedRequest != null)
            {
                // Invoice Product Items
                var builder = Builders<InvoiceProductItem>.Filter;
                var productItemfilter = builder.Eq(c => c.InvoiceNo, invoiceNo) &
                    builder.Eq(u => u.PipelineSource, pipelineSource) &
                    builder.Eq(u => u.SourceBusinessUnit, buid);

                invoiceEnrichedRequest.InvoiceStage.Invoices[0].InvoiceProductItem = _dataContext.InvoiceProductItems.Find(productItemfilter)?.FirstOrDefault();
            }

            return invoiceEnrichedRequest;
        }
        #endregion        

        /// <summary>
        /// This method deletes InvoiceEnrichedRequest
        /// </summary>
        /// <returns></returns>
        [Route("{pipelineSource}/{identifier}/{identifierList}")]
        [HttpDelete]
        #region DeleteInvoiceEnrichedRequest
        public IActionResult DeleteInvoiceEnrichedRequest(string pipelineSource, string identifier, string identifierList, bool deleteRollup = true)
        {
            _logger.LogDebug("DeleteInvoiceEnrichedRequest started");

            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var items = identifierList?.Split(",");

                identifier = identifier.Trim();
                pipelineSource = pipelineSource.Trim();

                if (items != null && items.Length > 0 && identifier.ToUpper().Equals("INVOICE"))
                {
                    Array.ForEach(items, item =>
                    {
                        ProcessDeleteInvoice(item, pipelineSource, deleteRollup);
                    });
                }

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"DeleteInvoiceEnrichedRequest - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// This method processes delete invoices
        /// </summary>
        /// <param name="item"></param>
        /// <param name="pipelineSource"></param>
        /// <param name="deleteRollup"></param>
        private void ProcessDeleteInvoice(string item, string pipelineSource, bool deleteRollup)
        {   
            if (!string.IsNullOrEmpty(item))
            {
                var filter = Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);
                var rollupFilter = Builders<RollupRequest>.Filter.Eq(u => u.PipelineSource, pipelineSource);

                _dataContext.InvoiceEnrichedRequestsV2.DeleteOne(Builders<InvoiceEnrichedRequest>.Filter.ElemMatch(u => u.InvoiceStage.Invoices, o => o.InvoiceNo.ToUpper() == item.Trim().ToUpper()) & filter);
                _dataContext.InvoiceProductItems.DeleteOne(Builders<InvoiceProductItem>.Filter.Eq(u => u.InvoiceNo, item.Trim()) & Builders<InvoiceProductItem>.Filter.Eq(u => u.PipelineSource, pipelineSource));

                if ("EMC".Equals(pipelineSource, StringComparison.InvariantCultureIgnoreCase) && deleteRollup)
                    _dataContext.RollupRequests.DeleteOne(Builders<RollupRequest>.Filter.ElemMatch(u => u.Details, i => i.InvoiceNo.ToUpper() == item.Trim().ToUpper()) & rollupFilter);
            }
        }
        #endregion

        /// <summary>
        /// This method unlocks InvoiceEnrichedRequest
        /// </summary>
        /// <param name="id"></param>
        [ExcludeFromCodeCoverage]
        private void UnlockInvoiceEnrichedRequest(string id)
        {
            var builder = Builders<InvoiceEnrichedRequest>.Filter;

            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.InvoiceEnrichedRequestsV2.UpdateOne(filter, Builders<InvoiceEnrichedRequest>.Update.Set(u => u.IsLocked, false));
        }
    }
}
