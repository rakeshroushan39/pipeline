﻿using AutoMapper;
using DFS.Banzai.Asset.Library.Entities;
using DFS.Banzai.Asset.Library.Interfaces;
using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Invoice.Library.Models.LeaseWave;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Buffers;
using System.Linq;
using System.Threading;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/Aura")]
	public class AuraInvoicesController : Controller
	{
		#region MemberVariables
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;
		private readonly IAssetDataContext _assetDataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
		private readonly IMapper _mapper;
        #endregion

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public AuraInvoicesController(IOptions<Library.Entities.Settings> settings, ILogger<AuraInvoicesController> logger,
			IMailService mailService, IDataContext mongoDataContext, 
			IAssetDataContext assetDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
			_dataContext = mongoDataContext;
			_assetDataContext = assetDataContext;
			_mapper = mapper;
		}

		/// <summary>
		/// This method gets combines Invoice and Asset detail and returns the resposne in Json.
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="invoiceNo"></param>
		/// <param name="vendorId"></param>
		/// <returns></returns>
		[Route("Invoice/PipelineSource/{pipelineSource}/Buid/{buid}/InvoiceNo/{invoiceNo}")]
		[Route("Invoice/PipelineSource/{pipelineSource}/Buid/{buid}/InvoiceNo/{invoiceNo}/VendorId/{vendorId}")]
		[HttpGet]
        #region GetAuraInvoice
        public IActionResult GetAuraInvoice(string pipelineSource, string buid, string invoiceNo, string vendorId = "")
		{
			var settings = new JsonSerializerSettings { Formatting = Formatting.Indented };
			OkObjectResult result;
			try
			{
				_logger.LogDebug($"Aura/GetAuraInvoice(PipelineSource/{pipelineSource}/Buid/{buid}/InvoiceNo/{invoiceNo}/VendorId/{vendorId})");

				var auraInvoiceResponseDto = GetInvoice(pipelineSource, buid, invoiceNo, vendorId);
				if (auraInvoiceResponseDto.Error != null)
				{
					result = Ok(auraInvoiceResponseDto);
					var mvcOptions = new MvcOptions() { SuppressOutputFormatterBuffering = false };
					result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, mvcOptions));
					return result;
				}

				var asset = GetClassafiAssetDetail(pipelineSource, buid, invoiceNo, vendorId);
				if (asset != null)
					auraInvoiceResponseDto = CombineInvoiceAndAsset(auraInvoiceResponseDto, asset);
				else
					auraInvoiceResponseDto = ConvertServiceTagsToArray(auraInvoiceResponseDto);

				result = Ok(auraInvoiceResponseDto);
				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError($"Aura/GetAuraInvoice({pipelineSource}, {buid}, {invoiceNo}, {vendorId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				var error = new ApiError()
				{
					Code = 500,
					State = "ERROR",
					Detail = $"Unhandled Exception : {ex.Message}"
				};

				result = Ok(new LeaseWaveInvoiceResponseDto() { Error = error });
				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

				return result;
			}
		}        

        /// <summary>
        /// This method searches InvoceEnrichedRequests based on invoiceNo, Buid, VendorId and PipelineSource filter
        /// </summary>
        /// <param name="pipelineSource"></param>
        /// <param name="buid"></param>
        /// <param name="invoiceNo"></param>
        /// <param name="vendorId"></param>
        /// <returns></returns>
        private LeaseWaveInvoiceResponseDto GetInvoice(string pipelineSource, string buid, string invoiceNo, string vendorId)
		{
			// Initialize LeaseWaveInvoiceRespose
			var leaseWaveInvoiceResponseDto = new LeaseWaveInvoiceResponseDto();
			leaseWaveInvoiceResponseDto.Error = null;

			// Validate input request
			var error = ValidateLeaseWaveInputRequest(pipelineSource, buid, invoiceNo);
			if (error != null)
			{
				leaseWaveInvoiceResponseDto.Error = error;
				return leaseWaveInvoiceResponseDto;
			}

			// GetInvoiceEnrichedRequest
			var invoiceEnrichedRequest = GetInvoiceEnrichedRequest(pipelineSource, buid, invoiceNo, vendorId);
			if (invoiceEnrichedRequest == null)
			{
				error = new ApiError()
				{
					Code = 404,
					State = "ERROR",
					Detail = $"Not Found : PipelineSource - {pipelineSource}, Buid - {buid}, InvoiceNo - {invoiceNo}, VendorId - {vendorId}"
				};

				leaseWaveInvoiceResponseDto.Error = error;
				return leaseWaveInvoiceResponseDto;
			}

			leaseWaveInvoiceResponseDto.Common = _mapper.Map<LeaseWaveCommonDto>(invoiceEnrichedRequest.Common);
			leaseWaveInvoiceResponseDto.Invoice = _mapper.Map<LeaseWaveInvoiceDto>(invoiceEnrichedRequest.InvoiceStage?.Invoices[0]);

			return leaseWaveInvoiceResponseDto;
		}

		/// <summary>
		/// This method validates the lease wave input request and returns a response if not valid
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="invoiceNo"></param>
		/// <returns></returns>
		private ApiError ValidateLeaseWaveInputRequest(string pipelineSource, string buid, string invoiceNo)
		{
			var errorDetail = new System.Text.StringBuilder();

			if (string.IsNullOrEmpty(pipelineSource))
				errorDetail.Append("PipelineSource is BLANK");

			if (string.IsNullOrEmpty(buid))
				errorDetail.Append("Buid is BLANK");

			if (string.IsNullOrEmpty(invoiceNo))
				errorDetail.Append("InvoiceNo is BLANK");

			if (!string.IsNullOrEmpty(errorDetail.ToString()))
			{
				var error = new ApiError()
				{
					Code = 400,
					State = "ERROR",
					Detail = "BadRequest: " + errorDetail.ToString()
				};

				return error;
			}
			else
				return null;
		}

		/// <summary>
		/// This method searches InvoiceEnrichedRequests collection based on InvoiceNo, Pipeline and Buid
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="vendorId"></param>
		/// <returns></returns>
		private InvoiceEnrichedRequest GetInvoiceEnrichedRequest(string pipelineSource, string buid, string invoiceNo, string vendorId = "")
		{
			var pipelineFilter = Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				pipelineFilter = pipelineFilter & Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);

            if(!string.IsNullOrEmpty(vendorId))
                pipelineFilter = pipelineFilter & Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, vendorId);

            var invoiceFilter = Builders<InvoiceEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo == invoiceNo);

			var filter = Builders<InvoiceEnrichedRequest>.Filter.And(invoiceFilter, pipelineFilter);

			var invoiceEnrichedRequest = _dataContext.InvoiceEnrichedRequestsV2.Find(filter)?.FirstOrDefault();

			if (invoiceEnrichedRequest != null)
			{
				// Invoice Product Items
				var builder = Builders<InvoiceProductItem>.Filter;
				var productItemfilter = builder.Eq(c => c.InvoiceNo, invoiceNo) &
					builder.Eq(u => u.PipelineSource, pipelineSource) &
					builder.Eq(u => u.SourceBusinessUnit, buid);

                invoiceEnrichedRequest.InvoiceStage.Invoices[0].InvoiceProductItem = _dataContext.InvoiceProductItems.Find(productItemfilter)?.FirstOrDefault();
			}

			return invoiceEnrichedRequest;
		}

		/// <summary>
		/// Gets ClassafiAssetDetails
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="vendorId"></param>
		/// <returns></returns>
		private dynamic GetClassafiAssetDetail(string pipelineSource, string buid, string invoiceNo, string vendorId = "")
		{			
			dynamic result = null;

			try
			{
				var builder = Builders<AssetEnrichedRequest>.Filter;
				var pipelineFilter = Builders<AssetEnrichedRequest>.Filter.Eq(u => u.PipelineSource, pipelineSource.Trim());
				var invoiceFilter = pipelineFilter & Builders<AssetEnrichedRequest>.Filter.Eq(u => u.InvoiceNo, invoiceNo.Trim());
				var buidFilter = invoiceFilter & Builders<AssetEnrichedRequest>.Filter.Eq(u => u.SourceBusinessUnit, buid.Trim());
				var filter = !string.IsNullOrEmpty(vendorId) ? buidFilter & builder.Eq(u => u.VendorID, vendorId.Trim()) : buidFilter;
				var assetEnrichedRequest = _assetDataContext.AssetEnrichedRequests.Find(filter)?.FirstOrDefault();

				//if (assetEnrichedRequest == null)
				//	return null;
				int retry = 0;

				while (assetEnrichedRequest == null)
				{
					retry++;

					Thread.Sleep(1000); //sleep for 1 seconds for 3 attempts

					assetEnrichedRequest = _assetDataContext.AssetEnrichedRequests.Find(filter)?.FirstOrDefault();

					if (retry >= 3)
						break;

				}

				if (assetEnrichedRequest == null)
					return null;

				retry = 0;
				while (assetEnrichedRequest?.ClassafiDetailResponse == null)
                {
					retry++;

					Thread.Sleep(1000); //sleep for 1 seconds for 3 attempts

					assetEnrichedRequest = _assetDataContext.AssetEnrichedRequests.Find(filter)?.FirstOrDefault();

					if (retry >= 3)
					{
						_logger.LogError($"Aura/GetClassafiAssetDetail({pipelineSource}, {buid}, {invoiceNo}, {vendorId}) - ClassafiDetailResponse After 3 attempts : {assetEnrichedRequest?.ClassafiDetailResponse.ToString()}");
						break;
					}
						
				}


				if (assetEnrichedRequest.ClassafiDetailResponse == null)
					return null;

				var jsonString = JsonConvert.SerializeObject(BsonTypeMapper.MapToDotNetValue(assetEnrichedRequest.ClassafiDetailResponse))?.ToString();

				result = JsonConvert.DeserializeObject(jsonString);
			}
			catch (Exception ex)
			{
				_logger.LogError($"ClassafiDetailResponse({pipelineSource},{invoiceNo},{buid},{vendorId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
			}

			return result;
		}

		/// <summary>
		/// This method combines invoice and asset
		/// </summary>
		/// <param name="leaseWaveInvoiceResponseDto"></param>
		/// <param name="assetResponse"></param>
		/// <returns></returns>
		private LeaseWaveInvoiceResponseDto CombineInvoiceAndAsset(LeaseWaveInvoiceResponseDto leaseWaveInvoiceResponseDto, JObject assetResponse)
		{
			if (assetResponse != null)
			{
				var assetHeader = new JObject(assetResponse);
				assetHeader.Remove("Assets");

				leaseWaveInvoiceResponseDto.Invoice.Classafi = assetHeader;

				if (leaseWaveInvoiceResponseDto?.Invoice?.InvoiceProductItem != null
					&& leaseWaveInvoiceResponseDto?.Invoice?.InvoiceProductItem?.InvoiceLines != null)
				{
					var assets = assetResponse["Assets"].Children();

					foreach (var invoiceLine in leaseWaveInvoiceResponseDto.Invoice.InvoiceProductItem.InvoiceLines)
					{
                        ProcessInvoiceAndAsset(assets, invoiceLine);
					}
				}
				return leaseWaveInvoiceResponseDto;
			}

			return leaseWaveInvoiceResponseDto;
		}

        /// <summary>
        /// This method processes invoiceline
        /// </summary>
        /// <param name="assets"></param>
        /// <param name="invoiceLine"></param>
        private void ProcessInvoiceAndAsset(JEnumerable<JToken> assets, LeaseWaveInvoiceLineDto invoiceLine)
        {
            var assetLine = (from asset in assets
                             where (asset["LineNumber"] != null && (int)asset["LineNumber"] == invoiceLine.LineNumber)
                             select asset)?.FirstOrDefault();

            if (assetLine != null)
            {
                if (!string.IsNullOrEmpty(invoiceLine.ServiceTags))
                    invoiceLine.serviceTags = invoiceLine.ServiceTags.Split(",");

                invoiceLine.Classafi = new JObject((JObject)assetLine);

                invoiceLine.Classafi.Remove("ProductDetails");

                var productDetails = assetLine["ProductDetails"].Children();

                foreach (var invoiceSubline in invoiceLine.InvoiceSubLines)
                {
                    var assetSubLine = (from prdDetail in productDetails
                                        where (prdDetail["LineNumber"] != null && (int)prdDetail["LineNumber"] == invoiceSubline.LineNumber)
                                        select prdDetail)?.FirstOrDefault();

                    if (assetSubLine != null)
                        invoiceSubline.Classafi = new JObject((JObject)assetSubLine);
                }
            }
        }

        /// <summary>
        /// This method convert servicetags to an array
        /// </summary>
        /// <param name="leaseWaveInvoiceResponseDto"></param>
        /// <returns></returns>
        private LeaseWaveInvoiceResponseDto ConvertServiceTagsToArray(LeaseWaveInvoiceResponseDto leaseWaveInvoiceResponseDto)
        {
            if (leaseWaveInvoiceResponseDto != null)
            {
                if (leaseWaveInvoiceResponseDto?.Invoice?.InvoiceProductItem != null
                    && leaseWaveInvoiceResponseDto?.Invoice?.InvoiceProductItem?.InvoiceLines != null)
                {
                    foreach (var invoiceLine in leaseWaveInvoiceResponseDto.Invoice.InvoiceProductItem.InvoiceLines)
                    {
                        if (!string.IsNullOrEmpty(invoiceLine.ServiceTags))
                            invoiceLine.serviceTags = invoiceLine.ServiceTags.Split(",");
                    }
                }
                return leaseWaveInvoiceResponseDto;
            }

            return leaseWaveInvoiceResponseDto;
        }
        #endregion
    }
}