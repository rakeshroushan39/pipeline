using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/Messages")]
    public class MessagesController : Controller
    {
	    private readonly ILogger _logger;
        private readonly IPublisher _rabbitMQueuePublisher;

        public MessagesController(ILogger<MessagesController> logger,
		    IDataContext dataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
        }

        /// <summary>
        /// This method gets invoice assets for given invoice numbers
        /// </summary>
        [Route("Publish/{queue}")]
        [HttpPost]
	    public IActionResult Publish(string queue, [FromBody] string message)
	    {
		    _logger.LogDebug($"Publish for queue {queue}- called");

		    try
		    {
				if (string.IsNullOrEmpty(queue))
				    ModelState.AddModelError("queue", "Invalid input");

			    if (!ModelState.IsValid)
				    return BadRequest(ModelState);

				_rabbitMQueuePublisher.Publish(message, queue);

			    return Ok(true);
		    }
		    catch (Exception ex)
		    {
			    _logger.LogError(ex, $"Publish for queue {queue} - EXCEPTION");

			    return StatusCode(500, "A problem happened while handling your request.");
		    }
	    }		

        /// <summary>
        /// This method gets invoice assets for given invoice numbers.
        /// </summary>
        /// <param name="queue"></param>
        /// <param name="chunkSize"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        [Route("Publish/{queue}/{chunkSize}")]
        [HttpPost]
        #region Publish by Chunk
        public IActionResult Publish(string queue, int chunkSize, [FromBody] string message)
        {
            try
            {
                if (string.IsNullOrEmpty(queue))
                    ModelState.AddModelError("queue", "Invalid input");

                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                if (chunkSize > 0)
                    ProcessChunkAndPublish(message, chunkSize, queue);
                else
                    _rabbitMQueuePublisher.Publish(message, queue);

                return Ok(true);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "A problem happened while handling your request.");
            }
        }

        /// <summary>
        /// This method processes message in chunks and publish the message
        /// </summary>
        /// <param name="message"></param>
        /// <param name="chunkSize"></param>
        /// <param name="queue"></param>
        private void ProcessChunkAndPublish(string message, int chunkSize, string queue)
        {
            var inputParams = message.Split("|");
            var additionalParams = new System.Text.StringBuilder();

            for (int i = 0; i < inputParams.Count(); i++)
            {
                if (i < 2)
                    continue;

                additionalParams.Append($"{inputParams[i]}|");
            }

            if (additionalParams.Length > 1)
                additionalParams.Remove(additionalParams.Length - 1, 1);

            var chunks = Chunk(inputParams[1].Split(","), chunkSize);

            if (chunks != null && chunks.Any())
                foreach (var chunk in chunks)
                    _rabbitMQueuePublisher.Publish($"{inputParams[0]}|{string.Join(",", chunk)}|{additionalParams?.ToString()}", queue);
        }

        /// <summary>
        /// This method chunks given list into sublists
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="chunkSize"></param>
        /// <returns></returns>
        public static IEnumerable<T[]> Chunk<T>(IEnumerable<T> source, int chunkSize)
        {
            var list = source as IList<T> ?? source.ToList();
            for (int start = 0; start < list.Count; start += chunkSize)
            {
                T[] chunk = new T[Math.Min(chunkSize, list.Count - start)];
                for (int i = 0; i < chunk.Length; i++)
                    chunk[i] = list[start + i];

                yield return chunk;
            }
        }
        #endregion
    }
}