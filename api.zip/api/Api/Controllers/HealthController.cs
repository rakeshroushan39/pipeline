using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Globalization;

namespace DFS.Banzai.Api.Controllers
{
    [Route("HealthCheck")]
    public class HealthController : Controller
    {
	    private readonly ILogger _logger;

        public HealthController(ILogger<HealthController> logger)
        {
            _logger = logger;
	    }

	    [HttpGet]
	    public IActionResult HealthCheck() {
		    try {
			    var resp = new { ping = DateTime.UtcNow.ToString(CultureInfo.InvariantCulture) };
			    
			    _logger.LogDebug("HEALTH CHECK: /ping");

			    return Ok(resp);
			}
		    catch (Exception ex) {
			    _logger.LogError($"HEALTH CHECK: / ping - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
		    }
	    }
	}
}