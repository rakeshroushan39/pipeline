using AutoMapper;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.FinanceCombos;
using DFS.Banzai.Library.Queries;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/FinanceCombos")]
	public class FinanceCombosController : Controller {
		private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
		private readonly IMapper _mapper;

		public FinanceCombosController(ILogger<FinanceCombosController> logger,
			IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _dataContext = mongoDataContext;
			_logger = logger;

			_mapper = mapper;
		}

        [HttpGet]
        public IActionResult GetAll()
        {
            _logger.LogDebug(LoggingEvents.GetItem, "GetAll items.");

            try
            {
                var items = _dataContext.FinanceCombos.GetAll();

                if (items == null || !items.Any())
                {
                    _logger.LogWarning(LoggingEvents.GetItemNotFound, "GetAll() - NOT FOUND");
                    return NotFound();
                }

                var result = _mapper.Map<IEnumerable<FinanceComboDto>>(items);

                return Ok(result); //Rap result with Ok (200) status code
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetAll() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, "A problem happened while handling your request.");
            }
        }

        /// <summary>
        /// Get FinanceCombo for a particular pipelineSource
        /// </summary>
        /// <param name="pipelineSource"></param>
        /// <returns></returns>
        [HttpGet("GetFinanceCombos/{pipelineSource}")]
        public IActionResult GetFinanceCombos(string pipelineSource) {
			_logger.LogDebug(LoggingEvents.GetItem, "GetAll items for a particular pipelineSource.");

			try {
              
                var items = _dataContext.FinanceCombos.Find(FinanceCombosQuery.ProductSpacesFilter(pipelineSource));
                if (items == null || !items.Any()) {
					_logger.LogWarning(LoggingEvents.GetItemNotFound, "GetAll() - NOT FOUND");
					return NotFound();
				}

				var result = _mapper.Map<IEnumerable<FinanceComboDto>>(items);
                result = result.Where(x => x.Active);
				return Ok(result); //Rap result with Ok (200) status code
			}
			catch (Exception ex) {
				_logger.LogError($"GetAll() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        [HttpGet("GetProductSpaces/{pipelineSource}")]
        public IActionResult GetProductSpaces(string pipelineSource)
        {
            _logger.LogDebug("GetProductSpaces", pipelineSource);

            try
            {
                ProjectionDefinition<FinanceCombo> projection = Builders<FinanceCombo>.Projection.Include(q => q.DFSProductSpace);
                var productSpaces = _dataContext.FinanceCombos.Find(FinanceCombosQuery.ProductSpacesFilter(pipelineSource), projection)?.ToList()?.Distinct();
                
                if (productSpaces == null || !productSpaces.Any())
                {
                    _logger.LogWarning("GetProductSpaces() - NOT FOUND");
                    return NotFound();
                }

                var resultSet = (from prdspc in productSpaces select prdspc.GetValue(1).ToString())?.Distinct(); 

                _logger.LogDebug("GetProductSpaces return", resultSet);

                return Ok(resultSet); //Rap result with Ok (200) status code
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetProductSpaces() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
            }
        }

        //Name = "GetById" is used by subsequenct controllers to generate URI for a given object ID.
        [HttpGet("{id:length(24)}", Name = "GetFinanceComboById")]
		public IActionResult GetById(string id) {
			_logger.LogDebug(LoggingEvents.GetItem, $"GetById({id}) items.");

			try {
				var item = _dataContext.FinanceCombos.GetById(id);

				if (item == null) {
					_logger.LogWarning(LoggingEvents.GetItemNotFound, $"GetById({id}) - NOT FOUND");

					return NotFound();
				}

				var result = _mapper.Map<FinanceComboDto>(item);

				return Ok(result);
			}
			catch (Exception ex) {
				_logger.LogError($"GetById({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

		[HttpPost]
		public IActionResult Create([FromBody] FinanceComboForCreationDto item) {
			_logger.LogDebug(LoggingEvents.GetItem, "Create() items.");

			try {
				if (!ModelState.IsValid) {
					return BadRequest(ModelState);
				}

				var finalFinanceCombo = _mapper.Map<FinanceCombo>(item);

				finalFinanceCombo.LastModifiedOn = DateTime.UtcNow;

				_dataContext.FinanceCombos.InsertOne(finalFinanceCombo);

				var createdFinanceComboToReturn = _mapper.Map<FinanceComboForCreationDto>(finalFinanceCombo);
                
				return CreatedAtRoute("GetFinanceComboById", new { id = finalFinanceCombo.Id }, createdFinanceComboToReturn);
			}
			catch (Exception ex) {
				_logger.LogError($"Create() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

		[HttpPut("{id:length(24)}")]
		public IActionResult Replace(string id, [FromBody] FinanceComboForUpdateDto item) {
			_logger.LogDebug(LoggingEvents.GetItem, $"Replace({id}) items.");

			try {
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var finalItem = _mapper.Map<FinanceCombo>(item);

				finalItem.Id = id;
				finalItem.LastModifiedOn = DateTime.UtcNow;

				return Update(finalItem) ? NoContent() : (IActionResult)NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"Replace({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

		[HttpDelete("{id:length(24)}")]
		public IActionResult Delete(string id) {
			_logger.LogDebug(LoggingEvents.GetItem, $"Delete({id}) items.");

			try {
				if (_dataContext.FinanceCombos.Remove(id)) 
					return NoContent(); 

				_logger.LogWarning(LoggingEvents.GetItemNotFound, $"Delete({id}) - NOT FOUND");
				return NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"Delete({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

		#region Private methods
		private bool Update(FinanceCombo item) {
			FilterDefinition<FinanceCombo> query = Builders<FinanceCombo>.Filter.Eq(e => e.Id, item.Id);
			return _dataContext.FinanceCombos.ReplaceOneAsync(query, item);
		}
		#endregion
	}
}