using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/OrderStatus/Missing")]
    public class OrderStatusController : Controller
    {
        private readonly ILogger _logger;       
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public OrderStatusController(IOptions<Settings> settings, ILogger<OrderStatusController> logger,
            IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _dataContext = mongoDataContext;
        }

		/// <summary>
		/// This method searches for all missing Order Status Notifications in 
		/// the OciNotifications collection and returns a distinct list of
		/// unique order numbers sorted by created date asc
		/// </summary>
		/// <returns></returns>		
		[HttpGet]
		public IActionResult GetMissingOrderStatus() {
			_logger.LogDebug("GetMissingOrderStatus items.");

			try {
				var builder = Builders<MissingOciNotification>.Filter;
				var filter = builder.Or(builder.Ne(u => u.SourceOrigin, "DOMS"), builder.Ne(u => u.SourcePaymentTerms, "DFS Loan"));
				var projection = Builders<MissingOciNotification>.Projection
								.Include("OrderNo")
								.Include("SourceOrigin")
								.Include("SourcePaymentTerms")
								.Include("CreateDateTime")
								.Include("DPID")
								.Exclude("_id");
				
				var missingOrderStatus = _dataContext.MissingOciNotifications.Find(filter, projection)?.ToList();

				if (missingOrderStatus == null || !missingOrderStatus.Any()) {
					_logger.LogWarning("GetMissingOrderStatus() - NOT FOUND");
					return NotFound();
				}

				var missingOrderStatusList = new List<OciNotificationDto>();

				foreach (var obj in missingOrderStatus)
					missingOrderStatusList.Add(BsonSerializer.Deserialize<OciNotificationDto>(obj));

				return Ok(missingOrderStatusList.GroupBy(x => x.OrderNo).Select(x => x.FirstOrDefault()));
			}
			catch (Exception ex) {
				_logger.LogError($"GetMissingOrderStatus() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, ex.Message);
			}
		}

		/// <summary>
		/// This method deletes order statuses from OciNotifications collection for given search criteria
		/// </summary>
		/// <param name="sourceOrigin"></param>
		/// <param name="sourcePaymentTerms"></param>
		/// <returns></returns>
		[Route("{sourceOrigin}/{sourcePaymentTerms}")]
		[HttpDelete]
		public IActionResult DeleteMissingOrderStatus(string sourceOrigin, string sourcePaymentTerms) {
			_logger.LogDebug($"Delete orders from OCI Notifications.");

			try {
				var builder = Builders<MissingOciNotification>.Filter;
				var filter = builder.Eq(u => u.SourceOrigin, sourceOrigin) & builder.Eq(u => u.SourcePaymentTerms, sourcePaymentTerms);
				_dataContext.MissingOciNotifications.DeleteManyAsync(filter);
				return Ok(); 
			}
			catch (Exception ex) {
				_logger.LogError($"Delete orders from OCI Notifications- EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}
	}
}