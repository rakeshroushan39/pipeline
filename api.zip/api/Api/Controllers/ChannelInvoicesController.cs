﻿using AutoMapper;
using DFS.Banzai.Api;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.ChannelInvoiceUpload;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Linq;

namespace Api.Controllers
{
    [Route("api/Channel")]
    public class ChannelInvoicesController : Controller
    {  
        private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly IMapper _mapper;

        public ChannelInvoicesController(ILogger<ChannelInvoicesController> logger,
            IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _dataContext = mongoDataContext;
            _logger = logger;
            _mapper = mapper;
        }

        /// <summary>
        /// Get the CurrencyCode and CurrencyName from Currency Collection
        /// </summary>
        /// <returns></returns>
        [Route("Invoice/Currency")]
        [HttpGet]
        public IActionResult GetCurrency()
        {
            _logger.LogDebug("Currency details.");

            try
            {   
                var items = _dataContext.Currency.GetAll();
                if (items == null || !items.Any())
                {
                    _logger.LogWarning("Currency() - NOT FOUND");
                    return NotFound();
                }

                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Currency() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// Get the Country Region details from CountryRegion Collection
        /// </summary>
        /// <returns></returns>
        [Route("Invoice/CountryRegions")]
        [HttpGet]
        public IActionResult GetCountryRegion()
        {
            _logger.LogDebug("CountryRegion details.");

            try
            {
                var items = _dataContext.CountryRegion.GetAll();               
                if (items == null || !items.Any())
                {
                    _logger.LogWarning("CountryRegion() - NOT FOUND");
                    return NotFound();
                }

                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger.LogError($"CountryRegion() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        //  This gets channel invoice request based on id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("Invoice/Id/{id}")]
        [HttpGet]
        public IActionResult GetChannelInvoiceById(string id)
        {
            _logger.LogDebug(LoggingEvents.GetItem, $"GetChannelInvoiceById({id}) items.");

            try
            {
                var item = _dataContext.InvoiceRequests.GetById(id);

                if (item == null)
                {
                    _logger.LogWarning(LoggingEvents.GetItemNotFound, $"GetChannelInvoiceById({id}) - NOT FOUND");

                    return NotFound();
                }

                var result = _mapper.Map<ChannelInvoiceUploadDto>(item);

                return Ok(result);                
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetChannelInvoiceById({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, "A problem happened while handling your request.");
            }
        }

        /// <summary>
        /// Creates ChannelInvoice request
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        [Route("Invoice")]
        [HttpPost]
        public IActionResult CreateInvoice([FromBody] ChannelInvoiceUploadDto item)
        {
            _logger.LogDebug(LoggingEvents.GetItem, "CreateInvoice() items.");

            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                
                var invoiceRequest = _mapper.Map<InvoiceRequest>(item);
                invoiceRequest.TimeStamp = DateTime.UtcNow;
                invoiceRequest.Id = ObjectId.GenerateNewId().ToString();

                _dataContext.InvoiceRequests.InsertOne(invoiceRequest);

                _rabbitMQueuePublisher.Publish(invoiceRequest.Id, "q.banzai.invoice.channel.enrichment");

                return StatusCode(200, "Successfully Saved");
            }
            catch (Exception ex)
            {
                _logger.LogError($"CreateInvoice() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, "A problem happened while handling your request.");
            }
        }
    }
}