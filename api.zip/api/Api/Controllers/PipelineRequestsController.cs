using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Linq;
using System.Xml;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/PipelineRequests")]
    public class PipelineRequestsController : Controller
    {
	    private readonly ILogger _logger;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly IDataContext _dataContext;

        public PipelineRequestsController(ILogger<PipelineRequestsController> logger, IDataContext dataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _dataContext = dataContext;
        }

        /// <summary>
        /// This method returns pipeline messages from PipelineRequests
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Content xml from collection</returns>
        [Route("{id:length(24)}")]
        [HttpGet]
        #region GetPipelineRequest
        public IActionResult GetPipelineRequest(string id)
        {
            _logger.LogDebug(LoggingEvents.GetItem, $"GetPipelineRequest({id})");

            try
            {
                var builder = Builders<PipelineRequest>.Filter;
                var filter = builder.Eq(u => u.Id, id);
                return Ok(_dataContext.PipelineRequests.Find(filter)?.FirstOrDefault()?.Content ?? string.Empty);
            }
            catch (XmlException e)
            {
                _logger.LogError($"GetPipelineRequest({id}) - EXCEPTION. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return NotFound();
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetPipelineRequest({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, ex.Message ?? "Internal Server Error");
            }
        }
        #endregion

        /// <summary>
        /// This method returns Invoice Notification details messages from PipelineInvoiceInboundNotifications Collection
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Content xml from collection</returns>
        [Route("InvoiceInboundNotifications/{id:length(24)}")]
        [HttpGet]
        #region GetPipelineInvoiceInboundNotifications
        public IActionResult GetPipelineInvoiceInboundNotifications(string id)
        {
            _logger.LogDebug(LoggingEvents.GetItem, $"GetPipelineInvoiceInboundNotifications({id}) items.");

            try
            {
                var idFilter = Builders<PipelineInvoiceInboundNotification>.Filter.Eq(u => u.Id, id);
                return Ok(_dataContext.PipelineInvoiceInboundNotifications.Find(idFilter)?.FirstOrDefault());
            }
            catch (XmlException e)
            {
                _logger.LogError($"GetPipelineInvoiceInboundNotifications({id}) - EXCEPTION. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return NotFound();
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetPipelineInvoiceInboundNotifications({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, ex.Message ?? "Internal Server Error");
            }
        }
        #endregion

        /// <summary>
        /// This method posts search criteria for reprocessing pipelineRequests collection
        /// </summary>
        [Route("Reprocess/{pipelineSource}/{transactionType}/{messageType}")]
		[HttpPost]
		public IActionResult ProcessPipelineRequests(string pipelineSource, string transactionType, string messageType) {
			_logger.LogDebug("ProcessPipelineRequests started");

			try {
                _rabbitMQueuePublisher.Publish($"{pipelineSource}|{transactionType}|{messageType}", "q.banzai.pipeline.rollup.requests");
				return Ok();
			}
			catch (Exception ex) {
				_logger.LogError($"ProcessPipelineRequests - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        /// <summary>
		/// This method returns Invoice messages Id from PipelineAuraInvoiceRequests
		/// </summary>
		/// <param name = "id" ></ param >
		/// < returns > Content Json from collection</returns>
		[Route("AuraInvoiceRequest/{id:length(24)}")]
		[HttpGet]
		#region GetAuraInvoiceRequests
		public IActionResult GetAuraInvoiceRequest(string id)
		{
			_logger.LogDebug(LoggingEvents.GetItem, $"GetAuraInvoiceRequest({id}) items.");

			try
			{
				var idFilter = Builders<PipelineAuraInvoiceRequestDto>.Filter.Eq(u => u.Id, id);
				return Ok(_dataContext.PipelineAuraInvoiceRequests.Find(idFilter)?.FirstOrDefault()?.Message ?? string.Empty);
			}
			catch (XmlException e)
			{
				_logger.LogError($"GetAuraInvoiceRequest({id}) - EXCEPTION. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return NotFound();
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetAuraInvoiceRequest({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, ex.Message ?? "Internal Server Error");
			}
		}
		#endregion

		/// <summary>
		/// This method returns Invoice messages Id from PipelineLeaseWaveContractRequests
		/// </summary>
		/// <param name = "id" ></ param >
		/// < returns > Content JSon from collection</returns>
		[Route("LeaseWaveContractRequest/{id:length(24)}")]
		[HttpGet]
		#region GetContractNotifications
		public IActionResult GetLeaseWaveContractRequest(string id)
		{
			_logger.LogDebug(LoggingEvents.GetItem, $"GetLeaseWaveContractRequest({id}) items.");

			try
			{
				var idFilter = Builders<PipelineLeaseWaveContractRequestDto>.Filter.Eq(u => u.Id, id);
				return Ok(_dataContext.PipelineLeaseWaveContractRequests.Find(idFilter)?.FirstOrDefault()?.Message ?? string.Empty);
			}
			catch (XmlException e)
			{
				_logger.LogError($"GetLeaseWaveContractRequest({id}) - EXCEPTION. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return NotFound();
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetLeaseWaveContractRequest({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, ex.Message ?? "Internal Server Error");
			}
		}
		#endregion
    }
}