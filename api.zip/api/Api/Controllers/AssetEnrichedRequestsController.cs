﻿using DFS.Banzai.Asset.Library.Entities;
using DFS.Banzai.Asset.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/AssetEnrichedRequests")]
    public class AssetEnrichedRequestsController : Controller
    {
        #region Member Variables
        private readonly ILogger _logger;
        private readonly IAssetDataContext _dataContext;
        private readonly List<string> _pipelineSourceList = new List<string>() { "DELL", "EMC", "CHANNEL" };
        private readonly IPublisher _rabbitMQueuePublisher;
        #endregion    

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public AssetEnrichedRequestsController(IOptions<Settings> settings, ILogger<AssetRequestsController> logger,
            IAssetMailService mailService, IAssetDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _dataContext = mongoDataContext;            
        }

        /// <summary>
        /// This method method searches AssetEnrichedRequests collection to retreive a ClassafiDetailResponse based on pipelineSource, invoiceNo, buid and vendorId.
        /// Have to enable security. 
        /// </summary>
        /// <param name="pipelineSource"></param>
        /// <param name="invoiceNo"></param>
        /// <param name="buid"></param>
        /// <param name="vendorId"></param>
        /// <returns></returns>
        [Route("ClassafiDetailResponse/{pipelineSource}/{invoiceNo}/{buid}")]
        [Route("ClassafiDetailResponse/{pipelineSource}/{invoiceNo}/{buid}/{vendorId}")]
        [HttpGet]
        #region ClassafiDetailResponse
        public IActionResult ClassafiDetailResponse(string pipelineSource, string invoiceNo, string buid, string vendorId = "")
        {
            _logger.LogDebug($"ClassafiDetailResponse({pipelineSource},{invoiceNo},{buid},{vendorId})");

            try
            {
                if (!_pipelineSourceList.Contains(pipelineSource, StringComparer.InvariantCultureIgnoreCase))
                    ModelState.AddModelError("pipelineSource", "Invalid Pipeline Source.");

                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var builder = Builders<AssetEnrichedRequest>.Filter;
                var pipelineFilter = Builders<AssetEnrichedRequest>.Filter.Eq(u => u.PipelineSource, pipelineSource.Trim());
                var invoiceFilter = pipelineFilter & Builders<AssetEnrichedRequest>.Filter.Eq(u => u.InvoiceNo, invoiceNo.Trim());
                var buidFilter = invoiceFilter & Builders<AssetEnrichedRequest>.Filter.Eq(u => u.SourceBusinessUnit, buid.Trim());
                var filter = !string.IsNullOrEmpty(vendorId) ? buidFilter & builder.Eq(u => u.VendorID, vendorId.Trim()) : buidFilter;
                var assetEnrichedRequest = _dataContext.AssetEnrichedRequests.Find(filter)?.FirstOrDefault();

                if (assetEnrichedRequest == null)
                    return null;

                if (assetEnrichedRequest.ClassafiDetailResponse != null)
                {
                    string jsonString = JsonConvert.SerializeObject(BsonTypeMapper.MapToDotNetValue(assetEnrichedRequest.ClassafiDetailResponse))?.ToString();
                    return Ok(JsonConvert.DeserializeObject(jsonString));
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"ClassafiDetailResponse({pipelineSource},{invoiceNo},{buid},{vendorId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }
        #endregion
    }
}
