using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/GAAPAttributes")]
	public class GaapAttributesController : Controller {
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public GaapAttributesController(IOptions<Settings> settings, ILogger<GaapAttributesController> logger,
            IMailService mailService, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _logger = logger;
            _dataContext = mongoDataContext;
        }

		/// <summary>
		/// This method searches GAAPAttributes collection to retreive a document based on pipelinesoure, buid and invoiceno.
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="invoiceNo"></param>
		/// <returns></returns>
		[Route("{pipelineSource}/{buid}/{invoiceNo}")]
        [HttpGet]
		#region GetGAAPAttributes
		public IActionResult GetGAAPAttributes(string pipelineSource, string buid, string invoiceNo) {
			_logger.LogDebug($"GetGAAPAttributes({pipelineSource},{buid},{invoiceNo})");

			try {

				if (string.IsNullOrEmpty(pipelineSource)) {
					ModelState.AddModelError("pipelineSource", "Invalid PipelineSource.");
					return BadRequest(ModelState);
				}
				else if (string.IsNullOrEmpty(buid)) {
					ModelState.AddModelError("buid", "Invalid BUID.");
					return BadRequest(ModelState);
				}
				else if (string.IsNullOrEmpty(invoiceNo)) {
					ModelState.AddModelError("invoiceNo", "Invalid InvoiceNo.");
					return BadRequest(ModelState);
				}

				var builder = Builders<GAAPAttributes>.Filter;
				var gaapAttributesFilter = builder.Eq(u => u.InvoiceNo, invoiceNo) & builder.Eq(u => u.SourceBusinessUnit, buid) & builder.Eq(u => u.PipelineSource, pipelineSource);

				var result = _dataContext.GAAPAttributes.Find(gaapAttributesFilter)?.FirstOrDefault();

				if (result == null) {
					_logger.LogDebug($"GetGAAPAttributes({pipelineSource},{buid},{invoiceNo}) - Not Found");

					return NotFound();
				}

				return Ok(result);
			}
			catch (Exception ex) {
				_logger.LogError($"GetGAAPAttributes({pipelineSource},{buid},{invoiceNo}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}
        #endregion

        /// <summary>
        /// This method unlocks a given document based on collection name and document id
        /// </summary>
        /// <param name="documentID"></param>
        /// <returns></returns>
        [Route("UnlockDocument/{documentID}")]
        [HttpPost]
        public IActionResult UnlockDocument(string documentID)
        {
            try
            {
                UnlockGAAPAttributesDocument(documentID);

                return Ok(true);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// This method removes lock on GAAPAttributesDocument for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockGAAPAttributesDocument(string id)
        {
            var builder = Builders<GAAPAttributes>.Filter;

            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.GAAPAttributes.UpdateOne(filter, Builders<GAAPAttributes>.Update.Set(u => u.IsLocked, false));
        }
    }
}