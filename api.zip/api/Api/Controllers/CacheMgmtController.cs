using DFS.Banzai.Library;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/CacheMgmt")]
	public class CacheMgmtController : Controller {
		private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;

        public CacheMgmtController(ILogger<CacheMgmtController> logger, IDataContext dataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
            _dataContext = dataContext;
        }

        [Route("VerifyEnrichKey")]
        [HttpGet]
		public IActionResult VerifyEnrichKey(string id) {
			_logger.LogDebug($"VerifyEnrichKey({id})");

			try {
				var key = $"{CacheKeys.EnrichFailureTracker}{id}";
                var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
                if (_dataContext.IgnoreRetry.Find(filter)?.Count() > 0)
                    return NoContent();

                _logger.LogWarning($"VerifyEnrichKey({id}) - NOT FOUND");

				return NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"VerifyEnrichKey({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}		

		[Route("IgnoreEnrichMessage")]
        [HttpPost]
		public IActionResult IgnoreEnrichMessage(string id) {
			_logger.LogDebug($"IgnoreEnrichMessage{id}");

			try {
				var key = $"{CacheKeys.EnrichFailureTracker}{id}";
                _dataContext.IgnoreRetry.InsertOne(new IgnoreRetry() { Guid = key });
				return NoContent();
			}
			catch (Exception ex) {
				_logger.LogError($"IgnoreEnrichMessage{id} - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		[Route("VerifyBIReportingKey")]
        [HttpGet]
		public IActionResult VerifyBIReportingKey(string id) {
			_logger.LogDebug($"VerifyBIReportingKey({id})");

			try {
				var key = $"{CacheKeys.BIFailureTracker}{id}";

                var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
                if (_dataContext.IgnoreRetry.Find(filter)?.Count() > 0)
                    return Ok();

				_logger.LogWarning($"VerifyBIReportingKey({id}) - NOT FOUND");

				return NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"VerifyBIReportingKey({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		[Route("IgnoreBIMessage")]
        [HttpPost]
		public IActionResult IgnoreBIMessage(string id) {
			_logger.LogDebug($"IgnoreBIMessage{id}");

			try {
				var key = $"{CacheKeys.BIFailureTracker}{id}";
                _dataContext.IgnoreRetry.InsertOne(new IgnoreRetry() { Guid = key });

                return NoContent();
			}
			catch (Exception ex) {
				_logger.LogError($"IgnoreBIMessage{id} - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		[Route("VerifyExceptionKey")]
		[HttpGet]
		public IActionResult VerifyExceptionKey(string id)
		{
			_logger.LogDebug($"VerifyExceptionKey({id})");

			try
			{
				var key = $"{id}";

				var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
				if (_dataContext.IgnoreRetry.Find(filter)?.Count() > 0)
					return Ok();

				_logger.LogWarning($"VerifyExceptionKey({id}) - NOT FOUND");

				return NotFound();
			}
			catch (Exception ex)
			{
				_logger.LogError($"VerifyExceptionKey({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		[Route("IgnoreException")]
		[HttpPost]
		public IActionResult IgnoreException(string id)
		{
			_logger.LogDebug($"IgnoreException{id}");

			try
			{
				var key = $"{id}";
				_dataContext.IgnoreRetry.InsertOne(new IgnoreRetry() { Guid = key });

				return NoContent();
			}
			catch (Exception ex)
			{
				_logger.LogError($"IgnoreException{id} - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}
	}
}