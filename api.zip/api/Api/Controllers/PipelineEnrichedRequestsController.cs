using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library;
using DFS.Banzai.Library.Aura.Models;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Library.Queries;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/PipelineEnrichedRequests")]
	public class PipelineEnrichedRequestsController : Controller
	{
		#region Member Variables
		private readonly ILogger _logger;
		private readonly Settings _settings;
		private StatusCombo _banzaiStatus;
		private readonly IDataContext _dataContext;
		private const string STATUS_UPDATE_UI = "Update Banzai Status UI";
		private const string STATUS_OVERRIDE_UI = "Override Banzai Status UI";
		private const string VOR = "VOR";
		private const string ORDER = "ORDER";
		private const string INVOICE = "INVOICE";
		private const string STATUS_OVERRIDE = "STATUSOVERRIDE";
		private readonly IPublisher _rabbitMQueuePublisher;
		#endregion

		/// <summary>
		/// Parameter constructor to initialize default objects
		/// </summary>
		public PipelineEnrichedRequestsController(IOptions<Settings> settings, ILogger<PipelineEnrichedRequestsController> logger,
			IMailService mailService, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
		{
			_rabbitMQueuePublisher = rabbitMQueuePublisher;
			_logger = logger;
			_settings = settings.Value;
			_dataContext = mongoDataContext;
		}
		/// <summary>
		/// This method searches PipelineEnrichedRequests collection to retreive a document based on pipelinesoure, documenttype, id, buid, vendorid.
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="docType"></param>
		/// <param name="id"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		[Route("{pipelineSource}/{docType}/{id}")]
		[Route("{pipelineSource}/{docType}/{id}/{buid}")]
		[Route("{pipelineSource}/{docType}/{id}/{buid}/{vendorid}")]
		[HttpGet]
		#region GetPipelineEnrichedRequest
		public IActionResult GetPipelineEnrichedRequest(string pipelineSource, string docType, string id, string buid = "", string vendorid = "")
		{
			_logger.LogDebug($"GetPipelineEnrichedRequest({pipelineSource},{docType},{id})");

			try
			{
				PipelineEnrichedRequest result;

				if (VOR.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByDpid(id, pipelineSource, buid, vendorid);
				else if (ORDER.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByOrderNo(id, pipelineSource, buid, vendorid);
				else if (INVOICE.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByInvoiceNo(id, pipelineSource, buid, vendorid);
				else
				{
					ModelState.AddModelError("docType", "Invalid Document Type.");
					return BadRequest(ModelState);
				}

				if (result == null && !INVOICE.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
				{
					_logger.LogWarning($"GetPipelineEnrichedRequest({pipelineSource},{docType},{id},{buid}) - NOT FOUND");
					return NotFound();
				}

				result = ApplyInvoiceDetailFromInvoiceDomain(result, id, pipelineSource, buid, vendorid);

				if (result == null)
				{
					_logger.LogWarning($"GetInvoiceEnrichedDocument for Invoice ({pipelineSource},{docType},{id},{buid}) - NOT FOUND");
					return NotFound();
				}

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetPipelineEnrichedRequest({pipelineSource},{docType},{id},{buid}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method searches PipelineEnrichedRequests collection based on VORID , Pipeline and buid
		/// </summary>
		/// <param name="vorID"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest SearchPipelineEnrichedRequestByDpid(string vorID, string pipelineSource, string buid = "", string vendorid = "")
		{
			var dpidFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.VorID, vorID);
			var pipelineFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);

			if (!string.IsNullOrEmpty(vendorid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, vendorid);

			var filter = Builders<PipelineEnrichedRequest>.Filter.And(dpidFilter, pipelineFilter);
			return _dataContext.PipelineEnrichedRequestsV2.Find(filter)?.FirstOrDefault();
		}

		/// <summary>
		/// This method searches PipelineEnrichedRequests collection based on OrderNumber, Pipeline and buid
		/// </summary>
		/// <param name="orderNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest SearchPipelineEnrichedRequestByOrderNo(string orderNo, string pipelineSource, string buid = "", string vendorid = "")
		{
			var pipelineFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);
			if (!string.IsNullOrEmpty(vendorid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, vendorid);

			var orderFilter = Builders<PipelineEnrichedRequest>.Filter.ElemMatch(x => x.OrderStage.Orders, c => c.OrderNo == orderNo);
			var filter = Builders<PipelineEnrichedRequest>.Filter.And(orderFilter, pipelineFilter);
			return _dataContext.PipelineEnrichedRequestsV2.Find(filter)?.FirstOrDefault();
		}

		/// <summary>
		/// This method searches PipelineEnrichedRequests collection based on InvoiceNo, Pipeline, buid and vendorId
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest SearchPipelineEnrichedRequestByInvoiceNo(string invoiceNo, string pipelineSource, string buid = "", string vendorid = "")
		{
			var pipelineFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);
			if (!string.IsNullOrEmpty(vendorid))
				pipelineFilter = pipelineFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, vendorid);

			var invoiceFilter = Builders<PipelineEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo == invoiceNo);
			var filter = Builders<PipelineEnrichedRequest>.Filter.And(invoiceFilter, pipelineFilter);

			return _dataContext.PipelineEnrichedRequestsV2.Find(filter)?.FirstOrDefault();
		}

		/// <summary>
		/// This method calls invoice domain to retreive invoice details
		/// </summary>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest ApplyInvoiceDetailFromInvoiceDomain(PipelineEnrichedRequest pipelineEnrichedRequest, string invoiceNo, string pipelineSource, string buid = "", string vendorid = "")
		{
			if (pipelineEnrichedRequest?.InvoiceStage?.Invoices != null && pipelineEnrichedRequest?.Common != null)
			{
				ApplyInvoiceDetail(ref pipelineEnrichedRequest, pipelineSource, buid, vendorid);
				return pipelineEnrichedRequest;
			}
			else
				return GetInvoiceEnrichedRequestFromBanzaiInvoice(pipelineEnrichedRequest, invoiceNo, pipelineSource, buid, vendorid) ?? pipelineEnrichedRequest;
		}

		/// <summary>
		/// This method applies invoice details for a given invoice
		/// </summary>
		/// <param name="pipelineInvoice"></param>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <param name="vendorid"></param>
		private void ApplyInvoiceDetail(ref PipelineEnrichedRequest pipelineEnrichedRequest,
			string pipelineSource, string buid, string vendorid)
		{
			foreach (Pipeline.Library.Entities.Invoice pipelineInvoice in pipelineEnrichedRequest.InvoiceStage.Invoices)
			{
				var invoicePipelineEnrichedRequest = GetInvoiceEnrichedRequestFromBanzaiInvoice(pipelineEnrichedRequest, pipelineInvoice.InvoiceNo, pipelineSource, buid, vendorid);

				if (invoicePipelineEnrichedRequest != null)
				{
					var banzaiInvoice = (from inv in invoicePipelineEnrichedRequest?.InvoiceStage?.Invoices
										 where inv.InvoiceNo == pipelineInvoice.InvoiceNo
										 select inv)?.FirstOrDefault();

					pipelineInvoice.Charges = banzaiInvoice?.Charges;
					pipelineInvoice.TaxDetails = banzaiInvoice?.TaxDetails;
					pipelineInvoice.InvoiceProductItem = banzaiInvoice?.InvoiceProductItem;

					if (pipelineInvoice.StatusHistory == null)
						pipelineInvoice.StatusHistory = new List<Status>();

					if (banzaiInvoice?.Status != null)
						pipelineInvoice.StatusHistory.Add(banzaiInvoice.Status);

					if (banzaiInvoice?.StatusHistory != null)
						pipelineInvoice.StatusHistory.AddRange(banzaiInvoice.StatusHistory);
				}
			}
		}

		/// <summary>
		/// This method queries InvoiceEnrichedRequests collection and generates PipelineEnrichedRequest
		/// </summary>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="buid"></param>
		/// <returns>PipelineEnrichedRequest</returns>
		private PipelineEnrichedRequest GetInvoiceEnrichedRequestFromBanzaiInvoice(PipelineEnrichedRequest originalPipelineEnrichedRequest, string invoiceNo, string pipelineSource, string buid = "", string vendorid = "")
		{
			PipelineEnrichedRequest pipelineEnrichedRequest = null;

			var pipelineFilter = Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				pipelineFilter = pipelineFilter & Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, buid);
			if (!string.IsNullOrEmpty(vendorid))
				pipelineFilter = pipelineFilter & Builders<InvoiceEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, vendorid);

			var invoiceFilter = Builders<InvoiceEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo == invoiceNo);
			var filter = Builders<InvoiceEnrichedRequest>.Filter.And(invoiceFilter, pipelineFilter);

			var invoiceEnrichedRequest = _dataContext.InvoiceEnrichedRequestsV2.Find(filter)?.FirstOrDefault();

			if (invoiceEnrichedRequest != null)
			{
				pipelineEnrichedRequest = new PipelineEnrichedRequest();

				// Root
				invoiceEnrichedRequest.CopyPropertiesTo(pipelineEnrichedRequest);

				//Common
				if (invoiceEnrichedRequest?.Common != null)
				{
					var common = new DFS.Banzai.Pipeline.Library.Entities.Common();
					invoiceEnrichedRequest?.Common.CopyPropertiesTo(common);

					pipelineEnrichedRequest.Common = common;
				}

				//InvoiceStage
				if (invoiceEnrichedRequest?.InvoiceStage != null)
				{
					var pipelineInvoiceStage = new DFS.Banzai.Pipeline.Library.Entities.InvoiceStage();

					invoiceEnrichedRequest?.InvoiceStage.CopyPropertiesTo(pipelineInvoiceStage);

					foreach (var invoice in invoiceEnrichedRequest?.InvoiceStage?.Invoices)
					{
						var pipelineInvoice = new DFS.Banzai.Pipeline.Library.Entities.Invoice();
						invoice.CopyPropertiesTo(pipelineInvoice);

						BuildInvoiceCharges(invoice, ref pipelineInvoice);

						BuildTaxDetails(invoice, ref pipelineInvoice);

						BuildInvoiceProductItems(ref pipelineInvoice, pipelineSource, invoiceNo, buid);

						BuildInvoiceStatusHistory(originalPipelineEnrichedRequest, invoice, ref pipelineInvoice);

						if (pipelineInvoiceStage.Invoices == null)
							pipelineInvoiceStage.Invoices = new List<Pipeline.Library.Entities.Invoice>();

						pipelineInvoiceStage.Invoices.Add(pipelineInvoice);
					}

					pipelineEnrichedRequest.InvoiceStage = pipelineInvoiceStage;
				}
			}

			return pipelineEnrichedRequest;
		}

		/// <summary>
		/// This method builds invoice charges
		/// </summary>
		/// <param name="invoice"></param>
		/// <param name="pipelineInvoice"></param>
		private void BuildInvoiceCharges(Invoice.Library.Entities.Invoice invoice,
			ref Pipeline.Library.Entities.Invoice pipelineInvoice)
		{
			if (invoice.Charges != null)
			{
				var pipelineInvoiceCharges = new List<DFS.Banzai.Pipeline.Library.Entities.InvoiceCharges>();
				foreach (var invoiceCharge in invoice.Charges)
				{
					var pipelineInvoiceCharge = new DFS.Banzai.Pipeline.Library.Entities.InvoiceCharges();
					invoiceCharge.CopyPropertiesTo(pipelineInvoiceCharge);

					pipelineInvoiceCharges.Add(pipelineInvoiceCharge);
				}

				pipelineInvoice.Charges = pipelineInvoiceCharges;
			}
		}

		/// <summary>
		/// This method builds tax details
		/// </summary>
		/// <param name="invoice"></param>
		/// <param name="pipelineInvoice"></param>
		private void BuildTaxDetails(Invoice.Library.Entities.Invoice invoice,
			ref Pipeline.Library.Entities.Invoice pipelineInvoice)
		{
			if (invoice.TaxDetails != null && invoice.TaxDetails.Count > 0)
			{
				var pipelineInvoiceTaxDetails = new List<DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail>();
				foreach (var invoiceTaxDetail in invoice.TaxDetails)
				{
					var pipelineInvoiceTaxDetail = new DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail();
					invoiceTaxDetail.CopyPropertiesTo(pipelineInvoiceTaxDetail);

					pipelineInvoiceTaxDetails.Add(pipelineInvoiceTaxDetail);
				}

				pipelineInvoice.TaxDetails = pipelineInvoiceTaxDetails;
			}
		}

		/// <summary>
		/// This method builds invoice status history
		/// </summary>
		/// <param name="originalPipelineEnrichedRequest"></param>
		/// <param name="invoice"></param>
		/// <param name="pipelineInvoice"></param>
		private void BuildInvoiceStatusHistory(PipelineEnrichedRequest originalPipelineEnrichedRequest, Invoice.Library.Entities.Invoice invoice,
			ref Pipeline.Library.Entities.Invoice pipelineInvoice)
		{
			if (invoice.Status != null)
			{
				var pipelineInvoiceStatusHistory = new List<Status>();
				var pipelineInvoiceStatus = new Status();

				if (originalPipelineEnrichedRequest == null)
				{
					invoice.Status.CopyPropertiesTo(pipelineInvoiceStatus);
					pipelineInvoiceStatus.Note = invoice.Status.InvoiceNote;
					pipelineInvoice.Status = pipelineInvoiceStatus;
				}
				else
				{
					invoice.Status.CopyPropertiesTo(pipelineInvoiceStatus);
					pipelineInvoiceStatus.Note = invoice.Status.InvoiceNote;
					pipelineInvoiceStatusHistory.Add(pipelineInvoiceStatus);
				}

				if (invoice.StatusHistory != null)
				{
					foreach (var invoiceStatus in invoice.StatusHistory)
					{
						var pipelineInvStatus = new Status();
						invoiceStatus.CopyPropertiesTo(pipelineInvStatus);
						pipelineInvStatus.Note = invoiceStatus.InvoiceNote;
						pipelineInvoiceStatusHistory.Add(pipelineInvStatus);
					}
				}

				pipelineInvoice.StatusHistory = pipelineInvoiceStatusHistory;
			}
		}

		/// <summary>
		/// This method builds invoice product items
		/// </summary>
		/// <param name="pipelineInvoice"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="invoiceNo"></param>
		/// <param name="buid"></param>
		private void BuildInvoiceProductItems(ref Pipeline.Library.Entities.Invoice pipelineInvoice,
		   string pipelineSource, string invoiceNo, string buid)
		{
			var builder = Builders<Invoice.Library.Entities.InvoiceProductItem>.Filter;
			var productItemfilter = builder.Eq(c => c.InvoiceNo, invoiceNo) &
				builder.Eq(u => u.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				productItemfilter = productItemfilter & Builders<Invoice.Library.Entities.InvoiceProductItem>.Filter.Eq(u => u.SourceBusinessUnit, buid);

			var invoiceProductItem = _dataContext.InvoiceProductItems.Find(productItemfilter)?.FirstOrDefault();

			if (invoiceProductItem != null)
			{
				var pipelineInvoiceProductItem = new Pipeline.Library.Entities.InvoiceProductItem();
				invoiceProductItem.CopyPropertiesTo(pipelineInvoiceProductItem);

				if (invoiceProductItem.InvoiceLines != null &&
					invoiceProductItem.InvoiceLines.Count > 0)
				{
					var pipelineInvoiceLines = new List<Pipeline.Library.Entities.InvoiceLine>();
					foreach (var invoiceLine in invoiceProductItem.InvoiceLines)
					{
						var pipelineInvoiceLine = new Pipeline.Library.Entities.InvoiceLine();
						invoiceLine.CopyPropertiesTo(pipelineInvoiceLine);

						BuildInvoiceLineSublines(invoiceLine, ref pipelineInvoiceLine);

						BuildInvoiceLineTaxDetails(invoiceLine, ref pipelineInvoiceLine);

						pipelineInvoiceLines.Add(pipelineInvoiceLine);
					}

					pipelineInvoiceProductItem.InvoiceLines = pipelineInvoiceLines;
				}

				pipelineInvoice.InvoiceProductItem = pipelineInvoiceProductItem;
			}
		}

		/// <summary>
		/// This method builds invoice line sublines
		/// </summary>
		/// <param name="invoiceLine"></param>
		/// <param name="pipelineInvoiceLine"></param>
		private void BuildInvoiceLineSublines(Invoice.Library.Entities.InvoiceLine invoiceLine,
			ref Pipeline.Library.Entities.InvoiceLine pipelineInvoiceLine)
		{
			if (invoiceLine.InvoiceSubLines != null && invoiceLine.InvoiceSubLines.Count > 0)
			{
				var pipelineInvoiceSubLines = new List<DFS.Banzai.Pipeline.Library.Entities.InvoiceSubLine>();
				foreach (var invoiceSubLine in invoiceLine.InvoiceSubLines)
				{
					var pipelineInvoiceSubLine = new DFS.Banzai.Pipeline.Library.Entities.InvoiceSubLine();

					invoiceSubLine.CopyPropertiesTo(pipelineInvoiceSubLine);

					#region SublineTaxDetails
					if (invoiceSubLine.TaxDetails != null && invoiceSubLine.TaxDetails.Count > 0)
					{
						var pipelineInvoiceSubLineTaxDetails = new List<DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail>();
						foreach (var invoiceSubLineTaxDetail in invoiceSubLine.TaxDetails)
						{
							var pipelineInvoiceSubLineTaxDetail = new DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail();
							invoiceSubLineTaxDetail.CopyPropertiesTo(pipelineInvoiceSubLineTaxDetail);

							pipelineInvoiceSubLineTaxDetails.Add(pipelineInvoiceSubLineTaxDetail);
						}

						pipelineInvoiceSubLine.TaxDetails = pipelineInvoiceSubLineTaxDetails;
					}
					#endregion

					pipelineInvoiceSubLines.Add(pipelineInvoiceSubLine);
				}

				pipelineInvoiceLine.InvoiceSubLines = pipelineInvoiceSubLines;
			}
		}

		/// <summary>
		/// This method builds invoice line tax details.
		/// </summary>
		/// <param name="invoiceLine"></param>
		/// <param name="pipelineInvoiceLine"></param>
		private void BuildInvoiceLineTaxDetails(Invoice.Library.Entities.InvoiceLine invoiceLine,
			ref Pipeline.Library.Entities.InvoiceLine pipelineInvoiceLine)
		{
			if (invoiceLine.TaxDetails != null && invoiceLine.TaxDetails.Count > 0)
			{
				var pipelineInvoiceTaxDetails = new List<DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail>();
				foreach (var invoiceTaxDetail in invoiceLine.TaxDetails)
				{
					var pipelineInvoiceTaxDetail = new DFS.Banzai.Pipeline.Library.Entities.InvoiceTaxDetail();

					invoiceTaxDetail.CopyPropertiesTo(pipelineInvoiceTaxDetail);

					pipelineInvoiceTaxDetails.Add(pipelineInvoiceTaxDetail);
				}

				pipelineInvoiceLine.TaxDetails = pipelineInvoiceTaxDetails;
			}
		}
		#endregion

		/// <summary>
		/// This method retreives all pipeline invoice for a given input search criteria
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[Route("Aura/Invoice/Find")]
		[HttpPost]
		#region FindInvoicesForAura
		public IActionResult FindInvoicesForAura([FromBody] SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			if (enrichedRequestLookupInfo == null)
				throw new ArgumentNullException(nameof(enrichedRequestLookupInfo));

			_logger.LogDebug("FindInvoicesForAura Started...");

			try
			{
				List<InvoiceExportResponseDto> result = null;

				if ("INVOICE".Equals(enrichedRequestLookupInfo.PipelineStage, StringComparison.InvariantCultureIgnoreCase))
					result = SearchInvoicesForAura(enrichedRequestLookupInfo);

				if (result == null || !result.Any())
				{
					_logger.LogWarning("FindInvoicesForAura - NOT FOUND");

					return NotFound();
				}

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"FindInvoicesForAura - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method searches Enrichment for Invoice pipeline stage
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		private List<InvoiceExportResponseDto> SearchInvoicesForAura(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			List<PipelineEnrichedRequest> pipelineEnrichedRequests = null;
			List<InvoiceExportResponseDto> invoiceExportResponseDtoList = new List<InvoiceExportResponseDto>();

			var invoiceFilter = GetInvoiceFilter(enrichedRequestLookupInfo);
			pipelineEnrichedRequests = _dataContext.PipelineEnrichedRequestsV2.Find(invoiceFilter).ToList();

			if (pipelineEnrichedRequests == null || !pipelineEnrichedRequests.Any())
			{
				_logger.LogWarning("SearchInvoicesForAura - NOT FOUND");
				return new List<InvoiceExportResponseDto>();
			}

			foreach (var pipelineEnrichedRequest in pipelineEnrichedRequests)
			{
				if ("C".Equals(pipelineEnrichedRequest.Common?.DFSOrphanFlag, StringComparison.InvariantCultureIgnoreCase))
					continue;

				if (pipelineEnrichedRequest.InvoiceStage?.Invoices == null)
					continue;

				GenerateInvoiceExportList(pipelineEnrichedRequest, ref invoiceExportResponseDtoList);
			}

			return invoiceExportResponseDtoList;
		}

		/// <summary>
		/// This method generates invoice export response list.
		/// </summary>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <param name="invoiceExportResponseDtoList"></param>
		private void GenerateInvoiceExportList(PipelineEnrichedRequest pipelineEnrichedRequest,
			ref List<InvoiceExportResponseDto> invoiceExportResponseDtoList)
		{
			if (pipelineEnrichedRequest != null)
			{
				foreach (var pipelineInvoice in pipelineEnrichedRequest?.InvoiceStage?.Invoices)
				{
					if ("INV-EXP-SENT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
						|| "INV-EXP-ACCEPT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
						continue;

					if (pipelineInvoice.StatusHistory != null && ValidStatusHistoryCodes(pipelineInvoice.StatusHistory))
						continue;

					if ("INV-ACCEPT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
						|| ValidateStatusHistoryForAcceptStatus(pipelineInvoice.StatusHistory))
					{
						var invoiceExportResponseDto = new InvoiceExportResponseDto
						{
							PipelineSource = pipelineEnrichedRequest.Common?.PipelineSource,
							VendorId = pipelineEnrichedRequest.Common?.VendorId,
							InvoiceNo = pipelineInvoice?.InvoiceNo,
							BUID = pipelineEnrichedRequest.Common?.SourceBusinessUnit,
							OrderNo = pipelineInvoice?.OrderNo,
							OriginalOrderNo = pipelineInvoice?.OriginalOrderNo,
							OriginalInvoiceNo = pipelineInvoice?.OriginalInvoiceNo,
							InvoiceType = pipelineInvoice?.InvoiceType,
							GAAPFlag = Convert.ToBoolean(pipelineInvoice?.GAAP),
							COGSFlag = Convert.ToBoolean(pipelineInvoice?.COGS),
							SixZeroSixFlag = Convert.ToBoolean(pipelineInvoice?.SixZeroSix),
							PDHFlag = Convert.ToBoolean(pipelineInvoice?.PDHFlag),
							DFSCustomer = Convert.ToBoolean(pipelineInvoice?.Status?.DFSCustomer),
							SentToAuraFlag = false,
							SourceCustomerId = pipelineEnrichedRequest.Common?.SourceCustomerID,
							CreditId = pipelineEnrichedRequest.Common?.DFSCreditID,
							ProductSummary = pipelineInvoice?.ProductSummary
						};

						invoiceExportResponseDtoList.Add(invoiceExportResponseDto);
					}
				}
			}
		}

		/// <summary>
		/// Validation of StatusHistory for set of status codes
		/// </summary>
		/// <param name="StatusHistory"></param>
		private bool ValidStatusHistoryCodes(List<Status> StatusHistory)
		{
			List<KeyValuePair<string, DateTime>> statusCodeAndDateTime = new List<KeyValuePair<string, DateTime>>();
			foreach (var status in StatusHistory)
			{
				if ("INV-EXP-SENT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
						|| "INV-EXP-ACCEPT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
						|| "INV-EXP-REJECT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
					statusCodeAndDateTime.Add(new KeyValuePair<string, DateTime>(status.BanzaiStatusCode.ToString(),
										Convert.ToDateTime(status.BanzaiStatusCreateDateTime)));
			}

			var findStatusCodeExpSent = statusCodeAndDateTime.ToList().Find(x => "INV-EXP-SENT".Equals(x.Key, StringComparison.InvariantCultureIgnoreCase));
			var findStatusCodeAccept = statusCodeAndDateTime.ToList().Find(x => "INV-EXP-ACCEPT".Equals(x.Key, StringComparison.InvariantCultureIgnoreCase));

			if (!string.IsNullOrEmpty(findStatusCodeExpSent.Key) || !string.IsNullOrEmpty(findStatusCodeAccept.Key))
			{
				var statusHistoryDate = statusCodeAndDateTime.OrderByDescending(x => x.Value).FirstOrDefault();
				if ("INV-EXP-REJECT".Equals(statusHistoryDate.Key, StringComparison.InvariantCultureIgnoreCase))
					return false;
			}

			if (!string.IsNullOrEmpty(findStatusCodeExpSent.Key) && !string.IsNullOrEmpty(findStatusCodeAccept.Key))
				return true;

			return false;
		}

		/// <summary>
		/// Validate Status History For Accept Status
		/// </summary>
		/// <param name="StatusHistory"></param>
		/// <returns></returns>
		private bool ValidateStatusHistoryForAcceptStatus(List<Status> StatusHistory)
		{
			if (StatusHistory != null)
			{
				foreach (var status in StatusHistory)
				{
					if ("INV-ACCEPT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
						return true;
				}
			}
			return false;
		}
		#endregion

		/// <summary>
		/// This method sends invoice notifications to Aura selected by user.
		/// </summary>
		/// <param name="invoiceExportRequestDtoList"></param>
		/// <param name="pipelineSource"></param>
		/// <param name="userEmailAddress"></param>
		/// <returns></returns>
		[Route("Aura/Invoice/Export/{pipelineSource}/{userEmailAddress}")]
		[HttpPost]
		#region SendPipelineInvoiceRequestsToAura
		public IActionResult SendPipelineInvoiceRequestsToAura([FromBody] List<InvoiceExportRequestDto> invoiceExportRequestDtoList, string pipelineSource, string userEmailAddress)
		{
			_logger.LogDebug($"SendPipelineInvoiceRequestsToAura");
			try
			{
				var message = JsonConvert.SerializeObject(invoiceExportRequestDtoList);
				if (!string.IsNullOrEmpty(pipelineSource))
				{
					if ("DELL".Equals(pipelineSource, StringComparison.InvariantCultureIgnoreCase))
					{
						_rabbitMQueuePublisher.Publish($"AuraInvoiceRequests|{message}|{userEmailAddress}", "q.banzai.pipeline.dell.enrichment");
						return Ok();
					}
					else if ("EMC".Equals(pipelineSource, StringComparison.InvariantCultureIgnoreCase))
					{
						_rabbitMQueuePublisher.Publish($"AuraInvoiceRequests|{message}|{userEmailAddress}", "q.banzai.pipeline.emc.enrichment");
						return Ok();
					}
					else if ("CHANNEL".Equals(pipelineSource, StringComparison.InvariantCultureIgnoreCase))
					{
						_rabbitMQueuePublisher.Publish($"AuraInvoiceRequests|{message}|{userEmailAddress}", "q.banzai.pipeline.channel.enrichment");
						return Ok();
					}
					else
					{
						_logger.LogError($"SendPipelineInvoiceRequestsToAura - Invalid Pipeline Source");
						return StatusCode(500, $"Invalid Pipeline Source");
					}
				}
				else
				{
					_logger.LogError($"SendPipelineInvoiceRequestsToAura - Invalid Pipeline Source");
					return StatusCode(500, $"Invalid Pipeline Source");
				}

			}
			catch (Exception ex)
			{
				_logger.LogError($"SendPipelineInvoiceRequestsToAura - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}
		#endregion

		/// <summary>
		/// This method searches EnrichedRequests collection to retreive a document based on pipelinesoure, documenttype and id.
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="docType"></param>
		/// <param name="id"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		[Route("Status/{pipelineSource}/{docType}/{id}")]
		[Route("Status/{pipelineSource}/{docType}/{id}/{buid}")]
		[Route("Status/{pipelineSource}/{docType}/{id}/{buid}/{vendorid}")]
		[HttpGet]
		#region GetPipelineEnrichedRequestForStatusChanges
		public IActionResult GetPipelineEnrichedRequestForStatusChanges(string pipelineSource, string docType, string id, string buid, string vendorid)
		{
			_logger.LogDebug($"GetPipelineEnrichedRequestForStatusChanges({pipelineSource},{docType},{id}, {buid}, {vendorid})");

			try
			{
				PipelineEnrichedRequest result;

				if (VOR.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByDpid(id, pipelineSource, buid, vendorid);
				else if (ORDER.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByOrderNo(id, pipelineSource, buid, vendorid);
				else if (INVOICE.Equals(docType, StringComparison.CurrentCultureIgnoreCase))
					result = SearchPipelineEnrichedRequestByInvoiceNo(id, pipelineSource, buid, vendorid);
				else
				{
					ModelState.AddModelError("docType", "Invalid Document Type.");
					return BadRequest(ModelState);
				}

				if (result == null)
				{
					_logger.LogWarning($"GetPipelineEnrichedRequestForStatusChanges({pipelineSource},{docType},{id},{buid}) - NOT FOUND");
					return NotFound();
				}

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetPipelineEnrichedRequestForStatusChanges({pipelineSource},{docType},{id},{buid}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}
		#endregion

		/// <summary>
		/// This method searches EnrichedRequests collection to find a customer
		/// </summary>
		/// <param name="docType"></param>
		/// <param name="id"></param>
		/// <returns></returns>
		[Route("Customer/{docType}/{id}")]
		[HttpGet]
		#region FindCustomer
		public IActionResult FindCustomer(string docType, string id)
		{
			_logger.LogDebug($"FindCustomer({docType},{id})");

			try
			{
				FilterDefinition<PipelineEnrichedRequest> filter;

				if (string.Compare(docType, VOR, StringComparison.OrdinalIgnoreCase) == 0)
					filter = PipelineEnrichedRequestsQuery.VorIdFilter(id);
				else if (string.Compare(docType, ORDER, StringComparison.OrdinalIgnoreCase) == 0)
					filter = PipelineEnrichedRequestsQuery.OrderNoFilter(id);
				else
				{
					ModelState.AddModelError("docType", "Invalid Document Type.");
					return BadRequest(ModelState);
				}

				var bson = _dataContext.PipelineEnrichedRequestsV2.Find(filter, PipelineEnrichedRequestsQuery.CustomerAssignmentProjection())?.FirstOrDefault();

				if (bson == null)
				{
					_logger.LogWarning($"FindCustomer({docType},{id}) - NOT FOUND");
					return NotFound();
				}

				var result = BsonSerializer.Deserialize<CustomerSearchDto>(bson);

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"FindCustomer({docType},{id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, "A problem happened while handling your request.");
			}
		}
		#endregion

		/// <summary>
		/// To reassign or unassign Customer for a given DPID.
		/// First lock both EnrichedRequest and RollupRequest DB collections. Incase of any error, throw it back.
		/// Update Customer info in EnrichedRequest and RollupRequest collections
		/// Unlock both EnrichedRequest and RollupRequest DB collections
		/// </summary>
		/// <param name="id"></param>
		/// <param name="item"></param>
		/// <returns></returns>        
		[Route("Customer/{id:length(24)}")]
		[HttpPut]
		#region UpdateCustomer
		public IActionResult UpdateCustomer(string id, [FromBody] UpdateCustomerRequesDto item)
		{
			_logger.LogDebug($"UpdateCustomer({id}) items.");

			try
			{
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var docBeforeUpdate = LockPipelineEnrichedRequest(id);

				if (docBeforeUpdate == null)
				{

					_logger.LogWarning($"UpdateCustomer({id}) - Record is locked or not found in EnrichedRequests collection.");

					return BadRequest("Record not found or locked in Enriched store! Try again later.");
				}

				if (item.Revision != docBeforeUpdate.Revision)
				{
					UnlockPipelineEnrichedRequest(id);

					_logger.LogWarning($"UpdateCustomer({id}) - Request revision {item.Revision} doesn't match with EnrichedRequests store {docBeforeUpdate.Revision}.");

					return BadRequest("Request revision number is older.");
				}

				//Orphan evaluation
				item.DFSOrphanFlag = OrphanStatusType.N.ToString();
				if (string.IsNullOrEmpty(item.DFSCreditID))
				{
					item.DFSOrphanFlag = OrphanStatusType.C.ToString();
				}
				else if (!string.IsNullOrEmpty(docBeforeUpdate.Common.DFSProductSpace))
				{
					if (item.DFSCustomerMLAFlag && "TRANSACTIONAL".Equals(docBeforeUpdate.Common.DFSProductSpace, StringComparison.CurrentCultureIgnoreCase))
						item.DFSOrphanFlag = OrphanStatusType.M.ToString();
					else if (!item.DFSCustomerMLAFlag && "MLA".Equals(docBeforeUpdate.Common.DFSProductSpace, StringComparison.CurrentCultureIgnoreCase))
						item.DFSOrphanFlag = OrphanStatusType.T.ToString();
				}

				if (!EnrichedRequestReassignCustomer(id, item))
				{
					UnlockPipelineEnrichedRequest(id);

					_logger.LogCritical($"UpdateCustomer({id}) - Error updating enriched document for revsion {docBeforeUpdate.Revision}");

					return StatusCode(500, $"A problem happened while updating enriched document for revision {docBeforeUpdate.Revision}");
				}

				UnlockPipelineEnrichedRequest(id);

				_rabbitMQueuePublisher.Publish(id, "q.banzai.pipeline.rollup.requests");

				return NoContent();
			}
			catch (Exception ex)
			{
				UnlockPipelineEnrichedRequest(id);

				_logger.LogCritical($"UpdateCustomer({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method re-assigns customer information on EnrichedRequests collection for a given ID
		/// </summary>
		/// <param name="id"></param>
		/// <param name="item"></param>
		/// <returns></returns>
		private bool EnrichedRequestReassignCustomer(string id, UpdateCustomerRequesDto item)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var filter = builder.Eq(u => u.Id, id);

			var update = Builders<PipelineEnrichedRequest>.Update
				.Set(u => u.Revision, item.Revision + 1)
				.Set(u => u.Common.DFSCreditSystem, item.DFSCreditSystem)
				.Set(u => u.Common.DFSCreditID, item.DFSCreditID)
				.Set(u => u.Common.DFSUnbookedExposureSystem, item.DFSUnbookedExposureSystem)
				.Set(u => u.Common.DFSUnbookedExposureID, item.DFSUnbookedExposureID)
				.Set(u => u.Common.DFSCustomerReassignedFlag, item.DFSCustomerReassignedFlag)
				.Set(u => u.Common.DFSSegment, item.DFSSegment).Set(u => u.Common.DFSSegmentClass, item.DFSSegmentClass)
				.Set(u => u.Common.DFSOrphanFlag, item.DFSOrphanFlag)
				.Set(u => u.Common.DFSCustomerMLAFlag, item.DFSCustomerMLAFlag)
				.Set(u => u.Common.DFSCustomerFundingSourceReviewFlag, item.DFSCustomerFundingSourceReviewFlag)
				.Set(u => u.Common.DFSCreditCautionFlag, item.DFSCreditCautionFlag)
				.Set(u => u.Common.UserLastModifiedBy, item.UserLastModifiedBy)
				.CurrentDate(u => u.Common.UserLastModifiedDate) //DateTime.UtcNow
				.Set(u => u.Common.DFSCustomerName, item.DFSCustomerName)
				.Set(u => u.Common.DirectOpsRep, item.DirectOpsRep);

			return _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, update);
		}
		#endregion

		/// <summary>
		/// This method searches EnrichedRequests and overrides status information
		/// </summary>
		/// <param name="updateStatusOverrideDto"></param>
		/// <returns></returns>
		[Route("Status/Override")]
		[HttpPut]
		#region OverrideBanzaiStatus
		public IActionResult OverrideBanzaiStatus([FromBody] UpdateStatusOverrideDto updateStatusOverrideDto)
		{
			_logger.LogDebug("OverrideBanzaiStatus");

			if (!ModelState.IsValid)
				return BadRequest(ModelState);

			try
			{
				var id = updateStatusOverrideDto.Id;
				var docBeforeUpdate = LockPipelineEnrichedStatusCodeDocument(updateStatusOverrideDto);
				if (docBeforeUpdate == null)
				{

					_logger.LogWarning($"OverrideBanzaiStatus-({id}) - Record is locked or not found in EnrichedRequests collection.");

					return BadRequest("Record not found or locked in Enriched store! Try again later.");
				}

				if (updateStatusOverrideDto.Revision != docBeforeUpdate.Revision)
				{
					UnlockPipelineEnrichedRequest(id);
					_logger.LogWarning($"OverrideBanzaiStatus-({id}) - Request revision {updateStatusOverrideDto.Revision} doesn't match with EnrichedRequests store revision- {docBeforeUpdate.Revision}.");

					return BadRequest("Request revision number is older.");
				}

				if (!EnrichedRequestStatusOverride(updateStatusOverrideDto, docBeforeUpdate, "StatusOverride"))
				{
					UnlockPipelineEnrichedRequest(id);
					_logger.LogCritical($"OverrideBanzaiStatus({id}) - Error updating enriched document for revsion {docBeforeUpdate.Revision}");

					return StatusCode(500, $"A problem happened while updating EnrichedRequest for revision - {docBeforeUpdate.Revision}");
				}

				UnlockPipelineEnrichedRequest(id);

				_rabbitMQueuePublisher.Publish(id, "q.banzai.pipeline.rollup.requests");

				return StatusCode(200, "Successfully Saved");
			}
			catch (Exception ex)
			{
				UnlockPipelineEnrichedRequest(updateStatusOverrideDto.Id);
				_logger.LogCritical($"OverrideBanzaiStatus - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method overrides status and status updates for EnrichedRequests collection
		/// </summary>
		/// <param name="statusOverrideInfo"></param>
		/// <param name="enrichedRequest"></param>
		/// <returns></returns>
		private bool EnrichedRequestStatusOverride(UpdateStatusOverrideDto statusOverrideInfo, PipelineEnrichedRequest enrichedRequest, string messageType)
		{
			messageType = messageType.ToUpper();

			var filter = Builders<PipelineEnrichedRequest>.Filter.Eq(e => e.Id, enrichedRequest.Id);

			var update = Builders<PipelineEnrichedRequest>.Update
				.Set(e => e.Revision, ++enrichedRequest.Revision)
				.Set(e => e.Common.UserLastModifiedBy, statusOverrideInfo.UserLastModifiedBy)
				.Set(e => e.IsLocked, false)
				.CurrentDate(e => e.Common.UserLastModifiedDate);

			_banzaiStatus = GetBanzaiStatus(statusOverrideInfo, messageType);

			if (_banzaiStatus == null)
				return false;

			switch (statusOverrideInfo.PipelineStage.ToUpper())
			{
				case VOR:
					update = (messageType == STATUS_OVERRIDE) ?
					   OverrideStatusVor(statusOverrideInfo, enrichedRequest, update) :
					   UpdateStatusVor(statusOverrideInfo, enrichedRequest, update);
					break;

				case ORDER:
					update = (messageType == STATUS_OVERRIDE) ?
					   OverrideStatusOrder(statusOverrideInfo, enrichedRequest, update) :
					   UpdateStatusOrder(statusOverrideInfo, enrichedRequest, update);
					break;

				case INVOICE:
					update = (messageType == STATUS_OVERRIDE) ?
						OverrideStatusInvoice(statusOverrideInfo, enrichedRequest, update) :
						UpdateStatusInvoice(statusOverrideInfo, enrichedRequest, update);
					break;

				default:
					update = null;
					break;
			}

			if (update != null)
				return _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, update);

			return false;
		}

		/// <summary>
		/// This method overrides vorNo status
		/// </summary>
		/// <param name="vorNo"></param>
		/// <param name="enrichedRequest"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> OverrideStatusVor(UpdateStatusOverrideDto statusOverrideDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusOverrideDto.VorNo))
				return null;

			VorStage vorstage = null;

			if (enrichedRequest.VorID == statusOverrideDto.VorNo)
				vorstage = enrichedRequest.VorStage;

			if (vorstage == null)
				return null;

			var previousStatus = vorstage.Clone() is VorStage ? (vorstage.Clone() as VorStage).Status : new Status();

			var newStatus = CreateNewStatusRecord(statusOverrideDto);

			if (newStatus == null)
				return null;

			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			vorstage.Status = newStatus;
			vorstage.Status.MessageType = STATUS_OVERRIDE_UI;
			vorstage.StatusHistory = vorstage.StatusHistory ?? new List<Status>();
			vorstage.StatusHistory.Add(previousStatus);
			update = update.Set(e => e.VorStage, vorstage);
			return update;
		}

		/// <summary>
		/// This method Overrides order status
		/// </summary>
		/// <param name="statusOverrideInfo"></param>
		/// <param name="enrichedRequest"></param>
		/// <param name="update"></param>
		/// <returns></returns>		
		private UpdateDefinition<PipelineEnrichedRequest> OverrideStatusOrder(UpdateStatusOverrideDto statusOverrideDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusOverrideDto.OrderNo))
				return null;

			Order order = enrichedRequest.OrderStage?.Orders?.FirstOrDefault(o => o.OrderNo == statusOverrideDto.OrderNo);
			if (order == null)
			{
				return null;
			}
			var previousStatus = order.Clone() is Order ? (order.Clone() as Order).Status : new Status();

			var newStatus = CreateNewStatusRecord(statusOverrideDto);
			if (newStatus == null)
			{
				return null;
			}

			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			order.Status = newStatus;
			order.Status.MessageType = STATUS_OVERRIDE_UI;
			order.StatusHistory = order.StatusHistory ?? new List<Status>();
			order.StatusHistory.Add(previousStatus);

			update = update.Set(e => e.OrderStage.Orders, enrichedRequest.OrderStage.Orders);
			return update;
		}

		/// <summary>
		/// Creates new status record
		/// </summary>
		/// <param name="statusOverrideDto"></param>
		/// <returns></returns>
		private Status CreateNewStatusRecord(UpdateStatusOverrideDto statusOverrideDto)
		{
			var newStatus = new Status
			{
				BanzaiStatusCreateDateTime = DateTime.UtcNow,
				DecisionSource = statusOverrideDto.UserLastModifiedBy,
				DecisionSourceStatusCode = null,
				DecisionSourceDateTime = DateTime.UtcNow,
				SourceStatusCode = null,
				SourceStatusCodeDateTime = null,
				MessageType = STATUS_UPDATE_UI,//*
				MessageID = null,
				MessageSourceDateTime = null,
				MessageReceivedDateTime = null,
				Note = statusOverrideDto.Note,
				BanzaiStatusCode = _banzaiStatus.BanzaiStatusCode,
				BanzaiStatusSequence = _banzaiStatus.BanzaiStatusSequence,
				BanzaiUnbookedExposureFlag = _banzaiStatus.BanzaiUnbookedExposureFlag,
				LatentTransaction = false
			};

			return newStatus;
		}

		/// <summary>
		/// This method overrides invoice status
		/// </summary>
		/// <param name="statusOverrideInfo"></param>
		/// <param name="enrichedRequest"></param>
		/// <param name="update"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> OverrideStatusInvoice(UpdateStatusOverrideDto statusOverrideDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusOverrideDto.InvoiceNo))
				return null;

			var invoice = enrichedRequest.InvoiceStage.Invoices.FirstOrDefault(i => i.InvoiceNo == statusOverrideDto.InvoiceNo);
			if (invoice == null)
			{
				return null;
			}

			var previousStatus = invoice.Clone() is Pipeline.Library.Entities.Invoice ? (invoice.Clone() as Pipeline.Library.Entities.Invoice).Status : new Status();

			var newStatus = CreateNewStatusRecord(statusOverrideDto);

			if (newStatus == null)
			{
				return null;
			}
			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			invoice.Status = newStatus;
			invoice.Status.MessageType = STATUS_OVERRIDE_UI;
			invoice.StatusHistory = invoice.StatusHistory ?? new List<Status>();
			invoice.StatusHistory.Add(previousStatus);

			update = update.Set(e => e.InvoiceStage.Invoices, enrichedRequest.InvoiceStage.Invoices);
			return update;
		}

		/// <summary>
		/// This method searches status combo repository for a given overrideinfo
		/// </summary>
		/// <param name="statusOverrideInfo"></param>
		/// <returns></returns>
		private StatusCombo GetBanzaiStatus(UpdateStatusOverrideDto statusOverrideInfo, string messageType)
		{
			_banzaiStatus = null;
			var statusCombos = _dataContext.StatusCombos.GetAll().ToList();

			if (STATUS_OVERRIDE.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
			{
				return statusCombos.Any() ?
					(from x in statusCombos
					 where
					 x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusOverrideInfo.BanzaiStatusOverrideCode?.ToUpper()) &&
					 x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(statusOverrideInfo.PipelineSource?.ToUpper()) &&
					 x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(statusOverrideInfo.PipelineStage?.ToUpper()) &&
					 x.Active &&
					 x.UserOverride
					 select x).FirstOrDefault() : null;
			}
			else
			{
				return statusCombos.Any() ?
				(from x in statusCombos
				 where
				 x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusOverrideInfo.BanzaiStatusOverrideCode?.ToUpper()) &&
				 x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(statusOverrideInfo.PipelineSource?.ToUpper()) &&
				 x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(statusOverrideInfo.PipelineStage?.ToUpper()) &&
				 x.Active &&
				 x.UserUpdateFuture
				 select x).FirstOrDefault() : null;
			}
		}

		/// <summary>
		/// This method applies lock on EnrichedRequests for given ID
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest LockPipelineEnrichedStatusCodeDocument(UpdateStatusOverrideDto updateStatusOverrideDto)
		{
			var enrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
			FilterDefinition<PipelineEnrichedRequest> filter = null;

			switch (updateStatusOverrideDto.PipelineStage)
			{
				case "VOR":
					filter = enrichedRequestBuilder.Eq(x => x.VorID, updateStatusOverrideDto.VorNo);
					break;
				case "ORDER":
					filter = enrichedRequestBuilder.ElemMatch(x => x.OrderStage.Orders, u => u.OrderNo == updateStatusOverrideDto.OrderNo);
					break;
				case "INVOICE":
					filter = enrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo == updateStatusOverrideDto.InvoiceNo);
					break;
			}

			filter = filter & enrichedRequestBuilder.Eq(x => x.IsLocked, false);
			if (!string.IsNullOrEmpty(updateStatusOverrideDto.BuId))
				filter = filter & enrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, updateStatusOverrideDto.BuId);
			if (!string.IsNullOrEmpty(updateStatusOverrideDto.VendorId))
				filter = filter & enrichedRequestBuilder.Eq(x => x.Common.VendorId, updateStatusOverrideDto.VendorId);

			var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
					Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
					ReturnDocument.Before);

			return result;
		}
		#endregion

		/// <summary>
		/// Status update for a give record(Vor, Order , Invoice)
		/// </summary>
		/// <param name="updateStatusOverrideDto"></param>
		/// <returns></returns>
		[Route("Status/Update")]
		[HttpPut]
		#region StatusUpdateBanzai
		public IActionResult StatusUpdateBanzai([FromBody] UpdateStatusOverrideDto updateStatusOverrideDto)
		{
			_logger.LogDebug("StatusUpdateBanzai");

			if (!ModelState.IsValid)
				return BadRequest(ModelState);

			try
			{
				var id = updateStatusOverrideDto.Id;
				var docBeforeUpdate = LockPipelineEnrichedStatusCodeDocument(updateStatusOverrideDto);
				if (docBeforeUpdate == null)
				{
					_logger.LogWarning($"StatusUpdateBanzai-({id}) - Record is locked or not found in EnrichedRequests collection.");
					return BadRequest("Record not found or locked in Enriched store! Try again later.");
				}

				if (updateStatusOverrideDto.Revision != docBeforeUpdate.Revision)
				{
					UnlockPipelineEnrichedRequest(id);
					_logger.LogWarning($"OverrideBanzaiStatus-({id}) - Request revision {updateStatusOverrideDto.Revision} doesn't match with EnrichedRequests store revision- {docBeforeUpdate.Revision}.");
					return BadRequest("Request revision number is older.");
				}

				if (!EnrichedRequestStatusOverride(updateStatusOverrideDto, docBeforeUpdate, "StatusUpdate"))
				{
					UnlockPipelineEnrichedRequest(id);
					_logger.LogCritical($"OverrideBanzaiStatus({id}) - Error updating enriched document for revsion {docBeforeUpdate.Revision}");
					return StatusCode(500, $"A problem happened while updating EnrichedRequest for revision - {docBeforeUpdate.Revision}");
				}

				UnlockPipelineEnrichedRequest(id);

				_rabbitMQueuePublisher.Publish(id, "q.banzai.pipeline.rollup.requests");

				return StatusCode(200, "Successfully Saved");
			}
			catch (Exception ex)
			{
				UnlockPipelineEnrichedRequest(updateStatusOverrideDto.Id);
				_logger.LogCritical($"OverrideBanzaiStatus - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method status update code for vorNo
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="enrichedRequest"></param>
		/// <param name="update"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateStatusVor(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusUpdateDto.VorNo))
				return null;

			VorStage vorstage = null;

			if (enrichedRequest.VorID == statusUpdateDto.VorNo)
				vorstage = enrichedRequest.VorStage;

			if (vorstage == null)
				return null;

			var previousStatus = vorstage.Clone() is VorStage ? (vorstage.Clone() as VorStage).Status : new Status();

			var newStatus = CreateNewStatusRecord(statusUpdateDto);
			if (newStatus == null)
				return null;

			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			vorstage.StatusHistory = vorstage.StatusHistory ?? new List<Status>();

			if (newStatus.BanzaiStatusSequence < vorstage?.Status?.BanzaiStatusSequence)
			{
				newStatus.LatentTransaction = true;
				vorstage.StatusHistory.Add(newStatus);
			}
			else
			{
				vorstage.StatusHistory.Add(previousStatus);
				vorstage.Status = newStatus;
			}

			update = update.Set(e => e.VorStage, enrichedRequest.VorStage);
			return update;
		}

		/// <summary>
		/// This method status update code for orderNo
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="enrichedRequest"></param>
		/// <param name="update"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateStatusOrder(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusUpdateDto.OrderNo))
				return null;

			Order order = enrichedRequest.OrderStage?.Orders?.FirstOrDefault(x => x.OrderNo == statusUpdateDto.OrderNo);
			if (order == null)
				return null;

			var previousStatus = order.Clone() is Order ? (order.Clone() as Order).Status : new Status();
			var newStatus = CreateNewStatusRecord(statusUpdateDto);
			if (newStatus == null)
				return null;

			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			order.StatusHistory = order.StatusHistory ?? new List<Status>();

			if (newStatus.BanzaiStatusSequence < order?.Status?.BanzaiStatusSequence)
			{
				newStatus.LatentTransaction = true;
				order.StatusHistory.Add(newStatus);
			}
			else
			{
				order.StatusHistory.Add(previousStatus);
				order.Status = newStatus;
			}


			update = update.Set(e => e.OrderStage.Orders, enrichedRequest.OrderStage.Orders);
			return update;
		}

		/// <summary>
		/// This method status update code for Invoice No
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="enrichedRequest"></param>
		/// <param name="update"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateStatusInvoice(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest enrichedRequest, UpdateDefinition<PipelineEnrichedRequest> update)
		{
			if (string.IsNullOrEmpty(statusUpdateDto.InvoiceNo))
				return null;

			var invoice = enrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo == statusUpdateDto.InvoiceNo);
			if (invoice == null)
				return null;

			var previousStatus = invoice.Clone() is Pipeline.Library.Entities.Invoice ? (invoice.Clone() as Pipeline.Library.Entities.Invoice).Status : new Status();

			var newStatus = CreateNewStatusRecord(statusUpdateDto);
			if (newStatus == null)
				return null;

			enrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
			invoice.StatusHistory = invoice.StatusHistory ?? new List<Status>();

			if (newStatus.BanzaiStatusSequence < invoice?.Status?.BanzaiStatusSequence)
			{
				newStatus.LatentTransaction = true;
				invoice.StatusHistory.Add(newStatus);
			}
			else
			{
				invoice.StatusHistory.Add(previousStatus);
				invoice.Status = newStatus;
			}

			update = update.Set(e => e.InvoiceStage.Invoices, enrichedRequest.InvoiceStage.Invoices);
			return update;
		}

		#endregion

		/// <summary>
		/// Mass Update PipelineEnrichedRequests collection based on given list
		/// </summary>
		[Route("UserDefinedFields/Update")]
		[HttpPut]
		#region UpdateUserDefindFields
		public IActionResult UpdateUserDefindFields([FromBody] List<UpdateEnrichedRequestDto> updateEnrichedRequesDtoList)
		{
			_logger.LogDebug("UpdateUserDefindFields started");

			try
			{
				if (updateEnrichedRequesDtoList == null || !updateEnrichedRequesDtoList.Any())
					return BadRequest();

				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var responseList = new List<UpdateEnrichedResponseDto>();

				foreach (var row in updateEnrichedRequesDtoList)
					responseList.Add(ProcessUDFRow(row));

				return Ok(responseList);
			}
			catch (Exception ex)
			{
				_logger.LogCritical($"UpdateUserDefindFields - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method process each row and update its record accordingly
		/// </summary>
		private UpdateEnrichedResponseDto ProcessUDFRow(UpdateEnrichedRequestDto updateEnrichedRequestDto)
		{
			var response = new UpdateEnrichedResponseDto
			{
				UpdateEnrichedRequest = updateEnrichedRequestDto,
				Status = string.Empty,
				Remarks = string.Empty
			};

			PipelineEnrichedRequest document = null;

			try
			{
				var parsed = Enum.TryParse(updateEnrichedRequestDto.Identifier, out MassUploadIdentifier identifier);
				if (!parsed)
				{
					_logger.LogWarning($"UpdateEnrichment - identifier {updateEnrichedRequestDto.Identifier} is invalid");
					response.Remarks = "DPID/Order/Invoice not updated. Identifier can not be empty.";
					return response;
				}

				if (string.IsNullOrEmpty(updateEnrichedRequestDto.PipelineSource))
				{
					response.Remarks = $"{identifier.ToString()} not updated. PipelineSource can not be empty.";
					return response;
				}

				if (string.IsNullOrEmpty(updateEnrichedRequestDto.IdentifierValue))
				{
					response.Remarks = $"{identifier.ToString()} not updated. IdentifierValue can not be empty.";
					return response;
				}

				switch (identifier)
				{
					case MassUploadIdentifier.DPID:
						document = SearchPipelineEnrichedRequestByDpid(updateEnrichedRequestDto.IdentifierValue, updateEnrichedRequestDto.PipelineSource);
						break;
					case MassUploadIdentifier.Order:
						document = SearchPipelineEnrichedRequestByOrderNo(updateEnrichedRequestDto.IdentifierValue, updateEnrichedRequestDto.PipelineSource);
						break;
					case MassUploadIdentifier.Invoice:
						document = SearchPipelineEnrichedRequestByInvoiceNo(updateEnrichedRequestDto.IdentifierValue, updateEnrichedRequestDto.PipelineSource);
						break;
					default:
						response.Remarks = "Invalid identifier Specified!";
						return response;
				}

				response.Status = "Found";

				if (document == null)
				{
					response.Status = "Not Found";
					return response;
				}

				if (document.IsLocked)
				{
					response.Status = "Found";
					response.Remarks = "Not updated, document locked";
					return response;
				}

				document = LockPipelineEnrichedRequest(document.Id);

				var update = GetUpdatedUDFDocument(response, document, updateEnrichedRequestDto, identifier);

				var filter = Builders<PipelineEnrichedRequest>.Filter.Eq(e => e.Id, document.Id);
				var updated = _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, update);
				if (!updated)
				{
					response.Remarks = "Update Failed";
					return response;
				}

				if (string.IsNullOrEmpty(response.Remarks))
					response.Remarks = "Successfully Updated";
			}
			catch (Exception e)
			{
				response.Remarks = $"Failed with error - {e.Message}";
			}
			finally
			{
				if (document != null)
					UnlockPipelineEnrichedRequest(document.Id);
			}

			return response;
		}

		/// <summary>
		/// This method gets updated pipeline enriched request after appling UDF
		/// </summary>
		/// <param name="response"></param>
		/// <param name="document"></param>
		/// <param name="updateEnrichedRequestDto"></param>
		/// <param name="identifier"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> GetUpdatedUDFDocument(UpdateEnrichedResponseDto response, PipelineEnrichedRequest document,
			UpdateEnrichedRequestDto updateEnrichedRequestDto, MassUploadIdentifier identifier)
		{
			var update = Builders<PipelineEnrichedRequest>.Update
				.Set(e => e.Revision, ++document.Revision)
				.Set(e => e.Common.UserLastModifiedBy, updateEnrichedRequestDto.UserName)
				.CurrentDate(e => e.Common.UserLastModifiedDate);

			if (!string.IsNullOrEmpty(updateEnrichedRequestDto.PurchaseOrderNumber))
				update = update.Set(e => e.Common.PurchaseOrderNumber, updateEnrichedRequestDto.PurchaseOrderNumber);
			if (!string.IsNullOrEmpty(updateEnrichedRequestDto.UserDefinedOne))
				update = update.Set(e => e.Common.UserDefined1, updateEnrichedRequestDto.UserDefinedOne);
			if (!string.IsNullOrEmpty(updateEnrichedRequestDto.UserDefinedTwo))
				update = update.Set(e => e.Common.UserDefined2, updateEnrichedRequestDto.UserDefinedTwo);
			if (!string.IsNullOrEmpty(updateEnrichedRequestDto.ShippingContactName))
				update = update.Set(e => e.Common.ShippingContactName, updateEnrichedRequestDto.ShippingContactName);
			if (!string.IsNullOrEmpty(updateEnrichedRequestDto.ContractNum))
			{
				if (identifier == MassUploadIdentifier.DPID)
					response.Remarks = $"DPID was provided Contract # \"{updateEnrichedRequestDto.ContractNum}\" " +
						$"and it needs to be blank. Other fields were updated.";
				else
					update = UpdateContractNum(document, identifier, updateEnrichedRequestDto, update, response);
			}

			return update;
		}

		/// <summary>
		/// This method updates contract number for given UDF row
		/// </summary>
		/// <param name="document"></param>
		/// <param name="identifier"></param>
		/// <param name="request"></param>
		/// <param name="update"></param>
		/// <param name="updateEnrichedResponseDto"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateContractNum(PipelineEnrichedRequest document, MassUploadIdentifier identifier,
			UpdateEnrichedRequestDto request, UpdateDefinition<PipelineEnrichedRequest> update, UpdateEnrichedResponseDto updateEnrichedResponseDto)
		{
			if (identifier == MassUploadIdentifier.Invoice)
				update = UpdateContractNumForInvoice(document, request, update, updateEnrichedResponseDto);
			else if (identifier == MassUploadIdentifier.Order)
				update = UpdateContractNumForOrder(document, request, update, updateEnrichedResponseDto);

			return update;
		}

		/// <summary>
		/// This method updates contract number for invoice.
		/// </summary>
		/// <param name="document"></param>
		/// <param name="request"></param>
		/// <param name="update"></param>
		/// <param name="updateEnrichedResponseDto"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateContractNumForInvoice(PipelineEnrichedRequest document,
			UpdateEnrichedRequestDto request, UpdateDefinition<PipelineEnrichedRequest> update, UpdateEnrichedResponseDto updateEnrichedResponseDto)
		{
			var invoice = document.InvoiceStage?.Invoices?.FirstOrDefault(i => i.InvoiceNo == request.IdentifierValue);
			if (invoice == null)
			{
				updateEnrichedResponseDto.Status = "Not Found";
				updateEnrichedResponseDto.Remarks = "Update Failed";
				return update;
			}
			var bookedStatus = invoice.Status?.BanzaiStatusCode?.ToUpper() ?? string.Empty;

			if (bookedStatus.Equals("BKD") || bookedStatus.Equals("BK") || bookedStatus.Equals("BOOKED"))
			{
				updateEnrichedResponseDto.Status = "Found";
				updateEnrichedResponseDto.Remarks = $"Contract # \"{request.ContractNum}\" can not be updated as the Invoice is Booked";
				return update;
			}

			invoice.ContractNum = request.ContractNum;
			update = update.Set(e => e.InvoiceStage.Invoices, document.InvoiceStage.Invoices);

			var order = document.OrderStage?.Orders?.FirstOrDefault(o => o.OrderNo == invoice.OrderNo);
			if (order == null)
				return update;

			order.ContractNum = request.ContractNum;
			update = update.Set(e => e.OrderStage.Orders, document.OrderStage.Orders);

			return update;
		}

		/// <summary>
		/// This method updates contract number for order
		/// </summary>
		/// <param name="document"></param>
		/// <param name="request"></param>
		/// <param name="update"></param>
		/// <param name="updateEnrichedResponseDto"></param>
		/// <returns></returns>
		private UpdateDefinition<PipelineEnrichedRequest> UpdateContractNumForOrder(PipelineEnrichedRequest document,
			UpdateEnrichedRequestDto request, UpdateDefinition<PipelineEnrichedRequest> update, UpdateEnrichedResponseDto updateEnrichedResponseDto)
		{
			var order = document.OrderStage?.Orders?.FirstOrDefault(o => o.OrderNo == request.IdentifierValue);
			if (order == null)
			{
				updateEnrichedResponseDto.Status = "Not Found";
				updateEnrichedResponseDto.Remarks = "Update Failed";
				return update;
			}

			var bookedStatus = order.Status?.BanzaiStatusCode?.ToUpper() ?? string.Empty;

			if (bookedStatus.Equals("BKD") || bookedStatus.Equals("BK"))
			{
				updateEnrichedResponseDto.Status = "Found";
				updateEnrichedResponseDto.Remarks = $"Contract #  \"{request.ContractNum}\" can not be updated as the Order is Booked";
				return update;
			}

			order.ContractNum = request.ContractNum;
			update = update.Set(e => e.OrderStage.Orders, document.OrderStage.Orders);

			var invoice = document.InvoiceStage?.Invoices?.FirstOrDefault(i => i.OrderNo == request.IdentifierValue);
			if (invoice == null)
				return update;

			invoice.ContractNum = request.ContractNum;
			update = update.Set(e => e.InvoiceStage.Invoices, document.InvoiceStage.Invoices);

			return update;
		}
		#endregion

		/// <summary>
		/// This method deletes PipelineEnrichedRequest
		/// </summary>
		/// <returns></returns>
		[Route("{pipelineSource}/{identifier}/{identifierList}")]
		[HttpDelete]
		#region DeletePipelineEnrichedRequest
		public IActionResult DeletePipelineEnrichedRequest(string pipelineSource, string identifier, string identifierList, bool deleteRollup = true)
		{
			_logger.LogDebug("DeletePipelineEnrichedRequest started");

			try
			{
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var items = identifierList?.Split(",");

				identifier = identifier.Trim();
				pipelineSource = pipelineSource.Trim();

				if (items != null && items.Length > 0)
				{
					var filter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);
					var rollupFilter = Builders<RollupRequest>.Filter.Eq(u => u.PipelineSource, pipelineSource);

					if ("PER".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
						DeletePipelineEnrichedRequestUsingID(items, deleteRollup);
					else if ("VOR".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
						DeleteVorPipelineEnrichedRequest(filter, rollupFilter, items, deleteRollup);
					else if ("ORDER".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
						DeleteOrderPipelineEnrichedRequest(filter, rollupFilter, items, deleteRollup);
					else if ("INVOICE".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
						DeleteInvoicePipelineEnrichedRequest(filter, rollupFilter, items, deleteRollup);
				}

				return Ok();
			}
			catch (Exception ex)
			{
				_logger.LogCritical($"DeletePipelineEnrichedRequest - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method delete pipeline enriched request based on mongoid.
		/// </summary>
		/// <param name="filter"></param>
		/// <param name="rollupFilter"></param>
		/// <param name="items"></param>
		/// <param name="deleteRollup"></param>
		private void DeletePipelineEnrichedRequestUsingID(string[] items, bool deleteRollup)
		{
			Array.ForEach(items, item =>
			{
				if (!string.IsNullOrEmpty(item))
				{
					_dataContext.PipelineEnrichedRequestsV2.DeleteOne(Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Id, item.Trim()));
					if (deleteRollup)
						_dataContext.RollupRequests.DeleteOne(Builders<RollupRequest>.Filter.Eq(u => u.Id, item.Trim()));
				}
			});
		}

        /// <summary>
        /// This method deletes pipelineenrichedrequest based on vor
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="rollupFilter"></param>
        /// <param name="items"></param>
        /// <param name="deleteRollup"></param>
        private void DeleteVorPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter, FilterDefinition<RollupRequest> rollupFilter,
			string[] items, bool deleteRollup)
		{
			Array.ForEach(items, item =>
			{
				if (!string.IsNullOrEmpty(item))
				{
					_dataContext.PipelineEnrichedRequestsV2.DeleteOne(Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.VorID, item.Trim()) & filter);
					if (deleteRollup)
						_dataContext.RollupRequests.DeleteOne(Builders<RollupRequest>.Filter.Eq(u => u.VorID, item.Trim()) & rollupFilter);
				}
			});
		}

		/// <summary>
		/// This method deletes pipelineenrichedrequest based on order
		/// </summary>
		/// <param name="filter"></param>
		/// <param name="rollupFilter"></param>
		/// <param name="items"></param>
		/// <param name="deleteRollup"></param>
		private void DeleteOrderPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter, FilterDefinition<RollupRequest> rollupFilter,
			string[] items, bool deleteRollup)
		{
			Array.ForEach(items, item =>
			{
				if (!string.IsNullOrEmpty(item))
				{
					_dataContext.PipelineEnrichedRequestsV2.DeleteOne(Builders<PipelineEnrichedRequest>.Filter.ElemMatch(u => u.OrderStage.Orders, o => o.OrderNo == item.Trim()) & filter);
					if (deleteRollup)
						_dataContext.RollupRequests.DeleteOne(Builders<RollupRequest>.Filter.ElemMatch(u => u.Details, o => o.OrderNo == item.Trim()) & rollupFilter);
				}
			});
		}

		/// <summary>
		/// This method deletes pipelineenrichedrequest based on invoice
		/// </summary>
		/// <param name="filter"></param>
		/// <param name="rollupFilter"></param>
		/// <param name="items"></param>
		/// <param name="deleteRollup"></param>
		private void DeleteInvoicePipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter, FilterDefinition<RollupRequest> rollupFilter,
			string[] items, bool deleteRollup)
		{
			Array.ForEach(items, item =>
			{
				if (!string.IsNullOrEmpty(item))
				{
					_dataContext.PipelineEnrichedRequestsV2.DeleteOne(Builders<PipelineEnrichedRequest>.Filter.ElemMatch(u => u.InvoiceStage.Invoices, o => o.InvoiceNo == item.Trim()) & filter);
					if (deleteRollup)
						_dataContext.RollupRequests.DeleteOne(Builders<RollupRequest>.Filter.ElemMatch(u => u.Details, o => o.InvoiceNo == item.Trim()) & rollupFilter);
				}
			});
		}
		#endregion

		/// <summary>
		/// This method reprocess messageid's of PipelineEnrichedRequest
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="identifier"></param>
		/// <param name="identifierList"></param>
		/// <returns></returns>
		[Route("Historic/{pipelineSource}/{identifier}/{identifierList}")]
		[HttpGet]
		#region PublishPipelineEnrichedRequest
		public IActionResult PublishPipelineEnrichedRequest(string pipelineSource, string identifier, string identifierList)
		{
			_logger.LogDebug("PublishPipelineEnrichedRequest started");

			try
			{
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var items = identifierList?.Split(",");

				identifier = identifier.Trim();
				pipelineSource = pipelineSource.Trim();

				if (items != null && items.Length > 0)
				{				
					if ("VOR".Equals(identifier, StringComparison.InvariantCultureIgnoreCase) ||
						"ORDER".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
                    {
						Array.ForEach(items, item =>
						{
							if (!string.IsNullOrEmpty(item))
								_rabbitMQueuePublisher.Publish(item, "q.banzai.pipeline.dell.enrichment");
						});
					}
					else if("INVOICE".Equals(identifier, StringComparison.InvariantCultureIgnoreCase))
                    {
						Array.ForEach(items, item =>
						{
							if (!string.IsNullOrEmpty(item))
							{
								if(pipelineSource.Equals("DELL", StringComparison.InvariantCultureIgnoreCase))
									_rabbitMQueuePublisher.Publish($"InvoiceRequest|{item}", "q.banzai.pipeline.dell.enrichment");
								else if (pipelineSource.Equals("EMC", StringComparison.InvariantCultureIgnoreCase))
									_rabbitMQueuePublisher.Publish($"InvoiceRequest|{item}", "q.banzai.pipeline.emc.enrichment");
								else if (pipelineSource.Equals("CHANNEL", StringComparison.InvariantCultureIgnoreCase))
									_rabbitMQueuePublisher.Publish($"InvoiceRequest|{item}", "q.banzai.pipeline.channel.enrichment");
							}
						});
					}
				}

				return Ok();
			}
			catch (Exception ex)
			{
				_logger.LogCritical($"PublishPipelineEnrichedRequest - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}
		#endregion

		/// <summary>
		/// This web api call returns Transaction Detail report 
		/// if record count is less than 100 else submits the request to a back ground processor
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[Route("GenerateTransactionDetailReport")]
		[HttpPost]
		[ExcludeFromCodeCoverage]
		#region GenerateTransactionDetailReport        
		public async Task<IActionResult> GenerateTransactionDetailReport([FromBody] SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			_logger.LogDebug("GenerateTransactionDetailReport Started...");

			try
			{
				if ("ALL".Equals(enrichedRequestLookupInfo.PipelineStage, StringComparison.InvariantCultureIgnoreCase))
					return await SearchPipelineEnrichment(enrichedRequestLookupInfo);
				else if ("VOR".Equals(enrichedRequestLookupInfo.PipelineStage, StringComparison.InvariantCultureIgnoreCase))
					return await SearchPipelineEnrichmentForVOR(enrichedRequestLookupInfo);
				else if ("ORDER".Equals(enrichedRequestLookupInfo.PipelineStage, StringComparison.InvariantCultureIgnoreCase))
					return await SearchPipelineEnrichmentForOrders(enrichedRequestLookupInfo);
				else if ("INVOICE".Equals(enrichedRequestLookupInfo.PipelineStage, StringComparison.InvariantCultureIgnoreCase))
					return await SearchPipelineEnrichmentForInvoices(enrichedRequestLookupInfo);
				else
				{
					_logger.LogWarning("GenerateTransactionDetailReport - NOT FOUND");
					return NotFound();
				}
			}
			catch (Exception ex)
			{
				_logger.LogError($"GenerateTransactionDetailReport - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method searches Enrichment for All pipeline stages
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private async Task<IActionResult> SearchPipelineEnrichment(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			List<SearchEnrichedResponseDto> result = null;
			var vorFilter = GetVorFilter(enrichedRequestLookupInfo);
			var orderFilter = GetOrderFilter(enrichedRequestLookupInfo);
			var invoiceFilter = GetInvoiceFilter(enrichedRequestLookupInfo);
			var vorCount = await _dataContext.PipelineEnrichedRequests.Find(vorFilter).CountAsync();
			var orderCount = await _dataContext.PipelineEnrichedRequests.Find(orderFilter).CountAsync();
			var invoiceCount = await _dataContext.PipelineEnrichedRequests.Find(invoiceFilter).CountAsync();

			if (vorCount + orderCount + invoiceCount > _settings.ReportsRecordLimit)
			{
				PublishTransactionDetailReportsQ(enrichedRequestLookupInfo);
				return Ok("Submitted to q.banzai.pipeline.transaction.detailreport.requests");
			}
			else if (vorCount == 0 && orderCount == 0 && invoiceCount == 0)
				return NotFound();
			else
				result = GetPipelineResult(enrichedRequestLookupInfo, vorFilter, orderFilter, invoiceFilter);

			if (result == null || !result.Any())
			{
				_logger.LogWarning("GetTransactionDetail - NOT FOUND");

				return NotFound();
			}

			return Ok(result);
		}

		/// <summary>
		/// This method gets pipeline result
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <param name="vorFilter"></param>
		/// <param name="orderFilter"></param>
		/// <param name="invoiceFilter"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private List<SearchEnrichedResponseDto> GetPipelineResult(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo,
			FilterDefinition<PipelineEnrichedRequest> vorFilter, FilterDefinition<PipelineEnrichedRequest> orderFilter,
			FilterDefinition<PipelineEnrichedRequest> invoiceFilter)
		{
			List<SearchEnrichedResponseDto> result = null;
			var vorResult = VorResponseMapper(_dataContext.PipelineEnrichedRequests.Find(vorFilter).Project<VorSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForVOR()).ToList());
			var orderResult = OrderResponseMapper(_dataContext.PipelineEnrichedRequests.Find(orderFilter).Project<OrdersSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForOrders()).ToList(), enrichedRequestLookupInfo);
			var invoiceResult = InvoiceResponseMapper(_dataContext.PipelineEnrichedRequests.Find(invoiceFilter).Project<InvoicesSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForInvoices()).ToList(), enrichedRequestLookupInfo);

			if (vorResult != null && vorResult.Count > 0)
			{
				if (orderResult != null && orderResult.Count > 0)
					vorResult.AddRange(orderResult);

				if (invoiceResult != null && invoiceResult.Count > 0)
					vorResult.AddRange(invoiceResult);

				result = vorResult;
			}
			else if (orderResult != null && orderResult.Count > 0)
			{
				if (invoiceResult != null && invoiceResult.Count > 0)
					orderResult.AddRange(invoiceResult);

				result = orderResult;
			}
			else if (invoiceResult != null && invoiceResult.Count > 0)
			{
				result = invoiceResult;
			}

			return result;
		}

		/// <summary>
		/// This method searches Enrichment for VOR pipeline stage
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private async Task<IActionResult> SearchPipelineEnrichmentForVOR(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			List<SearchEnrichedResponseDto> result = null;
			var vorFilter = GetVorFilter(enrichedRequestLookupInfo);
			var vorCount = await _dataContext.PipelineEnrichedRequests.Find(vorFilter)?.CountAsync();

			if (vorCount > _settings.ReportsRecordLimit)
			{
				PublishTransactionDetailReportsQ(enrichedRequestLookupInfo);
				return Ok("Submitted to PIPELINE_TRANSACTION_DETAIL_REPORT_REQUESTS_Q");
			}
			else if (vorCount == 0)
				return NotFound();
			else
				result = VorResponseMapper(_dataContext.PipelineEnrichedRequests.Find(vorFilter).Project<VorSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForVOR())?.ToList());

			if (result == null || !result.Any())
			{
				_logger.LogWarning("GetTransactionDetail for VOR - NOT FOUND");
				return NotFound();
			}

			return Ok(result);
		}

		/// <summary>
		/// This method returns VorFilter for transaction detail report generation
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private FilterDefinition<PipelineEnrichedRequest> GetVorFilter(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;
			var filter = builder.Eq(u => u.Common.PipelineSource, enrichedRequestLookupInfo.PipelineSource);
			filter = filter & builder.Eq(u => u.VorStage.Status.BanzaiUnbookedExposureFlag, enrichedRequestLookupInfo.BanzaiUnbookedExposureFlag);
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.BanzaiStatusCode) ? (filter & builder.Eq(u => u.VorStage.Status.BanzaiStatusCode, enrichedRequestLookupInfo.BanzaiStatusCode)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSOrphanFlag) ? (filter & builder.Eq(u => u.Common.DFSOrphanFlag, enrichedRequestLookupInfo.DFSOrphanFlag)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSProductSpace) ? (filter & builder.Eq(u => u.Common.DFSProductSpace, enrichedRequestLookupInfo.DFSProductSpace)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSCreditID) ? (filter & builder.Eq(u => u.Common.DFSCreditID, enrichedRequestLookupInfo.DFSCreditID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSUnbookedExposureID) ? (filter & builder.Eq(u => u.Common.DFSUnbookedExposureID, enrichedRequestLookupInfo.DFSUnbookedExposureID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.SourceBusinessUnit) ? (filter & builder.Eq(u => u.Common.SourceBusinessUnit, enrichedRequestLookupInfo.SourceBusinessUnit)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DellCustomerNumber) ? (filter & builder.Eq(u => u.Common.SourceCustomerID, enrichedRequestLookupInfo.DellCustomerNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DirectOpsRep) ? (filter & builder.Eq(u => u.Common.DirectOpsRep, enrichedRequestLookupInfo.DirectOpsRep)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSFinanceProduct) ? (filter & builder.Eq(u => u.Common.DFSFinanceProduct, enrichedRequestLookupInfo.DFSFinanceProduct)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.PurchaseOrderNumber) ? (filter & builder.Eq(u => u.Common.PurchaseOrderNumber, enrichedRequestLookupInfo.PurchaseOrderNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSVendorOrphanFlag) ? (filter & builder.Eq(u => u.Common.VendorOrphan, Convert.ToBoolean(enrichedRequestLookupInfo.DFSVendorOrphanFlag))) : filter;

			filter = filter & builder.Gte(u => u.VorStage.Status.BanzaiStatusCreateDateTime, enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeFrom)
						 & builder.Lte(u => u.VorStage.Status.BanzaiStatusCreateDateTime, enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeTo);

			return filter;
		}

		/// <summary>
		/// Vor response mapper for tuning data and formatting the same
		/// </summary>
		/// <param name="resultSet"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private static List<SearchEnrichedResponseDto> VorResponseMapper(IEnumerable<VorSearchDto> resultSet)
		{
			return (from record in resultSet
					where record?.VorStage != null
					select new SearchEnrichedResponseDto
					{
						// Common
						Pipeline = record.Common?.PipelineSource,

						Stage = "VOR",
						Sequence = record.VorStage.Status?.BanzaiStatusSequence,

						ID = record.VorID,

						Status = record.VorStage.Status?.BanzaiStatusCode,
						StatusDateTime = record.VorStage.Status?.BanzaiStatusCreateDateTime,
						SourceDateTime = record.VorStage.Status?.DecisionSourceDateTime,

						FinanceAmount = record.VorStage.DFSFinanceAmount,
						TotalAmount = record.VorStage.TotalAmount,

						VOR = record.VorID,
						VorFinanceAmt = record.VorStage.DFSFinanceAmount,

						PC = record.Common?.DFSPayCode,
						VORPC = record.Common?.SourcePaymentCategoryCode,
						FinanceProduct = record.Common?.DFSFinanceProduct,

						ProductSummary = record.VorStage.ProductSummary,
						DirectOpsRep = record.Common?.DirectOpsRep,
						PO = record.Common?.PurchaseOrderNumber,

						UDF1 = record.Common?.UserDefined1,

						UDF2 = record.Common?.UserDefined2,

						// Flags
						MLA = record.Common?.DFSCustomerMLAFlag,
						Orphan = record.Common?.DFSOrphanFlag,
						FunderOverideReview = record.Common?.DFSCustomerFundingSourceReviewFlag,
						CreditCautionList = record.Common?.DFSCreditCautionFlag,

						// Customer+
						CreditID = !string.IsNullOrEmpty(record.Common?.DFSCreditID) ? $"{record.Common?.DFSCreditID}/{record.Common?.DFSCreditSystem}" : null,
						UnBookedID = !string.IsNullOrEmpty(record.Common?.DFSUnbookedExposureID) ? $"{record.Common?.DFSUnbookedExposureID}/{record.Common?.DFSUnbookedExposureSystem}" : null,
						SourceID = record.Common?.SourceCustomerID,
						Name = string.IsNullOrEmpty(record.Common?.DFSCustomerName) ? record.Common?.SourceCustomerName : record.Common?.DFSCustomerName,
						EndUserContact = record.Common?.ShippingContactName,

						// Vendor
						VendorId = record.Common?.VendorId,
						VendorName = record.Common?.VendorName,
						VendorOrphan = record.Common?.VendorOrphan,
						// Ship Addr
						Line1 = record.Common?.ShippingAddressLine1,
						Line2 = record.Common?.ShippingAddressLine2,
						City = record.Common?.ShippingCity,
						State = record.Common?.ShippingState,
						Postal = record.Common?.ShippingPostalCode,
						Country = record.Common?.ShippingCountry,

						// LastUpdated
						SystemLastUpdated = record.Common?.BanzaiLastModifiedDateTime,
						UserLastUpdate = record.Common?.UserLastModifiedDate,
						UserLastUpdateBy = record.Common?.UserLastModifiedBy
					}).ToList();
		}

		/// <summary>
		/// This method searches Enrichment for Order pipeline stage
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private async Task<IActionResult> SearchPipelineEnrichmentForOrders(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			List<SearchEnrichedResponseDto> result = null;
			var orderFilter = GetOrderFilter(enrichedRequestLookupInfo);
			var orderCount = await _dataContext.PipelineEnrichedRequests.Find(orderFilter)?.CountAsync();

			if (orderCount > _settings.ReportsRecordLimit)
			{
				PublishTransactionDetailReportsQ(enrichedRequestLookupInfo);
				return Ok("Submitted to PIPELINE_TRANSACTION_DETAIL_REPORT_REQUESTS_Q");
			}
			else if (orderCount == 0)
				return NotFound();
			else
				result = OrderResponseMapper(_dataContext.PipelineEnrichedRequests.Find(orderFilter).Project<OrdersSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForOrders()).ToList(), enrichedRequestLookupInfo);

			if (result == null || !result.Any())
			{
				_logger.LogWarning("GetTransactionDetail for Order - NOT FOUND");
				return NotFound();
			}

			return Ok(result);
		}

		/// This method returns OrderFilter for transaction detail report generation
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private FilterDefinition<PipelineEnrichedRequest> GetOrderFilter(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;
			var filter = builder.Eq(u => u.Common.PipelineSource, enrichedRequestLookupInfo.PipelineSource);
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSOrphanFlag) ? (filter & builder.Eq(u => u.Common.DFSOrphanFlag, enrichedRequestLookupInfo.DFSOrphanFlag)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSProductSpace) ? (filter & builder.Eq(u => u.Common.DFSProductSpace, enrichedRequestLookupInfo.DFSProductSpace)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSCreditID) ? (filter & builder.Eq(u => u.Common.DFSCreditID, enrichedRequestLookupInfo.DFSCreditID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSUnbookedExposureID) ? (filter & builder.Eq(u => u.Common.DFSUnbookedExposureID, enrichedRequestLookupInfo.DFSUnbookedExposureID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.SourceBusinessUnit) ? (filter & builder.Eq(u => u.Common.SourceBusinessUnit, enrichedRequestLookupInfo.SourceBusinessUnit)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DellCustomerNumber) ? (filter & builder.Eq(u => u.Common.SourceCustomerID, enrichedRequestLookupInfo.DellCustomerNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DirectOpsRep) ? (filter & builder.Eq(u => u.Common.DirectOpsRep, enrichedRequestLookupInfo.DirectOpsRep)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSFinanceProduct) ? (filter & builder.Eq(u => u.Common.DFSFinanceProduct, enrichedRequestLookupInfo.DFSFinanceProduct)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.PurchaseOrderNumber) ? (filter & builder.Eq(u => u.Common.PurchaseOrderNumber, enrichedRequestLookupInfo.PurchaseOrderNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSVendorOrphanFlag) ? (filter & builder.Eq(u => u.Common.VendorOrphan, Convert.ToBoolean(enrichedRequestLookupInfo.DFSVendorOrphanFlag))) : filter;

			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.BanzaiStatusCode) ? (filter & builder.ElemMatch(x => x.OrderStage.Orders, u => u.Status.BanzaiStatusCode == enrichedRequestLookupInfo.BanzaiStatusCode)) : filter;
			filter = filter & builder.ElemMatch(x => x.OrderStage.Orders, u => u.Status.BanzaiUnbookedExposureFlag == enrichedRequestLookupInfo.BanzaiUnbookedExposureFlag);
			filter = filter & builder.ElemMatch(x => x.OrderStage.Orders, u => u.Status.BanzaiStatusCreateDateTime >= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeFrom && u.Status.BanzaiStatusCreateDateTime <= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeTo);

			return filter;
		}

		/// <summary>
		/// Order response mapper for tuning data and formatting the same
		/// </summary>
		/// <param name="resultSet"></param>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns>List<SearchEnrichedResponseDto></returns>
		[ExcludeFromCodeCoverage]
		private List<SearchEnrichedResponseDto> OrderResponseMapper(IEnumerable<OrdersSearchDto> resultSet, SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			var orderResponse = (from record in resultSet
								 where record != null
								 from order in record.OrderStage?.Orders
								 where order != null && order.Status?.BanzaiStatusCreateDateTime >= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeFrom &&
								 order.Status?.BanzaiStatusCreateDateTime <= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeTo &&
								 order.Status?.BanzaiUnbookedExposureFlag == enrichedRequestLookupInfo.BanzaiUnbookedExposureFlag
								 select new SearchEnrichedResponseDto
								 {
									 Pipeline = record.Common?.PipelineSource,

									 Stage = "ORDER",
									 Sequence = order.Status?.BanzaiStatusSequence,

									 ID = order.OrderNo,

									 Status = order.Status?.BanzaiStatusCode,
									 StatusDateTime = order.Status?.BanzaiStatusCreateDateTime,
									 SourceDateTime = order.Status?.DecisionSourceDateTime,

									 FinanceAmount = order.DFSFinanceAmount,
									 TotalAmount = order.TotalAmount,

									 VOR = record.VorID,
									 VorFinanceAmt = record.VorStage?.DFSFinanceAmount,

									 OrderNumber = order.OrderNo,
									 OrderSource = order.SourceOrigin,

									 PC = record.Common?.DFSPayCode,
									 VORPC = record.Common?.SourcePaymentCategoryCode,
									 FinanceProduct = record.Common?.DFSFinanceProduct,

									 ProductSummary = order.ProductSummary,
									 DirectOpsRep = record.Common?.DirectOpsRep,
									 PO = record.Common?.PurchaseOrderNumber,

									 ContractNo = order.ContractNum,

									 UDF1 = record.Common?.UserDefined1,

									 UDF2 = record.Common?.UserDefined2,

									 // Flags
									 MLA = record.Common?.DFSCustomerMLAFlag,
									 Orphan = record.Common?.DFSOrphanFlag,
									 FunderOverideReview = record.Common?.DFSCustomerFundingSourceReviewFlag,
									 CreditCautionList = record.Common?.DFSCreditCautionFlag,

									 // Customer+
									 CreditID = !string.IsNullOrEmpty(record.Common?.DFSCreditID) ? $"{record.Common?.DFSCreditID}/{record.Common?.DFSCreditSystem}" : null,
									 UnBookedID = !string.IsNullOrEmpty(record.Common?.DFSUnbookedExposureID) ? $"{record.Common?.DFSUnbookedExposureID}/{record.Common?.DFSUnbookedExposureSystem}" : null,
									 SourceID = record.Common?.SourceCustomerID,
									 Name = string.IsNullOrEmpty(record.Common?.DFSCustomerName) ? record.Common?.SourceCustomerName : record.Common?.DFSCustomerName,
									 EndUserContact = record.Common?.ShippingContactName,

									 // Vendor
									 VendorId = record.Common?.VendorId,
									 VendorName = record.Common?.VendorName,
									 VendorOrphan = record.Common?.VendorOrphan,

									 // Ship Addr
									 Line1 = record.Common?.ShippingAddressLine1,
									 Line2 = record.Common?.ShippingAddressLine2,
									 City = record.Common?.ShippingCity,
									 State = record.Common?.ShippingState,
									 Postal = record.Common?.ShippingPostalCode,
									 Country = record.Common?.ShippingCountry,

									 // LastUpdated
									 SystemLastUpdated = record.Common?.BanzaiLastModifiedDateTime,
									 UserLastUpdate = record.Common?.UserLastModifiedDate,
									 UserLastUpdateBy = record.Common?.UserLastModifiedBy
								 }).ToList();

			if (!string.IsNullOrEmpty(enrichedRequestLookupInfo.BanzaiStatusCode))
				orderResponse = orderResponse.Where(u => string.Equals(u.Status, enrichedRequestLookupInfo.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))?.ToList();

			return orderResponse;
		}

		/// <summary>
		/// This method searches Enrichment for Invoice pipeline stage
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private async Task<IActionResult> SearchPipelineEnrichmentForInvoices(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			List<SearchEnrichedResponseDto> result = null;
			var invoiceFilter = GetInvoiceFilter(enrichedRequestLookupInfo);
			var invoiceCount = await _dataContext.PipelineEnrichedRequests.Find(invoiceFilter)?.CountAsync();

			if (invoiceCount > _settings.ReportsRecordLimit)
			{
				PublishTransactionDetailReportsQ(enrichedRequestLookupInfo);
				return Ok("Submitted to PIPELINE_TRANSACTION_DETAIL_REPORT_REQUESTS_Q");
			}
			else if (invoiceCount == 0)
				return NotFound();
			else
				result = InvoiceResponseMapper(_dataContext.PipelineEnrichedRequests.Find(invoiceFilter).Project<InvoicesSearchDto>(PipelineEnrichedRequestsQuery.EnrichedReportProjectionForInvoices()).ToList(), enrichedRequestLookupInfo);

			if (result == null || !result.Any())
			{
				_logger.LogWarning("GetTransactionDetail for Invoice - NOT FOUND");
				return NotFound();
			}

			return Ok(result);
		}

		/// This method returns InvoiceFilter for transaction detail report generation
		/// </summary>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		private FilterDefinition<PipelineEnrichedRequest> GetInvoiceFilter(SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;
			var filter = builder.Eq(u => u.Common.PipelineSource, enrichedRequestLookupInfo.PipelineSource);
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSOrphanFlag) ? (filter & builder.Eq(u => u.Common.DFSOrphanFlag, enrichedRequestLookupInfo.DFSOrphanFlag)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSProductSpace) ? (filter & builder.Eq(u => u.Common.DFSProductSpace, enrichedRequestLookupInfo.DFSProductSpace)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSCreditID) ? (filter & builder.Eq(u => u.Common.DFSCreditID, enrichedRequestLookupInfo.DFSCreditID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSUnbookedExposureID) ? (filter & builder.Eq(u => u.Common.DFSUnbookedExposureID, enrichedRequestLookupInfo.DFSUnbookedExposureID)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.SourceBusinessUnit) ? (filter & builder.Eq(u => u.Common.SourceBusinessUnit, enrichedRequestLookupInfo.SourceBusinessUnit)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DellCustomerNumber) ? (filter & builder.Eq(u => u.Common.SourceCustomerID, enrichedRequestLookupInfo.DellCustomerNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DirectOpsRep) ? (filter & builder.Eq(u => u.Common.DirectOpsRep, enrichedRequestLookupInfo.DirectOpsRep)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSFinanceProduct) ? (filter & builder.Eq(u => u.Common.DFSFinanceProduct, enrichedRequestLookupInfo.DFSFinanceProduct)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.PurchaseOrderNumber) ? (filter & builder.Eq(u => u.Common.PurchaseOrderNumber, enrichedRequestLookupInfo.PurchaseOrderNumber)) : filter;
			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.DFSVendorOrphanFlag) ? (filter & builder.Eq(u => u.Common.VendorOrphan, Convert.ToBoolean(enrichedRequestLookupInfo.DFSVendorOrphanFlag))) : filter;

			filter = !string.IsNullOrEmpty(enrichedRequestLookupInfo.BanzaiStatusCode) ? (filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.Status.BanzaiStatusCode == enrichedRequestLookupInfo.BanzaiStatusCode)) : filter;
			filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.Status.BanzaiUnbookedExposureFlag == enrichedRequestLookupInfo.BanzaiUnbookedExposureFlag);
			filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.Status.BanzaiStatusCreateDateTime >= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeFrom && u.Status.BanzaiStatusCreateDateTime <= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeTo);

			if (enrichedRequestLookupInfo.InvoiceCreateDateTimeFrom != default(DateTime) && enrichedRequestLookupInfo.InvoiceCreateDateTimeTo != default(DateTime))
				filter = filter & builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceDate >= enrichedRequestLookupInfo.InvoiceCreateDateTimeFrom && u.InvoiceDate <= enrichedRequestLookupInfo.InvoiceCreateDateTimeTo);

			return filter;
		}

		/// <summary>
		/// Invoices response mapper for tuning data and formatting the same
		/// </summary>
		/// <param name="resultSet"></param>
		/// <param name="enrichedRequestLookupInfo"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private static List<SearchEnrichedResponseDto> InvoiceResponseMapper(IEnumerable<InvoicesSearchDto> resultSet, SearchPipelineEnrichedRequestDto enrichedRequestLookupInfo)
		{
			var invoiceResponse = (from record in resultSet
								   where record != null
								   from invoice in record.InvoiceStage?.Invoices
								   where invoice != null && invoice.Status?.BanzaiStatusCreateDateTime >= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeFrom &&
								   invoice.Status?.BanzaiStatusCreateDateTime <= enrichedRequestLookupInfo.BanzaiStatusCreateDateTimeTo &&
								   invoice.Status?.BanzaiUnbookedExposureFlag == enrichedRequestLookupInfo.BanzaiUnbookedExposureFlag
								   select new SearchEnrichedResponseDto
								   {
									   Pipeline = record.Common?.PipelineSource,

									   //Stage
									   Stage = "INVOICE",
									   Sequence = invoice.Status?.BanzaiStatusSequence,

									   ID = invoice.InvoiceNo,

									   //Status
									   Status = invoice.Status?.BanzaiStatusCode,
									   StatusDateTime = invoice.Status?.BanzaiStatusCreateDateTime,
									   SourceDateTime = invoice.Status?.DecisionSourceDateTime,

									   //FinanceAmount
									   FinanceAmount = invoice.TotalDFSFinanceAmount,
									   TotalAmount = invoice.TotalAmount,

									   //Vor
									   VOR = record.VorID,
									   VorFinanceAmt = record.VorStage?.DFSFinanceAmount,

									   //Order
									   OrderNumber = invoice.OrderNo,
									   OrderSource = record.OrderStage?.Orders?.FirstOrDefault(o => o.OrderNo == invoice.OrderNo)?.SourceOrigin,

									   //Invoice
									   InvoiceNo = invoice.InvoiceNo,
									   InvoiceType = invoice.InvoiceType,
									   OriginalInvoiceNo = invoice.OriginalInvoiceNo,
									   OriginalOrderNo = invoice.OriginalOrderNo,
									   InvoiceDate = invoice.InvoiceDate,
									   DFSOpportunityID = invoice.DFSOpportunityID,

									   // PC
									   PC = record.Common?.DFSPayCode,
									   VORPC = record.Common?.SourcePaymentCategoryCode,
									   FinanceProduct = record.Common?.DFSFinanceProduct,

									   // ProductSummary
									   ProductSummary = invoice.ProductSummary,
									   ServiceTagQty = invoice.TagCount,
									   TagVariance = invoice.TagVariance,
									   DirectOpsRep = record.Common?.DirectOpsRep,
									   PO = record.Common?.PurchaseOrderNumber,

									   ContractNo = invoice.ContractNum,

									   UDF1 = record.Common?.UserDefined1,

									   UDF2 = record.Common?.UserDefined2,

									   // Flags
									   MLA = record.Common?.DFSCustomerMLAFlag,
									   Orphan = record.Common?.DFSOrphanFlag,
									   FunderOverideReview = record.Common?.DFSCustomerFundingSourceReviewFlag,
									   CreditCautionList = record.Common?.DFSCreditCautionFlag,

									   // Customer+
									   CreditID = !string.IsNullOrEmpty(record.Common?.DFSCreditID) ? $"{record.Common?.DFSCreditID}/{record.Common?.DFSCreditSystem}" : null,
									   UnBookedID = !string.IsNullOrEmpty(record.Common?.DFSUnbookedExposureID) ? $"{record.Common?.DFSUnbookedExposureID}/{record.Common?.DFSUnbookedExposureSystem}" : null,
									   SourceID = record.Common?.SourceCustomerID,
									   Name = string.IsNullOrEmpty(record.Common?.DFSCustomerName) ? record.Common?.SourceCustomerName : record.Common?.DFSCustomerName,
									   EndUserContact = record.Common?.ShippingContactName,

									   // Vendors
									   VendorId = record.Common?.VendorId,
									   VendorName = record.Common?.VendorName,
									   VendorOrphan = record.Common?.VendorOrphan,

									   // Ship Addr
									   Line1 = record.Common?.ShippingAddressLine1,
									   Line2 = record.Common?.ShippingAddressLine2,
									   City = record.Common?.ShippingCity,
									   State = record.Common?.ShippingState,
									   Postal = record.Common?.ShippingPostalCode,
									   Country = record.Common?.ShippingCountry,

									   // LastUpdated
									   SystemLastUpdated = record.Common?.BanzaiLastModifiedDateTime,
									   UserLastUpdate = record.Common?.UserLastModifiedDate,
									   UserLastUpdateBy = record.Common?.UserLastModifiedBy
								   }).ToList();

			if (!string.IsNullOrEmpty(enrichedRequestLookupInfo.BanzaiStatusCode))
				invoiceResponse = invoiceResponse.Where(u => string.Equals(u.Status, enrichedRequestLookupInfo.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))?.ToList();

			return invoiceResponse;
		}

		/// <summary>
		/// This method publishes filter criteria to PIPELINE_TRANSACTION_DETAIL_REPORT_REQUESTS_Q to 
		/// generate TransactionDetail report in the background
		/// </summary>
		/// <param name="searchEnrichedRequestDto"></param>
		private void PublishTransactionDetailReportsQ([FromBody] SearchPipelineEnrichedRequestDto searchEnrichedRequestDto)
		{
			_logger.LogDebug("PIPELINE_TRANSACTION_DETAIL_REPORT_REQUESTS_Q - called");
            _rabbitMQueuePublisher.Publish(JsonConvert.SerializeObject(searchEnrichedRequestDto), "q.banzai.pipeline.transaction.detailreport.requests");
		}
		#endregion

		/// <summary>
		/// This method unlocks a given document based on document id
		/// </summary>
		/// <param name="documentID"></param>
		/// <returns></returns>
		[Route("Unlock/{documentID}")]
		[HttpPost]
		private IActionResult UnlockPipelineEnrichedDocument(string documentID)
		{
			try
			{
				UnlockPipelineEnrichedRequest(documentID);
				return Ok(true);
			}
			catch (Exception ex)
			{
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// This method unlocks PipelineEnrichedRequest
		/// </summary>
		/// <param name="id"></param>
		private void UnlockPipelineEnrichedRequest(string id)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var filter = builder.Eq(u => u.Id, id)
						 & builder.Eq(u => u.IsLocked, true);

			_dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
		}

		/// <summary>
		/// This method applies lock on EnrichedRequests for given ID
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest LockPipelineEnrichedRequest(string id)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var filter = builder.Eq(u => u.Id, id)
						 & builder.Eq(u => u.IsLocked, false);

			var docBeforeUpate = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true), ReturnDocument.Before);

			return docBeforeUpate;
		}
	}
}