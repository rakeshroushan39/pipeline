using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Rollups;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	public class RollupRequestsController : Controller
	{
		private readonly ILogger _logger;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly IDataContext _dataContext;

		public RollupRequestsController(ILogger<RollupRequestsController> logger, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _dataContext = mongoDataContext;
            _logger = logger;
		}

		[Obsolete("GetByCreditSystem is deprecated, please use GetByUnbookedExpSystem or GetRollupByUnbookedExpSystem instead.")]
        [HttpGet("api/Exposure/Credit")]
        #region GetByCreditSystem		
        public IActionResult GetByCreditSystem(string pipelineSource, string dfsCreditSystem = "",
			string dfsCreditId = "", string dfsUnbookedExposureSystem = "", string dfsUnbookedExposureId = "")
		{

			_logger.LogDebug($"GetByCreditSystem({pipelineSource}, {dfsCreditSystem}, {dfsCreditId}) items.");

			try
			{
				if (string.IsNullOrEmpty(pipelineSource))
				{
					ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");
				}

				else if (string.IsNullOrEmpty(dfsCreditSystem) && string.IsNullOrEmpty(dfsCreditId) && string.IsNullOrEmpty(dfsUnbookedExposureSystem) && string.IsNullOrEmpty(dfsUnbookedExposureId))
				{
					ModelState.AddModelError("(dfsCreditSystem and dfsCreditId) or (dfsUnbookedExposureSystem and dfsUnbookedExposureId)", "The combination of dfsCreditSystem/Id or dfsUnbookedExposureSystem/Id.");
				}
				else if ((!string.IsNullOrEmpty(dfsCreditSystem) && string.IsNullOrEmpty(dfsCreditId)) || (string.IsNullOrEmpty(dfsCreditSystem) && !string.IsNullOrEmpty(dfsCreditId)))
				{
					ModelState.AddModelError("dfsCreditSystem and dfsCreditId", "The combination of dfsCreditSystem/Id.");
				}

				else if ((!string.IsNullOrEmpty(dfsUnbookedExposureSystem) && string.IsNullOrEmpty(dfsUnbookedExposureId)) || (string.IsNullOrEmpty(dfsUnbookedExposureSystem) && !string.IsNullOrEmpty(dfsUnbookedExposureId)))
				{
					ModelState.AddModelError("dfsUnbookedExposureSystem and dfsUnbookedExposureId", "The combination of dfsUnbookedExposureSystem/Id.");
				}

				if (!ModelState.IsValid)
				{
					return BadRequest(ModelState);
				}

				var result = ExposureByCreditSystem(pipelineSource, dfsCreditSystem, dfsCreditId, dfsUnbookedExposureSystem, dfsUnbookedExposureId);

				if (result == null || !result.Any())
					return NotFound();

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetByCreditSystem({pipelineSource}, {dfsCreditSystem}, {dfsCreditId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// Gets exposure by credit system
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="dfsCreditSystem"></param>
		/// <param name="dfsCreditId"></param>
		/// <param name="dfsUnbookedExposureSystem"></param>
		/// <param name="dfsUnbookedExposureId"></param>
		/// <returns></returns>
		private IEnumerable<ExposureResponseDto> ExposureByCreditSystem(string pipelineSource, string dfsCreditSystem, string dfsCreditId, string dfsUnbookedExposureSystem = "", string dfsUnbookedExposureId = "")
		{
			// Filters DPID's which has atleast one record with DFSUnbookedExposure flag as true
			var match = new BsonDocument {
				{"PipelineSource", pipelineSource},
				{"Details.DFSUnbookedExposureFlag",true}
			};


			if (!string.IsNullOrEmpty(dfsCreditSystem) && !string.IsNullOrEmpty(dfsCreditId))
			{
				match.Add("DFSCreditSystem", dfsCreditSystem);
				match.Add("DFSCreditID", dfsCreditId);
			}

			if (!string.IsNullOrEmpty(dfsUnbookedExposureSystem) && !string.IsNullOrEmpty(dfsUnbookedExposureId))
			{
				match.Add("DFSUnbookedExposureSystem", dfsUnbookedExposureSystem);
				match.Add("DFSUnbookedExposureID", dfsUnbookedExposureId);
			}



			var builder = Builders<BsonDocument>.Filter;
			var filter = builder.Eq("Details.DFSUnbookedExposureFlag", true);
			var group = CreateCreditBsonGroup();

			var unbookedRecords = ExposureAggregate(match, filter, group);

			var aggregateResult = RegroupAndAggregate(unbookedRecords);

			return aggregateResult;
		}

		/// <summary>
		/// Credit BsonGrop for aggregations
		/// </summary>
		/// <returns></returns>
		private BsonDocument CreateCreditBsonGroup()
		{
			return new BsonDocument {
				{
					"_id", new BsonDocument {
						{"PipelineSource", "$PipelineSource"},
						{"DFSCreditSystem", "$DFSCreditSystem"},
						{"DFSCreditID", "$DFSCreditID"},
						{"PipelineStage", "$PipelineStage"},
						{"DFSUnbookedExposureSystem", "$DFSUnbookedExposureSystem"},
						{"DFSUnbookedExposureID", "$DFSUnbookedExposureID"},
						{"DFSPayCode", "$DFSPayCode"},
						{"DFSFinanceProduct", "$DFSFinanceProduct"},
						{"DFSSalesPipeline", "$DFSSalesPipeline"},
						{"DFSProductSpace", "$DFSProductSpace"},
						{"BanzaiStatusCode", "$Details.BanzaiStatusCode"}
					}
				},
				{"Quantity", new BsonDocument("$sum", 1)},
				{"Total", new BsonDocument("$sum", "$Details.DFSFinanceAmount")}
			};
		}

		/// <summary>
		/// Exposure and Aggregate on RollupRequests collection
		/// </summary>
		/// <param name="match"></param>
		/// <param name="filter"></param>
		/// <param name="group"></param>
		/// <returns></returns>
		private IList<BsonDocument> ExposureAggregate(BsonDocument match, FilterDefinition<BsonDocument> filter, BsonDocument group)
		{
            return _dataContext.RollupRequests.Aggregate(match, filter, group, "Details");
		}

		/// <summary>
		/// Regroups based on exposureresponse dto
		/// </summary>
		/// <param name="groupResult"></param>
		/// <returns></returns>
		private static IList<ExposureResponseDto> RegroupAndAggregate(IEnumerable<BsonDocument> groupResult)
		{
			var rollupCollection = new List<ExposureResponseDto>();

			foreach (var obj in groupResult)
			{
				var item = BsonSerializer.Deserialize<ExposureResponseDto>((BsonDocument)obj["_id"]);
				item.Quantity = obj["Quantity"].ToInt32();
				item.Total = obj["Total"].ToDecimal();

				rollupCollection.Add(item);
			}

			return rollupCollection;
		}
		#endregion

		[HttpGet("api/Exposure/UnbookedExp")]
		#region GetByUnbookedExpSystem
		public IActionResult GetByUnbookedExpSystem(string pipelineSource, string dfsUnbookedExposureSystem, string dfsUnbookedExposureId)
		{

			_logger.LogDebug($"GetByUnbookedExpSystem({pipelineSource}, {dfsUnbookedExposureSystem}, {dfsUnbookedExposureId}) items.");

			try
			{
				if (string.IsNullOrEmpty(pipelineSource))
					ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");

				if (string.IsNullOrEmpty(dfsUnbookedExposureSystem))
					ModelState.AddModelError("dfsUnbookedExposureSystem", "The provided DFS Unbooked Exposure System.");

				if (string.IsNullOrEmpty(dfsUnbookedExposureId))
					ModelState.AddModelError("dfsUnbookedExposureId", "The provided DFS Unbooked Exposure Id.");

				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var result = ExposureByUnbookedExpSystem(pipelineSource, dfsUnbookedExposureSystem, dfsUnbookedExposureId);

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetByUnbookedExpSystem({pipelineSource}, {dfsUnbookedExposureSystem}, {dfsUnbookedExposureId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// Gets exposure by UnbookedExposure system
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="dfsUnbookedExposureSystem"></param>
		/// <param name="dfsUnbookedExposureId"></param>
		/// <returns></returns>
		private decimal ExposureByUnbookedExpSystem(string pipelineSource, string dfsUnbookedExposureSystem, string dfsUnbookedExposureId)
		{
			var match = new BsonDocument {
				{"DFSUnbookedExposureID", dfsUnbookedExposureId},
				{"DFSUnbookedExposureSystem", dfsUnbookedExposureSystem},
				{"PipelineSource", pipelineSource},
				{"Details.DFSUnbookedExposureFlag",true}
			};

			var builder = Builders<BsonDocument>.Filter;
			var filter = builder.Eq("Details.DFSUnbookedExposureFlag", true);

			var group = new BsonDocument {
				{
					"_id", new BsonDocument()
				},
				{"Total", new BsonDocument("$sum", "$Details.DFSFinanceAmount")}
			};
            
			var result = _dataContext.RollupRequests.Aggregate(match, filter, group, "Details");
			return result.Count > 0 ? Math.Round(result[0]["Total"].ToDecimal(), 2) : 0.00m;
		}

        #endregion

        [HttpGet("api/Exposure/UnbookedExpRollup")]
        #region GetRollup CreditSystem & UnbookedExpSystem		
        public IActionResult GetRollupByUnbookedExpSystem(string pipelineSource, string dfsUnbookedExposureSystem, string dfsUnbookedExposureId)
		{

			_logger.LogDebug($"GetRollupByUnbookedExpSystem({pipelineSource}, {dfsUnbookedExposureSystem}, {dfsUnbookedExposureId}) items.");

			try
			{
				if (string.IsNullOrEmpty(pipelineSource))
				{
					ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");
				}

				if (string.IsNullOrEmpty(dfsUnbookedExposureSystem))
				{
					ModelState.AddModelError("dfsUnbookedExposureSystem", "The provided DFS Unbooked Exposure System.");
				}

				if (string.IsNullOrEmpty(dfsUnbookedExposureId))
				{
					ModelState.AddModelError("dfsUnbookedExposureId", "The provided DFS Unbooked Exposure Id.");
				}

				if (!ModelState.IsValid)
				{
					return BadRequest(ModelState);
				}

				var match = new BsonDocument {
					{"DFSUnbookedExposureID", dfsUnbookedExposureId},
					{"DFSUnbookedExposureSystem", dfsUnbookedExposureSystem},
					{"PipelineSource", pipelineSource},
					{"Details.DFSUnbookedExposureFlag",true}
				};

				var result = GenerateExposure(match);

				if (result == null || !result.Any())
					return NotFound();

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetRollupByUnbookedExpSystem({pipelineSource}, {dfsUnbookedExposureSystem}, {dfsUnbookedExposureId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		[HttpGet("api/Exposure/CreditRollup")]
		public IActionResult GetRollupByCreditSystem(string pipelineSource, string dfsCreditSystem, string dfsCreditId)
		{

			_logger.LogDebug($"GetRollupByCreditSystem({pipelineSource}, {dfsCreditSystem}, {dfsCreditId}) items.");

			try
			{
				if (string.IsNullOrEmpty(pipelineSource))
				{
					ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");
				}

				if (string.IsNullOrEmpty(dfsCreditSystem))
				{
					ModelState.AddModelError("dfsCreditSystem", "The provided DFS Credit System.");
				}

				if (string.IsNullOrEmpty(dfsCreditId))
				{
					ModelState.AddModelError("dfsCreditId", "The provided DFS Credit Id.");
				}

				if (!ModelState.IsValid)
				{
					return BadRequest(ModelState);
				}

				var match = new BsonDocument {
					{"DFSCreditID", dfsCreditId},
					{"DFSCreditSystem", dfsCreditSystem},
					{"PipelineSource", pipelineSource},
					{"Details.DFSUnbookedExposureFlag",true}
				};

				var result = GenerateExposure(match);

				if (result == null || !result.Any())
					return NotFound();

				return Ok(result);
			}
			catch (Exception ex)
			{
				_logger.LogError($"GetRollupByCreditSystem({pipelineSource}, {dfsCreditSystem}, {dfsCreditId}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

		/// <summary>
		/// Gets exposure by credit system
		/// </summary>
		private IEnumerable<ExposureResponseDto> GenerateExposure(BsonDocument match)
		{
			var filter = Builders<BsonDocument>.Filter.Eq("Details.DFSUnbookedExposureFlag", true);
			var group = new BsonDocument {
				{
					"_id", new BsonDocument {
						{"PipelineSource", "$PipelineSource"},
						{"DFSCreditSystem", "$DFSCreditSystem"},
						{"DFSCreditID", "$DFSCreditID"},
						{"PipelineStage", "$PipelineStage"},
						{"DFSUnbookedExposureSystem", "$DFSUnbookedExposureSystem"},
						{"DFSUnbookedExposureID", "$DFSUnbookedExposureID"},
						{"DFSPayCode", "$DFSPayCode"},
						{"DFSFinanceProduct", "$DFSFinanceProduct"},
						{"DFSSalesPipeline", "$DFSSalesPipeline"},
						{"DFSProductSpace", "$DFSProductSpace"},
						{"BanzaiStatusCode", "$Details.BanzaiStatusCode"}
					}
				},
				{"Quantity", new BsonDocument("$sum", 1)},
				{"Total", new BsonDocument("$sum", "$Details.DFSFinanceAmount")}
			};

			var unbookedRecords = _dataContext.RollupRequests.Aggregate(match, filter, group, "Details");

			var rollupCollection = new List<ExposureResponseDto>();

			foreach (var obj in unbookedRecords)
			{
				var item = BsonSerializer.Deserialize<ExposureResponseDto>((BsonDocument)obj["_id"]);
				item.Quantity = obj["Quantity"].ToInt32();
				item.Total = obj["Total"].ToDecimal();

				rollupCollection.Add(item);
			}

			return rollupCollection;
		}
		#endregion

		/// <summary>
		/// This method deletes EnrichedRequest
		/// </summary>
		/// <returns></returns>
		[Route("api/{pipelineSource}/{identifier}/{identifierList}")]
		[HttpDelete]
		#region DeleteRollupRequest
		public IActionResult DeleteRollupRequest(string pipelineSource, string identifier, string identifierList) {
			_logger.LogDebug("DeleteRollupRequest started");

			try {
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var items = identifierList?.Split(",");

				identifier = identifier.Trim();
				pipelineSource = pipelineSource.Trim();

				if (items != null && items.Length > 0) {

					var filter = Builders<RollupRequest>.Filter.Eq(u => u.PipelineSource, pipelineSource);

                    if (identifier.ToUpper().Equals("VOR"))
                        DeleteRollupForVor(items, filter);
                    else if (identifier.ToUpper().Equals("ORDER"))
                        DeleteRollupForOrder(items, filter);
                    else if (identifier.ToUpper().Equals("INVOICE"))
                        DeleteRollupForInvoice(items, filter);
				}

				return Ok();
			}
			catch (Exception ex) {
				_logger.LogCritical($"DeleteRollupRequest - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}

        /// <summary>
        /// This method deletes vor based on vor
        /// </summary>
        /// <param name="items"></param>
        /// <param name="filter"></param>
        private void DeleteRollupForVor(string[] items, FilterDefinition<RollupRequest> filter)
        {
            Array.ForEach(items, item =>
            {
                if (!string.IsNullOrEmpty(item))
                    _dataContext.RollupRequests.DeleteOne(filter & Builders<RollupRequest>.Filter.Eq(u => u.VorID, item.Trim()));
            });
        }

        /// <summary>
        /// This method deletes vor based on order
        /// </summary>
        /// <param name="items"></param>
        /// <param name="filter"></param>
        private void DeleteRollupForOrder(string[] items, FilterDefinition<RollupRequest> filter)
        {
            Array.ForEach(items, item =>
            {
                if (!string.IsNullOrEmpty(item))
                    _dataContext.RollupRequests.DeleteOne(filter & Builders<RollupRequest>.Filter.ElemMatch(u => u.Details,
                        o => o.OrderNo == item.Trim()));
            });
        }

        /// <summary>
        /// This method deletes vor based on invoice
        /// </summary>
        /// <param name="items"></param>
        /// <param name="filter"></param>
        private void DeleteRollupForInvoice(string[] items, FilterDefinition<RollupRequest> filter)
        {
            Array.ForEach(items, item => {
                if (!string.IsNullOrEmpty(item))
                    _dataContext.RollupRequests.DeleteOne(filter & Builders<RollupRequest>.Filter.ElemMatch(u => u.Details, 
                        i => i.InvoiceNo == item.Trim()));
            });
        }
        #endregion

        /// <summary>
        /// Republishing EnrichedRequests to Roll up Queue for a given pipeline
        /// </summary>
        [Route("api/RollupRequests/ReCreate/{pipelineSource}")]
        [HttpPost()]
        public IActionResult RecreateRollupRequests(string pipelineSource)
        {
            _logger.LogDebug("RecreateRollupRequests started");

            try
            {
                var filter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineSource);
                var projection = Builders<PipelineEnrichedRequest>.Projection.Include(u => u.Id);
                var pipelineEnrichedRequests = _dataContext.PipelineEnrichedRequestsV2.Find(filter, projection);

                foreach (var document in pipelineEnrichedRequests)
                    _rabbitMQueuePublisher.Publish(document["_id"].ToString(), "q.banzai.pipeline.rollup.requests");

                return Ok($"{pipelineEnrichedRequests.Count()} {pipelineSource} EnrichedRequests are published to RollupRequests Queue");
            }
            catch (Exception ex)
            {
                _logger.LogError($"RecreateRollupRequests - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                return StatusCode(500, "A problem happened while handling your request.");
            }
        }

        /// <summary>
        /// This method unlocks a given document based on collection name and document id
        /// </summary>
        /// <param name="documentID"></param>
        /// <returns></returns>
        [HttpPost("UnlockDocument/{documentID}")]
        public IActionResult UnlockDocument(string documentID)
        {
            try
            {
                UnlockRollupDocument(documentID);

                return Ok(true);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
            }
        }

        /// <summary>
        /// This method removes lock on RollupDocument for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockRollupDocument(string id)
        {
            var builder = Builders<RollupRequest>.Filter;

            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.RollupRequests.UpdateOne(filter, Builders<RollupRequest>.Update.Set(u => u.IsLocked, false));
        }
    }
}