using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
    [Route("api/ExclusionRules")]
	public class ExclusionRulesController : Controller {
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;
		private List<string> _message;
        private readonly IPublisher _rabbitMQueuePublisher;

        public ExclusionRulesController(ILogger<ExclusionRulesController> logger,
			IDataContext dataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;
			_dataContext = dataContext;
		}

		[HttpGet]
		public IActionResult GetAll() {
			_logger.LogDebug("GetAll items.");

			try {
				var items = _dataContext.ExclusionRules.GetAll();

				if (items == null || !items.Any()) {
					_logger.LogWarning("GetAll() - NOT FOUND");
					return NotFound();
				}

				return Json(items.ToList());
			}
			catch (Exception ex) {
				_logger.LogError($"Get() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        [Route("ManageBuid")]
		[HttpPost]
		public IActionResult ManageBuid([FromQuery(Name = "BUID")] string buid, [FromQuery(Name = "IsExcluded")] bool excluded, [FromQuery(Name = "Pipeline Source")] PipelineSource pipelineSource, [FromQuery(Name = "Pipeline Stage")] PipelineStage pipelineStage) {
			_logger.LogDebug("ManageBuid");

			try {
				if (!ModelState.IsValid) {
					return BadRequest(ModelState);
				}
				_message = new List<string>();
				var collection = new List<ExclusionRules>();
				var items = _dataContext.ExclusionRules.GetAll();

				if (string.IsNullOrEmpty(buid) && string.IsNullOrEmpty(pipelineSource.ToString()) && string.IsNullOrEmpty(pipelineStage.ToString()))
					return BadRequest();

				if (!string.IsNullOrEmpty(buid)) {
					var id = buid.Split(',');

					if (items.Any())
                        ProcessExclusionRules(id, items, pipelineSource, pipelineStage, excluded, collection);
					else
                        ProcessExclusionRulesForBuid(id, pipelineSource, pipelineStage, excluded, collection);
				}
				else {
					if (items.Any())
						foreach (var item in items) {
							_dataContext.ExclusionRules.FindOneAndUpdate(
								Builders<ExclusionRules>.Filter.Eq(u => u.BUID, item.BUID) &
								Builders<ExclusionRules>.Filter.Eq(u => u.PipelineSource, pipelineSource.ToString()) &
								Builders<ExclusionRules>.Filter.Eq(u => u.PipelineStage, pipelineStage.ToString()),
								Builders<ExclusionRules>.Update.Set(u => u.IsExcluded, excluded), ReturnDocument.After);
							_message.Add($"BUID-{item.BUID} is updated");
						}
				}
				return Json(_message);
			}
			catch (Exception ex) {
				_logger.LogError($"ManageBuid{buid}-{excluded}-{pipelineSource}-{pipelineStage} - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				return StatusCode(500, $"A problem happened while handling your request - {ex.Message}");
			}
		}       

        /// <summary>
        /// This method processes exclusion rules
        /// </summary>
        /// <param name="id"></param>
        /// <param name="items"></param>
        /// <param name="pipelineSource"></param>
        /// <param name="pipelineStage"></param>
        /// <param name="excluded"></param>
        /// <param name="collection"></param>
        private void ProcessExclusionRules(string[] id, IEnumerable<ExclusionRules> items, PipelineSource pipelineSource, 
            PipelineStage pipelineStage, bool excluded, List<ExclusionRules> collection)
        {
            foreach (var item in id)
            {
                var existedBUID = items.Where(x => x.BUID == item).Select(x => x.BUID).ToList();
                if (existedBUID.Any())
                {
                    _dataContext.ExclusionRules.FindOneAndUpdate(
                                  Builders<ExclusionRules>.Filter.Eq(u => u.BUID, item) &
                                  Builders<ExclusionRules>.Filter.Eq(u => u.PipelineSource, pipelineSource.ToString()) &
                                  Builders<ExclusionRules>.Filter.Eq(u => u.PipelineStage, pipelineStage.ToString()),
                                  Builders<ExclusionRules>.Update.Set(u => u.IsExcluded, excluded), ReturnDocument.After);

                    _message.Add($"BUID-{item} is updated");
                }
                else
                {
                    collection.Add(new ExclusionRules()
                    {
                        BUID = item,
                        IsExcluded = excluded,
                        PipelineSource = pipelineSource.ToString(),
                        PipelineStage = pipelineStage.ToString()
                    });
                    _message.Add($"BUID-{item} is created");
                    _dataContext.ExclusionRules.InsertMany(collection);
                }
            }
        }

        /// <summary>
        /// This method processes exclusion rules for given buid
        /// </summary>
        /// <param name="id"></param>
        /// <param name="pipelineSource"></param>
        /// <param name="pipelineStage"></param>
        /// <param name="excluded"></param>
        /// <param name="collection"></param>
        private void ProcessExclusionRulesForBuid(string[] id, PipelineSource pipelineSource,
            PipelineStage pipelineStage, bool excluded, List<ExclusionRules> collection)
        {
            foreach (var value in id)
            {
                collection.Add(new ExclusionRules()
                {
                    BUID = value,
                    IsExcluded = excluded,
                    PipelineSource = pipelineSource.ToString(),
                    PipelineStage = pipelineStage.ToString()
                });
                _message.Add($"BUID-{value} is created");
            }
            if (collection.Any())
                _dataContext.ExclusionRules.InsertMany(collection);
        }

        [JsonConverter(typeof(StringEnumConverter))]
		public enum PipelineSource {
			DELL = 1,
			EMC = 2
		}

		[JsonConverter(typeof(StringEnumConverter))]
		public enum PipelineStage {
			VOR = 1,
			ORDER = 2,
			INVOICE = 3
		}
	}
}