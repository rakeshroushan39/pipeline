using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.AspNetCore.Mvc.NewtonsoftJson;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Buffers;
using System.Collections.Generic;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/ClassafiInvoices")]
	public class ClassafiInvoicesController : Controller {
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;

        /// <summary>
        /// Parameter constructor to initialize default objects
        /// </summary>
        public ClassafiInvoicesController(IOptions<Settings> settings, ILogger<ClassafiInvoicesController> logger,
			IMailService mailService, IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _logger = logger;			
			_dataContext = mongoDataContext;
		}
     
        /// <summary>
        /// This method gets invoice details along with skulist in JsonFormat.
        /// </summary> 
        /// <param name="invoiceNo"></param>
        /// <param name="buid"></param>
        /// <returns></returns>
        [Route("Invoice/{invoiceNo}/Invoices")]
		[Route("Invoice/{invoiceNo}/Buid/{buid}/Invoices")]
		[HttpGet]
		public IActionResult GetInvoicesByInvoiceNoAndBuid(string invoiceNo, string buid = "") {
			var settings = new JsonSerializerSettings { Formatting = Formatting.Indented };

			OkObjectResult result;
			try
			{
				_logger.LogDebug($"ClassafiInvoices/GetInvoicesByInvoiceNoAndBuid({invoiceNo}-{buid})");

				var response = GetClassafiResponse("INVOICE", invoiceNo?.Trim(), buid?.Trim());

				result = Ok(response);
				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));
				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError($"ClassafiInvoices/GetInvoicesByInvoiceNoAndBuid({invoiceNo}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				var error = new ClassafiError()
				{
					Code = 500,
					State = "ERROR",
					Detail = $"Unhandled Exception : {ex.Message}"
				};

				result = Ok(new ClassafiResponseDto() { Errors = new List<ClassafiError> { error } });
				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

				return result;
			}
		}	

		/// <summary>
		/// This method gets invoice details along with skulist in JsonFormat.
		/// </summary>
		/// <param name="orderNo"></param>
		/// <param name="buid"></param>
		/// <returns></returns>
		[Route("Order/{orderNo}/Invoices")]
		[Route("Order/{orderNo}/Buid/{buid}/Invoices")]
		[HttpGet]
		public IActionResult GetInvoicesByOrderNoAndBuid(string orderNo, string buid = "") {
			var settings = new JsonSerializerSettings { Formatting = Formatting.Indented };

			OkObjectResult result;
			try
			{
				_logger.LogDebug($"ClassafiInvoices/GetInvoicesByOrderNoAndBuid({orderNo}-{buid})");

				var response = GetClassafiResponse("ORDER", orderNo?.Trim(), buid?.Trim());

				result = Ok(response);

				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

				return result;
			}
			catch (Exception ex)
			{
				_logger.LogError($"ClassafiInvoices/GetInvoicesByOrderNoAndBuid({orderNo}-{buid}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				var error = new ClassafiError()
				{
					Code = 500,
					State = "ERROR",
					Detail = $"Unhandled Exception : {ex.Message}"
				};

				result = Ok(new ClassafiResponseDto() { Errors = new List<ClassafiError> { error } });
				var options = new MvcOptions() { SuppressOutputFormatterBuffering = false };
				result.Formatters.Add(new NewtonsoftJsonOutputFormatter(settings, ArrayPool<char>.Shared, options));

				return result;
			}
		}

		/// <summary>
		/// This method searches EnrichedRequests based on invoice or order searchtype filter
		/// </summary>		
		/// <param name="searchType"></param>
		/// <param name="searchValue"></param>
		/// <param name="pipelineSource"></param>
		/// <returns>ClassafiResponseDto</returns>
		private ClassafiResponseDto GetClassafiResponse(string searchType, string searchValue, string buid, string pipelineSource = "DELL") {

			var request = ValidateClassafiInputRequest(searchType, searchValue);
			if (request != null)
				return request;

            FilterDefinition<ClassafiInvoice> searchTypeFilter = null;

			if ("INVOICE".Equals(searchType, StringComparison.InvariantCultureIgnoreCase))
				searchTypeFilter = Builders<ClassafiInvoice>.Filter.Eq(c => c.InvoiceNumber, searchValue);
			else if ("ORDER".Equals(searchType, StringComparison.InvariantCultureIgnoreCase))
				searchTypeFilter = Builders<ClassafiInvoice>.Filter.Eq(x => x.OrderNumber, searchValue);

			searchTypeFilter = searchTypeFilter & Builders<ClassafiInvoice>.Filter.Eq(u => u.PipelineSource, pipelineSource);

			if (!string.IsNullOrEmpty(buid))
				searchTypeFilter = searchTypeFilter & Builders<ClassafiInvoice>.Filter.Eq(u => u.BusinessUnitID, buid);

			var filter = Builders<ClassafiInvoice>.Filter.And(searchTypeFilter);

			var classafiInvoices = _dataContext.ClassafiInvoices.FindByFilter(filter);

			var classafiResponseDto = new ClassafiResponseDto {
				Errors = new List<ClassafiError>(),
				Invoices = new List<ClassafiInvoice>()
			};

			if (classafiInvoices == null || classafiInvoices.Count == 0) {
				var classafiError = new ClassafiError() {
					Code = 404,
					State = "ERROR"
				};

				classafiError.Detail = $"Not Found : {searchType}-{searchValue}";

				if (!string.IsNullOrEmpty(buid))
					classafiError.Detail += $";BusinessUnitID-{buid}";

				classafiResponseDto.Errors.Add(classafiError);
			}
			else
				classafiResponseDto.Invoices = classafiInvoices;

			return classafiResponseDto;
		}

		/// <summary>
		/// This method validates the Classafi input request and returns a ClassafiResponse if not valid
		/// </summary>
		/// <param name="searchType">ex : INVOICE or ORDER</param>
		/// <param name="searchValue"></param>
		/// <returns>ClassafiResponseDto</returns>
		private ClassafiResponseDto ValidateClassafiInputRequest(string searchType, string searchValue) {
			var errorDetail = new System.Text.StringBuilder();

			if (string.IsNullOrEmpty(searchValue)) {
				if (searchType.Equals("INVOICE"))
					errorDetail.Append("invoiceNo is BLANK");
				else
					errorDetail.Append("orderNo is BLANK");
			}

			if (!string.IsNullOrEmpty(errorDetail.ToString())) {
				var classafiResponse = new ClassafiResponseDto {
					Invoices = new List<ClassafiInvoice>()
				};

				classafiResponse.Errors = new List<ClassafiError> {
					new ClassafiError() {
						Code = 400,
						State = "ERROR",
						Detail = "BadRequest: " + errorDetail.ToString()
					}
				};

				return classafiResponse;
			}
			else
				return null;
		}
	}
}