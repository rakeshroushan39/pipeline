using AutoMapper;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.InvoiceTaxCombos;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Api.Controllers
{
	[Route("api/InvoiceTaxCombos")]
	public class InvoiceTaxCombosController : Controller {
		private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly IPublisher _rabbitMQueuePublisher;
		private readonly IMapper _mapper;

        public InvoiceTaxCombosController(ILogger<InvoiceTaxCombosController> logger,
			IDataContext mongoDataContext, IPublisher rabbitMQueuePublisher, IMapper mapper)
        {
            _rabbitMQueuePublisher = rabbitMQueuePublisher;
            _dataContext = mongoDataContext;
			_logger = logger;

			_mapper = mapper;
		}

		[HttpGet]
		public IActionResult GetAll() {
			_logger.LogDebug(LoggingEvents.GetItem, "GetAll items.");

			try {
				var items = _dataContext.InvoiceTaxCombos.GetAll();

				if (items == null || !items.Any()) {
					_logger.LogWarning(LoggingEvents.GetItemNotFound, "GetAll() - NOT FOUND");
					return NotFound();
				}

				var result = _mapper.Map<IEnumerable<InvoiceTaxComboDto>>(items);

				return Ok(result); //Rap result with Ok (200) status code
			}
			catch (Exception ex) {
				_logger.LogError($"GetAll() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        /// <summary>
        //  This is used by subsequenct controllers to generate URI for a given object ID.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id:length(24)}", Name = "GetInvoiceTaxComboById")]
		public IActionResult GetInvoiceTaxComboById(string id) {
			_logger.LogDebug(LoggingEvents.GetItem, $"GetById({id}) items.");

			try {
				var item = _dataContext.InvoiceTaxCombos.GetById(id);

				if (item == null) {
					_logger.LogWarning(LoggingEvents.GetItemNotFound, $"GetById({id}) - NOT FOUND");

					return NotFound();
				}

				var result = _mapper.Map<InvoiceTaxComboDto>(item);

				return Ok(result);
			}
			catch (Exception ex) {
				_logger.LogError($"GetById({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        /// <summary>
        /// Creates InvoiceTaxCombo entity and saves to Mongo
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
		[HttpPost]
		public IActionResult Create([FromBody] InvoiceTaxComboForCreationDto item) {
			_logger.LogDebug(LoggingEvents.GetItem, "Create() items.");

			try {
				if (!ModelState.IsValid) {
					return BadRequest(ModelState);
				}

				var invoiceTaxCombo = _mapper.Map<InvoiceTaxCombo>(item);

				invoiceTaxCombo.LastModifiedOn = DateTime.UtcNow;

				_dataContext.InvoiceTaxCombos.InsertOne(invoiceTaxCombo);

				var createdInvoiceTaxComboToReturn = _mapper.Map<InvoiceTaxComboForCreationDto>(invoiceTaxCombo);

				return CreatedAtRoute("GetInvoiceTaxComboById", new { id = invoiceTaxCombo.Id }, createdInvoiceTaxComboToReturn);
			}
			catch (Exception ex) {
				_logger.LogError($"Create() - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        /// <summary>
        /// Updates InvoiceTaxCombo entity and saves to Mongo
        /// </summary>
        /// <param name="id"></param>
        /// <param name="item"></param>
        /// <returns></returns>
		[HttpPut("{id:length(24)}")]
		public IActionResult Replace(string id, [FromBody] InvoiceTaxComboForUpdateDto item) {
			_logger.LogDebug(LoggingEvents.GetItem, $"Replace({id}) items.");

			try {
				if (!ModelState.IsValid)
					return BadRequest(ModelState);

				var finalItem = _mapper.Map<InvoiceTaxCombo>(item);

				finalItem.Id = id;
				finalItem.LastModifiedOn = DateTime.UtcNow;

                FilterDefinition<InvoiceTaxCombo> query = Builders<InvoiceTaxCombo>.Filter.Eq(e => e.Id, finalItem.Id);                
                return _dataContext.InvoiceTaxCombos.ReplaceOneAsync(query, finalItem) ? NoContent() : (IActionResult)NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"Replace({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}

        /// <summary>
        /// Deletes InvoiceTaxCombo entity and saves to Mongo
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
		[HttpDelete("{id:length(24)}")]
		public IActionResult Delete(string id) {
			_logger.LogDebug(LoggingEvents.GetItem, $"Delete({id}) items.");

			try {
				if (_dataContext.InvoiceTaxCombos.Remove(id)) 
					return NoContent(); // 204 No Content

				_logger.LogWarning(LoggingEvents.GetItemNotFound, $"Delete({id}) - NOT FOUND");

				return NotFound();
			}
			catch (Exception ex) {
				_logger.LogError($"Delete({id}) - EXCEPTION. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				return StatusCode(500, "A problem happened while handling your request.");
			}
		}		
	}
}