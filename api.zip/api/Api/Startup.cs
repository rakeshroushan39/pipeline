using AutoMapper;
using DFS.Banzai.Asset.Data;
using DFS.Banzai.Asset.Library.Interfaces;
using DFS.Banzai.Asset.Library.Mailer;
using DFS.Banzai.Data;
using DFS.Banzai.Invoice.Library.Models.LeaseWave;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Healthcheck;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Mailer;
using DFS.Banzai.Library.Models;
using DFS.Banzai.Library.Models.ChannelInvoiceUpload;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.Models.FinanceCombos;
using DFS.Banzai.Library.Models.InvoiceTaxCombos;
using DFS.Banzai.Library.Models.StatusCombos;
using DFS.Banzai.Library.RabbitMQ;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Serialization;
using Steeltoe.Extensions.Configuration.CloudFoundry;
using Steeltoe.Management.CloudFoundry;
using Steeltoe.Management.Endpoint;
using Steeltoe.Management.Endpoint.CloudFoundry;
using Steeltoe.Management.Endpoint.Env;
using Steeltoe.Management.Hypermedia;
using System.Diagnostics.CodeAnalysis;

namespace DFS.Banzai.Api
{
    [ExcludeFromCodeCoverage]
    public class Startup {
		public static IConfiguration Configuration { get; private set; }

		public Startup(IConfiguration configuration) {
			Configuration = configuration;
		}

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers()
            .AddNewtonsoftJson(options =>
             {
                 options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                 if (options.SerializerSettings.ContractResolver != null && options.SerializerSettings.ContractResolver is DefaultContractResolver castedResolver)
                     castedResolver.NamingStrategy = null;
             });

            services.AddMvc()
                .AddMvcOptions(o => o.EnableEndpointRouting = false)
                .AddMvcOptions(o => o.OutputFormatters.Add(
                    new XmlDataContractSerializerOutputFormatter()));
            
            services.Configure<Settings>(Configuration);            
            services.Configure<DFS.Banzai.Asset.Library.Entities.Settings>(Configuration);
            services.ConfigureCloudFoundryOptions(Configuration);

            //User of #if directive. Local Service is called only when build type is Debug. Otherwise, Cloud Service is called
            //Lifetime of the object is Transient - initialized per call
#if DEBUG
            services.AddTransient<IMailService, LocalMailService>();
#else
			services.AddTransient<IMailService, MailService>();
#endif

#if DEBUG
            services.AddTransient<IAssetMailService, AssetLocalMailService>();
#else
			services.AddTransient<IAssetMailService, AssetMailService>();
#endif
            services.AddScoped<IAssetDataContext, AssetMongoDataContext>();

            //Lifetime of the object is Singleton - initialized only once
            services.AddScoped<IDataContext, MongoDataContext>();

            //RabbitMQ setup            
            services.AddRabbitMQueueMessageBus(Configuration, ServiceLifetime.Scoped, true);

            //AutoMapper Configuration
            services.AddSingleton(c => GetMapperConfiguration());

            //Health check contributors for steel toe
            services.AddSingleton<Steeltoe.Common.HealthChecks.IHealthContributor, MongoDBHealthContributor>();

            // Add managment endpoint services
            services.AddCloudFoundryActuators(Configuration, MediaTypeVersion.V2, ActuatorContext.ActuatorAndCloudFoundry);
            services.AddEnvActuator(Configuration);
            services.AddHealthChecks();

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Banzai API", Version = "v1" });
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline. 
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
            if (env.IsDevelopment()) {
				app.UseDeveloperExceptionPage();
			}
			else {
                app.UseExceptionHandler(new ExceptionHandlerOptions
                {
                    ExceptionHandler = async context =>
                    {
                        context.Response.ContentType = "text/plain";
                        await context.Response.WriteAsync("Welcome to the error page.");
                    }
                });
            }

            // Add management endpoints into pipeline
            app.UseCloudFoundryActuators(MediaTypeVersion.V2, ActuatorContext.ActuatorAndCloudFoundry);
            app.UseEnvActuator();            
            app.UseCloudFoundrySecurity();
            app.UseHealthChecks("/health");            

            //Incase of failure, instead of blank page, displays status code
            app.UseStatusCodePages();

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Banzai API V1");
            });

            app.UseMvc();
        }

        /// <summary>
        /// This method returns mapper configuration
        /// </summary>
        /// <returns></returns>
        private IMapper GetMapperConfiguration()
        {
            var configuration = new MapperConfiguration(cfg => {
                //To map objects from Entity to repective DTO. 
                cfg.CreateMap<FinanceCombo, FinanceComboForCreationDto>();
                cfg.CreateMap<FinanceCombo, FinanceComboDto>();
                cfg.CreateMap<StatusCombo, StatusComboForDmlDto>();
                cfg.CreateMap<Library.Entities.Asset, InvoiceAssetsResponseDto>();
                cfg.CreateMap<ErrorLog, ErrorResponseDto>();
                cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboForCreationDto>();
                cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboDto>();

                cfg.CreateMap<Invoice.Library.Entities.Common, LeaseWaveCommonDto>();
                cfg.CreateMap<Invoice.Library.Entities.Invoice, LeaseWaveInvoiceDto>();
                cfg.CreateMap<Invoice.Library.Entities.InvoiceTaxDetail, LeaseWaveInvoiceTaxDetail>();
                cfg.CreateMap<Invoice.Library.Entities.InvoiceProductItem, LeaseWaveInvoiceProductItemDto>();
                cfg.CreateMap<Invoice.Library.Entities.InvoiceLine, LeaseWaveInvoiceLineDto>();
                cfg.CreateMap<Invoice.Library.Entities.InvoiceSubLine, LeaseWaveInvoiceSubLineDto>();
                cfg.CreateMap<InvoiceRequest, ChannelInvoiceUploadDto>();

                //To map objects from DTO to repective Entity.
                cfg.CreateMap<FinanceCombo, FinanceComboForCreationDto>().ReverseMap();
                cfg.CreateMap<FinanceComboForUpdateDto, FinanceCombo>();
                cfg.CreateMap<StatusCombo, StatusComboForDmlDto>().ReverseMap();
                cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboForCreationDto>().ReverseMap();
                cfg.CreateMap<InvoiceTaxComboForUpdateDto, InvoiceTaxCombo>();
                cfg.CreateMap<InvoiceRequest, ChannelInvoiceUploadDto>().ReverseMap();
            });

            return configuration.CreateMapper();
        }
    }
}
