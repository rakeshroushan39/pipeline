using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.FinanceCombos;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    //Context sharing tests during execution
    public class FinanceCombosControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;

		public FinanceCombosControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;
			_apiFixture.FinanceCombosController.ModelState.Clear();
		}

		//Need to understand this test cases and implement in Processors
		[Trait("API", "FinanceCombos_GetAll")]
		[Fact]
		public void Should_GetFinanceCombos_When_Available_V2()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = JsonConvert.SerializeObject(new List<FinanceComboDto>{
				new FinanceComboDto {
					Active = true,
					PipelineSource = "DELL",
					DFSFinanceProduct = "VOR",
					DFSPayCode = "NEW VOR",
					DFSPaymentMethodCode = "NEW",
					DFSProductSpace = "VOR-NEW",
					DFSSalesPipeline = "VOR Submitted",
					DFSCreditSystem = "Test",
					DFSUnbookedExposureSystem = "TestOne",
					SourcePaymentMethodCode = "HLD",
					SourcePaymentMethodCodeDesc = "Submitted"
				}
			});

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.GetAll()).Returns(GetFinanceCombos());

			//Act
			var result = _apiFixture.FinanceCombosController.GetAll();

			var actualFinanceCombo = JsonConvert.SerializeObject(((ObjectResult)result).Value as List<FinanceComboDto>);
			var actualStatusCode = ((ObjectResult)result).StatusCode;

			//Assert
			Assert.Equal(expectedDto, actualFinanceCombo);
			Assert.Equal(expectedStatus, actualStatusCode);
		}

		[Trait("API", "FinanceCombos_GetAll")]
		[Fact]
		public void Should_GetFinanceCombos_When_Available()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = new List<FinanceComboDto>{
				new FinanceComboDto {
					Active = true,
					PipelineSource = "DELL",
					DFSFinanceProduct = "VOR",
					DFSPayCode = "NEW VOR",
					DFSPaymentMethodCode = "NEW",
					DFSProductSpace = "VOR-NEW",
					DFSSalesPipeline = "VOR Submitted",
					DFSCreditSystem = "Test",
					DFSUnbookedExposureSystem = "TestOne",
					SourcePaymentMethodCode = "HLD",
					SourcePaymentMethodCodeDesc = "Submitted"
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.GetAll()).Returns(GetFinanceCombos());

			//Act
			var obj = _apiFixture.FinanceCombosController.GetAll();
			var actualDto = ((ObjectResult)obj).Value as List<FinanceComboDto>;
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);
			actualDto.Should().BeEquivalentTo(expectedDto);
		}

		[Trait("API", "FinanceCombos_GetAll")]
		[Fact]
		public void Should_RaiseNotFound_When_NotAvailable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.GetAll()).Returns(() => null);

			//Act
			var actual = _apiFixture.FinanceCombosController.GetAll() as NotFoundResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_GetAll")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.GetAll()).Throws<Exception>();

			//Act
			var actual = _apiFixture.FinanceCombosController.GetAll() as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "FinanceCombos_GetById")]
		[Fact]
		public void Should_GetFinanceCombos_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var financeComboid = "59b2ab05815e95090899a477";

			var expectedDto = JsonConvert.SerializeObject(new FinanceComboDto
			{
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "VOR",
				DFSPayCode = "NEW VOR",
				DFSPaymentMethodCode = "NEW",
				DFSProductSpace = "VOR-NEW",
				DFSSalesPipeline = "VOR Submitted",
				DFSCreditSystem = "Test",
				DFSUnbookedExposureSystem = "TestOne",
				SourcePaymentMethodCode = "HLD",
				SourcePaymentMethodCodeDesc = "Submitted"

			});
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.GetById(financeComboid)).Returns(GetFinanceCombosById);

			//Act.
			var actual = _apiFixture.FinanceCombosController.GetById(financeComboid) as OkObjectResult;

			var actualFinanceCombo = JsonConvert.SerializeObject(actual?.Value as FinanceComboDto);
			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);
			Assert.Equal(expectedDto, actualFinanceCombo);
		}

		[Trait("API", "FinanceCombos_GetById")]
		[Fact]
		public void Should_RaiseItemNotFound_When_InvalidIdRequestIsPassed()
		{
			// Arrange.
			var expected = (int)HttpStatusCode.NotFound;
			var financeComboid = "59b2ab05815e95090";
			_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.GetById(It.IsAny<string>())).Returns(() => null);

			//Act.
			var actual = _apiFixture.FinanceCombosController.GetById(financeComboid) as NotFoundResult;

			//Assert.
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_GetById")]
		[Fact]
		public void Should_RaiseException_When_IssueInGetById()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var financeComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.GetById(financeComboid)).Throws<Exception>();

			//Act
			var actual = _apiFixture.FinanceCombosController.GetById(financeComboid) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "FinanceCombos_Create")]
		[Fact]
		public void Should_CreateFinanceCombo_When_ObjectIsValid()
		{
			//Arrange			
			var expectedStatus = (int)HttpStatusCode.Created;
			
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.InsertOne(It.IsAny<FinanceCombo>()));

			//Act
			var actual = _apiFixture.FinanceCombosController.Create(CreateFinanceComboDto()) as ObjectResult;

			Assert.Equal(expectedStatus, actual?.StatusCode);

		}

		[Trait("API", "FinanceCombos_Create")]
		[Fact]
		public void Should_RaiseException_When_IssueInCreate()
		{

			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.InsertOne(It.IsAny<FinanceCombo>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.FinanceCombosController.Create(CreateFinanceComboDto()) as ObjectResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_Delete")]
		[Fact]
		public void Should_RaiseNoContentResult_When_NotAvalible()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var financeComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Remove(It.IsAny<string>())).Returns(true);

			//Act
			var actual = _apiFixture.FinanceCombosController.Delete(financeComboid) as NoContentResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "FinanceCombos_Delete")]
		[Fact]
		public void Should_RaiseNotFound_When_InvalidIdIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			var financeComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Remove(It.IsAny<string>())).Returns(false);

			//Act
			var actual = _apiFixture.FinanceCombosController.Delete(financeComboid) as NotFoundResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "FinanceCombos_Delete")]
		[Fact]
		public void Should_RaiseInternalServerError_When_InvalidRequest()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var financeComboid = "59b2ab05815e95090899a477";


			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Remove(It.IsAny<string>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.FinanceCombosController.Delete(financeComboid) as ObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);

		}

		[Trait("API", "FinanceCombos_Delete")]
		[Fact]
		public void Should_DeleteFinanceCombos_When_validIdRequestPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var financeComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Remove(financeComboid)).Returns(true);

			//Act
			var actual = _apiFixture.FinanceCombosController.Delete(financeComboid) as NoContentResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_Replace")]
		[Fact]
		public void Should_RaiseBadRequestException_When_InvalidObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;
			var financeComboid = "59b2ab05815e95090899a477";

			var financeComboForUpdateDto = new FinanceComboForUpdateDto {
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "VOR",
				DFSPayCode = "NEW VOR",
				DFSPaymentMethodCode = "NEW",
				DFSProductSpace = "VOR-NEW",
				DFSSalesPipeline = "VOR Submitted",
				DFSCreditSystem = "Test",
				DFSUnbookedExposureSystem = "TestOne",
				SourcePaymentMethodCode = "HLD",
				SourcePaymentMethodCodeDesc = "Submitted"
			};
			_apiFixture.FinanceCombosController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actual = _apiFixture.FinanceCombosController.Replace(financeComboid, financeComboForUpdateDto) as BadRequestObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_Replace")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidReplaceObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var financeComboid = "59b2ab05815e95090899a477";

			var _financeComboForUpdateDto = new FinanceComboForUpdateDto()
			{
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "VOR",
				DFSPayCode = "NEW VOR",
				DFSPaymentMethodCode = "NEW",
				DFSProductSpace = "VOR-NEW",
				DFSSalesPipeline = "VOR Submitted",
				DFSCreditSystem = "Test",
				DFSUnbookedExposureSystem = "TestOne",
				SourcePaymentMethodCode = "HLD",
				SourcePaymentMethodCodeDesc = "Submitted"
			};

			//Act
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<FinanceCombo>>(), It.IsAny<FinanceCombo>())).Throws<Exception>();
			var actual = _apiFixture.FinanceCombosController.Replace(financeComboid, _financeComboForUpdateDto) as ObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "FinanceCombos_Replace")]
		[Fact]
		public void Should_RaiseNotFoundResult_When_NotAvaliable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			var financeComboid = "59b2ab05815e95090899a477";
			var financeComboForUpdateDto = UpdateFinanceComboDto();

			//Don't delete: Using V2
			_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<FinanceCombo>>(), It.IsAny<FinanceCombo>())).Returns(() => false);

			//Don't delete: Using V1 with Task
			//ReplaceOneResult mockObj = new ReplaceOneResult.Acknowledged(0, 0, null);
			//Task<ReplaceOneResult> temp = new Task<ReplaceOneResult>(ReplaceObj);
			//_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<FinanceCombo>>(),
			//	It.IsAny<FinanceCombo>(), It.IsAny<UpdateOptions>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(mockObj));

			//Don't delete: Using V1
			//ReplaceOneResult mockObj = new ReplaceOneResult.Acknowledged(0, 0, null);
			//_apiFixture.MongoDataContext.Setup(T => T.FinanceCombos.ReplaceOne(It.IsAny<FilterDefinition<FinanceCombo>>(),
			//	It.IsAny<FinanceCombo>(), It.IsAny<UpdateOptions>(), It.IsAny<CancellationToken>())).Returns(mockObj);

			//Act
			var actual = _apiFixture.FinanceCombosController.Replace(financeComboid, financeComboForUpdateDto) as NotFoundResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		//Don't delete: Using V1 with Task - Should_RaiseNotFoundResult_When_NotAvaliable
		private ReplaceOneResult ReplaceObj() => new ReplaceOneResult.Acknowledged(0,0,null);

		[Trait("API", "FinanceCombos_Replace")]
		[Fact]
		public void Should_ReplaceFinanceCombos_When_Avaliable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var financeComboid = "59b2ab05815e95090899a477";
			var financeComboForUpdateDto = UpdateFinanceComboDto();

			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<FinanceCombo>>(), It.IsAny<FinanceCombo>())).Returns(() => true);

			//Act

			var actual = _apiFixture.FinanceCombosController.Replace(financeComboid, financeComboForUpdateDto) as NoContentResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "GetFinanceCombos")]
		[Fact]
		public void Should_GetFinanceCombos_When_Data_Not_Available()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.GetAll()).Returns(() => null);

			//Act
			var obj = _apiFixture.FinanceCombosController.GetFinanceCombos("DELL");
			var actualStatusCode = ((OkObjectResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);
			
		}
		[Trait("API", "GetFinanceCombos")]
		[Fact]
		public void Should_GetFinanceCombos_When_Data_Available()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Find(It.IsAny<FilterDefinition<FinanceCombo>>())).Returns(GetFinanceCombos());

			//Act
			var obj = _apiFixture.FinanceCombosController.GetFinanceCombos("DELL");
			var actualStatusCode = ((OkObjectResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetFinanceCombos")]
		[Fact]
		public void Should_GetFinanceCombos_When_Throws_Exception()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Find(It.IsAny<FilterDefinition<FinanceCombo>>())).Throws<Exception>();

			//Act
			var obj = _apiFixture.FinanceCombosController.GetFinanceCombos("DELL");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetFinanceCombos")]
		[Fact]
		public void Should_GetProductSpaces_When_Data_Not_Available()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.FinanceCombos.Find(It.IsAny<FilterDefinition<FinanceCombo>>())).Returns(GetFinanceCombos());

			//Act
			var obj = _apiFixture.FinanceCombosController.GetProductSpaces("DELL");
			var actualStatusCode = ((NotFoundResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		private FinanceComboForUpdateDto UpdateFinanceComboDto()
		{
			return new FinanceComboForUpdateDto
			{
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "LOAN-SW",
				DFSPayCode = "#",
				DFSPaymentMethodCode = "?",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSUnbookedExposureSystem = "RAPPORT",
				SourcePaymentMethodCode = "NP",
				SourcePaymentMethodCodeDesc = "DFS Loan/Software",
				SourcePaymentCategoryCode = "NP",
				SourcePaymentCategoryDesc = "LoanPayment",
				SourcePaymentTerms = "DFS LOAN/SOFTWARE"
			};
		}

		private FinanceComboForCreationDto CreateFinanceComboDto()
		{
			return new FinanceComboForCreationDto
			{
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "LOAN-SW",
				DFSPayCode = "#",
				DFSPaymentMethodCode = "?",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSUnbookedExposureSystem = "RAPPORT",
				SourcePaymentMethodCode = "NP",
				SourcePaymentMethodCodeDesc = "DFS Loan/Software",
				SourcePaymentCategoryCode = "NP",
				SourcePaymentCategoryDesc = "LoanPayment",
				SourcePaymentTerms = "DFS LOAN/SOFTWARE"
			};
		}

		private static IEnumerable<FinanceCombo> GetFinanceCombos()
		{
			return new List<FinanceCombo>
			{
				  new FinanceCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					DFSFinanceProduct = "VOR",
					DFSPayCode = "NEW VOR",
					DFSPaymentMethodCode = "NEW",
					DFSProductSpace = "VOR-NEW",
					DFSSalesPipeline = "VOR Submitted",
					DFSCreditSystem = "Test",
					DFSUnbookedExposureSystem = "TestOne",
					SourcePaymentMethodCode = "HLD",
					SourcePaymentMethodCodeDesc = "Submitted"
				}
			};
		}

		private static FinanceCombo GetFinanceCombosById()
		{
			return new FinanceCombo
			{
				Active = true,
				PipelineSource = "DELL",
				DFSFinanceProduct = "VOR",
				DFSPayCode = "NEW VOR",
				DFSPaymentMethodCode = "NEW",
				DFSProductSpace = "VOR-NEW",
				DFSSalesPipeline = "VOR Submitted",
				DFSCreditSystem = "Test",
				DFSUnbookedExposureSystem = "TestOne",
				SourcePaymentMethodCode = "HLD",
				SourcePaymentMethodCodeDesc = "Submitted"
			};
		}
	}
}
