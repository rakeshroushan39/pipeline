using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;
using Xunit.Abstractions;

namespace DFS.Banzai.Api.UnitTest
{
    [Collection("API collection")]
	public class ErrorsControllerTest
    {

		private readonly ApiFixture _apiFixture;
		private readonly ITestOutputHelper _output;

		public ErrorsControllerTest(ApiFixture apiFixture, ITestOutputHelper output)
		{
			_apiFixture = apiFixture;
			_output = output;
			_apiFixture.ErrorsController.ModelState.Clear();
		}

		//GetById Method Test cases
		[Trait("API", "Reports_GetById")]
		[Fact]
		public void Should_GetById_RaiseBadRequest_When_InvalidDate() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;			
			//Act
			var actualStatusCombo = _apiFixture.ErrorsController.GetError(GetInvalidStratDate(), GetInvalidEndDate()) as BadRequestObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatusCombo?.StatusCode);
		}

		//GetById Method Test cases
		[Trait("API", "Reports_GetById")]
		[Fact]
		public void Should_GetById_RaiseBadRequest_When_ModelstateInvalid() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;			
			//Act			
			_apiFixture.ErrorsController.ModelState.AddModelError("Banzai", "Adding Model Error");
			var actualStatusCombo = _apiFixture.ErrorsController.GetError(GetNewDate(), GetNewDate()) as BadRequestObjectResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatusCombo?.StatusCode);
		}

		//GetById Method Test cases
		[Trait("API", "Reports_GetById")]
		[Fact]
		public void Should_GetById_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange			
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.ErrorLogs.Find(It.IsAny<FilterDefinition<ErrorLog>>()))
				.Throws<Exception>();
			//Act			
			var actualStatusCombo = _apiFixture.ErrorsController.GetError(GetNewDate(), GetNewDate()) as ObjectResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatusCombo?.StatusCode);
		}

		//GetById Method Test cases
		[Trait("API", "Reports_GetById")]
		[Fact]
		public void Should_GetById_RaiseNotFound_When_NullIsPassed() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup((x=>x.ErrorLogs.Find(It.IsAny<FilterDefinition<ErrorLog>>())))
				.Returns(() => null);
			//Act			
			var actualStatusCombo = _apiFixture.ErrorsController.GetError(GetNewDate(), GetNewDate()) as NotFoundResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatusCombo?.StatusCode);
		}

		//GetById Method Test cases
		[Trait("API", "Reports_GetById")]
		[Fact]
		public void Should_GetById_When_ValidInput() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ErrorLogs.Find(It.IsAny<FilterDefinition<ErrorLog>>()))
				.Returns(() => GetStrategyError());			
			//Act			
			var actualStatusCombo = _apiFixture.ErrorsController.GetError(GetNewDate(), GetNewDate()) as OkObjectResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatusCombo?.StatusCode);
		}

		#region Private methods
		private static List<ErrorLog> GetStrategyError() {
			return new List<ErrorLog>() { new ErrorLog {
				Processor = "PipelineDellEnrichmentRequestsProcessor",
					Message = "some value",
					ErrorDetails = "There was some error in generating Reports"
			} };
		}
		private DateTime GetNewDate() {
			return new DateTime();
		}
		private DateTime GetInvalidStratDate() {
			return new DateTime(2008, 10, 25);
		}
		private DateTime GetInvalidEndDate() {
			return new DateTime(2008, 12, 25);
		}
		#endregion
	}
}
