﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Authentication;
using System.Text;
using System.Xml;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
   public class PipelineRequestsControllerTest : IClassFixture<ApiFixture>
    {
        private readonly ApiFixture _apiFixture;

        public PipelineRequestsControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
            _apiFixture.PipelineRequestsController.ModelState.Clear();
        }

		[Trait("API", "GetPipelineRequest")]
		[Fact]
		public void Should_GetPipelineRequest_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var id = "59b2ab05815e95090899a477";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineRequests.GetById(id)).Returns(GetPipelineRequest);

			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetPipelineRequest(id) as OkObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}


		[Trait("API", "GetPipelineRequest")]
		[Fact]
		public void Should_GetPipelineRequest_When_NotValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var id = "";
			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetPipelineRequest(id) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "PipelineInvoiceInboundNotifications")]
		[Fact]
		public void Should_PipelineInvoiceInboundNotifications_When_Found()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var id = "123";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.GetById(id)).Throws<XmlException>();

			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetPipelineInvoiceInboundNotifications(id) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "PipelineInvoiceInboundNotifications")]
		[Fact]
		public void Should_PipelineInvoiceInboundNotifications_When_NotFound()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var id = "123";
			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetPipelineInvoiceInboundNotifications(id) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "PipelineInvoiceInboundNotifications")]
		[Fact]
		public void Should_ProcessPipelineRequests_When_Found()
		{
			// Arrange.
			//Act.
			var actual = _apiFixture.PipelineRequestsController.ProcessPipelineRequests("DELL","ORDER","OCI") as ObjectResult;
			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "GetAuraInvoiceRequest")]
		[Fact]
		public void Should_GetAuraInvoiceRequest_When_NotFound()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetAuraInvoiceRequest("123") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetAuraInvoiceRequest")]
		[Fact]
		public void Should_GetAuraInvoiceRequest_When_Found()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineAuraInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineAuraInvoiceRequestDto>>())).Returns(GetPipelineAuraInvoiceRequestDto());
			var actual = _apiFixture.PipelineRequestsController.GetAuraInvoiceRequest("123") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetLeaseWaveContractRequest")]
		[Fact]
		public void Should_GetLeaseWaveContractRequest_When_NotFound()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			//Act.
			var actual = _apiFixture.PipelineRequestsController.GetLeaseWaveContractRequest("123") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetLeaseWaveContractRequest")]
		[Fact]
		public void Should_GetLeaseWaveContractRequest_When_Found()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.Find(It.IsAny<FilterDefinition<PipelineLeaseWaveContractRequestDto>>())).Returns(GetPipelineLeaseWaveContractRequestDto());
			var actual = _apiFixture.PipelineRequestsController.GetLeaseWaveContractRequest("123") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}




		private static PipelineRequest GetPipelineRequest()
		{
			return new PipelineRequest
			{

				PipelineSource = "DELL",
				Content = "{\r\n  \"Common\": {\r\n    \"PipelineSource\": \"CHANNEL\",\r\n    \"DFSCreditID\": \"12235\",\r\n    \"DFSCustomerName\": \"AUSTIN WINNELSON CO\",\r\n    \"DFSCountryName\": \"USA\",\r\n    \"DFSBusinessUnit\": \"11\",\r\n    \"DFSRegionCode\": \"AMERICAS\",\r\n    \"DFSCountryCode\": \"US\",\r\n    \"DFSLanguageCode\": \"EN\",\r\n    \"DirectOpsRep\": \"\",\r\n    \"Currency\": \"CAD\",\r\n    \"CurrencyName\": \"Canadian Dollar\",\r\n    \"DFSFinanceProduct\": \"LOAN\",\r\n    \"VendorId\": \"Vendor4\",\r\n    \"VendorName\": \"VendorName1\",\r\n    \"PurchaseOrderNumber\": \"\",\r\n    \"ShippingContactName\": \"\",\r\n    \"ShippingAddressLine1\": \"\",\r\n    \"ShippingAddressLine2\": \"\",\r\n    \"ShippingCity\": \"\",\r\n    \"ShippingState\": \"\",\r\n    \"ShippingPostalCode\": \"\",\r\n    \"ShippingCountry\": \"\",\r\n    \"UserLastModifiedBy\": \"Pony_Vagrecha\",\r\n    \"UserLastModifiedDate\": \"2020-04-13T07:08:27.3782722Z\"\r\n  },\r\n  \"InvoiceDetails\": {\r\n    \"InvoiceNo\": \"NewTemplate11\",\r\n    \"InvoiceDate\": \"2020-04-10T00:00:00\",\r\n    \"InvoiceType\": \"INVOICE\",\r\n    \"OrderNo\": \"\",\r\n    \"OriginalOrderNo\": \"\",\r\n    \"AssociatedOrderNo\": \"\",\r\n    \"OriginalInvoiceNo\": \"\",\r\n    \"TotalDFSFinanceAmount\": 1.0,\r\n    \"Freight\": 0.0,\r\n    \"SalesTax\": 0.0,\r\n    \"TotalAmount\": 1.0,\r\n    \"ExtendedAmount\": 1.0,\r\n    \"TagCount\": 0,\r\n    \"TagVariance\": 0,\r\n    \"FreightItemFlag\": false,\r\n    \"InvoiceLines\": [\r\n      {\r\n        \"LineNumber\": 1,\r\n        \"ItemID\": \"SHF\",\r\n        \"ItemDescription\": \"skjfh\",\r\n        \"Quantity\": 1,\r\n        \"ExtendedAmount\": 1.0,\r\n        \"EquipmentType\": \"EMC Upgrade\",\r\n        \"TagCount\": 0,\r\n        \"TagVariance\": 0,\r\n        \"ServiceTags\": \"\",\r\n        \"SalesTax\": 0.0,\r\n        \"InvoiceSubLines\": [\r\n          {\r\n            \"LineNumber\": 1,\r\n            \"ItemID\": \"f\",\r\n            \"ItemDescription\": \"j\",\r\n            \"Quantity\": 1,\r\n            \"ExtendedAmount\": 1.0,\r\n            \"ManufacturerItemId\": \"1\",\r\n            \"FinancingProductCode\": \"97210\",\r\n            \"CostType\": \"H\",\r\n            \"ItemSubType\": \"\",\r\n            \"ManufacturerName\": \"DELL\",\r\n            \"EnvironmentalFee\": 0.0,\r\n            \"SalesTax\": 0.0\r\n          }\r\n        ]\r\n      }\r\n    ],\r\n    \"Status\": {\r\n      \"DecisionSource\": \"USER UPLOAD\",\r\n      \"DecisionSourceStatusCode\": \"20\",\r\n      \"DecisionSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageType\": \"USER UPLOAD\",\r\n      \"MessageSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageReceivedDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"InvoiceNote\": \"\"\r\n    }\r\n  }\r\n}",
				TransactionType = "INVOICE",
				MessageType = "USER UPLOAD",
				InvoiceNo = "NewTemplate11",
				TimeStamp = DateTime.UtcNow

			};
		}
		private static List<PipelineAuraInvoiceRequestDto> GetPipelineAuraInvoiceRequestDto()
		{
			return new List<PipelineAuraInvoiceRequestDto> { new PipelineAuraInvoiceRequestDto {
				PipelineSource = "DELL",
			} };

		}
		private static List<PipelineLeaseWaveContractRequestDto> GetPipelineLeaseWaveContractRequestDto()
		{
			return new List<PipelineLeaseWaveContractRequestDto> { new PipelineLeaseWaveContractRequestDto {
				Id="123"
			} };

		}
	}
}
