﻿using DFS.Banzai.Asset.Library.Entities;
using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class EmcAssetRequestsControllerTest: IClassFixture<ApiFixture>
    {
        private readonly ApiFixture _apiFixture;

        public EmcAssetRequestsControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
        }
		[Trait("API", "EmcAssetRequestsController")]
		[Fact]
		public void Should_GetEMCAssets_when_validMessage()
		{
			//Arrange

			var invoices = "123";
			var piplinesource = "DELL";
			var expectedStatusCode = (int)HttpStatusCode.OK;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.EmcAssetRequests.Find(It.IsAny<FilterDefinition<Assets>>())).Returns(GetAssetRequests());
            //Act
            var actual = _apiFixture.EmcAssetRequestsController.GetEMCAssets(piplinesource, invoices) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
        [Trait("API", "EmcAssetRequestsController")]
        [Fact]
        public void Should_GetEMCAssets_when_NotvalidMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.EmcAssetRequests.Find(It.IsAny<FilterDefinition<Assets>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.EmcAssetRequestsController.GetEMCAssets(piplinesource, invoices) as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }


        #region Private Methods
        /// <summary>
        /// This method creates and returns asset request
        /// </summary>
        /// <returns></returns>
        private IEnumerable<Assets> GetAssetRequests()
        {
            List<Assets> assetRequests = new List<Assets>();

            assetRequests.Add(new Assets()
            {
                PipelineSource = "DELL",
                InvoiceNo = "123",
                AssetItems = new List<Library.Entities.Asset>(){ new Library.Entities.Asset() {
                    VendorId = "001162.0000",
                    TieNo = 1,
                    PONo = "11000-0000013689",
                    ManufacturerId = "001162.0000",
                    AssetFlag = "Y",
                    CostType = "RealTime",
                    MiscType ="qw" ,
                    ServiceTag = "NA",
                    Quantity = 4,
                    ItemNo = "PS-BAS-ESDTRRES",
                    Description = "Residency for Enterprise Storage -TR",
                    UnitPrice = 331,
                    RowTotal = 12,
                    EquipmentType = "RealTime",
                    ProductCode = "RealTime",
                    FinancingProductCode = "P01E4",
                    AddressOne = "2800 S ASHLAND AVE",
                    AddressTwo = "ASHLAND" ,
                    City = "CHICAGO",
                    State = "IL",
                    County = "USS",
                    Country ="US",
                    ZipCode = "60608", 
                    ProgramType = "RealTime",
                    TCredit = "123",
                    SoftwareDeliveryMethod = "we"
                } }

            });

            return assetRequests;
        }
        #endregion


    }
}
