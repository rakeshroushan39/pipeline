using AutoMapper;
using DFS.Banzai.Api.Controllers;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.Models.FinanceCombos;
using DFS.Banzai.Library.Models.InvoiceTaxCombos;
using DFS.Banzai.Library.Models.StatusCombos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using DFS.Banzai.Asset.Library.Interfaces;
using DFS.Banzai.Invoice.Library.Models.LeaseWave;
using Api.Controllers;
using DFS.Banzai.Library.Models.ChannelInvoiceUpload;

namespace DFS.Banzai.Api.UnitTest
{
    public class ApiFixture : IDisposable
	{
		public readonly CacheMgmtController CacheMgmtController;
		public readonly StatusCombosController StatusCombosController;
		public readonly FinanceCombosController FinanceCombosController;
		public readonly InvoiceTaxCombosController InvoiceTaxCombosController;
		public readonly Mock<IDataContext> MongoDataContext;
		public readonly Mock<IAssetDataContext> MongoDataContextAsset;
		public readonly MessagesController MessagesController;
		public readonly EmcAssetRequestsController EmcAssetRequestsController;
		public readonly RollupRequestsController RollupRequestsController;
		public readonly ChannelInvoicesController ChannelInvoicesController;
		public readonly PipelineEnrichedRequestsController PipelineEnrichedRequestsController;
		public readonly InvoiceEnrichedRequestsController InvoiceEnrichedRequestsController;
		public readonly AssetEnrichedRequestsController AssetEnrichedRequestsController;
		public readonly AuraInvoicesController AuraInvoicesController;
		public readonly ClassafiInvoicesController ClassafiInvoicesController;
		public readonly ExclusionRulesController ExclusionRulesController;
		public readonly GaapAttributesController GaapAttributesController;
		public readonly InvoiceRequestsController InvoiceRequestsController;
		public readonly OrderStatusController OrderStatusController;
		public readonly PipelineRequestsController PipelineRequestsController;
		public readonly ErrorsController ErrorsController;
        public readonly Mock<IPublisher> RMQPublisher;
		public readonly Mock<IMapper> MapperObj;

		public ApiFixture()
		{
			MongoDataContext = new Mock<IDataContext>();
			MongoDataContextAsset = new Mock<IAssetDataContext>();

			var settings = new Mock<IOptions<Settings>>();
			Settings getSettings = new Settings { DELL_OPS_EMAIL_ADDRESS = "DFS_IT_Originationss_Banzai_DEV@dell.com", ASPNETCORE_ENVIRONMENT = "Development" };
			settings.Setup(x => x.Value).Returns(() => getSettings);

			var assetsettings = new Mock<IOptions<DFS.Banzai.Asset.Library.Entities.Settings>>();
			Settings getSettingss = new Settings { DELL_OPS_EMAIL_ADDRESS = "DFS_IT_Originationss_Banzai_DEV@dell.com", ASPNETCORE_ENVIRONMENT = "Development" };
			settings.Setup(x => x.Value).Returns(() => getSettingss);

			RMQPublisher = new Mock<IPublisher>();
			MapperObj = new Mock<IMapper>();

            Queue[] queues = new Queue[35];

			var publisherQueue = new Mock<IPublisherQueue>();
			publisherQueue.Setup(x => x.Queues).Returns(queues);

			var mailService = new Mock<IMailService>();
			var assetmailService = new Mock<IAssetMailService>();

			var loggerStatusCombo = new Mock<ILogger<StatusCombosController>>();
			StatusCombosController = new StatusCombosController(loggerStatusCombo.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());

            var loggerFinanceCombo = new Mock<ILogger<FinanceCombosController>>();
			FinanceCombosController = new FinanceCombosController(loggerFinanceCombo.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());

			var loggerGaapAttributesController = new Mock<ILogger<GaapAttributesController>>();
			GaapAttributesController = new GaapAttributesController(settings.Object, loggerGaapAttributesController.Object, mailService.Object, MongoDataContext.Object, RMQPublisher.Object);

			var loggerInvoiceRequestsController = new Mock<ILogger<InvoiceRequestsController>>();
			InvoiceRequestsController = new InvoiceRequestsController(settings.Object, loggerInvoiceRequestsController.Object, MongoDataContext.Object, RMQPublisher.Object);


			var loggerMessages = new Mock<ILogger<MessagesController>>();
			MessagesController = new MessagesController(loggerMessages.Object, MongoDataContext.Object, RMQPublisher.Object);
			
			
			var loggerEmcAssetRequests = new Mock<ILogger<EmcAssetRequestsController>>();
			EmcAssetRequestsController = new EmcAssetRequestsController(settings.Object, loggerEmcAssetRequests.Object, mailService.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());
			
			var loggerAssetEnrichmentRequests = new Mock<ILogger<AssetRequestsController>>();
			AssetEnrichedRequestsController = new AssetEnrichedRequestsController(assetsettings.Object, loggerAssetEnrichmentRequests.Object, assetmailService.Object, MongoDataContextAsset.Object, RMQPublisher.Object);

			var loggerAuraInvoicesController = new Mock<ILogger<AuraInvoicesController>>();
			AuraInvoicesController = new AuraInvoicesController(settings.Object, loggerAuraInvoicesController.Object, mailService.Object, MongoDataContext.Object, MongoDataContextAsset.Object, RMQPublisher.Object, GetMapperConfiguration());

			var loggerRollups = new Mock<ILogger<RollupRequestsController>>();
			RollupRequestsController = new RollupRequestsController(loggerRollups.Object, MongoDataContext.Object, RMQPublisher.Object);
			
			var loggerOrderStatusController = new Mock<ILogger<OrderStatusController>>();
			OrderStatusController = new OrderStatusController(settings.Object, loggerOrderStatusController.Object, MongoDataContext.Object, RMQPublisher.Object);

			var loggerChannelInvoiceController = new Mock<ILogger<ChannelInvoicesController>>();
			ChannelInvoicesController = new ChannelInvoicesController(loggerChannelInvoiceController.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());

			var loggerPipelineEnrichedRequests = new Mock<ILogger<PipelineEnrichedRequestsController>>();
			PipelineEnrichedRequestsController = new PipelineEnrichedRequestsController(settings.Object, loggerPipelineEnrichedRequests.Object, mailService.Object, MongoDataContext.Object, RMQPublisher.Object);

			var loggerClassafiInvoicesController = new Mock<ILogger<ClassafiInvoicesController>>();
			ClassafiInvoicesController = new ClassafiInvoicesController(settings.Object, loggerClassafiInvoicesController.Object, mailService.Object, MongoDataContext.Object, RMQPublisher.Object);

			var loggerInvoiceEnrichedRequests = new Mock<ILogger<InvoiceEnrichedRequestsController>>();
			InvoiceEnrichedRequestsController = new InvoiceEnrichedRequestsController(settings.Object, loggerInvoiceEnrichedRequests.Object, mailService.Object, MongoDataContext.Object, RMQPublisher.Object);

            var loggerInvoiceTaxCombosController = new Mock<ILogger<InvoiceTaxCombosController>>();
			InvoiceTaxCombosController = new InvoiceTaxCombosController(loggerInvoiceTaxCombosController.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());
			
			var loggerExclusionRulesController = new Mock<ILogger<ExclusionRulesController>>();
			ExclusionRulesController = new ExclusionRulesController(loggerExclusionRulesController.Object, MongoDataContext.Object, RMQPublisher.Object);
			
			var loggerPipelineRequestsController = new Mock<ILogger<PipelineRequestsController>>();
			PipelineRequestsController = new PipelineRequestsController(loggerPipelineRequestsController.Object, MongoDataContext.Object, RMQPublisher.Object);


			var loggerCacheMgmt = new Mock<ILogger<CacheMgmtController>>();
			CacheMgmtController = new CacheMgmtController(loggerCacheMgmt.Object, MongoDataContext.Object, RMQPublisher.Object);

            var loggerErrors = new Mock<ILogger<ErrorsController>>();
			ErrorsController = new ErrorsController(settings.Object, loggerErrors.Object, MongoDataContext.Object, RMQPublisher.Object, GetMapperConfiguration());
        }		

		/// <summary>
		/// This method returns mapper configuration
		/// </summary>
		/// <returns></returns>
		private IMapper GetMapperConfiguration()
		{
			var configuration = new MapperConfiguration(cfg => {
				//To map objects from Entity to repective DTO. 
				cfg.CreateMap<FinanceCombo, FinanceComboForCreationDto>();
				cfg.CreateMap<InvoiceAssetsResponseDto, Library.Entities.Asset>();
				cfg.CreateMap<FinanceCombo, FinanceComboDto>();
				cfg.CreateMap<ChannelInvoiceUploadDto, Library.Entities.InvoiceRequest>();
				
				cfg.CreateMap<StatusCombo, StatusComboForDmlDto>();
				cfg.CreateMap<Library.Entities.Asset, InvoiceAssetsResponseDto>();
				cfg.CreateMap<ErrorLog, ErrorResponseDto>();
				cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboForCreationDto>();
				cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboDto>();
				cfg.CreateMap<Invoice.Library.Entities.Common, LeaseWaveCommonDto>();
				cfg.CreateMap<Invoice.Library.Entities.Invoice, LeaseWaveInvoiceDto>();
				cfg.CreateMap<Invoice.Library.Entities.InvoiceProductItem, LeaseWaveInvoiceProductItemDto>();
				cfg.CreateMap<Invoice.Library.Entities.InvoiceLine, LeaseWaveInvoiceLineDto>();
				cfg.CreateMap<Invoice.Library.Entities.InvoiceSubLine, LeaseWaveInvoiceSubLineDto>();


				


				//To map objects from DTO to repective Entity.
				cfg.CreateMap<FinanceCombo, FinanceComboForCreationDto>().ReverseMap();
				cfg.CreateMap<InvoiceAssetsResponseDto, Library.Entities.Asset>().ReverseMap();
				cfg.CreateMap<ChannelInvoiceUploadDto, Library.Entities.InvoiceRequest>().ReverseMap(); ;
				cfg.CreateMap<FinanceComboForUpdateDto, FinanceCombo>();
				cfg.CreateMap<StatusCombo, StatusComboForDmlDto>().ReverseMap();
				cfg.CreateMap<InvoiceTaxCombo, InvoiceTaxComboForCreationDto>().ReverseMap();
				cfg.CreateMap<InvoiceTaxComboForUpdateDto, InvoiceTaxCombo>();

			});

			return configuration.CreateMapper();
		}

		public void Dispose()
		{
			//Cleanup
			//Mapper.Reset();
		}
	}
}