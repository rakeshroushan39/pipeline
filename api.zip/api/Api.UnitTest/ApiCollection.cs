﻿using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
	[CollectionDefinition("API collection")]
	public class ApiCollection : ICollectionFixture<ApiFixture> {}
}