using DFS.Banzai.Library.Models.Enrichments;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Net;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class MessagesControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;

		public MessagesControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;

			_apiFixture.MessagesController.ModelState.Clear();
		}		

		[Trait("API", "Messages_Publish")]
		[Fact]
		public void Should_RaiseInvalidQueueExcepationMessage_when_InvalidQueueMessage()
		{
			//Arrange

			var message = "RABBITMQ_URI";
			var queue = "queue";
			var expectedStatusCode = (int)HttpStatusCode.BadRequest;
			_apiFixture.MessagesController.ModelState.AddModelError("message", "Invalid queue.");

			//Act
			var actual =  _apiFixture.MessagesController.Publish(queue, message) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "Messages_Publish")]
		[Fact]
		public void Should_RaiseBadRequestException_when_InvalidMessageAndQueue()
		{
			//Arrange
			var message = "";
			var queue = "";
			var expectedStatusCode = (int)HttpStatusCode.BadRequest;
			_apiFixture.MessagesController.ModelState.AddModelError("message", "Invalid Message.");

			//Act
			var actual =  _apiFixture.MessagesController.Publish(queue, message) as BadRequestObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}

		[Trait("API", "Messages_Publish")]
		[Fact]
		public void Should_Publish_When_Valid()
		{
			//Arrange
			var message = "RABBITMQ_URI";
			var queue = "100";
			var expectedStatusCode = (int)HttpStatusCode.OK;
            _apiFixture.RMQPublisher.Setup(x => x.Publish(It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(),
                5, false, false, false, null));

			//Act
			var actual =  _apiFixture.MessagesController.Publish(queue, message) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}


		[Trait("API", "Messages_Publish")]
		[Fact]
		public void Should_Publish_when_validQueueMessage()
		{
			//Arrange

			var message = "RABBITMQ_URI";
			var queue = "queue";
			int chunksize = 10;
			var expectedStatusCode = (int)HttpStatusCode.InternalServerError;
			_apiFixture.RMQPublisher.Setup(x => x.Publish(It.IsAny<string>(), It.IsAny<string>(),
				It.IsAny<string>(), It.IsAny<string>(),
				5, false, false, false, null));

			//Act
			var actual = _apiFixture.MessagesController.Publish(queue, chunksize,message) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
	}
}
