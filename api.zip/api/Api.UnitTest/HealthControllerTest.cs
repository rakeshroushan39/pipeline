using DFS.Banzai.Api.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class HealthControllerTest
		{
		[Trait("API", "HealthCheck")]
		[Fact]
		public void Should_RaiseHealthCheckSuccess_When_ValidObject()
			{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var logger = new Mock<ILogger<HealthController>>();
			var healthcontroller = new HealthController(logger.Object);
			
			//Act
			var actual = healthcontroller.HealthCheck() as OkObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actual?.StatusCode);
		}		
	}
}