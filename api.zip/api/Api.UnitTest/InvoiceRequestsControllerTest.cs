﻿using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace DFS.Banzai.Api.UnitTest
{
    public class InvoiceRequestsControllerTest : IClassFixture<ApiFixture>
    {

        private readonly ApiFixture _apiFixture;
        private readonly ITestOutputHelper _output;

        public InvoiceRequestsControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;

            _apiFixture.InvoiceRequestsController.ModelState.Clear();
        }
		[Trait("API", "GetInvoiceRequest")]
		[Fact]
		public void Should_GetInvoiceRequest_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var id = "59b2ab05815e95090899a477";
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceRequests.GetById(id)).Returns(GetinvoiceById);

			//Act.
			var actual = _apiFixture.InvoiceRequestsController.GetInvoiceRequest(id) as OkObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetInvoiceRequest")]
		[Fact]
		public void Should_GetInvoiceRequest_When_InvalidObjectIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var id = "";
			//_apiFixture.MongoDataContext.Setup(x => x.InvoiceRequests.GetById(id)).Returns(() => null);

			//Act.
			var actual = _apiFixture.InvoiceRequestsController.GetInvoiceRequest(id) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetMissingInvoiceRequests")]
		[Fact]
		public void Should_GetMissingInvoiceRequests_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.MissingInvoiceRequests.Find(It.IsAny<FilterDefinition<MissingInvoiceRequest>>()))
				.Returns(GetMissingInvoiceRequestsId);
			//Act.
			var actual = _apiFixture.InvoiceRequestsController.GetMissingInvoiceRequests() as NotFoundResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetMissingInvoiceRequests")]
		[Fact]
		public void Should_GetMissingInvoiceRequests_When_InvalidObjectIsPassed()
		{

			//Act.
			var actual = _apiFixture.InvoiceRequestsController.GetMissingInvoiceRequests() as ObjectResult;
			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "ResubmitMissingInvoiceRequests")]
		[Fact]
		public void Should_ResubmitMissingInvoiceRequests_When_NotValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var id = "1234b";
			_apiFixture.MongoDataContext.Setup(x => x.MissingInvoiceRequests.Find(It.IsAny<FilterDefinition<MissingInvoiceRequest>>()))
				.Returns(GetMissingInvoiceRequestsId);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineRequests.Find(It.IsAny<FilterDefinition<PipelineRequest>>()))
				.Returns(GetpipelineRequests);

			//Act.
			var actual = _apiFixture.InvoiceRequestsController.ResubmitMissingInvoiceRequests(id) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		private static InvoiceRequest GetinvoiceById()
		{
			return new InvoiceRequest
			{

				PipelineSource = "DELL",
				Content = "{\r\n  \"Common\": {\r\n    \"PipelineSource\": \"CHANNEL\",\r\n    \"DFSCreditID\": \"12235\",\r\n    \"DFSCustomerName\": \"AUSTIN WINNELSON CO\",\r\n    \"DFSCountryName\": \"USA\",\r\n    \"DFSBusinessUnit\": \"11\",\r\n    \"DFSRegionCode\": \"AMERICAS\",\r\n    \"DFSCountryCode\": \"US\",\r\n    \"DFSLanguageCode\": \"EN\",\r\n    \"DirectOpsRep\": \"\",\r\n    \"Currency\": \"CAD\",\r\n    \"CurrencyName\": \"Canadian Dollar\",\r\n    \"DFSFinanceProduct\": \"LOAN\",\r\n    \"VendorId\": \"Vendor4\",\r\n    \"VendorName\": \"VendorName1\",\r\n    \"PurchaseOrderNumber\": \"\",\r\n    \"ShippingContactName\": \"\",\r\n    \"ShippingAddressLine1\": \"\",\r\n    \"ShippingAddressLine2\": \"\",\r\n    \"ShippingCity\": \"\",\r\n    \"ShippingState\": \"\",\r\n    \"ShippingPostalCode\": \"\",\r\n    \"ShippingCountry\": \"\",\r\n    \"UserLastModifiedBy\": \"Pony_Vagrecha\",\r\n    \"UserLastModifiedDate\": \"2020-04-13T07:08:27.3782722Z\"\r\n  },\r\n  \"InvoiceDetails\": {\r\n    \"InvoiceNo\": \"NewTemplate11\",\r\n    \"InvoiceDate\": \"2020-04-10T00:00:00\",\r\n    \"InvoiceType\": \"INVOICE\",\r\n    \"OrderNo\": \"\",\r\n    \"OriginalOrderNo\": \"\",\r\n    \"AssociatedOrderNo\": \"\",\r\n    \"OriginalInvoiceNo\": \"\",\r\n    \"TotalDFSFinanceAmount\": 1.0,\r\n    \"Freight\": 0.0,\r\n    \"SalesTax\": 0.0,\r\n    \"TotalAmount\": 1.0,\r\n    \"ExtendedAmount\": 1.0,\r\n    \"TagCount\": 0,\r\n    \"TagVariance\": 0,\r\n    \"FreightItemFlag\": false,\r\n    \"InvoiceLines\": [\r\n      {\r\n        \"LineNumber\": 1,\r\n        \"ItemID\": \"SHF\",\r\n        \"ItemDescription\": \"skjfh\",\r\n        \"Quantity\": 1,\r\n        \"ExtendedAmount\": 1.0,\r\n        \"EquipmentType\": \"EMC Upgrade\",\r\n        \"TagCount\": 0,\r\n        \"TagVariance\": 0,\r\n        \"ServiceTags\": \"\",\r\n        \"SalesTax\": 0.0,\r\n        \"InvoiceSubLines\": [\r\n          {\r\n            \"LineNumber\": 1,\r\n            \"ItemID\": \"f\",\r\n            \"ItemDescription\": \"j\",\r\n            \"Quantity\": 1,\r\n            \"ExtendedAmount\": 1.0,\r\n            \"ManufacturerItemId\": \"1\",\r\n            \"FinancingProductCode\": \"97210\",\r\n            \"CostType\": \"H\",\r\n            \"ItemSubType\": \"\",\r\n            \"ManufacturerName\": \"DELL\",\r\n            \"EnvironmentalFee\": 0.0,\r\n            \"SalesTax\": 0.0\r\n          }\r\n        ]\r\n      }\r\n    ],\r\n    \"Status\": {\r\n      \"DecisionSource\": \"USER UPLOAD\",\r\n      \"DecisionSourceStatusCode\": \"20\",\r\n      \"DecisionSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageType\": \"USER UPLOAD\",\r\n      \"MessageSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageReceivedDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"InvoiceNote\": \"\"\r\n    }\r\n  }\r\n}",
				TransactionType = "INVOICE",
				MessageType = "USER UPLOAD",
				InvoiceNo = "NewTemplate11",
				TimeStamp = DateTime.UtcNow

			};
		}
	
		private static List<MissingInvoiceRequest> GetMissingInvoiceRequestsId() => new List<MissingInvoiceRequest>{new MissingInvoiceRequest {
				PipelineSource = "DELL",
				MessageType = "USER UPLOAD",
				InvoiceNo = "NewTemplate11",
				DecisionSource = "EDI_DFS",
				DecisionSourceDateTime = DateTime.UtcNow,
				DecisionSourceStatusCode = "20",
				SourceBusinessUnitID= "707",
				ReferenceID = "1111155846",
				CorrelationID = "44707d85-0129-4a70-a9b7-b7b88b8ef343",
				CreateDateTime = DateTime.UtcNow,
				MessageID = "5ee8e151bf0a7f000ee5e7d4"

		} };

		private static List<PipelineRequest> GetpipelineRequests() => new List<PipelineRequest>{new PipelineRequest {
				PipelineSource = "DELL",
				//Content = "{\r\n  \"Common\": {\r\n    \"PipelineSource\": \"DELL\",\r\n    \"DFSCreditID\": \"12235\",\r\n    \"DFSCustomerName\": \"AUSTIN WINNELSON CO\",\r\n    \"DFSCountryName\": \"USA\",\r\n    \"DFSBusinessUnit\": \"11\",\r\n    \"DFSRegionCode\": \"AMERICAS\",\r\n    \"DFSCountryCode\": \"US\",\r\n    \"DFSLanguageCode\": \"EN\",\r\n    \"DirectOpsRep\": \"\",\r\n    \"Currency\": \"CAD\",\r\n    \"CurrencyName\": \"Canadian Dollar\",\r\n    \"DFSFinanceProduct\": \"LOAN\",\r\n    \"VendorId\": \"Vendor4\",\r\n    \"VendorName\": \"VendorName1\",\r\n    \"PurchaseOrderNumber\": \"\",\r\n    \"ShippingContactName\": \"\",\r\n    \"ShippingAddressLine1\": \"\",\r\n    \"ShippingAddressLine2\": \"\",\r\n    \"ShippingCity\": \"\",\r\n    \"ShippingState\": \"\",\r\n    \"ShippingPostalCode\": \"\",\r\n    \"ShippingCountry\": \"\",\r\n    \"UserLastModifiedBy\": \"Pony_Vagrecha\",\r\n    \"UserLastModifiedDate\": \"2020-04-13T07:08:27.3782722Z\"\r\n  },\r\n  \"InvoiceDetails\": {\r\n    \"InvoiceNo\": \"NewTemplate11\",\r\n    \"InvoiceDate\": \"2020-04-10T00:00:00\",\r\n    \"InvoiceType\": \"INVOICE\",\r\n    \"OrderNo\": \"\",\r\n    \"OriginalOrderNo\": \"\",\r\n    \"AssociatedOrderNo\": \"\",\r\n    \"OriginalInvoiceNo\": \"\",\r\n    \"TotalDFSFinanceAmount\": 1.0,\r\n    \"Freight\": 0.0,\r\n    \"SalesTax\": 0.0,\r\n    \"TotalAmount\": 1.0,\r\n    \"ExtendedAmount\": 1.0,\r\n    \"TagCount\": 0,\r\n    \"TagVariance\": 0,\r\n    \"FreightItemFlag\": false,\r\n    \"InvoiceLines\": [\r\n      {\r\n        \"LineNumber\": 1,\r\n        \"ItemID\": \"SHF\",\r\n        \"ItemDescription\": \"skjfh\",\r\n        \"Quantity\": 1,\r\n        \"ExtendedAmount\": 1.0,\r\n        \"EquipmentType\": \"EMC Upgrade\",\r\n        \"TagCount\": 0,\r\n        \"TagVariance\": 0,\r\n        \"ServiceTags\": \"\",\r\n        \"SalesTax\": 0.0,\r\n        \"InvoiceSubLines\": [\r\n          {\r\n            \"LineNumber\": 1,\r\n            \"ItemID\": \"f\",\r\n            \"ItemDescription\": \"j\",\r\n            \"Quantity\": 1,\r\n            \"ExtendedAmount\": 1.0,\r\n            \"ManufacturerItemId\": \"1\",\r\n            \"FinancingProductCode\": \"97210\",\r\n            \"CostType\": \"H\",\r\n            \"ItemSubType\": \"\",\r\n            \"ManufacturerName\": \"DELL\",\r\n            \"EnvironmentalFee\": 0.0,\r\n            \"SalesTax\": 0.0\r\n          }\r\n        ]\r\n      }\r\n    ],\r\n    \"Status\": {\r\n      \"DecisionSource\": \"USER UPLOAD\",\r\n      \"DecisionSourceStatusCode\": \"20\",\r\n      \"DecisionSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageType\": \"USER UPLOAD\",\r\n      \"MessageSourceDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"MessageReceivedDateTime\": \"2020-04-13T07:08:27.3832624Z\",\r\n      \"InvoiceNote\": \"\"\r\n    }\r\n  }\r\n}",
				TransactionType = "INVOICE",
				Content = "{}",
				MessageType = "USER UPLOAD",
				InvoiceNo = "NewTemplate11",
				Id="1234b"

		} };
	}
}
