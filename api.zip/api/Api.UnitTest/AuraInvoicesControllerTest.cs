﻿using DFS.Banzai.Asset.Library.Entities;
using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Invoice.Library.Models.LeaseWave;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class AuraInvoicesControllerTest: IClassFixture<ApiFixture>
    {

        private readonly ApiFixture _apiFixture;

        public AuraInvoicesControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
        }

        [Trait("API", "AuraInvoicesControllerTest")]
        [Fact]
        public void Should_GetAuraInvoice_when_validMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "1234";
            var vendorid = "234";
            var expectedStatusCode = (int)HttpStatusCode.OK;
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "DELL",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m,
								ServiceTags= "qw",
								InvoiceSubLines = new List<InvoiceSubLine>()
									{
										new InvoiceSubLine
										{
										  EnvironmentalFee=123,
										}
									 }
							}
					   },
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
                .Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(GetAssetEnrichedRequests());
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as OkObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
		[Trait("API", "AuraInvoicesControllerTest")]
		[Fact]
		public void Should_GetAuraInvoice_when_NotvalidMessage()
		{
			//Arrange

			var invoices = "123";
			var piplinesource = "DELL";
			var buid = "1234";
			var vendorid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "DELL",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m,
								ServiceTags= "qw",
							}
					   },
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(() => null);

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "AuraInvoicesControllerTest")]
		[Fact]
		public void Should_GetAuraInvoice_when_ThrowsException()
		{
			//Arrange

			var invoices = "123";
			var piplinesource = "DELL";
			var buid = "1234";
			var vendorid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "DELL",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m,
								ServiceTags= "qw",
							}
					   },
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Throws<Exception>();

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "AuraInvoicesControllerTest")]
		[Fact]
		public void Should_GetAuraInvoice_when_ThrowsException_when_invoiveEnrichment()
		{
			//Arrange

			var invoices = "123";
			var piplinesource = "DELL";
			var buid = "1234";
			var vendorid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "DELL",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m,
								ServiceTags= "qw",
							}
					   },
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Throws<Exception>();
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Throws<Exception>();

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "AuraInvoicesControllerTest")]
		[Fact]
		public void Should_GetAuraInvoice_when_ThrowsException_when_All_Null()
		{
			//Arrange

			var invoices = "";
			var piplinesource = "";
			var buid = "";
			var vendorid = "";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Throws<Exception>();
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Throws<Exception>();
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "AuraInvoicesControllerTest")]
		[Fact]
		public void Should_GetAuraInvoice_when_Not_validMessage()
		{
			//Arrange

			var invoices = "123";
			var piplinesource = "DELL";
			var buid = "1234";
			var vendorid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>())).Returns(() => null);
			_apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(GetAssetEnrichedRequests());
			//Act
			var actual = _apiFixture.AuraInvoicesController.GetAuraInvoice(piplinesource, invoices, buid, vendorid) as ObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}

		/// <summary>
		/// This method creates and return list of AssetEnrichedRequests
		/// </summary>
		/// <returns></returns>
		private List<AssetEnrichedRequest> GetAssetEnrichedRequests()
		{
			return new List<AssetEnrichedRequest> { GetAssetEnrichedRequest() };
		}

		/// <summary>
		/// This method returns expected AssetEnrichedRequest
		/// </summary>
		/// <returns></returns>
		private AssetEnrichedRequest GetAssetEnrichedRequest()
		{
			var classifyDetailRes = BsonSerializer.Deserialize<BsonDocument>
		(@"{""CorrelationId"" : ""bf43a7da-632a-450b-8205-668799e42280"", 
        ""AssetType"" : ""DELL_DIRECT"", 
        ""PipelineSource"" : ""DELL"", 
        ""VendorId"" : null, 
        ""InvoiceNumber"" : ""3681324978"", 
        ""BusinessUnitId"" : ""707"", 
        ""CogsEnrichmentDate"" : null, 
        ""RevenueEnrichmentDate"" : null, 
        ""GaapEnrichmentDate"" : ""2020-06-03T21:50:30.462Z""
           ""Assets"" : [
            {
                ""LineNumber"" : NumberInt(1), 
                ""BaseCode"" : ""210-ANUD"", 
                ""BaseDescription"" : null, 
                ""AssetType"" : ""DELL_DIRECT"", 
                ""SerialNumberList"" : [
                    ""31Y37X2""
                ], 
                ""ReferenceIdList"" : null, 
                ""AsSoldAmount"" : 862.49, 
                ""SkuTypeCode"" : null, 
                ""Quantity"" : NumberInt(1), 
                ""TagCount"" : NumberInt(1), 
                ""TagVariance"" : NumberInt(0), 
                ""ResidualValue"" : 0.0, 
                ""ProductDetails"" : [
                    {
                        ""LineNumber"" : NumberInt(1), 
                        ""Code"" : ""210-ANUD"", 
                        ""Description"" : ""Inspiron 5680"", 
                        ""Quantity"" : NumberInt(1), 
                        ""QuantityPerAsset"" : 1.0, 
                        ""AsSoldUnitPrice"" : 45.94, 
                        ""AsSoldAmount"" : 45.94, 
                        ""SkyTypeCode"" : null, 
                        ""GaapAttributes"" : {
                            ""FINITEMCAT_DISP"" : ""FINHARDWR"", 
                            ""FINREVCLS_DISP"" : ""Bse HW Dell Syst"", 
                            ""FINLEASPRD_DISP"" : ""Hard""
                        }, 
                        ""GaapError"" : null, 
                        ""CogsLOB"" : ""NA"", 
                        ""RevenueLOB"" : ""NA"", 
                        ""CogsAmount"" : 0.0, 
                        ""CogsAmountPerAsset"" : null, 
                        ""AllocatedAmount"" : 0.0, 
                        ""AllocatedAmountPerAsset"" : null
                    }, 
]}]

}");

			return new AssetEnrichedRequest
			{
				Revision = 2,
				VendorID = "234",
				InvoiceNo = "123",
				PipelineSource = "DELL",
				SourceBusinessUnit = "1234",
				Six0Six = false,
				COGS = true,
				GAAP = false,
				LastModifiedDateTime = DateTime.UtcNow,
				CreateDateTime = DateTime.UtcNow,
				StatusHistory = new List<AssetStatus>()
				{
					new AssetStatus
					{
						NotificationType = "COGS",
						CorrelationID = "1233333",
						MessageID = "5d692d85d3588a2a0ad23537",
						CreateDateTime = DateTime.UtcNow,
						DecisionSourceDateTime = DateTime.UtcNow,
						MessageReceivedDateTime = DateTime.UtcNow
					},

					new AssetStatus
					{
						NotificationType = "GAAP",
						CorrelationID = "1212",
						MessageID = "5d692d85d3588a2a0ad231222",
						CreateDateTime = DateTime.UtcNow,
						DecisionSourceDateTime = DateTime.UtcNow,
						MessageReceivedDateTime = DateTime.UtcNow
					}
				},
				IsLocked = false,
				ClassafiDetailResponse = classifyDetailRes
			};


		}
		private static List<InvoiceEnrichedRequest> GetEnrichementDocList() => new List<InvoiceEnrichedRequest>{new InvoiceEnrichedRequest {
			//VorID = "2005384176647",
			//DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
		
			//OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = false,
			  //OrderStage = new OrderStage(){
							 //PipelineStage = "Order",
							 //Orders = new List<Order>() {
							 //new Order {
									//OrderNo ="D123",
									//DFSFinanceAmount = 100,
									//Status = new Status() {
									//	   BanzaiStatusCode = "VOR",
									//	   BanzaiStatusCreateDateTime = DateTime.UtcNow
									//}}}},
			Common = new Common(){
				PipelineSource="DELL",
				SourceCustomerID="sss",
				SourceCustomerName="ggg",
				DFSUnbookedExposureID="ttt",
				SourcePaymentTerms="ggg",
				ShippingCountry="uu",
				DFSCountryCode="US",
				SourceBusinessUnit="1234",
				VendorId="234"
			},
			//VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage(){ PipelineStage="INVOICE",
				Invoices =new List<Invoice.Library.Entities.Invoice>(){ new Invoice.Library.Entities.Invoice() {
					InvoiceNo ="123",
					Status=new InvoiceStatus(){ BanzaiStatusCode="ddd"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="D123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} } }
		} };

	}
}
