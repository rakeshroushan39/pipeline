using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.InvoiceTaxCombos;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
	//Context sharing tests during execution
	public class InvoiceTaxCombosControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;

		public InvoiceTaxCombosControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;
			//_apiFixture.InvoiceTaxCombosController.ModelState.Clear();
		}

		//Need to understand this test cases and implement in Processors
		[Trait("API", "InvoiceTaxCombos_GetAll")]
		[Fact]
		public void Should_GetInvoiceTaxCombos_When_Available_V2()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = JsonConvert.SerializeObject(new List<InvoiceTaxComboDto>{
				new InvoiceTaxComboDto {
					Active = true,
					PipelineSource = "DELL",
					SourceBusinessUnit = "LOAN-SW",
					TaxOrgID = "#",
					TaxCode = "?",
					ItemTaxExempt = "LOAN/SOFTWARE",
					TaxComboEnabled = "DIRECT",
					CFOCode = "CMS"
				}
			});

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.GetAll()).Returns(GetInvoiceTaxCombos());

			//Act
			var result = _apiFixture.InvoiceTaxCombosController.GetAll();

			var actualInvoiceTaxCombo = JsonConvert.SerializeObject(((ObjectResult)result).Value as List<InvoiceTaxComboDto>);
			var actualStatusCode = ((ObjectResult)result).StatusCode;

			//Assert
			//Assert.Equal(expectedDto, actualInvoiceTaxCombo);
			Assert.Equal(expectedStatus, actualStatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_GetAll")]
		[Fact]
		public void Should_GetInvoiceTaxCombos_When_Available()
		{
			//Arrange	
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = new List<InvoiceTaxComboDto>{
				new InvoiceTaxComboDto {
					Active = true,
					PipelineSource = "DELL",
					SourceBusinessUnit = "TBD",
					TaxOrgID = "12",
					TaxCode = "001_OS",
					ItemTaxExempt = "Y",
					TaxComboEnabled = "Y",
					CFOCode = "OS"
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.GetAll()).Returns(GetInvoiceTaxCombos());

			//Act
			var obj = _apiFixture.InvoiceTaxCombosController.GetAll();
			var actualDto = ((ObjectResult)obj).Value as List<InvoiceTaxComboDto>;
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert
			Assert.Equal(expectedStatus, actualStatusCode);
			actualDto.Should().BeEquivalentTo(expectedDto);
		}

		[Trait("API", "InvoiceTaxCombos_GetAll")]
		[Fact]
		public void Should_RaiseNotFound_When_NotAvailable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(T => T.InvoiceTaxCombos.GetAll()).Returns(() => null);

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.GetAll() as NotFoundResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_GetAll")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(T => T.InvoiceTaxCombos.GetAll()).Throws<Exception>();

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.GetAll() as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "InvoiceTaxCombos_GetById")]
		[Fact]
		public void Should_GetInvoiceTaxCombos_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			var expectedDto = JsonConvert.SerializeObject(new InvoiceTaxComboDto
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			});
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.GetById(InvoiceTaxComboid)).Returns(GetInvoiceTaxCombosById);

			//Act.
			var actual = _apiFixture.InvoiceTaxCombosController.GetInvoiceTaxComboById(InvoiceTaxComboid) as OkObjectResult;

			var actualInvoiceTaxCombo = JsonConvert.SerializeObject(actual?.Value as InvoiceTaxComboDto);
			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);
			Assert.Equal(expectedDto, actualInvoiceTaxCombo);
		}

		[Trait("API", "InvoiceTaxCombos_GetById")]
		[Fact]
		public void Should_RaiseItemNotFound_When_InvalidIdRequestIsPassed()
		{
			// Arrange.
			var expected = (int)HttpStatusCode.NotFound;
			var InvoiceTaxComboid = "59b2ab05815e95090";
			_apiFixture.MongoDataContext.Setup(T => T.InvoiceTaxCombos.GetById(It.IsAny<string>())).Returns(() => null);

			//Act.
			var actual = _apiFixture.InvoiceTaxCombosController.GetInvoiceTaxComboById(InvoiceTaxComboid) as NotFoundResult;

			//Assert.
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_GetById")]
		[Fact]
		public void Should_RaiseException_When_IssueInGetById()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(T => T.InvoiceTaxCombos.GetById(InvoiceTaxComboid)).Throws<Exception>();

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.GetInvoiceTaxComboById(InvoiceTaxComboid) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "InvoiceTaxCombos_Create")]
		[Fact]
		public void Should_CreateInvoiceTaxCombo_When_ObjectIsValid()
		{
			//Arrange			
			var expectedStatus = (int)HttpStatusCode.Created;

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.InsertOne(It.IsAny<InvoiceTaxCombo>()));

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Create(CreateInvoiceTaxComboDto()) as ObjectResult;

			Assert.Equal(expectedStatus, actual?.StatusCode);

		}

		[Trait("API", "InvoiceTaxCombos_Create")]
		[Fact]
		public void Should_RaiseException_When_IssueInCreate()
		{

			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.InsertOne(It.IsAny<InvoiceTaxCombo>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Create(CreateInvoiceTaxComboDto()) as ObjectResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_Delete")]
		[Fact]
		public void Should_RaiseNoContentResult_When_NotAvalible()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.Remove(It.IsAny<string>())).Returns(true);

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Delete(InvoiceTaxComboid) as NoContentResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "InvoiceTaxCombos_Delete")]
		[Fact]
		public void Should_RaiseNotFound_When_InvalidIdIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.Remove(It.IsAny<string>())).Returns(false);

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Delete(InvoiceTaxComboid) as NotFoundResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "InvoiceTaxCombos_Delete")]
		[Fact]
		public void Should_RaiseInternalServerError_When_InvalidRequest()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";


			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.Remove(It.IsAny<string>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Delete(InvoiceTaxComboid) as ObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);

		}

		[Trait("API", "InvoiceTaxCombos_Delete")]
		[Fact]
		public void Should_DeleteInvoiceTaxCombos_When_validIdRequestPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.Remove(InvoiceTaxComboid)).Returns(true);

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Delete(InvoiceTaxComboid) as NoContentResult;

			//Assert			
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_Replace")]
		[Fact]
		public void Should_RaiseBadRequestException_When_InvalidObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			var InvoiceTaxComboForUpdateDto = new InvoiceTaxComboForUpdateDto
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			};
			_apiFixture.InvoiceTaxCombosController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Replace(InvoiceTaxComboid, InvoiceTaxComboForUpdateDto) as BadRequestObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_Replace")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidReplaceObjectIsPassed()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";

			var _InvoiceTaxComboForUpdateDto = new InvoiceTaxComboForUpdateDto()
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			};

			//Act
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<InvoiceTaxCombo>>(), It.IsAny<InvoiceTaxCombo>())).Throws<Exception>();
			var actual = _apiFixture.InvoiceTaxCombosController.Replace(InvoiceTaxComboid, _InvoiceTaxComboForUpdateDto) as ObjectResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "InvoiceTaxCombos_Replace")]
		[Fact]
		public void Should_RaiseNotFoundResult_When_NotAvaliable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";
			var InvoiceTaxComboForUpdateDto = UpdateInvoiceTaxComboDto();

			_apiFixture.MongoDataContext.Setup(T => T.InvoiceTaxCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<InvoiceTaxCombo>>(), It.IsAny<InvoiceTaxCombo>())).Returns(() => false);

			//Act
			var actual = _apiFixture.InvoiceTaxCombosController.Replace(InvoiceTaxComboid, InvoiceTaxComboForUpdateDto) as NotFoundResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		//Don't delete: Using V1 with Task - Should_RaiseNotFoundResult_When_NotAvaliable
		private ReplaceOneResult ReplaceObj() => new ReplaceOneResult.Acknowledged(0, 0, null);

		[Trait("API", "InvoiceTaxCombos_Replace")]
		[Fact]
		public void Should_ReplaceInvoiceTaxCombos_When_Avaliable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NoContent;
			var InvoiceTaxComboid = "59b2ab05815e95090899a477";
			var InvoiceTaxComboForUpdateDto = UpdateInvoiceTaxComboDto();

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceTaxCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<InvoiceTaxCombo>>(), It.IsAny<InvoiceTaxCombo>())).Returns(() => true);

			//Act

			var actual = _apiFixture.InvoiceTaxCombosController.Replace(InvoiceTaxComboid, InvoiceTaxComboForUpdateDto) as NoContentResult;

			//Assert		
			Assert.Equal(expected, actual?.StatusCode);
		}

		private InvoiceTaxComboForUpdateDto UpdateInvoiceTaxComboDto()
		{
			return new InvoiceTaxComboForUpdateDto
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			};
		}

		private InvoiceTaxComboForCreationDto CreateInvoiceTaxComboDto()
		{
			return new InvoiceTaxComboForCreationDto
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			};
		}

		private static IEnumerable<InvoiceTaxCombo> GetInvoiceTaxCombos()
		{
			return new List<InvoiceTaxCombo>
			{
				  new InvoiceTaxCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceBusinessUnit = "TBD",
					TaxOrgID = "12",
					TaxCode = "001_OS",
					ItemTaxExempt = "Y",
					TaxComboEnabled = "Y",
					CFOCode = "OS"
				  }
			};
		}

		private static InvoiceTaxCombo GetInvoiceTaxCombosById()
		{
			return new InvoiceTaxCombo
			{
				Active = true,
				PipelineSource = "DELL",
				SourceBusinessUnit = "TBD",
				TaxOrgID = "12",
				TaxCode = "001_OS",
				ItemTaxExempt = "Y",
				TaxComboEnabled = "Y",
				CFOCode = "OS"
			};
		}
	}
}
