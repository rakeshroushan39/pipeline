using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.StatusCombos;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;
using Xunit.Abstractions;

namespace DFS.Banzai.Api.UnitTest
{
    //Context sharing accross test classes
    [Collection("API collection")]
	public class StatusCombosControllerTest {

		private readonly ApiFixture _apiFixture;
		private readonly ITestOutputHelper _output;

		public StatusCombosControllerTest(ApiFixture apiFixture, ITestOutputHelper output) {
			_apiFixture = apiFixture;
			_output = output;
			_apiFixture.StatusCombosController.ModelState.Clear();
		}

		//GetAll Method Test cases
		[Trait("API", "StatusCombos_GetAll")]
		[Fact]
		public void Should_GetStatusCombos_When_Available() {
			//_output.WriteLine($"API ID={_apiFixture.StatusCombosController.Id}");
			_output.WriteLine("API ID=StatusCombos_GetAll");

			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedStatusComb = JsonConvert.SerializeObject(new List<StatusCombo>{
				new StatusCombo {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"				
			} });
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());

			//Act
			var result = _apiFixture.StatusCombosController.GetAll();
			var actualStatusCombo = JsonConvert.SerializeObject(((ObjectResult)result).Value as List<StatusCombo>);
			var actualStatusCode = ((ObjectResult)result).StatusCode;

			//Assert
			Assert.Equal(expectedStatusComb, actualStatusCombo);
			Assert.Equal(expectedStatus, actualStatusCode);
		}

		//GetAll Method Test case
		[Trait("API", "StatusCombos_GetAll")]
		[Fact]
		public void Should_GetAll_RaiseNotFound_When_NotAvailable() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(() => null);

			//Act
			var actualStatusCode = _apiFixture.StatusCombosController.GetAll() as NotFoundResult;
			
			//Asset
			Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
		}

		//GetAll Method Test case
		[Trait("API", "StatusCombos_GetAll")]
		[Fact]
		public void Should_GetAll_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetAll() as ObjectResult;

			//Asset
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetbyID Method Test case
		[Trait("API", "StatusCombos_GetbyID")]
		[Fact]
		public void Should_GetbyID_ReturnsQuery_When_IdIsGiven() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
            _apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos());

            //Act
            var actualStatus = _apiFixture.StatusCombosController.GetById(It.IsAny<string>()) as OkObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetbyID Method Test case
		[Trait("API", "StatusCombos_GetbyID")]
		[Fact]
		public void Should_GetbyID_ReturnsNull_When_Notfound() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(() => null);

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetById("123") as NotFoundResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);

		}

		//GetbyID Method Test case
		[Trait("API", "StatusCombos_GetbyID")]
		[Fact]
		public void Should_GetbyID_When_ValidIdIsGiven() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
            _apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos());

            //Act
            var actualStatus = _apiFixture.StatusCombosController.GetById("123") as OkObjectResult;            

            //Assert			
            Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetbyID Method Test case
		[Trait("API", "StatusCombos_GetbyID")]
		[Fact]
		public void Should_GetbyID_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetById("123") as ObjectResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Create Method Test case
		[Trait("API", "StatusCombos_Create")]
		[Fact]
		public void Should_CreateStatusCombos_When_PassingValidObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.Created;
		
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.InsertOne(It.IsAny<StatusCombo>()));

			//Act
			var actualStatus = _apiFixture.StatusCombosController.Create(new StatusComboForDmlDto()) as ObjectResult;
			_apiFixture.MongoDataContext.Verify(x => x.StatusCombos.InsertOne(It.IsAny<StatusCombo>()), Times.AtLeastOnce);

			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Create Method Test case
		[Trait("API", "StatusCombos_Create")]
		[Fact]
		public void Should_Create_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.InsertOne(It.IsAny<StatusCombo>())).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.Create(new StatusComboForDmlDto()) as ObjectResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		
		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCodes_When_ValiDataGiven()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos());

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCodes(pipelinesource, pipelinestage) as OkObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		
		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCodes_When_NotValiDataGiven()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(() => null);

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCodes(pipelinesource, pipelinestage) as NotFoundResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCodes_When_ThrowsException()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCodes(pipelinesource, pipelinestage) as ObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCombos_When_ValiDataGiven()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos());

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCombos(pipelinesource, pipelinestage) as OkObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCombos_When_NotValiDataGiven()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(() => null);

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCombos(pipelinesource, pipelinestage) as NotFoundResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		[Trait("API", "GetStatusCodes")]
		[Fact]
		public void Should_GetStatusCombos_When_ThrowsException()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var pipelinesource = "DELL";
			var pipelinestage = "INVOICE";
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.GetStatusCombos(pipelinesource, pipelinestage) as ObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Replace Method Test case
		[Trait("API", "StatusCombos_Replace")]
		[Fact]
		public void Should_Replace_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var statusComboForDmlDto = new StatusComboForDmlDto() {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"

			};			
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<StatusCombo>>(),
				It.IsAny<StatusCombo>())).Throws<Exception>();
			//Act
			var actualStatus = _apiFixture.StatusCombosController.Replace("59b29afa815e95090899a46d",
				statusComboForDmlDto) as ObjectResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Replace Method Test case
		[Trait("API", "StatusCombos_Replace")]
		[Fact]
		public void Should_Replace_RaiseNotFound_When_NotAvailable() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			var statusComboForDmlDto = new StatusComboForDmlDto() {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"

			};
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<StatusCombo>>(),
				It.IsAny<StatusCombo>()));
			//Act
			var actualStatus = _apiFixture.StatusCombosController.Replace("59b29afa815e95090899a46d",
				statusComboForDmlDto) as NotFoundResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//Replace Method Test case
		[Trait("API", "StatusCombos_Replace")]
		[Fact]
		public void Should_Replace_When_ValidInput() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NoContent;
			var statusComboForDmlDto = new StatusComboForDmlDto() {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"

			};
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.ReplaceOneAsync(It.IsAny<FilterDefinition<StatusCombo>>(),
				It.IsAny<StatusCombo>())).Returns(()=>true);
			//Act
			var actualStatus = _apiFixture.StatusCombosController.Replace("59b29afa815e95090899a46d",
				statusComboForDmlDto) as NoContentResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//Replace  Method Test case
		[Trait("API", "StatusCombos_Replace")]
		[Fact]
		public void Should_Replace_RaiseBadRequest_When_ModelStateInvalid() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;								
			_apiFixture.StatusCombosController.ModelState.AddModelError("Banzai", "Adding Model Error");
			//Act	
			var actualStatus = _apiFixture.StatusCombosController.Replace("59b29afa815e95090899a46d",
				GetStatusComboForDmlDto()) as BadRequestObjectResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Delete Method Test case
		[Trait("API", "StatusCombos_Delete")]
		[Fact]
		public void Should_Delete_RaiseInternalServerError_When_InvalidInputObject() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Remove(It.IsAny<string>())).Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.StatusCombosController.Delete("123") as ObjectResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//Delete Method Test case
		[Trait("API", "StatusCombos_Delete")]
		[Fact]
		public void Should_Delete_When_ValidIdIsGiven() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NoContent;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Remove(It.IsAny<string>())).Returns(true);
			//Act
			var actualStatus = _apiFixture.StatusCombosController.Delete("123") as NoContentResult;
			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}


		//Delete Method Test case
		[Trait("API", "StatusCombos_Delete")]
		[Fact]
		public void Should_Delete_RaiseNotFound_When_NotAvailable() {
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.Remove(It.IsAny<string>())).Returns(false);

			//Act
			var actualStatus = _apiFixture.StatusCombosController.Delete("123") as NotFoundResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}



		#region Private methods
		private static List<StatusCombo> GetStatusCombos() {
			return new List<StatusCombo> { new StatusCombo {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"				
			} };
			
		}
		private static StatusComboForDmlDto GetStatusComboForDmlDto() {
			return new StatusComboForDmlDto() {
				Active = true,
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"
			};
		}
		#endregion
	}


}