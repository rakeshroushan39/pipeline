﻿using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class ClassafiInvoicesControllerTest : IClassFixture<ApiFixture>
    {
		private readonly ApiFixture _apiFixture;
		public ClassafiInvoicesControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;
			_apiFixture.ClassafiInvoicesController.ModelState.Clear();
		}


		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByInvoiceNoAndBuid_when_validMessage()
		{
			//Arrange
			var invoiceno = "123";
			var buid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Returns(GetNullEnrichementUnLockedDoc);
			
			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByInvoiceNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByInvoiceNoAndBuid_when_NotvalidMessage()
		{
			//Arrange
			var invoiceno = "";
			var buid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Returns(() => null);

			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByInvoiceNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByInvoiceNoAndBuid_when_NotvalidBuidMessage()
		{
			//Arrange
			var invoiceno = "123";
			var buid = "";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Returns(() => null);

			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByInvoiceNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByInvoiceNoAndBuid_when_NotvalidExcepMessage()
		{
			//Arrange
			var invoiceno = "123";
			var buid = "";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByInvoiceNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByInvoiceNoAndBuid_when_ThrowsException()
		{
			//Arrange
			var invoiceno = "123";
			var buid = "";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			//_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByInvoiceNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		[Trait("API", "ClassafiInvoicesControllerTest")]
		[Fact]
		public void Should_GetInvoicesByOrderNoAndBuid_when_validMessage()
		{
			//Arrange
			var invoiceno = "123";
			var buid = "234";
			var expectedStatusCode = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.ClassafiInvoices.Find(It.IsAny<FilterDefinition<ClassafiInvoice>>())).Returns(GetNullEnrichementUnLockedDoc);

			//Act
			var actual = _apiFixture.ClassafiInvoicesController.GetInvoicesByOrderNoAndBuid(invoiceno, buid) as OkObjectResult;

			//Asset
			Assert.Equal(expectedStatusCode, actual?.StatusCode);

		}
		private static List<ClassafiInvoice> GetNullEnrichementUnLockedDoc() => new List<ClassafiInvoice>{new ClassafiInvoice {
				PipelineSource = "DELL",
				InvoiceNumber = "123",
				BusinessUnitID = "234",
				DellCustomerNumber = "US118298776",
				Currency= "USD"
		} };


	}
}
