﻿using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace DFS.Banzai.Api.UnitTest
{
    public class OrderStatusControllerTest : IClassFixture<ApiFixture>
    {
		private readonly ApiFixture _apiFixture;

		public OrderStatusControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;
		}
		[Trait("API", "GetMissingOrderStatus")]
		[Fact]
		public void Should_GetMissingOrderStatus_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.NotFound;
			
			_apiFixture.MongoDataContext.Setup(x => x.MissingOciNotifications.Find(It.IsAny<FilterDefinition<MissingOciNotification>>()))
				.Returns(GetMissingInvoiceRequestsId);
			//Act.
			var actual = _apiFixture.OrderStatusController.GetMissingOrderStatus() as NotFoundResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "GetMissingOrderStatus")]
		[Fact]
		public void Should_GetMissingOrderStatus_When_NotValidIdRequestIsPassed()
		{
			// Arrange.

			
			//Act.
			var actual = _apiFixture.OrderStatusController.GetMissingOrderStatus() as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}

		[Trait("API", "DeleteMissingOrderStatus")]
		[Fact]
		public void Should_DeleteMissingOrderStatus_When_ValidIdRequestIsPassed()
		{
			// Arrange.
			var sourceOrigin = "OCI";
			var sourcepaytems = "1";
			_apiFixture.MongoDataContext.Setup(x => x.MissingOciNotifications.Find(It.IsAny<FilterDefinition<MissingOciNotification>>()))
				.Returns(GetMissingInvoiceRequestsId);
			//Act.
			var actual = _apiFixture.OrderStatusController.DeleteMissingOrderStatus(sourceOrigin, sourcepaytems) as OkObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "GetMissingOrderStatus")]
		[Fact]
		public void Should_DeleteMissingOrderStatus_When_NotValidIdRequestIsPassed()
		{
			// Arrange.
			var sourceOrigin = "OCI";
			var sourcepaytems = "1";
			
			//Act.
			var actual = _apiFixture.OrderStatusController.DeleteMissingOrderStatus(sourceOrigin, sourcepaytems) as ObjectResult;


			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}


		private static List<MissingOciNotification> GetMissingInvoiceRequestsId() => new List<MissingOciNotification>{new MissingOciNotification {
				CreateDateTime = DateTime.UtcNow,
				Id = "5ee8e151bf0a7f000ee5e7d4",
				SourceOrigin = "oci",
				SourcePaymentTerms = "1"

		} };
	}
}
