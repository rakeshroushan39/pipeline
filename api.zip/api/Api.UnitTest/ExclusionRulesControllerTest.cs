﻿using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.Json.Serialization;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class ExclusionRulesControllerTest : IClassFixture<ApiFixture>
    {
        private readonly ApiFixture _apiFixture;

        public ExclusionRulesControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
        }



		[Trait("API", "ExclusionRules")]
		[Fact]
		public void Should_GetAll_when_validMessage()
		{
			//Arrange

			_apiFixture.MongoDataContext.Setup(x => x.ExclusionRules.GetAll()).Returns(GetExclusionRules());
			//Act
			var result = _apiFixture.ExclusionRulesController.GetAll() as JsonResult;

			//Asset
			
			Assert.NotNull(result.Value);

		}
		[Trait("API", "ExclusionRules")]
		[Fact]
		public void Should_GetAll_When_NotAvailable()
		{
			//Arrange
			var expected = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(T => T.ExclusionRules.GetAll()).Returns(() => null);

			//Act
			var actual = _apiFixture.ExclusionRulesController.GetAll() as NotFoundResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "ExclusionRules")]
		[Fact]
		public void Should_GetAll_When_ThrowsException()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(T => T.ExclusionRules.GetAll()).Throws<Exception>();

			//Act
			var actual = _apiFixture.ExclusionRulesController.GetAll() as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "ManageBuid")]
		[Fact]
		public void Should_ManageBuid_when_validMessage()
		{
			//Arrange
			var buid = "123";
			var isexcluded = false;

			_apiFixture.MongoDataContext.Setup(x => x.ExclusionRules.GetAll()).Returns(GetExclusionRules());
			//Act
			var result = _apiFixture.ExclusionRulesController.ManageBuid(buid, isexcluded, Controllers.ExclusionRulesController.PipelineSource.DELL, Controllers.ExclusionRulesController.PipelineStage.INVOICE) as JsonResult;

			//Asset

			Assert.NotNull(result.Value);

		}
		[Trait("API", "ManageBuid")]
		[Fact]
		public void Should_ManageBuid_when_validMessage_ExclustionEmpty()
		{
			//Arrange
			var buid = "";
			var isexcluded = false;

			_apiFixture.MongoDataContext.Setup(x => x.ExclusionRules.GetAll()).Returns(GetExclusionRules());
			//Act
			var result = _apiFixture.ExclusionRulesController.ManageBuid(buid, isexcluded, Controllers.ExclusionRulesController.PipelineSource.DELL, Controllers.ExclusionRulesController.PipelineStage.INVOICE) as JsonResult;

			//Asset

			Assert.NotNull(result.Value);

		}
		[Trait("API", "ManageBuid")]
		[Fact]
		public void Should_ManageBuid_when_validMessage_ThrowsException()
		{
			//Arrange
			var buid = "123";
			var isexcluded = false;
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.ExclusionRules.GetAll()).Returns(() => null);
			//Act
			var actual = _apiFixture.ExclusionRulesController.ManageBuid(buid, isexcluded, Controllers.ExclusionRulesController.PipelineSource.DELL, Controllers.ExclusionRulesController.PipelineStage.INVOICE) as ObjectResult;

			//Asset

			Assert.Equal(expected, actual?.StatusCode);

		}


		private static IEnumerable<ExclusionRules> GetExclusionRules()
		{
			return new List<ExclusionRules>
			{
				  new ExclusionRules
				  {
					Id= "5de",
					BUID="123",
					PipelineSource ="DELL",
					PipelineStage ="INVOICE",
					IsExcluded = false
				  }

			};
		}
	
	}
}
