using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;
using Xunit.Sdk;

namespace DFS.Banzai.Api.UnitTest
{
    public class CacheMgmtControllerTest : IClassFixture<ApiFixture>
    {
        private readonly ApiFixture _apiFixture;

        public CacheMgmtControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;

            _apiFixture.CacheMgmtController.ModelState.Clear();
        }

        [Trait("API", "CacheMgmt_VerifyEnrichKey")]
        [Fact]
        public void Should_VerifyEnrichKey_RaiseNotFound_When_InvalidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NotFound;
            var mockObj = new List<IgnoreRetry>() {
                new IgnoreRetry(){ Guid="1233344"}
            };

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(value:null);

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyEnrichKey("5a5f89aae62040002c7eb964") as NotFoundResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }

        [Trait("API", "CacheMgmt_VerifyEnrichKey")]
        [Fact]
        public void Should_ReturnNoContent_When_KeyExistsInCache()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NoContent;
            var mockObj = new List<IgnoreRetry>() {
                new IgnoreRetry(){ Guid="1233344"}
            };

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(mockObj);

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyEnrichKey("1") as NoContentResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        
        [Trait("API", "CacheMgmt_VerifyEnrichKey")]
        [Fact]
        public void Should_VerifyEnrichKey_RaiseInternalServerError_When_RequestUnhandled()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.InternalServerError;

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Throws<Exception>();

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyEnrichKey("") as ObjectResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }

        [Trait("API", "CacheMgmt_IgnoreEnrichMessage")]
        [Fact]
        public void Should_IgnoreEnrichMessage_When_ValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NoContent;
            
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.IgnoreEnrichMessage("1") as NoContentResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "VerifyBIReportingKey")]
        [Fact]
        public void Should_VerifyBIReportingKey_When_ValidInput()
        {
            //Arrange
           
            var mockObj = new List<IgnoreRetry>() {
                new IgnoreRetry(){ Guid="1233344"}
            };

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(mockObj);
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyBIReportingKey("1") as NoContentResult;

            //Asset
            Assert.Null(actualStatusCode?.StatusCode);
        }
        [Trait("API", "VerifyBIReportingKey")]
        [Fact]
        public void Should_VerifyBIReportingKey_When_NotValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NotFound;
            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(value: null);
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyBIReportingKey("1") as NotFoundResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "VerifyBIReportingKey")]
        [Fact]
        public void Should_VerifyBIReportingKey_When_ExceptionValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.InternalServerError;
            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Throws<Exception>();
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyBIReportingKey("1") as ObjectResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "IgnoreBIMessage")]
        [Fact]
        public void Should_IgnoreBIMessage_When_ValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NoContent;

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.IgnoreBIMessage("1") as NoContentResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "IgnoreBIMessage")]
        [Fact]
        public void Should_IgnoreBIMessage_When_NotValidInput()
        {
            //Arrange

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.IgnoreBIMessage("1") as ThrowsException;

            //Asset
            Assert.Null(actualStatusCode);
        }
        [Trait("API", "VerifyExceptionKey")]
        [Fact]
        public void Should_VerifyExceptionKey_When_ValidInput()
        {
            //Arrange

            var mockObj = new List<IgnoreRetry>() {
                new IgnoreRetry(){ Guid="1233344"}
            };

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(mockObj);
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyExceptionKey("1") as OkObjectResult;

            //Asset
            Assert.Null(actualStatusCode?.StatusCode);
        }
        [Trait("API", "VerifyExceptionKey")]
        [Fact]
        public void Should_VerifyExceptionKey_When_NotFoundValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NotFound;
            var mockObj = new List<IgnoreRetry>() {
                new IgnoreRetry(){ Guid="1233344"}
            };

            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Returns(value: null);
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyExceptionKey("1") as NotFoundResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "VerifyExceptionKey")]
        [Fact]
        public void Should_VerifyExceptionKey_When_ExceptionValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.InternalServerError;
            _apiFixture.MongoDataContext.Setup(x => x.IgnoreRetry.Find(It.IsAny<FilterDefinition<IgnoreRetry>>())).Throws<Exception>();
            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.VerifyExceptionKey("1") as ObjectResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "IgnoreException")]
        [Fact]
        public void Should_IgnoreException_When_ValidInput()
        {
            //Arrange
            var expectedStatus = (int)HttpStatusCode.NoContent;

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.IgnoreException("1") as NoContentResult;

            //Asset
            Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
        }
        [Trait("API", "IgnoreException")]
        [Fact]
        public void Should_IgnoreException_When_NotValidInput()
        {
            //Arrange

            //Act
            var actualStatusCode = _apiFixture.CacheMgmtController.IgnoreException("1") as ThrowsException;

            //Asset
            Assert.Null(actualStatusCode);
        }



    }
}
