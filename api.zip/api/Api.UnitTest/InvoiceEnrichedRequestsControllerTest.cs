using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.Models.InvoiceEnrichments;
//using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;
using Xunit.Abstractions;

namespace DFS.Banzai.Api.UnitTest
{
	public class InvoiceEnrichedRequestsControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;
		private readonly ITestOutputHelper _output;

		public InvoiceEnrichedRequestsControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;

			_apiFixture.InvoiceEnrichedRequestsController.ModelState.Clear();
		}

		//GetInvoiceData Method Test case
		[Trait("API", "InvoiceEnrichedRequest_GetInvoiceData")]
		[Fact]
		public void Should_GetInvoiceData_RaiseException_When_NotFound()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetNullEnrichementLockedDoc);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetEMCInvoice(GetSearchInvoiceRequestDto()) as NotFoundResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetInvoiceData Method Test case
		[Trait("API", "InvoiceEnrichedRequest_GetInvoiceData")]
		[Fact]
		public void Should_GetInvoiceData_When_ValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetEMCInvoice(GetSearchInvoiceRequestDto()) as OkObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetInvoiceData Method Test case
		[Trait("API", "InvoiceEnrichedRequest_GetInvoiceData")]
		[Fact]
		public void Should_ReturnNotFound_When_InvalidInvoice()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NotFound;

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>())).Returns(() => null);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetEMCInvoice(new SearchInvoiceRequestDto()) as NotFoundResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetInvoiceData Method Test case
		[Trait("API", "InvoiceEnrichedRequest_GetInvoiceData")]
		[Fact]
		public void Should_RaiseBadRequest_When_NullInvoice()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;

			_apiFixture.InvoiceEnrichedRequestsController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actual = _apiFixture.InvoiceEnrichedRequestsController.GetEMCInvoice(null) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}


		//GetInvoice Method Test case
		[Trait("API", "GetInvoice")]
		[Fact]
		public void Should_GetInvoice_When_ValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			 
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoice(GetInvoiceRequestDto()) as OkObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//GetInvoice Method Test case
		[Trait("API", "GetInvoice")]
		[Fact]
		public void Should_GetInvoice_When_NotValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;

			// _apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
			 // .Returns(() => null);
			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoice(GetInvoiceRequestDto()) as ObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//GetInvoice Method Test case
		[Trait("API", "GetInvoice")]
		[Fact]
		public void Should_GetInvoice_When_NotValidInput_Error()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
			.Throws<Exception>();

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoice(GetInvoiceRequestClientDto()) as ObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//GetInvoice Method Test case
		[Trait("API", "GetInvoice")]
		[Fact]
		public void Should_GetInvoice_When_Enrichment_ValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoice(GetInvoiceRequestDto()) as OkObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//GetInvoice Method Test case
		[Trait("API", "GetInvoiceEnrichedRequest")]
		[Fact]
		public void Should_GetInvoiceEnrichedRequest_When_Enrichment_ValidInput()
		{
			//Arrange
			var doctype = "INVOICE";
			var buid = "234";
			var id = "123b";
			var pipelinesource = "DELL";


			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoiceEnrichedRequest(pipelinesource,doctype,id,buid) as NotFoundResult;
			//Assert
			Assert.Null(actualStatus?.StatusCode);
		}
		[Trait("API", "GetInvoiceEnrichedRequest")]
		[Fact]
		public void Should_GetInvoiceEnrichedRequest_When_Exception_ValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var doctype = "INVOICE";
			var buid = "234";
			var id = "123b";
			var pipelinesource = "DELL";


			//_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				//.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.GetInvoiceEnrichedRequest(pipelinesource, doctype, id, buid) as ObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		[Trait("API", "DeleteInvoiceEnrichedRequest")]
		[Fact]
		public void Should_DeleteInvoiceEnrichedRequest_When_Enrichment_ValidInput()
		{
			//Arrange
			var doctype = "INVOICE";
			var identifierlist = "123,234,456";
			var pipelinesource = "DELL";
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "DELL",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m
							}
					   },
				}
			};
		
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.DeleteInvoiceEnrichedRequest(pipelinesource, doctype, identifierlist) as ObjectResult;
			//Assert
			Assert.Null(actualStatus?.StatusCode);
		}
		[Trait("API", "DeleteInvoiceEnrichedRequest")]
		[Fact]
		public void Should_DeleteInvoiceEnrichedRequest_When_EmcSource_ValidInput()
		{
			//Arrange
			var doctype = "INVOICE";
			var identifierlist = "123,234,456";
			var pipelinesource = "EMC";
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "EMC",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m
							}
					   },
				}
			};
			var Rollup = new List<RollupRequest>
			{
				new RollupRequest
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "EMC",
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.Find(It.IsAny<FilterDefinition<RollupRequest>>())).Returns(Rollup);

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.DeleteInvoiceEnrichedRequest(pipelinesource, doctype, identifierlist) as ObjectResult;
			//Assert
			Assert.Null(actualStatus?.StatusCode);
		}
		[Trait("API", "DeleteInvoiceEnrichedRequest")]
		[Fact]
		public void RaiseException_DeleteInvoiceEnrichedRequest_When_EmcSource_ValidInput()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var doctype = "INVOICE";
			var identifierlist = "123,234,456";
			var pipelinesource = "EMC";
			var invoiceproductItems = new List<InvoiceProductItem>
			{
				new InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "EMC",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
					InvoiceLines = new List<InvoiceLine>()
						{
							new InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m
							}
					   },
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<InvoiceProductItem>>())).Returns(invoiceproductItems);
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.FindByFilter(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>()))
				.Returns(GetEnrichementDocList);

			//Act
			var actualStatus = _apiFixture.InvoiceEnrichedRequestsController.DeleteInvoiceEnrichedRequest(pipelinesource, doctype, identifierlist) as ObjectResult;
			//Assert
			Assert.Equal(expected, actualStatus?.StatusCode);
		}

		#region Private methods
		
		private static List<InvoiceEnrichedRequest> GetNullEnrichementLockedDoc() => new List<InvoiceEnrichedRequest>{new InvoiceEnrichedRequest {
			//VorID = "",
			//DPIDServiceInSync = "",
			BanzaiFinancialComboInSync = "",
			RapportGetCustomerServiceInSync = "",
			BanzaiStatusInSync = "",
			OrderSummaryServiceInSync = "",
			//OrderDetailServiceInSync = "",
			IsLocked = true,
			//OrderStage = new OrderStage(),
			Common = null,
			//VorStage = new VorStage(),
			InvoiceStage = null
		} };
		private static List<InvoiceEnrichedRequest> GetEnrichementDocList() => new List<InvoiceEnrichedRequest>{new InvoiceEnrichedRequest {
			Id="123b",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
		
			//OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = false,
			  //OrderStage = new OrderStage(){
							 //PipelineStage = "Order",
							 //Orders = new List<Order>() {
							 //new Order {
									//OrderNo ="D123",
									//DFSFinanceAmount = 100,
									//Status = new Status() {
									//	   BanzaiStatusCode = "VOR",
									//	   BanzaiStatusCreateDateTime = DateTime.UtcNow
									//}}}},
			Common = new Common(){
				PipelineSource="DELL",
				SourceCustomerID="sss",
				SourceCustomerName="ggg",
				DFSUnbookedExposureID="ttt",
				SourcePaymentTerms="ggg",
				ShippingCountry="uu",
				DFSCountryCode="US",
				SourceBusinessUnit="234",
				VendorId="12"
			},
			//VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage(){ PipelineStage="VOR",
				Invoices =new List<Invoice.Library.Entities.Invoice>(){ new Invoice.Library.Entities.Invoice() {
					InvoiceNo ="123",
					Status=new InvoiceStatus(){ BanzaiStatusCode="ddd"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="D123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} } }
		} };

		private SearchInvoiceRequestDto GetSearchInvoiceRequestDto()
		{
			return new SearchInvoiceRequestDto()
			{
				PipelineSource = "DELL",
				BanzaiStatus = "null",
				SourceCustomerID = "C12345",
				InvoiceNo = "123",
				SourceDealId = "333",
				OrderNo = "431341231",
				InvoiceType = "s",
				SourceCustomerName = "Dell",
				DFSCountryCode = "US",
				ShippingCountry = "us"
			};
		}


		private InvoiceRequestDto GetInvoiceRequestDto()
		{
			return new InvoiceRequestDto()
			{
				ClientName= "Majidi",
				PipelineSource = "DELL",
				SearchBy = "INVOICENO",
				SearchValue = "123",
				SourceBusinessUnit = "11",
				VendorId = "12",
				ReturnInvoiceLines= true,
				ReturnInvoiceSubLines= true,
				ReturnStatusHistory= true

			};
		}
		private InvoiceRequestDto GetInvoiceRequestClientDto()
		{
			return new InvoiceRequestDto()
			{
				ClientName = "",
				PipelineSource = "",
				SearchBy = "",
				SearchValue = "",
				SourceBusinessUnit = "",
				VendorId = "",
				ReturnInvoiceLines = true,
				ReturnInvoiceSubLines = true,
				ReturnStatusHistory = true

			};
		}
		#endregion
	}
}

