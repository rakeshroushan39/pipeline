using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library.Aura.Models;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Pipeline.Library.Entities;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;
using InvoiceStage = DFS.Banzai.Pipeline.Library.Entities.InvoiceStage;

namespace DFS.Banzai.Api.UnitTest
{
	public class PipelineEnrichedRequestsControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;

		public PipelineEnrichedRequestsControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;

			_apiFixture.PipelineEnrichedRequestsController.ModelState.Clear();
		}

		[Trait("API", "PipelineEnrichedRequest_FindCustomer")]
		[Fact]
		public void Should_RaiseInvalidDocumentException_when_DocumentTypeIsInvalid()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "Test";

			var expected = (int)HttpStatusCode.BadRequest;

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.FindCustomer(doctype, id) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);

		}

		[Trait("API", "PipelineEnrichedRequest_FindCustomer")]
		[Fact]
		public void Should_ReturnCustomer_When_ValidVorId()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "VOR";
			var mockObj = new List<BsonDocument> {
				BsonSerializer.Deserialize<BsonDocument>(
					"{ \"_id\" : \"5a8efc4ffd0e8d4090401be0\", \"VorID\" : \"2001498953641\", \"Revision\" : 2, \"Common\" : { \"DFSCreditSystem\" : \"CMS\", \"DFSCreditID\" : \"98777\", \"DFSCustomerReassignedFlag\" : false, \"DFSUnbookedExposureSystem\" : \"\", \"DFSUnbookedExposureID\" : \"\", \"DFSSegment\" : null, \"DFSSegmentClass\" : null, \"DFSOrphanFlag\" : \"N\", \"DFSCustomerMLAFlag\" : false, \"DFSCustomerFundingSourceReviewFlag\" : false, \"DFSCreditCautionFlag\" : false, \"DFSCustomerName\" : null, \"DirectOpsRep\" : null, \"DFSProductSpace\" : \"TRANSACTIONAL LEASE\", \"SourceCustomerID\" : \"540000006119\", \"SourceCustomerName\" : \"CR488 UAT CO 45 TERMS CC\" }, \"OrderStage\" : { \"Orders\" : [{ \"OrderNo\" : \"113305550\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305568\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305576\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305584\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305592\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }] } }")
			};

			var expected = (int)HttpStatusCode.OK;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ProjectionDefinition<PipelineEnrichedRequest>>(), 0)).Returns(mockObj);

			//Act
			var actualObj = _apiFixture.PipelineEnrichedRequestsController.FindCustomer(doctype, id);
			var actualStatusCode = ((ObjectResult)actualObj).StatusCode;
			var actualDto = ((ObjectResult)actualObj).Value as CustomerSearchDto;

			//Asset
			Assert.Equal(expected, actualStatusCode);
			actualDto.Should().BeEquivalentTo(ExpectedCustomerSearchResult());
		}

		private CustomerSearchDto ExpectedCustomerSearchResult()
		{
			string obj =
				"{\"Id\":\"5a8efc4ffd0e8d4090401be0\",\"VorID\":\"2001498953641\",\"Revision\":2,\"Common\":{\"DFSOrphanFlag\":\"N\",\"SourceCustomerID\":\"540000006119\",\"SourceCustomerName\":\"CR488 UAT CO 45 TERMS CC\",\"DFSCreditSystem\":\"CMS\",\"DFSCreditID\":\"98777\",\"DFSUnbookedExposureSystem\":\"\",\"DFSUnbookedExposureID\":\"\",\"DFSCustomerName\":null,\"DFSCustomerMLAFlag\":false,\"DFSSegment\":null,\"DFSSegmentClass\":null,\"DFSCustomerFundingSourceReviewFlag\":false,\"DFSCreditCautionFlag\":false,\"DirectOpsRep\":null,\"DFSCustomerReassignedFlag\":false,\"DFSProductSpace\":\"TRANSACTIONAL LEASE\"},\"OrderStage\":{\"Orders\":[{\"OrderNo\":\"113305550\",\"Status\":{\"BanzaiStatusCode\":\"INV\",\"DecisionSourceStatusCode\":\"INV\"}},{\"OrderNo\":\"113305568\",\"Status\":{\"BanzaiStatusCode\":\"INV\",\"DecisionSourceStatusCode\":\"INV\"}},{\"OrderNo\":\"113305576\",\"Status\":{\"BanzaiStatusCode\":\"INV\",\"DecisionSourceStatusCode\":\"INV\"}},{\"OrderNo\":\"113305584\",\"Status\":{\"BanzaiStatusCode\":\"INV\",\"DecisionSourceStatusCode\":\"INV\"}},{\"OrderNo\":\"113305592\",\"Status\":{\"BanzaiStatusCode\":\"INV\",\"DecisionSourceStatusCode\":\"INV\"}}]}}";
			return JsonConvert.DeserializeObject<CustomerSearchDto>(obj);
			//refer to serialize object -  string output = JsonConvert.SerializeObject(result);
		}

		[Trait("API", "PipelineEnrichedRequest_FindCustomer")]
		[Fact]
		public void Should_RaiseNotFound_When_InvalidVORIdRequest()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "VOR";
			var expected = (int)HttpStatusCode.NotFound;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ProjectionDefinition<PipelineEnrichedRequest>>(), 0)).Returns(() => null);

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.FindCustomer(doctype, id) as NotFoundResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_FindCustomer")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidVORIdRequest()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "VOR";
			var expected = (int)HttpStatusCode.InternalServerError;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ProjectionDefinition<PipelineEnrichedRequest>>(), 0)).Throws<Exception>();

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.FindCustomer(doctype, id) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_GetEnrichedDocument")]
		[Fact]
		public void Should_GetEnrichmentDocument_when_ValidOrderAndPipelineSource()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;
			var id = "2005384176647";
			var doctype = "Order";
			var pipelineSource = "Dell";
			var invoiceproductItems = new List<Invoice.Library.Entities.InvoiceProductItem>
			{
				new Invoice.Library.Entities.InvoiceProductItem
				{
				   Id = "5b8116149983e5002f4c3f4d",
				   PipelineSource = "EMC",
				   SourceBusinessUnit = "1234",
				   InvoiceNo = "123",
				   
					InvoiceLines = new List<Invoice.Library.Entities.InvoiceLine>()
						{
							new Invoice.Library.Entities.InvoiceLine()
							{
								LineNumber = 1,
								ItemID ="570-AAQC",
								Quantity = 1,
								UnitPrice = 5.6m,
								TaxDetails = new List<Invoice.Library.Entities.InvoiceTaxDetail>
										  {
											new Invoice.Library.Entities.InvoiceTaxDetail
											{
												TaxType="ab"
											}
										  },
								InvoiceSubLines = new List<Invoice.Library.Entities.InvoiceSubLine>()
									{
										new Invoice.Library.Entities.InvoiceSubLine
										{ 
										  EnvironmentalFee=123,
										  TaxDetails = new List<Invoice.Library.Entities.InvoiceTaxDetail>
										  {
											new Invoice.Library.Entities.InvoiceTaxDetail
											{
												TaxType="ab"
											}
										  }
										
										}
									}
							},
				        }
				}
			};

			_apiFixture.MongoDataContext.Setup(x => x.InvoiceProductItems.Find(It.IsAny<FilterDefinition<Invoice.Library.Entities.InvoiceProductItem>>())).Returns(invoiceproductItems);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocByOrderAndPipeline());
			_apiFixture.MongoDataContext.Setup(x => x.InvoiceEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<InvoiceEnrichedRequest>>())).Returns(GetEnrichedInvoiceEnrichedRequests());

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequest(pipelineSource, doctype, id) as OkObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_GetEnrichedDocument")]
		[Fact]
		public void Should_GetEnrichmentDocument_when_ValidInvoiceAndPipelineSource()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "Invoice";
			var pipelineSource = "Dell";

		
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocByInvoiceAndPipeline());

			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequest(pipelineSource, doctype, id) as OkObjectResult;

			//Asset
			Assert.Null(actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_GetEnrichedDocument")]
		[Fact]
		public void Should_RaiseInvalidEnrichDocumentException_when_DocumentTypeIsInvalid()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "Test";
			var pipelineSource = "Dell";
			var expected = (int)HttpStatusCode.BadRequest;

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequest(pipelineSource, doctype, id) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);

		}

		[Trait("API", "PipelineEnrichedRequest_GetEnrichedDocument")]
		[Fact]
		public void Should_RaiseEnrichDocumentNotFound_When_InvalidRequest()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "VOR";
			var pipelineSource = "Dell";
			var expected = (int)HttpStatusCode.NotFound;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequest(pipelineSource, doctype, id) as NotFoundResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_GetEnrichedDocument")]
		[Fact]
		public void Should_RaiseInternalServerException_When_InvalidRequest()
		{
			//Arrange
			var id = "2005384176647";
			var doctype = "VOR";
			var pipelineSource = "Dell";
			var expected = (int)HttpStatusCode.InternalServerError;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequest(pipelineSource, doctype, id) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_RaiseBadRequestException_when_StatusObjectIdInvalid()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;
			var updateStatusOverrideDto = new UpdateStatusOverrideDto();

			_apiFixture.PipelineEnrichedRequestsController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as BadRequestObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_RaiseRevisionNumberIsOlder_when_RevisionMisMatch()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 90,
				BanzaiStatusOverrideCode = "VOR",
				PipelineSource = "Dell",
				PipelineStage = "Order",
				InvoiceNo = "5201043153",
				OrderNo = "2005408599287",
				UserLastModifiedBy = "Test"
			};

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as BadRequestObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_RaiseBadRequest_When_OverrideStatusEnrichmentDocLocked()
		{
			//Arrange
			var expected = (int)HttpStatusCode.BadRequest;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto();

			_apiFixture.MongoDataContext.Setup(x =>
				x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), It.IsAny<ReturnDocument>())).Returns(() => null);

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_RaiseException_When_OverrideStatusErrorsOut()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			var updateStatusOverrideDto = new UpdateStatusOverrideDto();

			_apiFixture.MongoDataContext.Setup(x =>
				x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), It.IsAny<ReturnDocument>())).Throws<Exception>();

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_RaiseException_When_OverrideStatusErrors()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto();

			_apiFixture.MongoDataContext.Setup(x =>
				x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Throws<Exception>();
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()),
				It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);

			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_OverrideBanzaiStatus_when_NotValidObject()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 96,

				BanzaiStatusOverrideCode = "VOR",
				PipelineSource = "Dell",
				PipelineStage = "ORDER",
				InvoiceNo = "5201043153",
				OrderNo = "2005408599287",
				UserLastModifiedBy = "chandra"

			};

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.FindOneAndUpdate((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>(), ReturnDocument.Before)).Returns(GetRollupRequest());
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.Find(It.IsAny<FilterDefinition<RollupRequest>>())).Returns(FindRollupRequest());


			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_OverrideBanzaiStatus_when_ValidObject()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "ORD-POR",
				PipelineSource = "DELL",
				PipelineStage = "ORDER",
				InvoiceNo = "123i",
				OrderNo = "115799545",
				CurrentStatus= "ORD-PP",
				UserLastModifiedBy = "Ashish",
				Note="Test_Ashish",
				BuId="11"
			};
			
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_OverrideBanzaiStatus_when_ValidObject_VOR()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "VOR-HLD",
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				CurrentStatus = "VOR-CAN",
				UserLastModifiedBy = "Ashish",
				VorNo= "2006745184528",
				Note = "Test_Ashish",
				BuId = "11"
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_OverrideBanzaiStatus_when_ValidObject_Invoice()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "INV-BOOKED",
				PipelineSource = "DELL",
				PipelineStage = "INVOICE",
				CurrentStatus = "INV-RCVD",
				UserLastModifiedBy = "Ashish",
				InvoiceNo = "10262694175",
				Note = "Test_Ashish",
				BuId = "11"
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.OverrideBanzaiStatus(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_StatusUpdateBanzai_when_ValidObject_ORDER()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "UPDATED_STATUS",
				PipelineSource = "DELL",
				PipelineStage = "ORDER",
				CurrentStatus = "ORD - PP",
				UserLastModifiedBy = "Ashish",
				VorNo = "2006745184528",
				OrderNo= "596977487",
				Note = "Test_Ashish",
				BuId = "11"
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLockUpdate());
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.StatusUpdateBanzai(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_StatusUpdateBanzai_when_ValidObject_VOR()
		{
			//Arrange
			var expected = (int)HttpStatusCode.OK;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "UPDATED_STATUS",
				PipelineSource = "DELL",
				PipelineStage = "VOR",
				CurrentStatus = "VOR - PP",
				UserLastModifiedBy = "Ashish",
				VorNo = "2006745184528",
				OrderNo = "596977487",
				Note = "Test_Ashish",
				BuId = "11"
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLockUpdate());
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.StatusUpdateBanzai(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		public void Should_StatusUpdateBanzai_when_ValidObject_INVOICE()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;

			var updateStatusOverrideDto = new UpdateStatusOverrideDto()
			{
				Id = "5a37ee3fbab8610025e98131",
				Revision = 0,
				BanzaiStatusOverrideCode = "UPDATED_STATUS",
				PipelineSource = "DELL",
				PipelineStage = "INVOICE",
				CurrentStatus = "INVOICE-PP",
				UserLastModifiedBy = "Ashish",
				VorNo = "2006745184528",
				InvoiceNo = "596977487",
				Note = "Test_Ashish",
				BuId = "11"
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLockUpdate());
			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombosforOverride());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.StatusUpdateBanzai(updateStatusOverrideDto) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}
		[Trait("API", "DeletePipelineEnrichedRequest")]
		[Fact]
		public void Should_DeletePipelineEnrichedRequest_when_NotValidObject_INVOICE()
		{
			//Arrange
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.FindOneAndUpdate((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>(), ReturnDocument.Before)).Returns(GetRollupRequest());
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.Find(It.IsAny<FilterDefinition<RollupRequest>>())).Returns(FindRollupRequest());


			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.DeletePipelineEnrichedRequest("DELL","INVOICE","123i",true) as ObjectResult;

			//Asset
			Assert.Null(actual);
		}
		[Trait("API", "DeletePipelineEnrichedRequest")]
		[Fact]
		public void Should_DeletePipelineEnrichedRequest_when_NotValidObject_Vor()
		{
			//Arrange
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.FindOneAndUpdate((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>(), ReturnDocument.Before)).Returns(GetRollupRequest());
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.Find(It.IsAny<FilterDefinition<RollupRequest>>())).Returns(FindRollupRequest());


			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.DeletePipelineEnrichedRequest("DELL", "VOR", "123i", true) as ObjectResult;

			//Asset
			Assert.Null(actual);
		}
		[Trait("API", "DeletePipelineEnrichedRequest")]
		[Fact]
		public void Should_DeletePipelineEnrichedRequest_when_NotValidObject_Order()
		{
			//Arrange
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.FindOneAndUpdate((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>(), ReturnDocument.Before)).Returns(GetRollupRequest());
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.Find(It.IsAny<FilterDefinition<RollupRequest>>())).Returns(FindRollupRequest());


			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.DeletePipelineEnrichedRequest("DELL", "ORDER", "123i", true) as ObjectResult;

			//Asset
			Assert.Null(actual);
		}
	/*	[Trait("API", "PipelineEnrichedRequest_OverrideBanzaiStatus")]
		[Fact]
		[Obsolete]
		public void Should_GenerateTransactionDetailReport_when_NotValidObject()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;

			var updateStatusOverrideDto = new SearchPipelineEnrichedRequestDto()
			{
				PipelineSource = "DELL",
				PipelineStage = "VOR",
			};
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichedRequest());
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne((It.IsAny<FilterDefinition<PipelineEnrichedRequest>>()), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.FindOneAndUpdate((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>(), ReturnDocument.Before)).Returns(GetRollupRequest());
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne((It.IsAny<FilterDefinition<RollupRequest>>()), It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(true);


			_apiFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			//Act
			var actual = _apiFixture.PipelineEnrichedRequestsController.GenerateTransactionDetailReport(updateStatusOverrideDto);

			//Asset
			Assert.Null(actual);
		}*/

		//UpdateCustomer Method Test cases
		[Trait("API", "Enrichments_UpdateCustomer")]
		[Fact]
		public void Should_RaiseBadRequest_When_InvalidCustomerInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;

			_apiFixture.PipelineEnrichedRequestsController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateCustomer(null, null) as ObjectResult;

			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateCustomer Method Test case
		[Trait("API", "Enrichments_UpdateCustomer")]
		[Fact]
		public void Should_FailToUpdate_When_EnrichedRequestLocked()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			var expectedValue = "Record not found or locked in Enriched store! Try again later.";

			//Lock enrichment document
			_apiFixture.MongoDataContext
				.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), It.IsAny<ReturnDocument>()))
				.Returns(() => null);

			//Act	
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateCustomer("59b29afa815e95090899a46d", new UpdateCustomerRequesDto()) as ObjectResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
			Assert.Equal(expectedValue, actualStatus?.Value);
		}

		//UpdateCustomer Method Test case
		[Trait("API", "Enrichments_UpdateCustomer")]
		[Fact]
		public void Should_FailtoUpdate_When_RevisionMisMatch()
		{
			//Arrange
			var id = "59b29afa815e95090899a46d";
			var mockDto = new PipelineEnrichedRequest
			{
				Revision = 2
			};

			var expectedStatus = (int)HttpStatusCode.BadRequest;
			var expectedValue = "Request revision number is older.";

			//Lock enrichment document
			_apiFixture.MongoDataContext
				.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), It.IsAny<ReturnDocument>()))
				.Returns(mockDto);

			//Unlock enrichment document
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(true);

			//Act	
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateCustomer(id, GetUpdateCustomerRequesDto()) as ObjectResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
			Assert.Equal(expectedValue, actualStatus?.Value);
		}

		//UpdateCustomer Method Test case
		[Trait("API", "Enrichments_UpdateCustomer")]
		[Fact]
		public void Should_RaiseError_When_UpdatingCustomer()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;

			//Lock enrichment document
			_apiFixture.MongoDataContext
				.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
					It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), It.IsAny<ReturnDocument>()))
				.Throws<Exception>();

			//Act	
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateCustomer("59b29afa815e95090899a46d", new UpdateCustomerRequesDto()) as ObjectResult;

			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateCustomer Method Test case
		[Trait("API", "Enrichments_UpdateCustomer")]
		[Fact]
		public void Should_UpdateCustomer_When_ValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.NoContent;
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(
				   It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				   It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(),
				   It.IsAny<ReturnDocument>())).Returns(GetEnrichedRequest);
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests.UpdateOne(It.IsAny<FilterDefinition<RollupRequest>>(),
				It.IsAny<UpdateDefinition<RollupRequest>>())).Returns(() => true);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(() => true);
			//Act	
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateCustomer("59b29afa815e95090899a46d",
				GetUpdateCustomerRequesDto()) as NoContentResult;
			//Assert		
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_RaiseBadRequest_When_NullInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(null) as BadRequestResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_RaiseBadRequest_When_ModelStateInvalid()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.PipelineEnrichedRequestsController.ModelState.AddModelError("Banzai", "Adding Model Error");

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedRequestDto()) as BadRequestObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}
		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_NotFound_When_DocumentIsNull()
		{
			//Arrange
			var expectedStatus = "Not Found";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>()));

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);

			//Act

			var retundStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedRequestDto()) as OkObjectResult;
			var responceList = retundStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualStatus = responceList?[0].Status;
			//Assert
			//Assert.Equal(expectedStatus, (actualStatus.Value).Items[0]).Status);

			Assert.Equal(expectedStatus, actualStatus);
		}
		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_NotUpdate_When_DocumentLocked()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedResult = "Not updated, document locked";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>()));

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetNullEnrichementLockedDoc);

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedRequestDto()) as OkObjectResult;
			var responceList = actualStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualResult = responceList?[0].Remarks;
			//Assert
			Assert.Equal(expectedResult, actualResult);
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_Fails_When_ErrorOccurs()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>()));
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichementDocList);
			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedRequestDto()) as OkObjectResult;
			//Assert
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedRequest_UpdateSuccessfull_When_ValidIvoice()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedResult = "Successfully Updated";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(() => true);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ReturnDocument>())).Returns(GetEnrichementDocUnbooked);

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedRequestDto()) as OkObjectResult;
			var responceList = actualStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualResult = responceList?[0].Remarks;
			//Assert
			Assert.Equal(expectedResult, actualResult);
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedDPIDRequest_UpdateSuccessfull_When_ValidDPID()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedResult = "DPID was provided Contract # \"ee\" and it needs to be blank. Other fields were updated.";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(() => true);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ReturnDocument>())).Returns(GetEnrichementDocUnbooked);

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedDPIDRequestDto()) as OkObjectResult;
			var responceList = actualStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualResult = responceList?[0].Remarks;
			//Assert
			Assert.Equal(expectedResult, actualResult);
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateEnrichedRequest")]
		[Fact]
		public void Should_UpdateEnrichedOrderRequest_UpdateSuccessfull_When_ValidOrder()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedResult = "Successfully Updated";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(() => true);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichementDocList);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ReturnDocument>())).Returns(GetEnrichementDocUnbooked);

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedOrderRequestDto()) as OkObjectResult;
			var responceList = actualStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualResult = responceList?[0].Remarks;
			//Assert
			Assert.Equal(expectedResult, actualResult);
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}

		//UpdateEnrichedRequest Method Test case
		[Trait("API", "Enrichments_UpdateUserDefindFields")]
		[Fact]
		public void Should_UpdateEnrichedOrderRequest_UpdateFail_When_OrderisNull()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedResult = "Update Failed";
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.UpdateOne(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>())).Returns(() => true);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetNullEnrichementUnLockedDoc);
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(
				It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ReturnDocument>())).Returns(GetEnrichementDocBooked);

			//Act
			var actualStatus = _apiFixture.PipelineEnrichedRequestsController.UpdateUserDefindFields(GetUpdateEnrichedOrderRequestDto()) as OkObjectResult;
			var responceList = actualStatus?.Value as List<UpdateEnrichedResponseDto>;
			var actualResult = responceList?[0].Remarks;
			//Assert
			Assert.Equal(expectedResult, actualResult);
			Assert.Equal(expectedStatus, actualStatus?.StatusCode);
		}


		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_FindInvoicesForAura_When_Found()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;

			var mockdtoobj = new List<SearchPipelineEnrichedRequestDto> {new SearchPipelineEnrichedRequestDto(){
				PipelineSource = "DELL",
				PurchaseOrderNumber = "dd",
				
			} };

			var SearchPipelineEnrichedRequestDto = new SearchPipelineEnrichedRequestDto()
			{
				PipelineSource = "DELL",
				PipelineStage = "INVOICE",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiUnbookedExposureFlag = true,
			};
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocSearchInvoicesForAura());
			var actual = _apiFixture.PipelineEnrichedRequestsController.FindInvoicesForAura(SearchPipelineEnrichedRequestDto) as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_FindInvoicesForAura_When_NotFound()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;

			var mockdtoobj = new List<SearchPipelineEnrichedRequestDto> {new SearchPipelineEnrichedRequestDto(){
				PipelineSource = "DELL",
				PurchaseOrderNumber = "dd",

			} };

			var SearchPipelineEnrichedRequestDto = new SearchPipelineEnrichedRequestDto()
			{
				PipelineSource = "DELL",
				PipelineStage = "INVOICE",
				BanzaiStatusCode = "VOR-NEW",
				BanzaiUnbookedExposureFlag = true,
			};
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.FindInvoicesForAura(SearchPipelineEnrichedRequestDto) as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_SendPipelineInvoiceRequestsToAura_When_Found_Dell()
		{
			// Arrange.

			var mockdtoobj = new List<InvoiceExportRequestDto> {new InvoiceExportRequestDto(){
				PipelineSource = "DELL",

			} };
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.SendPipelineInvoiceRequestsToAura(mockdtoobj,"DELL","ashish-kumar2@dell.com") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_SendPipelineInvoiceRequestsToAura_When_Found_Emc()
		{
			// Arrange.

			var mockdtoobj = new List<InvoiceExportRequestDto> {new InvoiceExportRequestDto(){
				PipelineSource = "EMC",

			} };
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.SendPipelineInvoiceRequestsToAura(mockdtoobj, "EMC", "ashish-kumar2@dell.com") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_SendPipelineInvoiceRequestsToAura_When_Found_Channel()
		{
			// Arrange.

			var mockdtoobj = new List<InvoiceExportRequestDto> {new InvoiceExportRequestDto(){
				PipelineSource = "CHANNEL",

			} };
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.SendPipelineInvoiceRequestsToAura(mockdtoobj, "CHANNEL", "ashish-kumar2@dell.com") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_SendPipelineInvoiceRequestsToAura_When_NotFound_PipelineSource()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var mockdtoobj = new List<InvoiceExportRequestDto> {new InvoiceExportRequestDto(){
				PipelineSource = "",

			} };
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.SendPipelineInvoiceRequestsToAura(mockdtoobj, "", "ashish-kumar2@dell.com") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_SendPipelineInvoiceRequestsToAura_When_NotFound_PipelineSourceNotValid()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			var mockdtoobj = new List<InvoiceExportRequestDto> {new InvoiceExportRequestDto(){
				PipelineSource = "",

			} };
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.SendPipelineInvoiceRequestsToAura(mockdtoobj, "AB", "ashish-kumar2@dell.com") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_When_Found()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocForStatusChanges());
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL","VOR", "123b","123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_When_Found_Order()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocForStatusChanges());
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL", "ORDER", "123b", "123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_When_Found_Invoice()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.OK;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocForStatusChanges());
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL", "INVOICE", "123b", "123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_When_NotFound()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetEnrichedDocForStatusChanges());
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL", "", "123b", "123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_Throws_Exception()
		{
			// Arrange.
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(() => null);
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL", "VOR", "123b", "123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Null(actualStatusCode);

		}
		[Trait("API", "FindInvoicesForAura")]
		[Fact]
		public void Should_GetPipelineEnrichedRequestForStatusChanges_When_ExceptionThrows()
		{
			// Arrange.
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			//Act.
			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Throws<Exception>();
			var actual = _apiFixture.PipelineEnrichedRequestsController.GetPipelineEnrichedRequestForStatusChanges("DELL", "VOR", "123b", "123", "234") as ObjectResult;

			var actualStatusCode = actual?.StatusCode;

			//Assert.
			Assert.Equal(expectedStatus, actualStatusCode);

		}

		#region Private methods
		private static List<UpdateEnrichedRequestDto> GetUpdateEnrichedOrderRequestDto()
		{
			return new List<UpdateEnrichedRequestDto> {new UpdateEnrichedRequestDto(){
				Identifier = "Order",
				IdentifierValue = "D123",
				PipelineSource = "DELL",
				PurchaseOrderNumber = "dd",
				ContractNum = "ee",
				UserDefinedOne = "ddd",
				UserDefinedTwo = "ss",
				ShippingContactName = "dd",
				UserName = "daad"
			} };
		}
		private static List<UpdateEnrichedRequestDto> GetUpdateEnrichedDPIDRequestDto()
		{
			return new List<UpdateEnrichedRequestDto>() {new UpdateEnrichedRequestDto(){
				Identifier = "DPID",
				IdentifierValue = "D123",
				PipelineSource = "DELL",
				PurchaseOrderNumber = "dd",
				ContractNum = "ee",
				UserDefinedOne = "ddd",
				UserDefinedTwo = "ss",
				ShippingContactName = "dd",
				UserName = "daad"
			} };
		}
		private static List<UpdateEnrichedRequestDto> GetUpdateEnrichedRequestDto()
		{
			return new List<UpdateEnrichedRequestDto>() {new UpdateEnrichedRequestDto(){
				Identifier = "Invoice",
				IdentifierValue = "D123",
				PipelineSource = "DELL",
				PurchaseOrderNumber = "dd",
				ContractNum = "ee",
				UserDefinedOne = "ddd",
				UserDefinedTwo = "ss",
				ShippingContactName = "dd",
				UserName = "daad"
			} };
		}
		private static List<PipelineEnrichedRequest> GetNullEnrichementLockedDoc() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {
			VorID = "",
			DPIDServiceInSync = "",
			BanzaiFinancialComboInSync = "",
			RapportGetCustomerServiceInSync = "",
			BanzaiStatusInSync = "",
			OrderSummaryServiceInSync = "",
			OrderDetailServiceInSync = "",
			IsLocked = true,
			OrderStage = new OrderStage(),
			Common = null,
			VorStage = new VorStage(),
			InvoiceStage = null
		} };
		private static List<PipelineEnrichedRequest> GetNullEnrichementUnLockedDoc() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {
			VorID = "",
			DPIDServiceInSync = "",
			BanzaiFinancialComboInSync = "",
			RapportGetCustomerServiceInSync = "",
			BanzaiStatusInSync = "",
			OrderSummaryServiceInSync = "",
			OrderDetailServiceInSync = "",
			IsLocked = false,
			OrderStage = null,
			Common = null,
			VorStage = new VorStage(),
			InvoiceStage = null
		} };
		private static List<PipelineEnrichedRequest> GetEnrichementDocList() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {
			VorID = "2005384176647",
			DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = false,
			  OrderStage = new OrderStage(){
							 PipelineStage = "Order",
							 Orders = new List<Order>() {
							 new Order {
									OrderNo ="D123",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									}}}},
			Common = new Pipeline.Library.Entities.Common(){PipelineSource="VOR",
				SourceCustomerID="sss",
				SourceCustomerName="ggg",
				DFSUnbookedExposureID="ttt",
				SourcePaymentTerms="ggg",
				ShippingCountry="uu",
				DFSCountryCode="US"
			},
			VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage(){ PipelineStage="VOR",
				Invoices =new List<Pipeline.Library.Entities.Invoice>(){ new Pipeline.Library.Entities.Invoice() {
					InvoiceNo ="ddd",
					Status=new Status(){ BanzaiStatusCode="ddd"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="D123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} } }
		} };
		private static PipelineEnrichedRequest GetEnrichementDocBooked() => new PipelineEnrichedRequest
		{
			VorID = "2005384176647",
			DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = false,
			OrderStage = new OrderStage()
			{
				PipelineStage = "Order",
				Orders = new List<Order>() {
							 new Order {
									OrderNo ="4123",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									}}}
			},
			Common = new Pipeline.Library.Entities.Common()
			{
				PipelineSource = "VOR",
				SourceCustomerID = "sss",
				SourceCustomerName = "ggg",
				DFSUnbookedExposureID = "ttt",
				SourcePaymentTerms = "ggg",
				ShippingCountry = "uu",
				DFSCountryCode = "US"
			},
			VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Pipeline.Library.Entities.Invoice>(){ new Pipeline.Library.Entities.Invoice() {
					InvoiceNo ="D123",
					Status=new Status(){ BanzaiStatusCode="BOOKED"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} }
			}
		};
		private static PipelineEnrichedRequest GetEnrichementDocUnbooked() => new PipelineEnrichedRequest
		{
			VorID = "2005384176647",
			DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = false,
			OrderStage = new OrderStage()
			{
				PipelineStage = "Order",
				Orders = new List<Order>() {
							 new Order {
									OrderNo ="D123",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									}}}
			},
			Common = new Pipeline.Library.Entities.Common()
			{
				PipelineSource = "VOR",
				SourceCustomerID = "sss",
				SourceCustomerName = "ggg",
				DFSUnbookedExposureID = "ttt",
				SourcePaymentTerms = "ggg",
				ShippingCountry = "uu",
				DFSCountryCode = "US"
			},
			VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Pipeline.Library.Entities.Invoice>(){ new Pipeline.Library.Entities.Invoice() {
					InvoiceNo ="D123",
					Status=new Status(){ BanzaiStatusCode="UNBOOKED"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="D123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} }
			}
		};

		private static List<PipelineEnrichedRequest> GetEnrichedDocByOrderAndPipeline() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {
			VorID = "2005384176647",
			DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = true,
			VorStage = new VorStage(),
			  OrderStage = new OrderStage(){
							 PipelineStage = "Order",
							 Orders = new List<Order>() {

							 new Order {
									OrderNo ="2005408599287",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									},


							  }
							 }
					  },
					  Common = new Pipeline.Library.Entities.Common() {
							 PipelineSource = "Dell",
							 PipelineStageStart= "Dell",
							 SourceCustomerName = "BULKINTEGRATION",
							 DFSCreditSystem = "CMS",
							 DFSCreditID = "null",
							 DFSUnbookedExposureSystem ="RAPPORT",
							 DFSUnbookedExposureID = "null"

					  },
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Pipeline.Library.Entities.Invoice>(){ new Pipeline.Library.Entities.Invoice() {
					InvoiceNo ="D123",
					Status=new Status(){ BanzaiStatusCode="BOOKED"},
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					BookingDate=new DateTime(2016,05,07)
				} }
			}
		} };
		private static List<InvoiceEnrichedRequest> GetEnrichedInvoiceEnrichedRequests() => new List<InvoiceEnrichedRequest>{new InvoiceEnrichedRequest {
			
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			
			IsLocked = true,
					  Common = new Invoice.Library.Entities.Common() {
							 PipelineSource = "Dell",
							 PipelineStageStart= "Dell",
							 SourceCustomerName = "BULKINTEGRATION",
							 DFSCreditSystem = "CMS",
							 DFSCreditID = "null",
							 DFSUnbookedExposureSystem ="RAPPORT",
							 DFSUnbookedExposureID = "null"

					  },
			InvoiceStage = new Invoice.Library.Entities.InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Invoice.Library.Entities.Invoice>(){ new Invoice.Library.Entities.Invoice() {
					InvoiceNo ="D123",
					InvoiceDate =new DateTime(),
					InvoiceType ="tttt",
					OrderNo ="123",
					OriginalOrderNo ="eeee",
					OriginalInvoiceNo ="eeee",
					SourceDealId ="eeee",
					TotalDFSFinanceAmount =9.44m,
					TotalAmount =33,
					TagCount =3,
					TagVariance =44,
					ContractNum="xxx",
					Status = new InvoiceStatus()
					{
						CorrelationID="123"
				    },
					Charges = new List<Invoice.Library.Entities.InvoiceCharges>()
				{
					new Invoice.Library.Entities.InvoiceCharges
					{
						ReasonCode="12"
					},

					new Invoice.Library.Entities.InvoiceCharges
					{
						ReasonCode="18"
					}
				},
					TaxDetails = new List<Invoice.Library.Entities.InvoiceTaxDetail>()
				{
					new Invoice.Library.Entities.InvoiceTaxDetail
					{
						Group = "a"
					}
				},
					BookingDate=new DateTime(2016,05,07)
				} }
			}
		} };
		private static List<PipelineEnrichedRequest> GetEnrichedDocByInvoiceAndPipeline() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {
			VorID = "2005384176647",
			DPIDServiceInSync = "DELL",
			BanzaiFinancialComboInSync = "VOR",
			RapportGetCustomerServiceInSync = "NEW VOR",
			BanzaiStatusInSync = "NEW",
			OrderSummaryServiceInSync = "VOR-NEW",
			OrderDetailServiceInSync = "VOR Submitted",
			IsLocked = true,
			OrderStage = new OrderStage(),
			Common = new Pipeline.Library.Entities.Common(),
			VorStage = new VorStage(),
			InvoiceStage = new InvoiceStage()
		} };
		private static List<PipelineEnrichedRequest> GetEnrichedDocSearchInvoicesForAura() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {

					  VorID = "2005384176647",
					  DPIDServiceInSync = "DELL",
					  BanzaiFinancialComboInSync = "VOR",
					  RapportGetCustomerServiceInSync = "NEW VOR",
					  BanzaiStatusInSync = "NEW",
					  OrderSummaryServiceInSync = "VOR-NEW",
					  OrderDetailServiceInSync = "VOR Submitted",
					  IsLocked = true,
					  VorStage = new VorStage(),
					  OrderStage = new OrderStage(){
							 PipelineStage = "Order",
							 Orders = new List<Order>() {

							 new Order {
									OrderNo ="2005408599287",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									},


							  }
							 }
					  },
					  Common = new Pipeline.Library.Entities.Common() {
							 PipelineSource = "Dell",
							 PipelineStageStart= "Dell",
							 SourceCustomerName = "BULKINTEGRATION",
							 DFSCreditSystem = "CMS",
							 DFSCreditID = "null",
							 DFSUnbookedExposureSystem ="RAPPORT",
							 DFSUnbookedExposureID = "null"

					  },

					  InvoiceStage = new InvoiceStage() {
							 PipelineStage="Order",

							 Invoices = new List<Pipeline.Library.Entities.Invoice>
							 {
									new Pipeline.Library.Entities.Invoice
									{
									InvoiceNo = "5201043153",
									OrderNo = "2005408599287",
									InvoiceDate = DateTime.UtcNow,
									InvoiceType = "INVOICE",
									TotalDFSFinanceAmount = 291007.24m,
									OriginalOrderNo = "null",
									OriginalInvoiceNo = "null",
									StatusHistory =  new List<Status>() {
										new Status{
										BanzaiStatusCode = "INV-EXP-SENT",
										BanzaiStatusCreateDateTime = DateTime.UtcNow
										}	   
									},
									Status = new Status() {
										   BanzaiStatusCode = "INV-ACCEPT",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									}
								}
							 }
					  },
			  }
			  };
		private static List<PipelineEnrichedRequest> GetEnrichedDocForStatusChanges() => new List<PipelineEnrichedRequest>{new PipelineEnrichedRequest {

					  VorID = "2005384176647",
					  DPIDServiceInSync = "DELL",
					  BanzaiFinancialComboInSync = "VOR",
					  RapportGetCustomerServiceInSync = "NEW VOR",
					  BanzaiStatusInSync = "NEW",
					  OrderSummaryServiceInSync = "VOR-NEW",
					  OrderDetailServiceInSync = "VOR Submitted",
					  IsLocked = true,
					  VorStage = new VorStage(),
					  OrderStage = new OrderStage(){
							 PipelineStage = "Order",
							 Orders = new List<Order>() {

							 new Order {
									OrderNo ="2005408599287",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									},


							  }
							 }
					  },
					  Common = new Pipeline.Library.Entities.Common() {
							 PipelineSource = "Dell",
							 PipelineStageStart= "Dell",
							 SourceCustomerName = "BULKINTEGRATION",
							 DFSCreditSystem = "CMS",
							 DFSCreditID = "null",
							 DFSUnbookedExposureSystem ="RAPPORT",
							 DFSUnbookedExposureID = "null"

					  },

					  InvoiceStage = new InvoiceStage() {
							 PipelineStage="Order",

							 Invoices = new List<Pipeline.Library.Entities.Invoice>
							 {
									new Pipeline.Library.Entities.Invoice
									{
									InvoiceNo = "5201043153",
									OrderNo = "2005408599287",
									InvoiceDate = DateTime.UtcNow,
									InvoiceType = "INVOICE",
									TotalDFSFinanceAmount = 291007.24m,
									OriginalOrderNo = "null",
									OriginalInvoiceNo = "null",

									Status = new Status() {
										   BanzaiStatusCode = "INV-ACCEPT",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									}
								}
							 }
					  },
			  }
			  };

		private static UpdateCustomerRequesDto GetUpdateCustomerRequesDto()
		{
			return new UpdateCustomerRequesDto
			{
				Revision = 96,
				DFSCreditSystem = "CMS",
				DFSCreditID = null,
				DFSUnbookedExposureSystem = "LMS",
				DFSUnbookedExposureID = null,
				DFSCustomerReassignedFlag = false,
				DFSSegment = null,
				DFSSegmentClass = null,
				DFSOrphanFlag = "false",
				DFSCustomerMLAFlag = false,
				DFSCustomerFundingSourceReviewFlag = false,
				DFSCreditCautionFlag = false,
				UserLastModifiedBy = "",
				DFSCustomerName = "dddd",
				DirectOpsRep = "dd"
			};
		}

		private static PipelineEnrichedRequest GetEnrichedRequest()
		{
			return new PipelineEnrichedRequest
			{
				VorID = "2005384176647",
				DPIDServiceInSync = "DELL",
				BanzaiFinancialComboInSync = "VOR",
				RapportGetCustomerServiceInSync = "NEW VOR",
				BanzaiStatusInSync = "NEW",
				OrderSummaryServiceInSync = "VOR-NEW",
				OrderDetailServiceInSync = "VOR Submitted",
				IsLocked = true,
				//Orders = new Orders(),
				OrderStage = new OrderStage()
				{
					PipelineStage = "Order",
					Orders = new List<Order>() {

							 new Order {
									OrderNo ="2005408599287",
									DFSFinanceAmount = 100,
									Status = new Status() {
										   BanzaiStatusCode = "VOR",
										   BanzaiStatusCreateDateTime = DateTime.UtcNow
									},


							  }
							 }
				},
				//Common = new Common(),
				Common = new Pipeline.Library.Entities.Common()
				{
					PipelineSource = "Dell",
					PipelineStageStart = "Dell",
					SourceCustomerName = "BULKINTEGRATION",
					UserLastModifiedBy = "chandra",
					DFSCreditSystem = "CMS",
					DFSCreditID = "null",
					DFSUnbookedExposureSystem = "RAPPORT",
					DFSUnbookedExposureID = "null"
				},

				VorStage = new VorStage(),
				InvoiceStage = new InvoiceStage(),
				Revision = 96

			};
		}


		private RollupRequest GetRollupRequest()
		{
			return new RollupRequest
			{
				Id = "2005384176647",
				VorID = "DELL",
				PipelineSource = "VOR",
				PipelineStage = "NEW VOR",
				DFSFinanceProduct = "NEW",
				DFSCustomerMLAFlag = true,
				IsLocked = true
			};
		}
		private static List<RollupRequest> FindRollupRequest()
		{
			return new List<RollupRequest>
			{
				new RollupRequest {
				Id = "2005384176647",
				VorID = "DELL",
				PipelineSource = "VOR",
				PipelineStage = "NEW VOR",

				DFSFinanceProduct = "NEW",
				DFSCustomerMLAFlag = true,
				IsLocked = true,
				Details = new List<Detail> {
					new Detail {
						InvoiceNo = "5201043153",
						OrderNo = "2005408599287",

					}
				},
			} };
		}
		private static List<StatusCombo> GetStatusCombos()
		{
			return new List<StatusCombo> { new StatusCombo {
				Active = true,
				PipelineSource = "Dell",
				PipelineStage = "Order",
				DecisionSource = "NEW VOR",
				DecisionSourceStatusCode = "NEW",
				BanzaiStatusCode = "VOR",
				BanzaiStatusDesc = "VOR Submitted",
				BanzaiUnbookedExposureFlag = true,
				BanzaiStatusSequence = 1000,
				SourceStatusCode = "HLD",
				SourceStatusDesc = "Submitted"
			} };

		}

		private static IEnumerable<StatusCombo> GetStatusCombosforOverride()
		{
			return new List<StatusCombo>
			{
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",

					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL ORDER",
					UserOverride = true,
					UserUpdateCurrent = true
				  },
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-SHPD",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL ORDER",
					UserOverride = true,
					UserUpdateCurrent = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3700,
				   BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-POR",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL ORDER",
					UserOverride = true,
					UserUpdateFuture = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Invoice Processed",
					BanzaiStatusCode = "INV-RCVD",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL INVOICE",
					UserOverride = true,
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "INV-BOOKED",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL INVOICE",
					UserOverride = true,
					UserUpdateFuture = true
				  },
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Validated",
					BanzaiStatusCode = "VOR-CAN",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL VOR",
					UserOverride = true,
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Hold",
					BanzaiStatusCode = "VOR-HLD",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL VOR",
					UserOverride = true,
					UserUpdateFuture = true
				  },
					new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Invoice Received",
					BanzaiStatusCode = "INV-RCVD",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL INVOICE"
				},
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "UPDATED_STATUS",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
					new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Received",
					BanzaiStatusCode = "VOR-PP",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL VOR",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Received",
					BanzaiStatusCode = "UPDATED_STATUS",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL VOR",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
					new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "INVOICE Received",
					BanzaiStatusCode = "INVOICE-PP",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL INVOICE",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "DELL",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "INVOICE Received",
					BanzaiStatusCode = "UPDATED_STATUS",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "DELL INVOICE",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				}
			};
		}
		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
		{
			Id = "5a8dbc8f21eb5a002da2a0e4",
			VorID = "2006745184528",
			IsLocked = false,

			Common = new Pipeline.Library.Entities.Common()
			{
				PipelineSource = "DELL",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
				SourceBusinessUnit = "11",
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
				}
			},
			InvoiceStage = new Pipeline.Library.Entities.InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()

				{
					new DFS.Banzai.Pipeline.Library.Entities.Invoice()

				{
						InvoiceNo ="10262694175",
						TotalDFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "INV-RCVD",
						BanzaiStatusSequence = 1070
					},

				} }
			},
			OrderStage = new OrderStage()
			{
				PipelineStage = "ORDER",
				Orders = new List<Order>()

				{
					new Order()

				{
						OrderNo ="115799545",
						DFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "ORD-PP",
						BanzaiStatusSequence = 3900
					},

				} }
			}
		};

		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLockUpdate() => new PipelineEnrichedRequest
		{
			Id = "5a8dbc8f21eb5a002da2a0e4",
			VorID = "2006745184528",
			IsLocked = false,

			Common = new Pipeline.Library.Entities.Common()
			{
				PipelineSource = "DELL",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
				}
			},

			OrderStage = new OrderStage()
			{
				PipelineStage = "ORDER",
				Orders = new List<Order>()

				{
					new Order()

				{
						OrderNo ="596977487",
						DFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "ORD-PP",
						BanzaiStatusSequence = 3900
					},

				} }
			},
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()

				{
					new DFS.Banzai.Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="10262694175",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				} }
			}
		};

		#endregion
	}
}

