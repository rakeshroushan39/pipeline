namespace DFS.Banzai.Api.UnitTest {
	public class MongoHealthContributorTest {
		
	}
}