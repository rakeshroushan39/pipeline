﻿using DFS.Banzai.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
   public class GaapAttributesControllerTest : IClassFixture<ApiFixture>
    {

        private readonly ApiFixture _apiFixture;

        public GaapAttributesControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
            _apiFixture.GaapAttributesController.ModelState.Clear();
        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_validMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "234";
            var expectedStatusCode = (int)HttpStatusCode.OK;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Returns(GetGAAPAttributesById);
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource,buid, invoices) as OkObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_InvalidMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "234";
            var expectedStatusCode = (int)HttpStatusCode.NotFound;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Returns(() => null);
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource, buid, invoices) as NotFoundResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_ThrowsException()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "234";
            var expectedStatusCode = (int)HttpStatusCode.InternalServerError;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource, buid, invoices) as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_ModelError()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "";
            var buid = "234";
            var expectedStatusCode = (int)HttpStatusCode.BadRequest;
            _apiFixture.EmcAssetRequestsController.ModelState.AddModelError("pipelineSource", "Invalid PipelineSource.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource, buid, invoices) as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_ModelError_Buid()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "";
            var expectedStatusCode = (int)HttpStatusCode.BadRequest;
            _apiFixture.EmcAssetRequestsController.ModelState.AddModelError("buid", "Invalid buid.");

            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource, buid, invoices) as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_GetGAAPAttributes_when_ModelError_invoice()
        {
            //Arrange

            var invoices = "";
            var piplinesource = "";
            var buid = "";
            var expectedStatusCode = (int)HttpStatusCode.BadRequest;
            _apiFixture.EmcAssetRequestsController.ModelState.AddModelError("Invoice", "Invoice.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.GaapAttributesController.GetGAAPAttributes(piplinesource, buid, invoices) as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_UnlockDocument_when_validMessage()
        {
            //Arrange
            var expectedStatusCode = (int)HttpStatusCode.OK;
            //_apiFixture.EmcAssetRequestsController.ModelState.AddModelError("message", "Invalid queue.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Returns(GetGAAPAttributesById);
            //Act
            var actual = _apiFixture.GaapAttributesController.UnlockDocument("1ab") as OkObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);
        }
        [Trait("API", "GetGAAPAttributes")]
        [Fact]
        public void Should_UnlockDocument_when_ThrowsException()
        {
            //Arrange
            var expectedStatusCode = (int)HttpStatusCode.OK;
            _apiFixture.EmcAssetRequestsController.ModelState.AddModelError("Invoice", "Invoice.");
            _apiFixture.MongoDataContext.Setup(x => x.GAAPAttributes.Find(It.IsAny<FilterDefinition<GAAPAttributes>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.GaapAttributesController.UnlockDocument("1ab") as ObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }

        private static List<GAAPAttributes> GetGAAPAttributesById() => new List<GAAPAttributes>{new GAAPAttributes {
               Id="1ab",
               PipelineSource = "DELL",
               SourceBusinessUnit="234",
               InvoiceNo="123",
               IsLocked= true

        } };


    }
}
