﻿using DFS.Banzai.Asset.Library.Entities;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class AssetEnrichedRequestsControllerTest : IClassFixture<ApiFixture>
    {

        private readonly ApiFixture _apiFixture;

        public AssetEnrichedRequestsControllerTest(ApiFixture apiFixture)
        {
            _apiFixture = apiFixture;
            _apiFixture.AssetEnrichedRequestsController.ModelState.Clear();
        }

        [Trait("API", "AssetEnrichedRequestsController")]
        [Fact]
        public void Should_ClassafiDetailResponse_when_validMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "1234";
            var vendorid = "234";
            var expectedStatusCode = (int)HttpStatusCode.OK;
            //_apiFixture.AssetEnrichedRequestsController.ModelState.AddModelError("pipelineSource", "Invalid Pipeline Source.");

            _apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(GetAssetEnrichedRequests());
            //Act
            var actual = _apiFixture.AssetEnrichedRequestsController.ClassafiDetailResponse(piplinesource, invoices, buid, vendorid) as OkObjectResult;

            //Asset
            Assert.Equal(expectedStatusCode, actual?.StatusCode);

        }

        [Trait("API", "AssetEnrichedRequestsController")]
        [Fact]
        public void Should_ClassafiDetailResponse_when_NotvalidMessage()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "DELL";
            var buid = "1234";
            var vendorid = "234";

            _apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Throws<Exception>();
            //Act
            var actual = _apiFixture.AssetEnrichedRequestsController.ClassafiDetailResponse(piplinesource, invoices, buid, vendorid) as OkObjectResult;

            //Asset
            Assert.Null( actual?.StatusCode);

        }
        [Trait("API", "AssetEnrichedRequestsController")]
        [Fact]
        public void Should_ClassafiDetailResponse_when_NotvalidNullMessage()
        {
            //Arrange

            var invoices = "";
            var piplinesource = "DELL";
            var buid = "1234";
            var vendorid = "234";
            
            _apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(() => null);
            //Act
            var actual = _apiFixture.AssetEnrichedRequestsController.ClassafiDetailResponse(piplinesource, invoices, buid, vendorid) as NotFoundResult;

            //Asset
            Assert.Null(actual?.StatusCode);

        }

        [Trait("API", "AssetEnrichedRequestsController")]
        [Fact]
        public void Should_ClassafiDetailResponse_when_ModelError()
        {
            //Arrange

            var invoices = "123";
            var piplinesource = "";
            var buid = "1234";
            var vendorid = "234";
           
            _apiFixture.AssetEnrichedRequestsController.ModelState.AddModelError("pipelineSource", "Invalid Pipeline Source.");

            _apiFixture.MongoDataContextAsset.Setup(x => x.AssetEnrichedRequests.Find(It.IsAny<FilterDefinition<AssetEnrichedRequest>>())).Returns(GetAssetEnrichedRequests());
            //Act
            var actual = _apiFixture.AssetEnrichedRequestsController.ClassafiDetailResponse(piplinesource, invoices, buid, vendorid) as NotFoundResult;

            //Asset
            Assert.Null(actual?.StatusCode);

        }



        #region Private Methods


        /// <summary>
        /// This method creates and return list of AssetEnrichedRequests
        /// </summary>
        /// <returns></returns>
        private List<AssetEnrichedRequest> GetAssetEnrichedRequests()
        {
            return new List<AssetEnrichedRequest> { GetAssetEnrichedRequest() };
        }

        /// <summary>
        /// This method returns expected AssetEnrichedRequest
        /// </summary>
        /// <returns></returns>
        private AssetEnrichedRequest GetAssetEnrichedRequest()
        {
            var classifyDetailRes = BsonSerializer.Deserialize<BsonDocument>
        (@"{""CorrelationId"" : ""bf43a7da-632a-450b-8205-668799e42280"", 
        ""AssetType"" : ""DELL_DIRECT"", 
        ""PipelineSource"" : ""DELL"", 
        ""VendorId"" : null, 
        ""InvoiceNumber"" : ""3681324978"", 
        ""BusinessUnitId"" : ""707"", 
        ""CogsEnrichmentDate"" : null, 
        ""RevenueEnrichmentDate"" : null, 
        ""GaapEnrichmentDate"" : ""2020-06-03T21:50:30.462Z""
           ""Assets"" : [
            {
                ""LineNumber"" : NumberInt(1), 
                ""BaseCode"" : ""210-ANUD"", 
                ""BaseDescription"" : null, 
                ""AssetType"" : ""DELL_DIRECT"", 
                ""SerialNumberList"" : [
                    ""31Y37X2""
                ], 
                ""ReferenceIdList"" : null, 
                ""AsSoldAmount"" : 862.49, 
                ""SkuTypeCode"" : null, 
                ""Quantity"" : NumberInt(1), 
                ""TagCount"" : NumberInt(1), 
                ""TagVariance"" : NumberInt(0), 
                ""ResidualValue"" : 0.0, 
                ""ProductDetails"" : [
                    {
                        ""LineNumber"" : NumberInt(1), 
                        ""Code"" : ""210-ANUD"", 
                        ""Description"" : ""Inspiron 5680"", 
                        ""Quantity"" : NumberInt(1), 
                        ""QuantityPerAsset"" : 1.0, 
                        ""AsSoldUnitPrice"" : 45.94, 
                        ""AsSoldAmount"" : 45.94, 
                        ""SkyTypeCode"" : null, 
                        ""GaapAttributes"" : {
                            ""FINITEMCAT_DISP"" : ""FINHARDWR"", 
                            ""FINREVCLS_DISP"" : ""Bse HW Dell Syst"", 
                            ""FINLEASPRD_DISP"" : ""Hard""
                        }, 
                        ""GaapError"" : null, 
                        ""CogsLOB"" : ""NA"", 
                        ""RevenueLOB"" : ""NA"", 
                        ""CogsAmount"" : 0.0, 
                        ""CogsAmountPerAsset"" : null, 
                        ""AllocatedAmount"" : 0.0, 
                        ""AllocatedAmountPerAsset"" : null
                    }, 
]}]

}");

            return new AssetEnrichedRequest
            {
                Revision = 2,
                VendorID = "234",
                InvoiceNo = "123",
                PipelineSource = "DELL",
                SourceBusinessUnit = "1234",
                Six0Six = false,
                COGS = true,
                GAAP = false,
                LastModifiedDateTime = DateTime.UtcNow,
                CreateDateTime = DateTime.UtcNow,
                StatusHistory = new List<AssetStatus>()
                {
                    new AssetStatus
                    {
                        NotificationType = "COGS",
                        CorrelationID = "1233333",
                        MessageID = "5d692d85d3588a2a0ad23537",
                        CreateDateTime = DateTime.UtcNow,
                        DecisionSourceDateTime = DateTime.UtcNow,
                        MessageReceivedDateTime = DateTime.UtcNow
                    },

                    new AssetStatus
                    {
                        NotificationType = "GAAP",
                        CorrelationID = "1212",
                        MessageID = "5d692d85d3588a2a0ad231222",
                        CreateDateTime = DateTime.UtcNow,
                        DecisionSourceDateTime = DateTime.UtcNow,
                        MessageReceivedDateTime = DateTime.UtcNow
                    }
                },
                IsLocked = false,
                ClassafiDetailResponse = classifyDetailRes
            };


        }
        #endregion
    }
}
