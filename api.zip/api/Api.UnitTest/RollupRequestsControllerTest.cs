using DFS.Banzai.Library.Models.Rollups;
using DFS.Banzai.Pipeline.Library.Entities;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using Xunit;

namespace DFS.Banzai.Api.UnitTest
{
    public class RollupRequestsControllerTest : IClassFixture<ApiFixture>
	{
		private readonly ApiFixture _apiFixture;

		public RollupRequestsControllerTest(ApiFixture apiFixture)
		{
			_apiFixture = apiFixture;

			_apiFixture.RollupRequestsController.ModelState.Clear();
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseBadRequestException_When_PipelineSourceIsNullOrEmpty()
		{
			//Arrange
			var pipelineSource = "";
			var dfsUnbookedExposureSystem = "RAPPORT";
			var dfsUnbookedExposureId = "2020";
			var expected = (int)HttpStatusCode.BadRequest;

			//Act
			_apiFixture.RollupRequestsController.ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");

			var actual = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem(pipelineSource, dfsUnbookedExposureSystem, dfsUnbookedExposureId) as BadRequestObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseBadRequestException_When_dfsUnbookedExposureSystemIsNullOrEmpty()
		{
			//Arrange
			var pipelineSource = "Dell";
			var dfsUnbookedExposureSystem = "";
			var dfsUnbookedExposureId = "2020";
			var expected = (int)HttpStatusCode.BadRequest;

			//Act
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsUnbookedExposureSystem", "The provided DFS Unbooked Exposure System.");

			var actual = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem(pipelineSource, dfsUnbookedExposureSystem, dfsUnbookedExposureId) as BadRequestObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseBadRequestException_When_dfsUnbookedExposureIdIsNullOrEmpty()
		{
			//Arrange
			var pipelineSource = "Dell";
			var dfsUnbookedExposureSystem = "RAPPORT";
			var dfsUnbookedExposureId = "";
			var expected = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsUnbookedExposureId", "The provided DFS Unbooked Exposure Id.");

			//Act
			var actual = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem(pipelineSource, dfsUnbookedExposureSystem, dfsUnbookedExposureId) as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseBadRequest_When_NoInput()
		{
			//Arrange
			var pipelineSource = "";
			var dfsUnbookedExposureSystem = "";
			var dfsUnbookedExposureId = "";
			var expected = (int)HttpStatusCode.BadRequest;

			//Act
			var actual = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem(pipelineSource, dfsUnbookedExposureSystem, dfsUnbookedExposureId) as ObjectResult;
			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseException_When_InvalidExpInput()
		{
			//Arrange
			var expected = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Throws<Exception>();

			//Act
			var actual = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem("DELL", "RAPPORT", "12345") as ObjectResult;

			//Asset
			Assert.Equal(expected, actual?.StatusCode);
		}

		//ToDo: Need to check this
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		//[Fact(Skip = "TBD")]
		[Fact]
		public void Should_ReturnAmount_When_ValidUnbookedInputs()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedAmount = 4384.42m;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Returns(RollupMock);

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByUnbookedExpSystem("DELL", "CMS", "16923252");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);
			Assert.Equal(expectedAmount, ((ObjectResult)obj).Value);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseBadRequest_When_InvalidExpValues()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.GetRollupByUnbookedExpSystem(null, null, null) as BadRequestObjectResult;
			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByUnbookedExpSystem")]
		[Fact]
		public void Should_RaiseException_When_UnbookedAggregateFails()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
					.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Throws<Exception>();

			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.GetRollupByUnbookedExpSystem("DELL", "CMS", "16923252") as ObjectResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByUnbookedExpSystem")]
		[Fact]
		public void Should_ReturnExposure_When_UnbookedValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = ExpectedExposureResult();
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
				.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Returns(RollupMock);

			//Act
			var obj = _apiFixture.RollupRequestsController.GetRollupByUnbookedExpSystem("DELL", "CMS", "16923252");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;
			var actualDto = ((ObjectResult)obj).Value as IEnumerable<ExposureResponseDto>;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);
			actualDto.Should().BeEquivalentTo(expectedDto);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByCreditSystem")]
		[Fact]
		public void Should_RaiseBadRequest_When_InvalidCreditInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.GetRollupByCreditSystem(null, null, null) as BadRequestObjectResult;
			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByCreditSystem")]
		[Fact]
		public void Should_RaiseException_When_CreditAggregateFails()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Throws<Exception>();

			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.GetRollupByCreditSystem("DELL", "CMS", "16923252") as ObjectResult;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode?.StatusCode);
		}

		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByCreditSystem")]
		[Fact]
		public void Should_ReturnExposure_When_CreditValidInput()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			var expectedDto = ExpectedExposureResult();
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
				.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Returns(RollupMock);

			//Act
			var obj = _apiFixture.RollupRequestsController.GetRollupByCreditSystem("DELL", "CMS", "16923252");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;
			var actualDto = ((ObjectResult)obj).Value as IEnumerable<ExposureResponseDto>;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);
			actualDto.Should().BeEquivalentTo(expectedDto);
		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		//[Fact(Skip = "TBD")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_Inputs()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Returns(RollupMock);

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "CMS", "16923252","CMA","123");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);
			
		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		//[Fact(Skip = "TBD")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_RaiseBadRequestException_When_PipelineSourceIsNullOrEmpty()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("pipelineSource", "The provided Pipeline Source.");

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("", "CMS", "16923252", "CMA", "123");
			var actualStatusCode = ((BadRequestObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_RaiseBadRequestException_When_DfsCreditSystemIsNullOrEmpty()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsCreditSystem and dfsCreditId", "The combination of dfsCreditSystem/Id.");

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "", "16923252", "CMA", "123");
			var actualStatusCode = ((BadRequestObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_RaiseBadRequestException_WhenDfscreditIdIsNullOrEmpty()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsCreditSystem and dfsCreditId", "The combination of dfsCreditSystem/Id.");

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "CMS", "", "CMA", "123");
			var actualStatusCode = ((BadRequestObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_RaiseBadRequestException_WhenDfsUnbookedExposureSystemIsNullOrEmpty()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsUnbookedExposureSystem and dfsUnbookedExposureId", "The combination of dfsUnbookedExposureSystem/Id.");

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "CMS", "a", "", "123");
			var actualStatusCode = ((BadRequestObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_RaiseBadRequestException_WhenDfsUnbookedExposureIdIsNullOrEmpty()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.BadRequest;
			_apiFixture.RollupRequestsController.ModelState.AddModelError("dfsUnbookedExposureSystem and dfsUnbookedExposureId", "The combination of dfsUnbookedExposureSystem/Id.");

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "CMS", "123", "a", "");
			var actualStatusCode = ((BadRequestObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}

		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		//[Fact(Skip = "TBD")]
		[Fact]
		[Obsolete]
		public void Should_GetByCreditSystem_When_ThrowsException()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.InternalServerError;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Throws<Exception>();

			//Act
			var obj = _apiFixture.RollupRequestsController.GetByCreditSystem("DELL", "CMS", "16923252", "CMA", "123");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);

		}
		[Trait("API", "DeleteRollupRequest")]
		[Fact]
		public void Should_DeleteRollupRequest_When_ValidInput()
		{
			//Arrange
			
			
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
				.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Returns(RollupMock);

			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.DeleteRollupRequest("DELL", "VOR", "16923252") as ObjectResult;
			
			

			//Assert			
			Assert.Null(actualStatusCode?.StatusCode);
			
		}
		[Trait("API", "DeleteRollupRequest")]
		[Fact]
		public void Should_DeleteRollupRequest_When_ValidInputForOrder()
		{
			//Arrange
			

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
				.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Returns(RollupMock);

			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.DeleteRollupRequest("DELL", "ORDER", "16923252") as ObjectResult;

			


			//Assert			
			Assert.Null(actualStatusCode?.StatusCode);

		}
		[Trait("API", "DeleteRollupRequest")]
		[Fact]
		public void Should_DeleteRollupRequest_When_ValidInputForINVOICE()
		{
			//Arrange
			

			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
				.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
				.Returns(RollupMock);

			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.DeleteRollupRequest("DELL", "INVOICE", "16923252") as ObjectResult;



			//Assert			
			Assert.Null(actualStatusCode?.StatusCode);

		}
		//GetByCreditSystem Method Test cases
		[Trait("API", "Rollups_GetRollupByCreditSystem")]
		[Fact]
		public void Should_RaiseException_When_DeleteRollupRequest()
		{
			//Act
			var actualStatusCode = _apiFixture.RollupRequestsController.DeleteRollupRequest("DELL", "INVOICE", "16923252") as ObjectResult;

			//Assert			
			Assert.Null(actualStatusCode?.StatusCode);
		}

		[Trait("API", "RecreateRollupRequests")]
		[Fact]
		public void Should_RecreateRollupRequests_When_ValidData()
		{
			//Arrange
			var Piplinesource = "DELL";
			var mockObj = new List<BsonDocument> {
				BsonSerializer.Deserialize<BsonDocument>(
					"{ \"_id\" : \"5a8efc4ffd0e8d4090401be0\", \"VorID\" : \"2001498953641\", \"Revision\" : 2, \"Common\" : { \"DFSCreditSystem\" : \"CMS\", \"DFSCreditID\" : \"98777\", \"DFSCustomerReassignedFlag\" : false, \"DFSUnbookedExposureSystem\" : \"\", \"DFSUnbookedExposureID\" : \"\", \"DFSSegment\" : null, \"DFSSegmentClass\" : null, \"DFSOrphanFlag\" : \"N\", \"DFSCustomerMLAFlag\" : false, \"DFSCustomerFundingSourceReviewFlag\" : false, \"DFSCreditCautionFlag\" : false, \"DFSCustomerName\" : null, \"DirectOpsRep\" : null, \"DFSProductSpace\" : \"TRANSACTIONAL LEASE\", \"SourceCustomerID\" : \"540000006119\", \"SourceCustomerName\" : \"CR488 UAT CO 45 TERMS CC\" }, \"OrderStage\" : { \"Orders\" : [{ \"OrderNo\" : \"113305550\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305568\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305576\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305584\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305592\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }] } }")
			};

			var expected = (int)HttpStatusCode.OK;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ProjectionDefinition<PipelineEnrichedRequest>>(), 0)).Returns(mockObj);

			//Act
			var actualObj = _apiFixture.RollupRequestsController.RecreateRollupRequests(Piplinesource);
			var actualStatusCode = ((ObjectResult)actualObj).StatusCode;
			
			//Asset
			Assert.Equal(expected, actualStatusCode);
		}

		[Trait("API", "RecreateRollupRequests")]
		[Fact]
		public void Should_RecreateRollupRequests_When_ThrowsException()
		{
			//Arrange
			var Piplinesource = "DELL";
			var mockObj = new List<BsonDocument> {
				BsonSerializer.Deserialize<BsonDocument>(
					"{ \"_id\" : \"5a8efc4ffd0e8d4090401be0\", \"VorID\" : \"2001498953641\", \"Revision\" : 2, \"Common\" : { \"DFSCreditSystem\" : \"CMS\", \"DFSCreditID\" : \"98777\", \"DFSCustomerReassignedFlag\" : false, \"DFSUnbookedExposureSystem\" : \"\", \"DFSUnbookedExposureID\" : \"\", \"DFSSegment\" : null, \"DFSSegmentClass\" : null, \"DFSOrphanFlag\" : \"N\", \"DFSCustomerMLAFlag\" : false, \"DFSCustomerFundingSourceReviewFlag\" : false, \"DFSCreditCautionFlag\" : false, \"DFSCustomerName\" : null, \"DirectOpsRep\" : null, \"DFSProductSpace\" : \"TRANSACTIONAL LEASE\", \"SourceCustomerID\" : \"540000006119\", \"SourceCustomerName\" : \"CR488 UAT CO 45 TERMS CC\" }, \"OrderStage\" : { \"Orders\" : [{ \"OrderNo\" : \"113305550\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305568\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305576\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305584\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }, { \"OrderNo\" : \"113305592\", \"Status\" : { \"DecisionSourceStatusCode\" : \"INV\", \"BanzaiStatusCode\" : \"INV\" } }] } }")
			};

			var expected = (int)HttpStatusCode.InternalServerError;

			_apiFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(),
				It.IsAny<ProjectionDefinition<PipelineEnrichedRequest>>(), 0)).Throws<Exception>();

			//Act
			var actualObj = _apiFixture.RollupRequestsController.RecreateRollupRequests(Piplinesource);
			var actualStatusCode = ((ObjectResult)actualObj).StatusCode;

			//Asset
			Assert.Equal(expected, actualStatusCode);
		}
		[Trait("API", "Rollups_GetByUnbookedExpSystem")]
		//[Fact(Skip = "TBD")]
		[Fact]
		public void Should_UnlockDocument_When_ValidUnbookedInputs()
		{
			//Arrange
			var expectedStatus = (int)HttpStatusCode.OK;
			_apiFixture.MongoDataContext.Setup(x => x.RollupRequests
			.Aggregate(It.IsAny<BsonDocument>(), It.IsAny<FilterDefinition<BsonDocument>>(), It.IsAny<BsonDocument>(), It.IsAny<string>()))
			.Returns(RollupMock);

			//Act
			var obj = _apiFixture.RollupRequestsController.UnlockDocument("16923252");
			var actualStatusCode = ((ObjectResult)obj).StatusCode;

			//Assert			
			Assert.Equal(expectedStatus, actualStatusCode);
		}

		private static IList<BsonDocument> RollupMock()
		{
			string obj1 =
				"{ \"_id\" : { \"PipelineSource\" : \"DELL\", \"DFSCreditSystem\" : \"RAPPORT\", \"DFSCreditID\" : \"542115\", \"PipelineStage\" : \"ORDER\", \"DFSUnbookedExposureSystem\" : \"RAPPORT\", \"DFSUnbookedExposureID\" : \"542115\", \"DFSPayCode\" : \"5\", \"DFSFinanceProduct\" : \"DBL\", \"DFSSalesPipeline\" : \"DIRECT\", \"DFSProductSpace\" : \"TRANSACTIONAL\", \"BanzaiStatusCode\" : \"ORD-CMP\" }, \"Quantity\" : 3, \"Total\" : 4384.4200000000001 }";
			string obj2 =
				"{ \"_id\" : { \"PipelineSource\" : \"DELL\", \"DFSCreditSystem\" : \"RAPPORT\", \"DFSCreditID\" : \"542115\", \"PipelineStage\" : \"VOR\", \"DFSUnbookedExposureSystem\" : \"RAPPORT\", \"DFSUnbookedExposureID\" : \"542115\", \"DFSPayCode\" : \"5\", \"DFSFinanceProduct\" : \"DBL\", \"DFSSalesPipeline\" : \"DIRECT\", \"DFSProductSpace\" : \"TRANSACTIONAL\", \"BanzaiStatusCode\" : \"VOR-ORL\" }, \"Quantity\" : 1, \"Total\" : 4384.4200000000001 }";
			string obj3 =
				"{ \"_id\" : { \"PipelineSource\" : \"DELL\", \"DFSCreditSystem\" : \"RAPPORT\", \"DFSCreditID\" : \"542115\", \"PipelineStage\" : \"ORDER\", \"DFSUnbookedExposureSystem\" : \"RAPPORT\", \"DFSUnbookedExposureID\" : \"542115\", \"DFSPayCode\" : \"\", \"DFSFinanceProduct\" : \"\", \"DFSSalesPipeline\" : \"\", \"DFSProductSpace\" : \"\", \"BanzaiStatusCode\" : \"ORD-POR\" }, \"Quantity\" : 1, \"Total\" : 974.25 }";
			string obj4 =
				"{ \"_id\" : { \"PipelineSource\" : \"DELL\", \"DFSCreditSystem\" : \"RAPPORT\", \"DFSCreditID\" : \"542115\", \"PipelineStage\" : \"ORDER\", \"DFSUnbookedExposureSystem\" : \"RAPPORT\", \"DFSUnbookedExposureID\" : \"542115\", \"DFSPayCode\" : \"5\", \"DFSFinanceProduct\" : \"DBL\", \"DFSSalesPipeline\" : \"DIRECT\", \"DFSProductSpace\" : \"TRANSACTIONAL LEASE\", \"BanzaiStatusCode\" : \"ORD-CMP\" }, \"Quantity\" : 3, \"Total\" : 4384.4200000000001 }";

			var bsonList = new List<BsonDocument> {
				BsonSerializer.Deserialize<BsonDocument>(obj1),
				BsonSerializer.Deserialize<BsonDocument>(obj2),
				BsonSerializer.Deserialize<BsonDocument>(obj3),
				BsonSerializer.Deserialize<BsonDocument>(obj4)
			};

			return bsonList;
		}

		private IEnumerable<ExposureResponseDto> ExpectedExposureResult()
		{
			string obj =
				"[{\"PipelineSource\":\"DELL\",\"PipelineStage\":\"ORDER\",\"DFSFinanceProduct\":\"DBL\",\"DFSPayCode\":\"5\",\"DFSProductSpace\":\"TRANSACTIONAL\",\"DFSSalesPipeline\":\"DIRECT\",\"DFSCreditSystem\":\"RAPPORT\",\"DFSCreditID\":\"542115\",\"DFSUnbookedExposureSystem\":\"RAPPORT\",\"DFSUnbookedExposureID\":\"542115\",\"BanzaiStatusCode\":\"ORD-CMP\",\"Quantity\":3,\"Total\":4384.42},{\"PipelineSource\":\"DELL\",\"PipelineStage\":\"VOR\",\"DFSFinanceProduct\":\"DBL\",\"DFSPayCode\":\"5\",\"DFSProductSpace\":\"TRANSACTIONAL\",\"DFSSalesPipeline\":\"DIRECT\",\"DFSCreditSystem\":\"RAPPORT\",\"DFSCreditID\":\"542115\",\"DFSUnbookedExposureSystem\":\"RAPPORT\",\"DFSUnbookedExposureID\":\"542115\",\"BanzaiStatusCode\":\"VOR-ORL\",\"Quantity\":1,\"Total\":4384.42},{\"PipelineSource\":\"DELL\",\"PipelineStage\":\"ORDER\",\"DFSFinanceProduct\":\"\",\"DFSPayCode\":\"\",\"DFSProductSpace\":\"\",\"DFSSalesPipeline\":\"\",\"DFSCreditSystem\":\"RAPPORT\",\"DFSCreditID\":\"542115\",\"DFSUnbookedExposureSystem\":\"RAPPORT\",\"DFSUnbookedExposureID\":\"542115\",\"BanzaiStatusCode\":\"ORD-POR\",\"Quantity\":1,\"Total\":974.25},{\"PipelineSource\":\"DELL\",\"PipelineStage\":\"ORDER\",\"DFSFinanceProduct\":\"DBL\",\"DFSPayCode\":\"5\",\"DFSProductSpace\":\"TRANSACTIONAL LEASE\",\"DFSSalesPipeline\":\"DIRECT\",\"DFSCreditSystem\":\"RAPPORT\",\"DFSCreditID\":\"542115\",\"DFSUnbookedExposureSystem\":\"RAPPORT\",\"DFSUnbookedExposureID\":\"542115\",\"BanzaiStatusCode\":\"ORD-CMP\",\"Quantity\":3,\"Total\":4384.42}]";
			return JsonConvert.DeserializeObject<IEnumerable<ExposureResponseDto>>(obj);
			//refer to serialize object -  string output = JsonConvert.SerializeObject(result);
		}
	}
}