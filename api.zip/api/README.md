# api


This project is a suite of webapi micro services used for internal and external communications between domains.
