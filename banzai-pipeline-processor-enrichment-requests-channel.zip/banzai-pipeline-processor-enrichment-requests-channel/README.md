# authorizedorderrequests

This project listens and processes orders authorized messages received from salyer