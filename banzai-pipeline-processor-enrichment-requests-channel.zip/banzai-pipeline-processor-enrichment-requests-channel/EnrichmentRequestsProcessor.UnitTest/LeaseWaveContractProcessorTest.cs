using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest
{
    public class LeaseWaveContractProcessorTest : IClassFixture<CoreFixture> {		

		private readonly CoreFixture _coreFixture;
               
        public LeaseWaveContractProcessorTest(CoreFixture coreFixture) {
			_coreFixture = coreFixture;
		}

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_ProcessLeaseWave_When_valid()
        {
            var leaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f";
          
            _coreFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.Find(It.IsAny<FilterDefinition<PipelineLeaseWaveContractRequestDto>>())).Returns(PipelineLeaseWaveContractRequests);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineRequests.Find(It.IsAny<FilterDefinition<PipelineRequest>>())).Returns(PipelineRequest);         
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());

            //Act
            var result = _coreFixture.StartupProcessor.Process(leaseWaveMessage);

            //Asset
            Assert.True(result);
        }       

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void ShouldFail_ProcessLeaseWave_When_CurrentReqIsNull()
        {
            var leaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f";          

            //Act
            var result = _coreFixture.StartupProcessor.Process(leaseWaveMessage);

            //Asset
            Assert.True(result);
        }               

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_ProcessLeaseWaveProc_When_valid()
        {
            var leaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f";

            _coreFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.Find(It.IsAny<FilterDefinition<PipelineLeaseWaveContractRequestDto>>())).Returns(PipelineLeaseWaveContractRequests);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineRequests.Find(It.IsAny<FilterDefinition<PipelineRequest>>())).Returns(PipelineRequest);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(leaseWaveMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_ProcessLeaseWaveProc_When_validStatusCombo()
        {
            var leaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f";

            _coreFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.Find(It.IsAny<FilterDefinition<PipelineLeaseWaveContractRequestDto>>())).Returns(PipelineLeaseWaveContractRequests);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineRequests.Find(It.IsAny<FilterDefinition<PipelineRequest>>())).Returns(PipelineRequest);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(leaseWaveMessage);

            //Asset
            Assert.True(result);
        }


        private IEnumerable<PipelineLeaseWaveContractRequestDto> PipelineLeaseWaveContractRequests()
        {
            return new List<PipelineLeaseWaveContractRequestDto>
			{
				new PipelineLeaseWaveContractRequestDto
				{
				Id = "5d847e62369595000f5be45f",
				ContractNumber = "200-001GPD00-000",
				NotificationType= "INVOICE",
				StatusCode= "Document Generated",
				EmployeeFirstName= "Srikanth",
				EmployeeLastName= "Gujjaru",
				EmailID= "srikanth_gujjaru@dell.com",
				DecisionDateTime= DateTime.UtcNow,
				TransactionDateTime= DateTime.UtcNow,
				MessageCreateDateTime= DateTime.UtcNow,
				Invoices=new List<ContractInvoiceDto> (){ new ContractInvoiceDto {
					InvoiceNo ="5201289933",
					VendorID ="778899",
					PipelineSource ="Channel",
					SourceBusinessUnit ="707"
				} },

				}
			};
		}

		[Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_SaveToError_ProcessInvoiceRequest_When_EmptyMessage()
        {
            //Arrange
            var message = "";
            _coreFixture.MongoDataContext.Reset();           
            _coreFixture.MongoDataContext.Setup(x => x.MessageValidationErrors.InsertOneAsync(It.IsAny<MessageValidationError>()));

            //Act
            var result = _coreFixture.StartupProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_FailAndRetry_When_MongoDBException()
        {
            //Act
            var LeaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f|srikanth_gujjaru@dell.com";
            _coreFixture.MongoDataContext.Reset();           
            _coreFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.InsertOne(It.IsAny<PipelineLeaseWaveContractRequestDto>())).Throws(new MongoException("MongoDB is down"));

            //Arrange 
            var result = _coreFixture.StartupProcessor.Process(LeaseWaveMessage);

            //Assert
            Assert.True(result);
        }

        [Trait("LeaseWaveContractProcessor", "LeaseWaveContractProcessorTest")]
        [Fact]
        public void Should_FailAndRetry_When_Exception()
        {
            //Arrance
            var LeaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f|srikanth_gujjaru@dell.com";
            _coreFixture.MongoDataContext.Reset();            
            _coreFixture.MongoDataContext.Setup(x => x.PipelineLeaseWaveContractRequests.InsertOne(It.IsAny<PipelineLeaseWaveContractRequestDto>()));
           
            //Act 
            var result = _coreFixture.StartupProcessor.Process(LeaseWaveMessage);

            //Assert
            Assert.True(result);
        }

        [Trait("LeaseWaveInvoiceProcessor", "LeaseWaveInvoiceProcessorTest")]
        [Fact]
        public void Should_ProcessLeaseWaveRequest_When_valid()
        {
            var LeaseWaveMessage = "LeaseWaveContractRequest|5de519c28f701900109f083f|srikanth_gujjaru@dell.com";

            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());

            //Act
            var result = _coreFixture.StartupProcessor.Process(LeaseWaveMessage);

            //Asset
            Assert.True(result);
        }
        private List<PipelineRequest> PipelineRequest()
        {
            return new List<PipelineRequest> {
                new PipelineRequest {
                    Id = "5a8dbc8f21eb5a002da2a0e4",
                    PipelineSource = "Channel",
                    Content = "", TransactionType = "" } };
        }

        private static PipelineEnrichedRequest GetEnrichementDocumentAndLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "Channel",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
            },
            InvoiceStage = new InvoiceStage
            {
                PipelineStage= "INVOICE",
                Invoices = new List<Library.Entities.Invoice>(){
                    new Library.Entities.Invoice {
                        InvoiceNo ="5201289933",
                        COGS =true,
                        GAAP =false,
                Status =new Status {
                    BanzaiStatusCode ="INV-EXP-ACCEPT",
                    DFSCustomer =true,
                    Discard =false,
                    DecisionSourceStatusCode="INVOICE"
                } } }
            },

            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
        };
        
        private IEnumerable<PipelineEnrichedRequest> GetpipelineEnrichedRequest()
        {
            return new List<PipelineEnrichedRequest>
            {
                new PipelineEnrichedRequest
                {
                Id = "5a8dbc8f21eb5a002da2a0e4",
                VorID = "2006745184528",
                IsLocked = false,                

                Common = new Common()
                {
                    PipelineSource = "Channel",
                    DFSFinanceProduct = "LOAN-SW",
                    DFSCustomerMLAFlag = false,
                    DFSPayCode = "#",
                    DFSProductSpace = "LOAN/SOFTWARE",
                    DFSSalesPipeline = "DIRECT",
                    DFSCreditSystem = "CMS",
                    DFSCreditID = "CMS",
                    DFSUnbookedExposureSystem = "",
                    DFSUnbookedExposureID = "",
                    DFSOrphanFlag = "N",                    
                },
               
                InvoiceStage=new InvoiceStage{
                    PipelineStage="INVOICE",
                    Invoices =new List<Library.Entities.Invoice>(){
                        new Library.Entities.Invoice{
                            InvoiceNo ="5201289933",                
                         COGS =true,                    
                         Status =new Status{
                        DecisionSourceStatusCode="INVOICE",                        
                        BanzaiStatusCode ="INV-EXP-ACCEPT",
                        SourceStatusCode="S",
                        Note="Test Note",
                        BanzaiStatusSequence=1,
                        Discard=false,
                        BanzaiStatusCreateDateTime=DateTime.UtcNow,
                       MessageType="LeaseWaveNotification",
                        DFSCustomer=true
                    }
                } } },
                VorStage = new VorStage()
                {
                    PipelineStage = "VOR",
                    DFSFinanceAmount = 100,
                    Status = new Status
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070,
                    }
                },
                }
            };

        }

        private static IEnumerable<StatusCombo> GetStatusCombos()
        {
            return new List<StatusCombo>
            {
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "Channel",
                    SourceStatusDesc = "TASK ID = Invoice",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Received",
                    BanzaiStatusCode = "INV-RCVD",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "Channel INVOICE"
                },
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "Channel",
                    SourceStatusDesc = "TASK ID = Invoice",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Received",
                    BanzaiStatusCode = "INV-RCVD",
                    DecisionSourceStatusCode = "Document Generated",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "Channel INVOICE"
                }
            };
        }

    }
}

