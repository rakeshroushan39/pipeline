﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor
{
    public class MassFundingDateUpdateTest : IClassFixture<CoreFixture>
    {
        private readonly CoreFixture _coreFixture;
        public MassFundingDateUpdateTest(CoreFixture coreFixture)
        {
            _coreFixture = coreFixture;
        }

        #region FundingDateUpdateTest

        [Trait("FundingDateUpdate", "FundingDateUpdateTest")]
        [Fact]
        public void Should_StatusUpdate_When_CorrectData()
        {
            //Arrange
            var massUploadMessage = "FundingDate|Channel:10262694175:11:12:05/08/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());

			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }
		[Trait("FundingDateUpdate", "FundingDateUpdateTest")]
		[Fact]
		public void Should_StatusUpdate_When_IncorrectCorrectData()
		{
			//Arrange
			var massUploadMessage = "FundingDate|Channel:10262694176:11:12:01/01/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}
		[Trait("FundingDateUpdate", "FundingDateUpdateTest")]
		[Fact]
		public void Should_StatusUpdate_When_IncorrectCorrectDataInvoice()
		{
			//Arrange
			var massUploadMessage = "FundingDate|Channel::11:12:01/01/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}
		[Trait("FundingDateUpdate", "FundingDateUpdateTest")]
		[Fact]
		public void Should_StatusUpdate_When_IncorrectCorrectDataBuid()
		{
			//Arrange
			var massUploadMessage = "FundingDate|Channel:10262694176::12:01/01/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}
		[Trait("FundingDateUpdate", "FundingDateUpdateTest")]
		[Fact]
		public void Should_StatusUpdate_When_IncorrectCorrectDataVendorId()
		{
			//Arrange
			var massUploadMessage = "FundingDate|Channel:10262694176:11::01/01/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}
		[Trait("FundingDateUpdate", "FundingDateUpdateTest")]
		[Fact]
		public void Should_StatusUpdate_When_IncorrectCorrectDataPipelineSource()
		{
			//Arrange
			var massUploadMessage = "FundingDate|:10262694176:11:12:01/01/2020|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}
		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
		{
			Id = "5a8dbc8f21eb5a002da2a0e4",
			VorID = "2006745184528",
			IsLocked = false,

			Common = new Common()
			{
				PipelineSource = "Channel",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
				SourceBusinessUnit = "11",
				VendorId = "12"
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
				}
			},
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Library.Entities.Invoice>()
				{
					new Library.Entities.Invoice(){
						InvoiceNo ="10262694175",
						TotalDFSFinanceAmount = 100,
						Status = new Status()
						{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "INV-RCVD",
						BanzaiStatusSequence = 1070
						},
						StatusHistory=new List<Status>()
						{ 
							new Status
							{
						BanzaiStatusCode= "BNF",
						BanzaiUnbookedExposureFlag=false,
						BanzaiStatusSequence=1070,
                        DecisionSourceDateTime = DateTime.Parse("2020-05-07 07:00:12.000Z"),
							} 
						}
					} 
				}
			},
			OrderStage = new OrderStage()
			{
				PipelineStage = "ORDER",
				Orders = new List<Order>()
				{
					new Order()
					{
						OrderNo ="115799545",
						DFSFinanceAmount = 100,
						Status = new Status()
						{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "ORD-PP",
						BanzaiStatusSequence = 3900
						},
					} 
				}
			}
		};
		private static IEnumerable<StatusCombo> GetStatusCombos()
		{
			return new List<StatusCombo>
			{
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 6000,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Funded",
					BanzaiStatusCode = "FND",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE"
				},
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "UPDATED_STATUS",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				}
			};
		}
		private static IEnumerable<StatusCombo> GetInvalidStatusCombos()
		{
			return new List<StatusCombo>
			{

				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				},
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Invoice",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "ORDER Received",
					BanzaiStatusCode = "UPDATED_STATUS",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true,
					UserUpdateFuture = true,
				}
			};
		}
		#endregion
	}
}
