﻿using DFS.Banzai.Library.Aura.Models;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor
{
    public class MassAuraInvoiceProcessorTest : IClassFixture<CoreFixture>
    {
        private readonly CoreFixture _coreFixture;
        public MassAuraInvoiceProcessorTest(CoreFixture coreFixture)
        {
            _coreFixture = coreFixture;
        }

        //Private Methods		
        private static PipelineEnrichedRequest GetEnrichementDocumentAndUnlock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006719735438",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "Channel",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
                SourceBusinessUnit = "11",
            },
            OrderStage = new OrderStage()
            {
                PipelineStage = "VOR",

                Orders = new List<Order>() {
                             new Order {
                                    DFSFinanceAmount = 100,
                                    Status = new Status() {
                                        BanzaiUnbookedExposureFlag = false,
                                           BanzaiStatusCode = "VOR-CAN",
                                           BanzaiStatusSequence = 1070,
                                           MessageType = "IL Booked Orders Upload",
                                           MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
                                           MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
                                           MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

                                    }}}
            },
            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                    MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


                }
            },

            InvoiceStage = new InvoiceStage()
            {
                PipelineStage = "VOR",
                Invoices = new List<Library.Entities.Invoice>()
                {  new Library.Entities.Invoice()

                {
                    InvoiceNo ="110567878",
                    TotalDFSFinanceAmount = 100,
                    Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-ACCEPT",
                        BanzaiStatusSequence = 1070
                    },

                },
                    {  new Library.Entities.Invoice()

                {
                    InvoiceNo ="110567877",
                    TotalDFSFinanceAmount = 100,
                    Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-EXP-ACCEPT",
                        BanzaiStatusSequence = 1070
                    },
                    StatusHistory = new List<Status>(){                        
                     new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-EXP-REJECT",
                        BanzaiStatusSequence = 1070
                    },
                     new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-EXP-SENT",
                        BanzaiStatusSequence = 1070
                    },

                    }

                }
                }
                }
                
            }
        };

        private static IEnumerable<PipelineAuraInvoiceRequestDto> GetPipelineAuraInvoiceRequest()
        {

            return new List<PipelineAuraInvoiceRequestDto>
            {
                  new PipelineAuraInvoiceRequestDto
                  {
                    Buid = "707",
                    EventId = "82e8671f-2879-46a5-988e-72f3ee88f2b3",
                    VendorID = "149",
                    PipelineSource = "EMC",
                    Id = "5d94bacd3fd2930016c07c28",
                    InfoMessage = "Success",
                    InvoiceNumber = "110567878",
                    Message ="{\n  \"EventId\": \"82e8671f-2879-46a5-988e-72f3ee88f2b3\",\n  \"Message\": \"Failure\",\n  \"Buid\": \"707\",\n  \"VendorID\": \"149\",\n  \"InvoiceNumber\": \"1014304111\"\n}"

                  }
            };

        }
        private static IEnumerable<StatusCombo> GetStatusCombos()
        {
            return new List<StatusCombo>
            {
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-PP",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateCurrent = true
                  },
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 4000,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-SHPD",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateCurrent = true
                  },
                   new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-POR",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateFuture = true
                  },
                   new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = INVOICE",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Processed",
                    BanzaiStatusCode = "INV-EXP-SENT",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL INVOICE",
                    UserUpdateCurrent = true
                  } ,
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = INVOICE",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "INV-BOOKED",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL INVOICE",
                    UserUpdateFuture = true
                  },
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = VOR",
                    SourceStatusCode = "VOR",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "VOR Validated",
                    BanzaiStatusCode = "VOR-CAN",
                    DecisionSourceStatusCode = "VOR",
                    PipelineStage = "VOR",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL VOR",
                    UserUpdateCurrent = true
                  } ,
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = VOR",
                    SourceStatusCode = "VOR",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "VOR Hold",
                    BanzaiStatusCode = "VOR-HLD",
                    DecisionSourceStatusCode = "VOR",
                    PipelineStage = "VOR",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL VOR",
                    UserUpdateFuture = true
                  }
            };
        }
        [Trait("MassAuraInvoiceProcessor", "MassAuraInvoiceProcessorTest")]
        [Fact]
        public void Should_SendRequestToAura_When_ValidRequest()
        {
            //Arrange
            var pipelineRequest = new List<PipelineEnrichedRequest>
            {
                new PipelineEnrichedRequest{
                Id = "5a8dbc8f21eb5a002da2a0e4",
                VorID = "2006719735438",
                IsLocked = false,

                Common = new Common()
                {
                    PipelineSource = "CHANNEL",
                    DFSFinanceProduct = "LOAN-SW",
                    DFSCustomerMLAFlag = false,
                    DFSPayCode = "#",
                    DFSProductSpace = "LOAN/SOFTWARE",
                    DFSSalesPipeline = "DIRECT",
                    DFSCreditSystem = "CMS",
                    DFSCreditID = "CMS",
                    DFSUnbookedExposureSystem = "",
                    DFSUnbookedExposureID = "",
                    DFSOrphanFlag = "N",
                    SourceBusinessUnit = "11",
                },
                OrderStage = new OrderStage()
                {
                    PipelineStage = "VOR",

                    Orders = new List<Order>() {
                             new Order {
                                    DFSFinanceAmount = 100,
                                    Status = new Status() {
                                        BanzaiUnbookedExposureFlag = false,
                                           BanzaiStatusCode = "VOR-CAN",
                                           BanzaiStatusSequence = 1070,
                                           MessageType = "IL Booked Orders Upload",
                                           MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
                                           MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
                                           MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

                                    }}}
                },
                VorStage = new VorStage()
                {
                    PipelineStage = "VOR",
                    DFSFinanceAmount = 100,
                    Status = new Status
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070,
                        MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


                    }
                },

                InvoiceStage = new InvoiceStage()
                {
                    PipelineStage = "VOR",
                    Invoices = new List<Library.Entities.Invoice>()
                {  new Library.Entities.Invoice()

                {
                    InvoiceNo ="110567878",
                    TotalDFSFinanceAmount = 100,
                    Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-ACCEPT",
                        BanzaiStatusSequence = 1070
                    },

                } }
                }
                }
            };
            var invoiceExportRequest = new List<InvoiceExportRequestDto>
            {
                  new InvoiceExportRequestDto
                  {
                    BuId="11",
                    InvoiceNo ="110567877",
                    VendorId="",
                    PipelineSource="CHANNEL"

                  },
                  new InvoiceExportRequestDto
                  {
                    BuId="11",
                    InvoiceNo ="110567878",
                    VendorId="",
                    PipelineSource="CHANNEL"
                  },
                  new InvoiceExportRequestDto
                  {
                    BuId="11",
                    InvoiceNo ="110567878",
                    VendorId="",
                    PipelineSource="CHANNEL"
                  }
            };
            var message = Newtonsoft.Json.JsonConvert.SerializeObject(invoiceExportRequest);
            message = "AuraInvoiceRequests|" + message + "|Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(pipelineRequest);
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());

            //Act
            var result = _coreFixture.MassAuraInvoiceProcessor.ProcessMassAuraInvoiceRequests(message);

            //Asset
            Assert.True(result);
        }

        [Trait("MassAuraInvoiceProcessor", "MassAuraInvoiceProcessorTest")]
        [Fact]
        public void Should_NotSendRequestToAura_When_InvoiceNoIsNull()
        {
            //Arrange
            var pipelineRequest = new List<PipelineEnrichedRequest>
            {
                new PipelineEnrichedRequest{
                Id = "5a8dbc8f21eb5a002da2a0e4",
                VorID = "2006719735438",
                IsLocked = false,

                Common = new Common()
                {
                    PipelineSource = "CHANNEL",
                    DFSFinanceProduct = "LOAN-SW",
                    DFSCustomerMLAFlag = false,
                    DFSPayCode = "#",
                    DFSProductSpace = "LOAN/SOFTWARE",
                    DFSSalesPipeline = "DIRECT",
                    DFSCreditSystem = "CMS",
                    DFSCreditID = "CMS",
                    DFSUnbookedExposureSystem = "",
                    DFSUnbookedExposureID = "",
                    DFSOrphanFlag = "N",
                    SourceBusinessUnit = "11",
                },
                OrderStage = new OrderStage()
                {
                    PipelineStage = "VOR",

                    Orders = new List<Order>() {
                             new Order {
                                    DFSFinanceAmount = 100,
                                    Status = new Status() {
                                        BanzaiUnbookedExposureFlag = false,
                                           BanzaiStatusCode = "VOR-CAN",
                                           BanzaiStatusSequence = 1070,
                                           MessageType = "IL Booked Orders Upload",
                                           MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
                                           MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
                                           MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

                                    }}}
                },
                VorStage = new VorStage()
                {
                    PipelineStage = "VOR",
                    DFSFinanceAmount = 100,
                    Status = new Status
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070,
                        MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


                    }
                },

                InvoiceStage = new InvoiceStage()
                {
                    PipelineStage = "VOR",
                    Invoices = new List<Library.Entities.Invoice>()
                {  new Library.Entities.Invoice()

                {
                    InvoiceNo ="110567878",
                    TotalDFSFinanceAmount = 100,
                    Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070
                    },

                } }
                }
                }
            };
            var invoiceExportRequest = new List<InvoiceExportRequestDto>
            {
                  new InvoiceExportRequestDto
                  {
                    BuId="11",
                    InvoiceNo ="110567878",
                    VendorId="",
                    PipelineSource="CHANNEL"

                  }
            };
            var pipelineAuraInvoiceRequest = new List<PipelineAuraInvoiceRequestDto> {
                new PipelineAuraInvoiceRequestDto{
                    Buid = "707",
                    EventId = "82e8671f-2879-46a5-988e-72f3ee88f2b3",
                    VendorID = "149",
                    PipelineSource = "EMC",
                    Id = "5d94bacd3fd2930016c07c28",
                    InfoMessage = "Success",
                    InvoiceNumber = "110567878",
                    Message ="{\n  \"EventId\": \"82e8671f-2879-46a5-988e-72f3ee88f2b3\",\n  \"Message\": \"Failure\",\n  \"Buid\": \"707\",\n  \"VendorID\": \"149\",\n  \"InvoiceNumber\": \"1014304111\"\n}"
                }
            };
            var message = Newtonsoft.Json.JsonConvert.SerializeObject(pipelineAuraInvoiceRequest);
            message = "AuraInvoiceRequests|" + message + "|Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(pipelineRequest);
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineAuraInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineAuraInvoiceRequestDto>>())).Returns(GetPipelineAuraInvoiceRequest);


            //Act
            var result = _coreFixture.MassAuraInvoiceProcessor.ProcessAuraInvoiceRequest(message);

            //Asset
            Assert.True(result);
        }


    }



}