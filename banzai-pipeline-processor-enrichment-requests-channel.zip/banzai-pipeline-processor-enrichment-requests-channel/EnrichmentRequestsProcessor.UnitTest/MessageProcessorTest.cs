﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using Moq;
using DFS.Banzai.Library.Entities;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest
{
	public class MessageProcessorTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;

		public MessageProcessorTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}
        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ProcessInvoiceRequest_When_valid()
        {
            var InvoiceMessage = "InvoiceRequest|5d847e62369595000f5be45f";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            //_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.MessageProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }
        private static IEnumerable<StatusCombo> GetStatusCombos()
        {
            return new List<StatusCombo>
            {
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "Channel",
                    SourceStatusDesc = "TASK ID = Invoice",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Received",
                    BanzaiStatusCode = "INV-RCVD",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "Channel INVOICE"
                }
            };
        }

        private IEnumerable<PipelineEnrichedRequest> GetpipelineEnrichedRequest()
        {
            return new List<PipelineEnrichedRequest>
            {
                new PipelineEnrichedRequest
                {
                Id = "5a8dbc8f21eb5a002da2a0e4",
                VorID = "2006745184528",
                IsLocked = false,

                Common = new Common()
                {
                    PipelineSource = "Channel",
                    DFSFinanceProduct = "LOAN-SW",
                    DFSCustomerMLAFlag = false,
                    DFSPayCode = "#",
                    DFSProductSpace = "LOAN/SOFTWARE",
                    DFSSalesPipeline = "DIRECT",
                    DFSCreditSystem = "CMS",
                    DFSCreditID = "CMS",
                    DFSUnbookedExposureSystem = "",
                    DFSUnbookedExposureID = "",
                    DFSOrphanFlag = "N",
                    VendorId= "122",

                },

                InvoiceStage=new InvoiceStage{
                    PipelineStage="INVOICE",
                    Invoices =new List<Library.Entities.Invoice>(){
                        new Library.Entities.Invoice{
                            InvoiceNo ="10251394476",
                         COGS =true,
                         Status =new Status{
                        DecisionSourceStatusCode="INVOICE",
                        BanzaiStatusCode ="INV-EXP-ACCEPT",
                        SourceStatusCode="S",
                        Note="Test Note",
                        BanzaiStatusSequence=1,
                        Discard=false,
                        BanzaiStatusCreateDateTime=DateTime.UtcNow,
                       MessageType="LeaseWaveNotification",
                        DFSCustomer=true,
                      
                    }
                } } },
                VorStage = new VorStage()
                {
                    PipelineStage = "VOR",
                    DFSFinanceAmount = 100,
                    Status = new Status
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070,
                    }
                },
                }
            };

        }
        private IEnumerable<PipelineInvoiceInboundNotification> PipelineInvoiceInboundNotification()
		{
			return new List<PipelineInvoiceInboundNotification>
			{
				new PipelineInvoiceInboundNotification
				{
				Id = "5d847e62369595000f5be45f",
				InvoiceNotificationMessageID = "5e8675f230f20e0010b73cd0",
				MessageNotificationType= "ProcessInvoice",
				InvoiceStatus= "INV-RCVD",
				InvoiceStatusDateTime= DateTime.UtcNow,
				DateTimeMessageCreated= DateTime.UtcNow,
				PipelineSource= "Channel",
				VendorID= "122",
				VendorName= "Test Vendor",
				VendorOrphan= true,
				SourceBusinessUnit ="",
				InvoiceNo = "10251394476",
				InvoiceDate = DateTime.UtcNow,
				InvoiceAmount =10000,
				MostRecentStatusRecord = new Status(){
				DecisionSource = "EDI_DFS_Dell Print",
				DecisionSourceStatusCode= "INVOICE-CFO",
				SourceStatusCode= "SC",
				 MessageType= "ProcessInvoice",
				MessageID= "5e8675f17c99ed00108b3183",
				 BanzaiStatusCode= "INV-RCVD",
				 BanzaiStatusSequence= 4000,
				BanzaiUnbookedExposureFlag = true,
				LatentTransaction= false,
				Note= ""
				},
				LastModifiedDateTime = DateTime.UtcNow

				}
			};
		}
	}
}
