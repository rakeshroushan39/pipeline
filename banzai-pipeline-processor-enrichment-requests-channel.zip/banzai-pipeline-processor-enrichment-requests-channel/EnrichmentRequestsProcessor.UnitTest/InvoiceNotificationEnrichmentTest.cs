﻿
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Pipeline.Library.Entities;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;



namespace DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest
{

	public class InvoiceNotificationEnrichmentTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;

		//Private Methods
		private static IEnumerable<StatusCombo> GetStatusCombos()
		{
			return new List<StatusCombo>
			{
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-SHPD",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-POR",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateFuture = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Invoice Processed",
					BanzaiStatusCode = "INV-EXP-SENT",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "INV-BOOKED",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateFuture = true
				  },
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Validated",
					BanzaiStatusCode = "VOR-CAN",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Hold",
					BanzaiStatusCode = "VOR-HLD",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateFuture = true
				  }
			};
		}
		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnlock() => new PipelineEnrichedRequest
		{
			Id = "5a8dbc8f21eb5a002da2a0e4",
			VorID = "2006719735438",
			IsLocked = false,
			BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
			BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
			Common = new Common()
			{
				PipelineSource = "Channel",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
				SourceBusinessUnit = "11",
			},
			OrderStage = new OrderStage()
			{
				PipelineStage = "VOR",

				Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
					MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


				}
			},

			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				} }
			}
		};
		public InvoiceNotificationEnrichmentTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}

		[Trait("InvoiceNotificationEnrichment", "InvoiceNotificationEnrichmentTest")]
		[Fact]
		public void Should_InvoiceNotificationEnrichment_EnrichInvoice_When_InvoiceRequestSent()
		{

			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",

					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "INVOICE",
					Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				} }
				}

			};
			var pipelineInvoiceInboundNotification = new PipelineInvoiceInboundNotification
			{
				InvoiceNo = "110567878",
				PipelineSource = "Channel",
				SourceBusinessUnit = "11",
				VendorID = "122",
				MostRecentStatusRecord = new Status()
				{
					DecisionSource = "EDI_DFS_Dell Print",
					DecisionSourceStatusCode = "INVOICE-CFO",
					SourceStatusCode = "SC",
					MessageType = "ProcessInvoice",
					MessageID = "5e8675f17c99ed00108b3183",
					BanzaiStatusCode = "INV-RCVD",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = true,
					LatentTransaction = false,
					Note = ""
				},
			};

			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);

			_coreFixture.InvoiceNotificationEnrichment.CurrentEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.PreviousEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Invoice;			
			_coreFixture.InvoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;
			_coreFixture.InvoiceNotificationEnrichment.PipelineMessageID = Guid.NewGuid().ToString();

			//Act
			var result = _coreFixture.InvoiceNotificationEnrichment.Run();

			//Asset
			Assert.NotNull(result);
		}

		[Trait("InvoiceNotificationEnrichment", "InvoiceNotificationEnrichmentTest")]
		[Fact]
		public void Should_InvoiceNotificationEnrichment_EnrichInvoice_When_BanzaiStatusIsNotNull()
		{

			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",

					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "INVOICE",
					Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				} }
				}

			};
			var pipelineInvoiceInboundNotification = new PipelineInvoiceInboundNotification
			{
				InvoiceNo = "110567878",
				PipelineSource = "Channel",
				SourceBusinessUnit = "11",
				VendorID = "122",
				MostRecentStatusRecord = new Status()
				{
					DecisionSource = "EDI_DFS_Dell Print",
					DecisionSourceStatusCode = "INVOICE",
					SourceStatusCode = "SC",
					MessageType = "ProcessInvoice",
					MessageID = "5e8675f17c99ed00108b3183",
					BanzaiStatusCode = "INV-RCVD",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = true,
					LatentTransaction = false,
					Note = ""
				},
			};

			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);

			_coreFixture.InvoiceNotificationEnrichment.CurrentEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.PreviousEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Invoice;
			_coreFixture.InvoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;
			_coreFixture.InvoiceNotificationEnrichment.PipelineMessageID = Guid.NewGuid().ToString();

			//Act
			var result = _coreFixture.InvoiceNotificationEnrichment.Run();

			//Asset
			Assert.NotNull(result);
		}

		[Trait("InvoiceNotificationEnrichment", "InvoiceNotificationEnrichmentTest")]
		[Fact]
		public void Should_InvoiceNotificationEnrichment_EnrichOrder_When_InvoiceRequestSent()
		{

			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",

					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "VOR",
					Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				} }
				}

			};
			var pipelineInvoiceInboundNotification = new PipelineInvoiceInboundNotification
			{
				OrderNo = "123345",
				InvoiceNo = "110567878",
				PipelineSource = "Channel",
				MostRecentStatusRecord = new Status()
				{
					DecisionSource = "EDI_DFS_Dell Print",
					DecisionSourceStatusCode = "INVOICE-CFO",
					SourceStatusCode = "SC",
					MessageType = "ProcessInvoice",
					MessageID = "5e8675f17c99ed00108b3183",
					BanzaiStatusCode = "INV-RCVD",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = true,
					LatentTransaction = false,
					Note = ""
				},
			};
			var status = new Status()
			{
				DecisionSourceStatusCode = "ORDER"
			};
			pipelineInvoiceInboundNotification.MostRecentStatusRecord = status;
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);

			_coreFixture.InvoiceNotificationEnrichment.CurrentEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Order;
			_coreFixture.InvoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;
			_coreFixture.InvoiceNotificationEnrichment.PipelineMessageID = Guid.NewGuid().ToString();

			//Act
			var result = _coreFixture.InvoiceNotificationEnrichment.Run();

			//Asset
			Assert.NotNull(result);
		}

		[Trait("InvoiceNotificationEnrichment", "InvoiceNotificationEnrichmentTest")]
		[Fact]
		public void Should_InvoiceNotificationEnrichment_EnrichOrderLatent_When_InvoiceRequestSent()
		{

			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",

					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									OrderNo = "110567879",
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "VOR",
					Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				}
					}
				}

			};
			var pipelineInvoiceInboundNotification = new PipelineInvoiceInboundNotification
			{
				OrderNo = "110567879",
				InvoiceNo = "110567878",
				PipelineSource = "Channel",
				MostRecentStatusRecord = new Status()
				{
					DecisionSource = "EDI_DFS_Dell Print",
					DecisionSourceStatusCode = "INVOICE-CFO",
					SourceStatusCode = "SC",
					MessageType = "ProcessInvoice",
					MessageID = "5e8675f17c99ed00108b3183",
					BanzaiStatusCode = "INV-RCVD",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = true,
					LatentTransaction = false,
					Note = ""
				},
			};
			var status = new Status()
			{
				DecisionSourceStatusCode = "ORDER"
			};
			pipelineInvoiceInboundNotification.MostRecentStatusRecord = status;
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);

			_coreFixture.InvoiceNotificationEnrichment.CurrentEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.PreviousEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Order;
			_coreFixture.InvoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;
			_coreFixture.InvoiceNotificationEnrichment.PipelineMessageID = Guid.NewGuid().ToString();		

			//Act
			var result = _coreFixture.InvoiceNotificationEnrichment.Run();

			//Asset
			Assert.NotNull(result);
		}
		[Trait("InvoiceNotificationEnrichment", "InvoiceNotificationEnrichmentTest")]
		[Fact]

		public void Should_NotInvoiceNotificationEnrichment_EnrichOrderStatus_When_InvoiceRequestSent()
		{

			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",

					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									OrderNo = "110567879",
									Status = new Status() {
										BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z")

									}}}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",


					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "VOR",
					Invoices = new List<Pipeline.Library.Entities.Invoice>()
				{  new Pipeline.Library.Entities.Invoice()

				{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},

				}
					}
				}

			};
			var pipelineInvoiceInboundNotification = new PipelineInvoiceInboundNotification
			{
				OrderNo = "110567879",
				InvoiceNo = "110567878",
				PipelineSource = "Channel",
				MostRecentStatusRecord = new Status()
				{
					DecisionSource = "EDI_DFS_Dell Print",
					DecisionSourceStatusCode = "INVOICE-CFO",
					SourceStatusCode = "SC",
					MessageType = "ProcessInvoice",
					MessageID = "5e8675f17c99ed00108b3183",
					BanzaiStatusCode = "INV-RCVD",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = true,
					LatentTransaction = false,
					Note = ""
				},
			};
			var status = new Status()
			{
				DecisionSourceStatusCode = "ORDER"
			};
			pipelineInvoiceInboundNotification.MostRecentStatusRecord = status;
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnlock());			
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.Find(It.IsAny<FilterDefinition<StatusCombo>>())).Returns(GetStatusCombos);

			_coreFixture.InvoiceNotificationEnrichment.CurrentEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.PreviousEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Order;
			_coreFixture.InvoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;
			_coreFixture.InvoiceNotificationEnrichment.PipelineMessageID = Guid.NewGuid().ToString();

			//_coreFixture.InvoiceNotificationEnrichment.RetryRequired = true;

			//Act
			var result = _coreFixture.InvoiceNotificationEnrichment.Run();

			//Asset
			Assert.NotNull(result);
		}
	}
}

