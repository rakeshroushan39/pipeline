﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Driver;
using Moq;
using Xunit;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using System.Diagnostics.CodeAnalysis;
using System.Xml.Linq;
using System.Data;
using DFS.Banzai.Library.XMLManager;

namespace DFS.Banzai.Streaming.EmcEnrichment.EnrichmentRequestsProcessor.UnitTest
{
	[ExcludeFromCodeCoverage]
	public class MassDfsOpsRepUpdateTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;
		public MassDfsOpsRepUpdateTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}
		[Trait("DfsOpsRepUpdate", "DfsOpsRepUpdateTest")]
		[Fact]
		public void Should_DFSOpsRepUpdate_When_CorrectData()
		{
			//Arrange 
			var massUploadMessage = "DFSOpsRep|::::,:1234:11:1234:PONY_VAGRECHA@DELL.COM,INVOICE::11:1234:PONY_VAGRECHA@DELL.COM,INVOICE:1234::1234:PONY_VAGRECHA@DELL.COM,INVOICE:1234:11::PONY_VAGRECHA@DELL.COM,INVOICE:1234:11:1234:,INVALIDPIPELINE:1234:11:1234:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN4:11:1041:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH@D.COM,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH@DELL,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN6:707:1032:MINU_SUNNY@DELL.COM,INVOICE:NEWORPHAN4:11:1032:DEEPESH_ARORA@DELL.COM,ORDER:602311267:11::PONY_VAGRECH,VOR:1234:11:1234:PONY_VAGRECHA@DELL.COM|R_Dasari#Worksheet in 17_Story8233482_ProductMangerTestScenarios#2020-06-01T02:15:34Z#R_Dasari@dell.com";
			//_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);
			//Asset
			Assert.True(result);
		}

		[Trait("DfsOpsRepUpdate", "DfsOpsRepUpdateTest")]
		[Fact]
		public void Should_DFSOpsRepUpdate_When_IncorrectData()
		{
			//Arrange
			var massUploadMessage = "DFSOpsRep|::::,:1234:11:1234:PONY_VAGRECHA@DELL.COM,INVOICE::11:1234:PONY_VAGRECHA@DELL.COM,INVOICE:1234::1234:PONY_VAGRECHA@DELL.COM,INVOICE:1234:11::PONY_VAGRECHA@DELL.COM,INVOICE:1234:11:1234:,INVALIDPIPELINE:1234:11:1234:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN4:11:1041:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH@D.COM,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECH@DELL,INVOICE:NEWORPHAN5:11:1041:PONY_VAGRECHA@DELL.COM,INVOICE:NEWORPHAN6:707:1032:MINU_SUNNY@DELL.COM,INVOICE:NEWORPHAN4:11:1032:DEEPESH_ARORA@DELL.COM,ORDER:602311267:11::PONY_VAGRECH,VOR:1234:11:1234:PONY_VAGRECHA@DELL.COM|R_Dasari#Worksheet in 17_Story8233482_ProductMangerTestScenarios#2020-06-01T02:15:34Z#R_Dasari@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
			//_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			////Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);
			//Asset
			Assert.True(result);
		}

		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
		{
			Id = "5e8c281c91881f000f208380",
			VorID = "",
			IsLocked = false,

			Common = new Common()
			{
				PipelineSource = "CHANNEL",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
				SourceBusinessUnit = "11",
				VendorId="1041"
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
				}
			},
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()

				{
					new DFS.Banzai.Pipeline.Library.Entities.Invoice()

				{
						InvoiceNo ="NewOrphan5",
						TotalDFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "INV-RCVD",
						BanzaiStatusSequence = 1070
					},

				} }
			},
			OrderStage = new OrderStage()
			{
				PipelineStage = "ORDER",
				Orders = new List<Order>()

				{
					new Order()

				{
						OrderNo ="115799545",
						DFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "ORD-PP",
						BanzaiStatusSequence = 3900
					},

				} }
			}
		};

	}
}
