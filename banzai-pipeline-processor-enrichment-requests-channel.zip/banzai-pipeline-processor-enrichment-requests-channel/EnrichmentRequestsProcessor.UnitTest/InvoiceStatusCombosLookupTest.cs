﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using System;
using System.Collections.Generic;
using Xunit;


namespace DFS.Banzai.Streaming.Channel.Enrichment.EnrichmentRequestsProcessor.UnitTest
{
	public class StatusCombosLookupTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;
		public StatusCombosLookupTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}

		//Private Methods
		private static IEnumerable<StatusCombo> GetInvalidStatusCombos()
		{
			return new List<StatusCombo>
			{
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-SHPD",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-POR",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateFuture = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Invoice Processed",
					BanzaiStatusCode = "INV-EXP-SENT",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "INV-BOOKED",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateFuture = true
				  },
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Validated",
					BanzaiStatusCode = "VOR-CAN",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Hold",
					BanzaiStatusCode = "VOR-HLD",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateFuture = true
				  }
			};
		}
		private static IEnumerable<StatusCombo> GetStatusCombos()
		{
			return new List<StatusCombo>
			{
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3900,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-PP",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				  new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 4000,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-SHPD",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "ORDER",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateCurrent = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = Order",
					SourceStatusCode = "ORDER",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "ORD-POR",
					DecisionSourceStatusCode = "ORDER",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel ORDER",
					UserUpdateFuture = true
				  },
				   new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Invoice Processed",
					BanzaiStatusCode = "INV-EXP-SENT",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = INVOICE",
					SourceStatusCode = "INVOICE",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "Order Processed",
					BanzaiStatusCode = "INV-BOOKED",
					DecisionSourceStatusCode = "INVOICE",
					PipelineStage = "INVOICE",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel INVOICE",
					UserUpdateFuture = true
				  },
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Validated",
					BanzaiStatusCode = "VOR-CAN",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateCurrent = true
				  } ,
				new StatusCombo
				  {
					Active = true,
					PipelineSource = "Channel",
					SourceStatusDesc = "TASK ID = VOR",
					SourceStatusCode = "VOR",
					BanzaiStatusSequence = 3700,
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusDesc = "VOR Hold",
					BanzaiStatusCode = "VOR-HLD",
					DecisionSourceStatusCode = "VOR",
					PipelineStage = "VOR",
					DFSCustomer = false,
					Discard = false,
					DecisionSource = "Channel VOR",
					UserUpdateFuture = true
				  }
			};
		}
		[Trait("StatusCombosLookup", "StatusCombosLookupTest")]
		[Fact]
		public void Should_BanzaiStatusElements_When_WithoutStatusCombos_PipelineEnrichedRequestAsVOR()
		{
			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",
					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									OrderNo = "110567879",
									Status = new Status() {
										   BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z"),
										   DecisionSourceStatusCode = "ORDER"
									}
							 }
					}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
						DecisionSourceStatusCode = "INVOICE"
					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "VOR",
					Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()
				{  new DFS.Banzai.Pipeline.Library.Entities.Invoice()

					{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},


				}

					}
				}

			};
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetInvalidStatusCombos());
			_coreFixture.InvoiceStatusCombosLookup.PipelineEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceStatusCombosLookup.RetryRequired = true;
			var result = _coreFixture.InvoiceStatusCombosLookup.Run();
			//Asset
			Assert.NotNull(result);
		}
		[Trait("StatusCombosLookup", "StatusCombosLookupTest")]
		[Fact]
		public void Should_BanzaiStatusElements_When_PipelineEnrichedRequestAsVOR()
		{
			var pipelineEnrichedRequest = new PipelineEnrichedRequest
			{
				Id = "5a8dbc8f21eb5a002da2a0e4",
				VorID = "2006719735438",
				IsLocked = false,
				BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString(),
				BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString(),
				Common = new Common()
				{
					PipelineSource = "Channel",
					DFSFinanceProduct = "LOAN-SW",
					DFSCustomerMLAFlag = false,
					DFSPayCode = "#",
					DFSProductSpace = "LOAN/SOFTWARE",
					DFSSalesPipeline = "DIRECT",
					DFSCreditSystem = "CMS",
					DFSCreditID = "CMS",
					DFSUnbookedExposureSystem = "",
					DFSUnbookedExposureID = "",
					DFSOrphanFlag = "N",
					SourceBusinessUnit = "11",
				},
				OrderStage = new OrderStage()
				{
					PipelineStage = "VOR",
					Orders = new List<Order>() {
							 new Order {
									DFSFinanceAmount = 100,
									OrderNo = "110567879",
									Status = new Status() {
										   BanzaiUnbookedExposureFlag = false,
										   BanzaiStatusCode = "VOR-CAN",
										   BanzaiStatusSequence = 1070,
										   MessageType = "IL Booked Orders Upload",
										   MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
										   MessageSourceDateTime = DateTime.Parse("2018-05-23 07:00:12.000Z"),
										   MessageReceivedDateTime= DateTime.Parse("2018-05-23 07:05:02.844Z"),
										   DecisionSourceStatusCode = "ORDER"
									}
							 }
					}
				},
				VorStage = new VorStage()
				{
					PipelineStage = "VOR",
					DFSFinanceAmount = 100,
					Status = new Status
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070,
						MessageID = "5550eb75-5dc6-4a40-a272-111546568ddf",
						DecisionSourceStatusCode = "INVOICE"
					}
				},

				InvoiceStage = new InvoiceStage()
				{
					PipelineStage = "VOR",
					Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()
				{  new DFS.Banzai.Pipeline.Library.Entities.Invoice()

					{
					InvoiceNo ="110567878",
					TotalDFSFinanceAmount = 100,
					Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "VOR-CAN",
						BanzaiStatusSequence = 1070
					},


				}

					}
				}

			};
			_coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
			_coreFixture.InvoiceStatusCombosLookup.PipelineEnrichedRequest = pipelineEnrichedRequest;
			_coreFixture.InvoiceStatusCombosLookup.RetryRequired = true;
			var result = _coreFixture.InvoiceStatusCombosLookup.Run();
			//Asset
			Assert.NotNull(result);
		}
	}
}
