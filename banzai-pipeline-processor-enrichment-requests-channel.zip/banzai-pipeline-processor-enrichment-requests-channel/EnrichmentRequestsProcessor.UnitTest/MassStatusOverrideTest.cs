using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using MongoDB.Driver;
using Moq;
using System.Collections.Generic;
using Xunit;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.UnitTes
{
    public class MassStatusOverrideTest : IClassFixture<CoreFixture>
    {
        private readonly CoreFixture _coreFixture;
        public MassStatusOverrideTest(CoreFixture coreFixture)
        {
            _coreFixture = coreFixture;

        }
        private static IEnumerable<StatusCombo> GetStatusCombos()
        {
            return new List<StatusCombo>
            {
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-PP",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateCurrent = true,
                    UserOverride = false
                  },
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 4000,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-SHPD",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateCurrent = true,
                    UserOverride = true
                  },
                   new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Order",
                    SourceStatusCode = "ORDER",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "ORD-POR",
                    DecisionSourceStatusCode = "ORDER",
                    PipelineStage = "ORDER",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL ORDER",
                    UserUpdateFuture = true,
                    UserOverride = true
                  },
                   new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = INVOICE",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Processed",
                    BanzaiStatusCode = "INV-RCVD",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL INVOICE",
                    UserUpdateCurrent = true,
                    UserOverride = true
                  } ,
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = INVOICE",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Order Processed",
                    BanzaiStatusCode = "INV-BOOKED",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL INVOICE",
                    UserUpdateFuture = true,
                    UserOverride = true
                  },
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = VOR",
                    SourceStatusCode = "VOR",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "VOR Validated",
                    BanzaiStatusCode = "VOR-CAN",
                    DecisionSourceStatusCode = "VOR",
                    PipelineStage = "VOR",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL VOR",
                    UserUpdateCurrent = true,
                    UserOverride = true
                  } ,
                new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = VOR",
                    SourceStatusCode = "VOR",
                    BanzaiStatusSequence = 3700,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "VOR Hold",
                    BanzaiStatusCode = "VOR-HLD",
                    DecisionSourceStatusCode = "VOR",
                    PipelineStage = "VOR",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "DELL VOR",
                    UserUpdateFuture = true,
                    UserOverride = true
                  }
            };
        }
        private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "CHANNEL",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
                SourceBusinessUnit = "11",
            },
            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
            InvoiceStage = new InvoiceStage()
            {
                PipelineStage = "VOR",
                Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()

                {
                    new DFS.Banzai.Pipeline.Library.Entities.Invoice()

                {
                        InvoiceNo ="10262694175",
                        TotalDFSFinanceAmount = 100,
                        Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "INV-RCVD",
                        BanzaiStatusSequence = 1070
                    },

                } }
            },
            OrderStage = new OrderStage()
            {
                PipelineStage = "ORDER",
                Orders = new List<Order>()

                {
                    new Order()

                {
                        OrderNo ="115799545",
                        DFSFinanceAmount = 100,
                        Status = new Status()
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "ORD-PP",
                        BanzaiStatusSequence = 3900
                    },

                } }
            }
        };
        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotOverrideStatus_When_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|2006719735438|chandrashekhar_bali#BanzaiMassUpload_Template#2018-09-25T09:18:04Z#chandrashekhar_bali@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));

            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }
        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotOverrideStatus_When_StringIsNull()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|||||";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));

            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_StatusOverride_When_CorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:10262694175:INV-RCVD:INV-BOOKED:TEST74:11:12|Ashish_kumar2#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Ashish_kumar2@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }


        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_PipelineStage_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL::115799545:ORD-PP:ORD-POR:TEST74:11:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }


        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_OrderNo_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE::ORD-PP:ORD-POR:TEST74:11:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_CurrentBaznaiStatus_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:10262694175:ORD-PP:ORD-POR:TEST74:11:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_FurtureBaznaiStatus_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:115799545:ORD-PP::TEST74:11:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_Note_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:115799545:ORD-PP:ORD-POR::11:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_BuId_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:115799545:ORD-PP:ORD-POR:TEST74:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }
        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_Id_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|EMCc:INVOICE:1234:ORD-PP:ORD-POR:TEST74:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }
        [Trait("MassStatusOverride", "StatusOverrideProcessorTest")]
        [Fact]
        public void Should_NotStatusOverride_When_DocUpdateNull_IncorrectData()
        {
            //Arrange
            var massUploadMessage = "StatusOverride|CHANNEL:INVOICE:1234:ORD-PP:ORD-POR:TEST74:|Srikanth_Gujjaru#BanzaiMassUpload_Template#2019-07-08T11:24:43Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

    }
}
