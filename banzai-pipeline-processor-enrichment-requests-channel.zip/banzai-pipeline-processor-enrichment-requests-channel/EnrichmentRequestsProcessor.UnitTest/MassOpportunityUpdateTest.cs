﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using MongoDB.Driver;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor
{
	
	public class MassOpportunityUpdateTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;
		public MassOpportunityUpdateTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}

        #region OpportunityUpdateTest
        
        [Trait("OpportunityUpdate", "OpportunityUpdateTest")]
        [Fact]
        public void Should_StatusUpdate_When_CorrectData()
        {
            //Arrange
            var massUploadMessage = "SFDCOpptyId|CHANNEL:10262694175:11:12:12345678|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            //Act
            var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

            //Asset
            Assert.True(result);
        }

		[Trait("OpportunityUpdate", "OpportunityUpdateTest")]
		[Fact]
		public void Should_NotStatusUpdate_When_PipelineStage_IncorrectData()
		{
			//Arrange
			var massUploadMessage = "SFDCOpptyId|CHANNEL::11::|Srikanth_Gujjaru#BanzaiMassUpload_Template#2020-04-23T16:28:24Z#Srikanth_Gujjaru@dell.com";
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before));			
			_coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
			//Act
			var result = _coreFixture.StartupProcessor.Process(massUploadMessage);

			//Asset
			Assert.True(result);
		}

		private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
		{
			Id = "5a8dbc8f21eb5a002da2a0e4",
			VorID = "2006745184528",
			IsLocked = false,

			Common = new Common()
			{
				PipelineSource = "CHANNEL",
				DFSFinanceProduct = "LOAN-SW",
				DFSCustomerMLAFlag = false,
				DFSPayCode = "#",
				DFSProductSpace = "LOAN/SOFTWARE",
				DFSSalesPipeline = "DIRECT",
				DFSCreditSystem = "CMS",
				DFSCreditID = "CMS",
				DFSUnbookedExposureSystem = "",
				DFSUnbookedExposureID = "",
				DFSOrphanFlag = "N",
				SourceBusinessUnit = "11",
				VendorId = "12"
			},
			VorStage = new VorStage()
			{
				PipelineStage = "VOR",
				DFSFinanceAmount = 100,
				Status = new Status
				{
					BanzaiUnbookedExposureFlag = false,
					BanzaiStatusCode = "VOR-CAN",
					BanzaiStatusSequence = 1070,
				}
			},
			InvoiceStage = new InvoiceStage()
			{
				PipelineStage = "VOR",
				Invoices = new List<DFS.Banzai.Pipeline.Library.Entities.Invoice>()

				{
					new DFS.Banzai.Pipeline.Library.Entities.Invoice()

				{
						InvoiceNo ="10262694175",
						TotalDFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "INV-RCVD",
						BanzaiStatusSequence = 1070
					},

				} }
			},
			OrderStage = new OrderStage()
			{
				PipelineStage = "ORDER",
				Orders = new List<Order>()

				{
					new Order()

				{
						OrderNo ="115799545",
						DFSFinanceAmount = 100,
						Status = new Status()
					{
						BanzaiUnbookedExposureFlag = false,
						BanzaiStatusCode = "ORD-PP",
						BanzaiStatusSequence = 3900
					},

				} }
			}
		};

		#endregion StatusUpdateTest
	}
}
