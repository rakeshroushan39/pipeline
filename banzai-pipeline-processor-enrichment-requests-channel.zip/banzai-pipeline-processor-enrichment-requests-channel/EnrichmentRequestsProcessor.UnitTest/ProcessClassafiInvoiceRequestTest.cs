﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest;
using Moq;
using DFS.Banzai.Library.Entities;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest
{
    public class ProcessClassafiInvoiceRequestTest : IClassFixture<CoreFixture>
	{
		private readonly CoreFixture _coreFixture;

		public ProcessClassafiInvoiceRequestTest(CoreFixture coreFixture)
		{
			_coreFixture = coreFixture;
		}

        #region ProcessClassafiInvoiceRequestTest
        //RunAuraInvoicePublishRules

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_Run_AuraInvoicePublishRules_When_INV_EXP_ACCEPT_GAAP()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsGAAP());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentInvExpacceptGAAPAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_Run_AuraInvoicePublishRules_When_INV_EXP_ACCEPT_COGS()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsCOGS());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentInvExpacceptCOGSAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_ProcessClassafiInvoiceRequest_When_NotificationTypeGAAP()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";            
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsGAAP());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_ProcessClassafiInvoiceRequest_When_NotificationTypeGAAPAnd_UnLocked()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";            
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsGAAP());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_ProcessClassafiInvoiceRequest_When_NotificationTypeCOGS()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";
            //var pipelineClassafiInvoiceRequest = _dataContext.PipelineClassafiInvoiceRequests.Find(filter)?.FirstOrDefault();
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find
            (It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsCOGS());

            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }
        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_ProcessClassafiInvoiceRequest_When_NotificationType606()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";            
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find
            (It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequests606());

            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_NotProcessClassafiInvoiceRequest_When_Invalid()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|5d847e62369595000f5be45f";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentAndLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        [Trait("ProcessClassafiInvoiceRequest", "ProcessClassafiInvoiceRequestTest")]
        [Fact]
        public void Should_FailtProcessClassafiInvoiceRequest_When_Invalid()
        {
            var InvoiceMessage = "ClassafiInvoiceRequest|";
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.Find(It.IsAny<FilterDefinition<PipelineClassafiInvoiceRequest>>())).Returns(GetpiPipelineClassafiInvoiceRequestsGAAP());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineInvoiceInboundNotifications.Find(It.IsAny<FilterDefinition<PipelineInvoiceInboundNotification>>())).Returns(PipelineInvoiceInboundNotification());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.Find(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>())).Returns(GetpipelineEnrichedRequest());
            _coreFixture.MongoDataContext.Setup(x => x.PipelineEnrichedRequestsV2.FindOneAndUpdate(It.IsAny<FilterDefinition<PipelineEnrichedRequest>>(), It.IsAny<UpdateDefinition<PipelineEnrichedRequest>>(), ReturnDocument.Before)).Returns(GetEnrichementDocumentInvExpacceptGAAPAndUnLock());
            _coreFixture.MongoDataContext.Setup(x => x.StatusCombos.GetAll()).Returns(GetStatusCombos());
            //Act
            var result = _coreFixture.StartupProcessor.Process(InvoiceMessage);

            //Asset
            Assert.True(result);
        }

        #endregion ProcessClassafiInvoiceRequestTest

        #region PrivateMethods

        private IEnumerable<PipelineClassafiInvoiceRequest> GetpiPipelineClassafiInvoiceRequestsGAAP()
        {
            var lstOfPipelineClassafiInvoiceRequest = new List<PipelineClassafiInvoiceRequest>();
            lstOfPipelineClassafiInvoiceRequest.Add(new PipelineClassafiInvoiceRequest 
            {
                CorrelationID= "711123ae-7b1c-4162-94ca-d4af5794f313",
                InvoiceNo = "5201289933",
                Id= "5eeb16a4ca9286a648377911",
                VendorID= "230",
                SourceBusinessUnit="707",
                PipelineSource="CHANNEL",
                NotificationType= "GAAP",
                LastModifiedDateTime=DateTime.UtcNow,
                DecisionSourceDateTime=DateTime.UtcNow,
                Links=null,
                Message= "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '3000107511232', 'businessUnitID': '707', 'notificationType': 'GAAP', 'classificationType': 'CHANNEL', 'vendorId': '230', 'pipelineSource': 'CHANNEL', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }"

            }
            );
            return lstOfPipelineClassafiInvoiceRequest;
        }

        private IEnumerable<PipelineClassafiInvoiceRequest> GetpiPipelineClassafiInvoiceRequestsCOGS()
        {
            var lstOfPipelineClassafiInvoiceRequest = new List<PipelineClassafiInvoiceRequest>();
            lstOfPipelineClassafiInvoiceRequest.Add(new PipelineClassafiInvoiceRequest
            {
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                InvoiceNo = "5201289933",
                Id = "5eeb16a4ca9286a648377911",
                VendorID = "230",
                SourceBusinessUnit = "707",
                PipelineSource = "CHANNEL",
                NotificationType = "COGS",
                LastModifiedDateTime = DateTime.UtcNow,
                DecisionSourceDateTime = DateTime.UtcNow,
                Links = null,
                Message = "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '3000107511232', 'businessUnitID': '707', 'notificationType': 'GAAP', 'classificationType': 'CHANNEL', 'vendorId': '230', 'pipelineSource': 'CHANNEL', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }"

            }
            );
            return lstOfPipelineClassafiInvoiceRequest;
        }

        private IEnumerable<PipelineClassafiInvoiceRequest> GetpiPipelineClassafiInvoiceRequests606()
        {
            var lstOfPipelineClassafiInvoiceRequest = new List<PipelineClassafiInvoiceRequest>();
            lstOfPipelineClassafiInvoiceRequest.Add(new PipelineClassafiInvoiceRequest
            {
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                InvoiceNo = "5201289933",
                Id = "5eeb16a4ca9286a648377911",
                VendorID = "230",
                SourceBusinessUnit = "707",
                PipelineSource = "CHANNEL",
                NotificationType = "606",
                LastModifiedDateTime = DateTime.UtcNow,
                DecisionSourceDateTime = DateTime.UtcNow,
                Links = null,
                Message = "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '3000107511232', 'businessUnitID': '707', 'notificationType': 'GAAP', 'classificationType': 'CHANNEL', 'vendorId': '230', 'pipelineSource': 'CHANNEL', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }"

            }
            );
            return lstOfPipelineClassafiInvoiceRequest;
        }

        private static IEnumerable<StatusCombo> GetStatusCombos()
        {
            return new List<StatusCombo>
            {
                  new StatusCombo
                  {
                    Active = true,
                    PipelineSource = "CHANNEL",
                    SourceStatusDesc = "TASK ID = Invoice",
                    SourceStatusCode = "INVOICE",
                    BanzaiStatusSequence = 3900,
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusDesc = "Invoice Received",
                    BanzaiStatusCode = "INV-RCVD",
                    DecisionSourceStatusCode = "INVOICE",
                    PipelineStage = "INVOICE",
                    DFSCustomer = false,
                    Discard = false,
                    DecisionSource = "CHANNEL INVOICE"
                }
            };
        }
        private static PipelineEnrichedRequest GetEnrichementDocumentAndLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = true,

            Common = new Common()
            {
                PipelineSource = "CHANNEL",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
            },
            InvoiceStage = new InvoiceStage
            {
                PipelineStage = "INVOICE",
                Invoices = new List<Library.Entities.Invoice>(){
                    new Library.Entities.Invoice {
                        InvoiceNo ="5201289933",
                        COGS =true,
                        GAAP =false,
                Status =new Status {
                    BanzaiStatusCode ="INV-EXP-ACCEPT",
                    DFSCustomer =true,
                    Discard =false,
                    DecisionSourceStatusCode="INVOICE"
                } } }
            },

            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
        };

        private static PipelineEnrichedRequest GetEnrichementDocumentAndUnLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "CHANNEL",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
            },
            InvoiceStage = new InvoiceStage
            {
                PipelineStage = "INVOICE",
                Invoices = new List<Library.Entities.Invoice>(){
                    new Library.Entities.Invoice {
                        InvoiceNo ="5201289933",
                        COGS =true,
                        GAAP =false,
                Status =new Status {
                    BanzaiStatusCode ="INV-EXP-ACCEPT",
                    DFSCustomer =true,
                    Discard =false,
                    DecisionSourceStatusCode="INVOICE"
                } } }
            },

            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
        };

        private static PipelineEnrichedRequest GetEnrichementDocumentInvExpacceptGAAPAndUnLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "CHANNEL",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
            },
            InvoiceStage = new InvoiceStage
            {
                PipelineStage = "INVOICE",
                Invoices = new List<Library.Entities.Invoice>(){
                    new Library.Entities.Invoice {
                        InvoiceNo ="5201289933",
                        COGS =false,
                        GAAP =true,
                Status =new Status {
                    BanzaiStatusCode ="INV-EXP-ACCEPT",
                    DFSCustomer =true,
                    Discard =false,
                    DecisionSourceStatusCode="INVOICE"
                },
                StatusHistory=StatusHistory()
                    } }
            },

            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
        };

        private static PipelineEnrichedRequest GetEnrichementDocumentInvExpacceptCOGSAndUnLock() => new PipelineEnrichedRequest
        {
            Id = "5a8dbc8f21eb5a002da2a0e4",
            VorID = "2006745184528",
            IsLocked = false,

            Common = new Common()
            {
                PipelineSource = "CHANNEL",
                DFSFinanceProduct = "LOAN-SW",
                DFSCustomerMLAFlag = false,
                DFSPayCode = "#",
                DFSProductSpace = "LOAN/SOFTWARE",
                DFSSalesPipeline = "DIRECT",
                DFSCreditSystem = "CMS",
                DFSCreditID = "CMS",
                DFSUnbookedExposureSystem = "",
                DFSUnbookedExposureID = "",
                DFSOrphanFlag = "N",
            },
            InvoiceStage = new InvoiceStage
            {
                PipelineStage = "INVOICE",
                Invoices = new List<Library.Entities.Invoice>(){
                    new Library.Entities.Invoice {
                        InvoiceNo ="5201289933",
                        COGS =true,
                        GAAP =false,
                Status =new Status {
                    BanzaiStatusCode ="INV-EXP-ACCEPT",
                    DFSCustomer =true,
                    Discard =false,
                    DecisionSourceStatusCode="INVOICE"
                },
                StatusHistory=StatusHistory()
                    } }
            },

            VorStage = new VorStage()
            {
                PipelineStage = "VOR",
                DFSFinanceAmount = 100,
                Status = new Status
                {
                    BanzaiUnbookedExposureFlag = false,
                    BanzaiStatusCode = "VOR-CAN",
                    BanzaiStatusSequence = 1070,
                }
            },
        };
        private static List<Status> StatusHistory()
        {
            var lstStatusHistory = new List<Status>
            {
                new Status
                {
                    BanzaiStatusCode = "SCH",
                    DFSCustomer = true,
                    Discard = false,
                    DecisionSourceStatusCode = "INVOICE"
                }
            };
            return lstStatusHistory;
        }

        private IEnumerable<PipelineEnrichedRequest> GetpipelineEnrichedRequest()
        {
            return new List<PipelineEnrichedRequest>
            {
                new PipelineEnrichedRequest
                {
                Id = "5a8dbc8f21eb5a002da2a0e4",
                VorID = "2006745184528",
                IsLocked = true,

                Common = new Common()
                {
                    PipelineSource = "CHANNEL",
                    DFSFinanceProduct = "LOAN-SW",
                    DFSCustomerMLAFlag = false,
                    DFSPayCode = "#",
                    DFSProductSpace = "LOAN/SOFTWARE",
                    DFSSalesPipeline = "DIRECT",
                    DFSCreditSystem = "CMS",
                    DFSCreditID = "CMS",
                    DFSUnbookedExposureSystem = "",
                    DFSUnbookedExposureID = "",
                    DFSOrphanFlag = "N",
                },

                InvoiceStage=new InvoiceStage{
                    PipelineStage="INVOICE",
                    Invoices =new List<Library.Entities.Invoice>(){
                        new Library.Entities.Invoice{
                            InvoiceNo ="10251394476",
                         COGS =true,
                         Status =new Status{
                        DecisionSourceStatusCode="INVOICE",
                        BanzaiStatusCode ="INV-EXP-ACCEPT",
                        SourceStatusCode="S",
                        Note="Test Note",
                        BanzaiStatusSequence=1,
                        Discard=false,
                        BanzaiStatusCreateDateTime=DateTime.UtcNow,
                       MessageType="LeaseWaveNotification",
                        DFSCustomer=true
                    }
                } } },
                VorStage = new VorStage()
                {
                    PipelineStage = "VOR",
                    DFSFinanceAmount = 100,
                    Status = new Status
                    {
                        BanzaiUnbookedExposureFlag = false,
                        BanzaiStatusCode = "VOR-CAN",
                        BanzaiStatusSequence = 1070,
                    }
                },
                }
            };

        }
        private IEnumerable<PipelineInvoiceInboundNotification> PipelineInvoiceInboundNotification()
		{
			return new List<PipelineInvoiceInboundNotification>
			{
				new PipelineInvoiceInboundNotification
				{
				Id = "5d847e62369595000f5be45f",
				InvoiceNotificationMessageID = "5e8675f230f20e0010b73cd0",
				MessageNotificationType= "ProcessInvoice",
				InvoiceStatus= "INV-RCVD",
				InvoiceStatusDateTime= DateTime.UtcNow,
				DateTimeMessageCreated= DateTime.UtcNow,
				PipelineSource= "DELL",
				VendorID= "122",
				VendorName= "Test Vendor",
				VendorOrphan= true,
				SourceBusinessUnit ="",
				InvoiceNo = "10251394476",
				InvoiceDate = DateTime.UtcNow,
				InvoiceAmount =10000,
				MostRecentStatusRecord = new Status(){
				DecisionSource = "EDI_DFS_Dell Print",
				DecisionSourceStatusCode= "INVOICE-CFO",
				SourceStatusCode= "SC",
				 MessageType= "ProcessInvoice",
				MessageID= "5e8675f17c99ed00108b3183",
				 BanzaiStatusCode= "INV-RCVD",
				 BanzaiStatusSequence= 4000,
				BanzaiUnbookedExposureFlag = true,
				LatentTransaction= false,
				Note= ""
				},
				LastModifiedDateTime = DateTime.UtcNow

				}
			};
		}

        #endregion PrivateMethods
    }
}
