﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.ExternalServices;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Enrichments;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Strategies;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;

namespace DFS.Banzai.Streaming.Channel.EnrichmentRequestsProcessor.UnitTest
{
    public class CoreFixture : IDisposable
    {       
        public readonly StartupProcessor StartupProcessor;
        public readonly MassStatusOverride MassStatusOverrideProcessor;
        public readonly MassStatusUpdate MassStatusUpdateProcessor;
        public readonly MassAuraInvoiceProcessor MassAuraInvoiceProcessor;
        public readonly MassOpportunityUpdate MassOpportunityUpdate;
        public readonly MassDfsOpsRepUpdate massDfsOpsRepUpdate;
        public InvoiceStatusCombosLookup InvoiceStatusCombosLookup { get; }
        public readonly Mock<IDataContext> MongoDataContext;
        public readonly MessageProcessor MessageProcessor;
        public readonly LeaseWaveContractProcessor LeaseWaveContractProcessor;
        public readonly InvoiceNotificationEnrichment InvoiceNotificationEnrichment;
        private GetBanzaiInvoiceService _getBanzaiInvoiceService;
        private readonly Mock<IPublisher> RMQPublisher;

        public CoreFixture()
        {
            var loggerDellEnrichmentRequestsMessageProcessor = new Mock<ILogger<StartupProcessor>>();
            var settings = new Mock<IOptions<Settings>>();
            var mailService = new Mock<IMailService>();
            MongoDataContext = new Mock<IDataContext>();
            RMQPublisher = new Mock<IPublisher>();
            var _messageProcessor = new Mock<MessageProcessor>();
            
            var queues = new Queue[3] { new Queue() { QueueName = "q.banzai.pipeline.channel.enrichment" },
                new Queue() { QueueName = "q.banzai.pipeline.rollup.requests" },
                new Queue() { QueueName = "", Exchange="dfs.order.banzai.pipeline.invoice.notifications.texg",
                    RoutingKey ="pipeline.invoice.notifications", Type="topic"} };            

            var publisherQueue = new Mock<IPublisherQueue>();
            publisherQueue.Setup(x=>x.Queues).Returns(queues);

            Settings getSettings = new Settings()
            {
                BANZAI_INVOICE_API_SERVICE_URI = "https://banzai-api-dit.ausvdc02.pcf.dell.com/api/InvoiceEnrichedRequests/Invoice",
                DPID_SERVICE_URI = "http://g4vmgcmsvc01.olqa.preol.dell.com:1000/GCMP.API/gcmp/api/orders/getorder/",
                ORDER_SERVICE_URI = "http://esom2.sit4.osb.us.dell.com/GOSSV2.01Service/RequesterABCS/QuerySalesOrderServiceV2.01",
                RAPPORT_GETCUSTOMER_SERVICE_URI = "http://AUSUWELSAPPG401.aus.amer.dell.com/DellFinancialServicesWebServices/CustomerLookupAdapter.asmx",
                CMS_GETCUSTOMER_SERVICE_URI = "https://rubicon-reverse-proxy-ge4.ausvdc02.pcf.dell.com/api/CustomerManagementProxy",
                SERVICE_ACCOUNT = "serviceBanzaiNP",
                SERVICE_ACCOUNT_PASS = "S2LZo,BRFv0ApC1w*34N:KYq",
                LDAP_SERVER_AMER = "ausdcamer.ins.dell.com"
            };

            settings.Setup(x => x.Value).Returns(() => getSettings);

            _getBanzaiInvoiceService = new GetBanzaiInvoiceService(settings.Object.Value, loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object);

            StartupProcessor = new StartupProcessor(settings.Object,
             loggerDellEnrichmentRequestsMessageProcessor.Object,
             mailService.Object,
             MongoDataContext.Object,
             RMQPublisher.Object,
            publisherQueue.Object);

            MassStatusOverrideProcessor = new MassStatusOverride(settings.Object,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object,
             RMQPublisher.Object,
            publisherQueue.Object);

            InvoiceNotificationEnrichment = new InvoiceNotificationEnrichment(settings.Object.Value,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object, _getBanzaiInvoiceService);

            MassStatusUpdateProcessor = new MassStatusUpdate(settings.Object,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object,
             RMQPublisher.Object,
            publisherQueue.Object);

            MassAuraInvoiceProcessor = new MassAuraInvoiceProcessor(settings.Object,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object,
             RMQPublisher.Object,
            publisherQueue.Object);

            InvoiceStatusCombosLookup = new InvoiceStatusCombosLookup(settings.Object.Value,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object);            

            MessageProcessor = new MessageProcessor(settings.Object,
             loggerDellEnrichmentRequestsMessageProcessor.Object,
             mailService.Object,
             MongoDataContext.Object,
             RMQPublisher.Object,
            publisherQueue.Object);

            LeaseWaveContractProcessor = new LeaseWaveContractProcessor(settings.Object,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object,
            RMQPublisher.Object,
            publisherQueue.Object);

            MassOpportunityUpdate = new MassOpportunityUpdate(settings.Object,
            loggerDellEnrichmentRequestsMessageProcessor.Object,
            mailService.Object,
            MongoDataContext.Object,
            RMQPublisher.Object,
            publisherQueue.Object);

         massDfsOpsRepUpdate = new MassDfsOpsRepUpdate(settings.Object,
         loggerDellEnrichmentRequestsMessageProcessor.Object,
         mailService.Object,
         MongoDataContext.Object,
          RMQPublisher.Object,
         publisherQueue.Object);
        }

        public void Dispose()
        {
            //Cleanup
            //Mapper.Reset();
        }
    }
}
