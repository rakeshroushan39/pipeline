using DFS.Banzai.Data;
using DFS.Banzai.Library;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Healthcheck;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Mailer;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Steeltoe.Common.HealthChecks;
using Steeltoe.Extensions.Configuration.CloudFoundry;
using Steeltoe.Management.CloudFoundry;
using Steeltoe.Management.Endpoint;
using Steeltoe.Management.Endpoint.Env;
using Steeltoe.Management.Hypermedia;
using System.Diagnostics.CodeAnalysis;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor
{
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        private IConfiguration Configuration { get; }        

        /// <summary>
        /// Constructor to initialize global vars
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="env"></param>
        public Startup(IConfiguration configuration) => Configuration = configuration;

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions();

            //IOption Pattern
            services.Configure<Settings>(Configuration);

            services.ConfigureCloudFoundryOptions(Configuration);

            //User of #if directive. Local Service is called only when build type is Debug. Otherwise, Cloud Service is called
            //Lifetime of the object is Transient - initialized per call
#if DEBUG
            services.AddTransient<IMailService, LocalMailService>();
#else
			services.AddTransient<IMailService, MailService>();
#endif      
            services.AddSingleton<IDataContext, MongoDataContext>();

            //RabbitMQ setup            
            services.AddRabbitMQueueMessageBus(Configuration);

            //Processor that Message Listener calls to process the incoming message
            services.AddSingleton<IMessageProcessor, StartupProcessor>();
            services.AddSingleton<MessageListenerV2>();
			
			//Health check contributors for steel toe
            services.AddSingleton<IHealthContributor, RabbitMQHealthContributor>();
            services.AddSingleton<IHealthContributor, MongoDBHealthContributor>();

            // Add managment endpoint services
            services.AddCloudFoundryActuators(Configuration, MediaTypeVersion.V2, ActuatorContext.ActuatorAndCloudFoundry);
            services.AddEnvActuator(Configuration);
            services.AddHealthChecks();
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if ("Development".Equals(env.EnvironmentName))
                app.UseDeveloperExceptionPage();

            // Add management endpoints into pipeline
            app.UseCloudFoundryActuators(MediaTypeVersion.V2, ActuatorContext.ActuatorAndCloudFoundry);
            app.UseEnvActuator();
            app.UseHealthChecks("/health");

            var listener = app.ApplicationServices.GetService<MessageListenerV2>();
            listener.StartListening();
        }
    }
}
