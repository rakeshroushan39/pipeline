using DFS.Banzai.Library.Aura.Models;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.ExcelManager;
using DFS.Banzai.Library.ExternalServices;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Library.Interfaces;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Enrichments;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public class MessageProcessor
    {
        #region MemberVariables
        protected readonly Settings _settings;
        protected readonly ILogger _logger;
        protected readonly IMailService _mailService;
        protected readonly IDataContext _dataContext;
        protected readonly IPublisher _rabbitMQueuePublisher;
        protected readonly Queue _channelEnrichmentQueue;
        protected readonly Queue _rollupRequestsQueue;
        protected readonly Queue _auraInvoiceExchange;
        private readonly List<IPipelineEnrichmentStrategy> _enrichmentStrategies = new List<IPipelineEnrichmentStrategy>();

        private FilterDefinition<PipelineEnrichedRequest> _searchByKeyFilter;
        private FilterDefinition<PipelineEnrichedRequest> _searchByIdFilter;
        private GetBanzaiInvoiceService _getBanzaiInvoiceService;
        private InvoiceNotificationEnrichment _invoiceNotificationEnrichment;
        private string _messageID = string.Empty;
        private string _incomingMessage = string.Empty;
        #endregion

        #region Properties
        public EnrichmentType EnrichmentType { get; set; }
        public string DocId { get; set; }
        public string OriginalMessageDocId { get; set; }
        #endregion

        /// <summary>
        /// Constructor to initialize Global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="rabbitMqMessageBus"></param>
        /// <param name="publisherQueue"></param>
        public MessageProcessor(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue)
        {
            _settings = settings.Value;
            _logger = logger;
            _mailService = mailService;
            _dataContext = dataContext;
            _rabbitMQueuePublisher = rabbitMQueuePublisher;

            //Setup Queues
            _channelEnrichmentQueue = publisherQueue.Queues[0];
            _rollupRequestsQueue = publisherQueue.Queues[1];
            _auraInvoiceExchange = publisherQueue.Queues[2];

            InitializeServicesAndEnableRetry();
        }

        /// <summary>
        /// This method initializes services to run for every message and enables/disables retry functionality
        /// </summary>
        private void InitializeServicesAndEnableRetry()
        {
            _getBanzaiInvoiceService = new GetBanzaiInvoiceService(_settings, _logger, _mailService, _dataContext);

            if (string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Production", StringComparison.OrdinalIgnoreCase) == 0
                        || string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Development", StringComparison.OrdinalIgnoreCase) == 0)
            {
                _getBanzaiInvoiceService.RetryRequired = true;
            }
        }

        /// <summary>
        /// This method gets triggered when message arrives in 
        /// PCF RMQ - PIPELINE_CHANNEL_ENRICHMENT_REQUESTS_Q Queue.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool Process(string message)
        {
            _logger.LogDebug($"Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor" +
                $"for processing PipelineInvoiceInboundNotification MessageID - {_messageID}");

            bool isSuccess = false;
            var messageDetail = message.Split("|");
            _incomingMessage = message;
            _messageID = messageDetail[1];
            _enrichmentStrategies.Clear();
            _searchByKeyFilter = null;
            _searchByIdFilter = null;


			if ("ClassafiInvoiceRequest".Equals(messageDetail[0], StringComparison.InvariantCultureIgnoreCase))
			{
				var filter = Builders<PipelineClassafiInvoiceRequest>.Filter.Eq(u => u.Id, _messageID);

				var pipelineClassafiInvoiceRequest = _dataContext.PipelineClassafiInvoiceRequests.Find(filter)?.FirstOrDefault();

				if (pipelineClassafiInvoiceRequest == null)
				{
					_logger.LogWarning($"Banzai.Pipeline.Emc.ClassafiInvoiceRequest for MessageID - {_messageID} does not exist.");

					throw new InvalidOperationException($"Banzai.Pipeline.Emc.ClassafiInvoiceRequest for MessageID - {_messageID} does not exist.");
				}

				isSuccess = EnrichClassafiInvoiceRequestAndSave(pipelineClassafiInvoiceRequest);
			}

			else if ("InvoiceRequest".Equals(messageDetail[0], StringComparison.InvariantCultureIgnoreCase))
			{
				var filter = Builders<PipelineInvoiceInboundNotification>.Filter.Eq(u => u.Id, _messageID);
				var pipelineInvoiceInboundNotification = _dataContext.PipelineInvoiceInboundNotifications.Find(filter)?.FirstOrDefault();

                if (pipelineInvoiceInboundNotification == null)
                {
                    _logger.LogWarning($"PipelineInvoiceInboundNotification for MessageID - {_messageID} does not exist.");
                    return true;
                }

                isSuccess = EnrichInvoiceRequestAndSave(pipelineInvoiceInboundNotification);
            }

            _logger.LogDebug($"Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor {_messageID} as {isSuccess}");

            return isSuccess;
        }

		/// <summary>
		/// This method enriches classafi invoice request
		/// </summary>
		/// <param name="pipelineClassafiInvoiceRequest"></param>
		/// <returns></returns>
		private bool EnrichClassafiInvoiceRequestAndSave(PipelineClassafiInvoiceRequest pipelineClassafiInvoiceRequest)
		{
			bool isProceed = false;

			PipelineEnrichedRequest previousPipelineEnrichedRequest = null;
			PipelineEnrichedRequest currentPipelineEnrichedRequest = null;
			var invoiceExportRequestDto = new InvoiceExportRequestDto
			{
				PipelineSource = pipelineClassafiInvoiceRequest.PipelineSource,
				InvoiceNo = pipelineClassafiInvoiceRequest.InvoiceNo,
				BuId = pipelineClassafiInvoiceRequest.SourceBusinessUnit,
				VendorId = pipelineClassafiInvoiceRequest.VendorID,
				NotificationType = string.Empty
			};

			try
			{
				string exists = string.Empty;
				var builder = Builders<PipelineEnrichedRequest>.Filter;
				_searchByKeyFilter = builder.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo == pipelineClassafiInvoiceRequest.InvoiceNo)
					& builder.Eq(u => u.Common.VendorId, pipelineClassafiInvoiceRequest.VendorID)
					& builder.Eq(u => u.Common.PipelineSource, pipelineClassafiInvoiceRequest.PipelineSource)
					& builder.Eq(u => u.Common.SourceBusinessUnit, pipelineClassafiInvoiceRequest.SourceBusinessUnit);

				(isProceed, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, exists) = CreatePipelineEnrichedRequest();

				if ("Document is locked".Equals(exists) || currentPipelineEnrichedRequest == null || !isProceed ||
					currentPipelineEnrichedRequest?.InvoiceStage == null)
					return true;

				var pipelineInvoice = (from inv in currentPipelineEnrichedRequest?.InvoiceStage?.Invoices
									   where inv.InvoiceNo.Equals(pipelineClassafiInvoiceRequest.InvoiceNo)
									   select inv)?.FirstOrDefault();

				if (pipelineInvoice == null)
					return true; // Acknowledge Message

				if ("GAAP".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase))
				{
					pipelineInvoice.GAAP = true;
					pipelineInvoice.GAAPMessageID = pipelineClassafiInvoiceRequest.Id;
				}
				else if ("COGS".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase))
				{
					pipelineInvoice.COGS = true;
					pipelineInvoice.COGSMessageID = pipelineClassafiInvoiceRequest.Id;
				}
				else if ("606".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase))
				{
					pipelineInvoice.SixZeroSix = true;
					pipelineInvoice.SixZeroSixMessageID = pipelineClassafiInvoiceRequest.Id;
				}

				UpdateRevision(ref previousPipelineEnrichedRequest, ref currentPipelineEnrichedRequest);
				isProceed = SaveToEnrichmentStore(currentPipelineEnrichedRequest);

				if (isProceed)
					RunAuraInvoicePublishRules(pipelineInvoice, pipelineClassafiInvoiceRequest, invoiceExportRequestDto);
			}
			catch (Exception e)
			{
				LockAndReadPipelineEnrichedRequest(_searchByIdFilter, false);

				_logger.LogError($"Error in Banzai.Pipeline.Emc Enrichment Invoice Notification processor - EnrichClassafiInvoiceRequestAndSave" +
					$" for Invoice - {pipelineClassafiInvoiceRequest.InvoiceNo}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

				if (!e.Message.Contains("IgnoreRetry"))
					throw;
			}

			_logger.LogDebug($"Banzai.Pipeline.Emc Enrichment Message process completed for ClassafiInvoiceRequest Invoice - {pipelineClassafiInvoiceRequest.InvoiceNo}");

			return true;
		}

		/// <summary>
		/// This method runs rules to process invoice publish to Aura.
		/// </summary>
		/// <param name="pipelineInvoice"></param>
		/// <param name="pipelineClassafiInvoiceRequest"></param>
		/// <param name="invoiceExportRequestDto"></param>
		private void RunAuraInvoicePublishRules(Library.Entities.Invoice pipelineInvoice, PipelineClassafiInvoiceRequest pipelineClassafiInvoiceRequest,
			InvoiceExportRequestDto invoiceExportRequestDto)
		{
            if (!"606".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase)
                &&
                ("INV-EXP-ACCEPT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
                || ValidateStatusHistoryForStatusCodeCheck("INV-EXP-ACCEPT", pipelineInvoice.StatusHistory)
                || "SCH".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
                || ValidateStatusHistoryForStatusCodeCheck("SCH", pipelineInvoice.StatusHistory)))
            {
                if ("GAAP".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase)
				&& pipelineInvoice.GAAP)
					invoiceExportRequestDto.NotificationType = "GAAP complete";
				else if ("COGS".Equals(pipelineClassafiInvoiceRequest.NotificationType, StringComparison.InvariantCultureIgnoreCase)
					&& pipelineInvoice.COGS)
					invoiceExportRequestDto.NotificationType = "COGS complete";

				var message = new JObject
							{
								{ "pipelineSource", invoiceExportRequestDto.PipelineSource },
								{ "invoiceNo", invoiceExportRequestDto.InvoiceNo},
								{ "buid", invoiceExportRequestDto.BuId},
								{ "vendorId", invoiceExportRequestDto.VendorId},
								{ "notificationType", invoiceExportRequestDto.NotificationType}
							};

				_rabbitMQueuePublisher.Publish(message: $"{message.ToString()}", exchange: _auraInvoiceExchange.Exchange,
					routingKey: _auraInvoiceExchange.RoutingKey, type: _auraInvoiceExchange.Type);
			}
		}

		/// <summary>
		/// Validate Status History For Status Check.
		/// </summary>
		/// <param name="StatusHistory"></param>
		/// <returns></returns>
		private bool ValidateStatusHistoryForStatusCodeCheck(string StatusCode, List<Status> StatusHistory)
		{
			if (StatusHistory != null)
			{
				foreach (var status in StatusHistory)
				{
					if (StatusCode.Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
						return true;
				}
			}
			return false;
		}

        /// <summary>
        ///  This method enriches and saves document to DB store.
        /// </summary>
        /// <param name = "pipelineInvoiceInboundNotification" > InputMessageReceivedFromQueue </ param >
        /// < returns > Boolean - Success / True, Failure/False and Enriched Document</returns>
        private bool EnrichInvoiceRequestAndSave(PipelineInvoiceInboundNotification pipelineInvoiceInboundNotification)
        {
            bool isProceed;
            string errorMessage;
            PipelineEnrichedRequest previousPipelineEnrichedRequest;
            PipelineEnrichedRequest currentPipelineEnrichedRequest;

            try
            {
                (isProceed, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, errorMessage) = RunEnrichmentRulesForInvoice(pipelineInvoiceInboundNotification);

                if ("Document is locked".Equals(errorMessage) || currentPipelineEnrichedRequest == null || !isProceed)
                    return true;

                UpdateRevision(ref previousPipelineEnrichedRequest, ref currentPipelineEnrichedRequest);

                isProceed = SaveToEnrichmentStore(currentPipelineEnrichedRequest);

                if (isProceed && currentPipelineEnrichedRequest != null)
                    _rabbitMQueuePublisher.Publish(currentPipelineEnrichedRequest.Id, _rollupRequestsQueue.QueueName);
            }
            catch (Exception e)
            {
                LockAndReadPipelineEnrichedRequest(_searchByIdFilter, false);

                _logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor - EnrichAndSave for Invoice - {pipelineInvoiceInboundNotification.InvoiceNo}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                if (!e.Message.Contains("IgnoreRetry"))
                    throw;
            }

            _logger.LogDebug($"Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor completed for Invoice - {pipelineInvoiceInboundNotification.InvoiceNo}");

            return true;
        }

        /// <summary>
        /// This method runs enrichment rules for Invoice
        /// </summary>
        /// <param name="previousPipelineEnrichedRequest"></param>
        /// <param name="currentPipelineEnrichedRequest"></param>
        /// <param name="pipelineInvoiceInboundNotification"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest previousPipelineEnrichedRequest, PipelineEnrichedRequest currentPipelineEnrichedRequest,
            string errorMessage) RunEnrichmentRulesForInvoice(PipelineInvoiceInboundNotification pipelineInvoiceInboundNotification)
        {
            var isProceed = true;
            string errorMessage = string.Empty;
            PipelineEnrichedRequest previousPipelineEnrichedRequest;
            PipelineEnrichedRequest currentPipelineEnrichedRequest;

            var builder = Builders<PipelineEnrichedRequest>.Filter;
            _searchByKeyFilter = builder.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo.ToUpper() == pipelineInvoiceInboundNotification.InvoiceNo.ToUpper())
                & builder.Eq(u => u.Common.PipelineSource, pipelineInvoiceInboundNotification.PipelineSource);

            if (!string.IsNullOrEmpty(pipelineInvoiceInboundNotification.SourceBusinessUnit))
                _searchByKeyFilter = _searchByKeyFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, pipelineInvoiceInboundNotification.SourceBusinessUnit);

            if (!string.IsNullOrEmpty(pipelineInvoiceInboundNotification.VendorID))
                _searchByKeyFilter = _searchByKeyFilter & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, pipelineInvoiceInboundNotification.VendorID);

            (isProceed, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, errorMessage) = CreatePipelineEnrichedRequest();

            if ("Document is locked".Equals(errorMessage))
                return (true, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, errorMessage);

            (isProceed, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest) = EnrichInvoice(previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, pipelineInvoiceInboundNotification);

            return (isProceed, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, errorMessage);
        }

        /// <summary>
        /// This method checks for previous enriched requests from db for any locks and then creates/clones new pipelinePipelineEnrichedRequest
        /// </summary>
        /// <returns></returns>
        private (bool, PipelineEnrichedRequest, PipelineEnrichedRequest, string) CreatePipelineEnrichedRequest()
        {
            PipelineEnrichedRequest currentPipelineEnrichedRequest = null;
            PipelineEnrichedRequest previousPipelineEnrichedRequest = LockAndReadPipelineEnrichedRequest(_searchByKeyFilter, true);

            if (previousPipelineEnrichedRequest != null)
            {
                _searchByIdFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Id, previousPipelineEnrichedRequest.Id);
                if (previousPipelineEnrichedRequest.IsLocked)
                {
                    for (var i = 1; i <= 20; i++)
                    {
                        System.Threading.Thread.Sleep(1000);
                        previousPipelineEnrichedRequest = LockAndReadPipelineEnrichedRequest(_searchByIdFilter, true);

                        if (!previousPipelineEnrichedRequest.IsLocked)
                            break;

                        if (i == 20)
                        {
                            UnLockPipelineEnrichedRequest(previousPipelineEnrichedRequest.Id); // unlocked after 20 attempts for each 2 sec cycle

                            _rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);

                            return (true, null, null, "Document is locked");
                        }
                    }
                }

                currentPipelineEnrichedRequest = previousPipelineEnrichedRequest.Clone() as PipelineEnrichedRequest;
                return (true, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest, "Found");
            }
            else
            {
                currentPipelineEnrichedRequest = new PipelineEnrichedRequest();
                return (true, null, currentPipelineEnrichedRequest, "NotFound");
            }
        }

        /// <summary>
        /// This method Gets PipelineEnrichedRequest and locks or unlocks for processing for a given dpid.
        /// Mainly during unlock, if there is no existing document in collections
        /// </summary>
        private PipelineEnrichedRequest LockAndReadPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter, bool isLocked)
        {
            if (filter == null) return null;

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(
                filter,
                Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, isLocked),
                ReturnDocument.Before);

            return result;
        }

        /// <summary>
        /// This method unlocks document for a given mongoid.
        /// </summary>
        /// <param name="id"></param>		
        protected void UnLockPipelineEnrichedRequest(string id)
        {
            var builder = Builders<PipelineEnrichedRequest>.Filter;

            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
        }

        /// <summary>
        /// This method enriches invoice section of enrichedrequest
        /// </summary>
        /// <remarks>Executes InvoiceNotification Lookup for Invoice Enrichment</remarks>
        /// <param name="previousPipelineEnrichedRequest"></param>
        /// <param name="pipelinePipelineEnrichedRequest"></param>
        /// <param name="pipelineInvoiceInboundNotification"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest previousPipelineEnrichedRequest, PipelineEnrichedRequest currentPipelineEnrichedRequest)
            EnrichInvoice(PipelineEnrichedRequest previousPipelineEnrichedRequest, PipelineEnrichedRequest currentPipelineEnrichedRequest,
            PipelineInvoiceInboundNotification pipelineInvoiceInboundNotification)
        {
            if (_invoiceNotificationEnrichment == null)
                _invoiceNotificationEnrichment = new InvoiceNotificationEnrichment(_settings, _logger, _mailService, _dataContext, _getBanzaiInvoiceService);

            if (string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Production", StringComparison.OrdinalIgnoreCase) == 0
                        || string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Development", StringComparison.OrdinalIgnoreCase) == 0)
                _invoiceNotificationEnrichment.RetryRequired = true;

            _invoiceNotificationEnrichment.CurrentEnrichedRequest = currentPipelineEnrichedRequest;
            _invoiceNotificationEnrichment.PreviousEnrichedRequest = previousPipelineEnrichedRequest;
            _invoiceNotificationEnrichment.EnrichmentType = EnrichmentType.Invoice;
            _invoiceNotificationEnrichment.DocId = pipelineInvoiceInboundNotification.InvoiceNo;
            _invoiceNotificationEnrichment.Message = null;
            _invoiceNotificationEnrichment.PipelineMessageID = _messageID;
            _invoiceNotificationEnrichment.PipelineInvoiceInboundNotification = pipelineInvoiceInboundNotification;

            currentPipelineEnrichedRequest = _invoiceNotificationEnrichment.Run();

            return (true, previousPipelineEnrichedRequest, currentPipelineEnrichedRequest);
        }

        /// <summary>
        /// This method creates/updates revision based on previous docs in store.
        /// </summary>
        protected void UpdateRevision(ref PipelineEnrichedRequest previousPipelineEnrichedRequest, ref PipelineEnrichedRequest currentPipelineEnrichedRequest)
        {
            currentPipelineEnrichedRequest.Common.BanzaiLastModifiedDateTime = DateTime.UtcNow;

            var previousRevision = previousPipelineEnrichedRequest?.Revision ?? 0;

            currentPipelineEnrichedRequest.Revision = previousRevision + 1;
        }

        /// <summary>
        /// This method saves current enriched request to enrichment store.
        /// </summary>
        /// <param name="pipelinePipelineEnrichedRequest"></param>
        /// <remarks />
        /// This process will not save the document to store if the current enriched request's revision 
        /// is lesser or equal to existing document in store. We are ignoring these transactions.
        private bool SaveToEnrichmentStore(PipelineEnrichedRequest pipelinePipelineEnrichedRequest)
        {
            if (pipelinePipelineEnrichedRequest == null) return false;

            var revision = pipelinePipelineEnrichedRequest.Revision;

            pipelinePipelineEnrichedRequest.IsLocked = false;

            if (_searchByIdFilter != null)
            {
                try
                {
                    _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(
                        _searchByIdFilter,
                        pipelinePipelineEnrichedRequest);
                }
                catch (MongoException)
                {
                    _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(
                        _searchByKeyFilter,
                        pipelinePipelineEnrichedRequest);

                    throw;
                }

                return true;
            }

            //Latent check for new record
            var builder = Builders<PipelineEnrichedRequest>.Filter;

            var latentFilter = _searchByKeyFilter & (builder.Eq(u => u.Revision, revision) | builder.Gt(u => u.Revision, revision));
            var filterResult = _dataContext.PipelineEnrichedRequestsV2.Find(latentFilter)?.FirstOrDefault();

            if (filterResult == null)
            {
                _dataContext.PipelineEnrichedRequestsV2.InsertOne(pipelinePipelineEnrichedRequest);
                return true;
            }
            else
            {
                // republish as the revision updated in other instance
                _rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);
                return false;
            }
        }

        /// <summary>
        /// This method generates audit report for DPID massupload
        /// </summary>
        /// <returns>MemoryStream</returns>
        protected System.IO.MemoryStream GenerateAuditReport(DataTable auditTable, string fileName) => ExcelHelper.GetExcelFromDataTableInSpecificFormat(auditTable, fileName);

        /// <summary>
        /// This method setups email object and triggers mail.
        /// </summary>
        protected void SendEmail(string subject, System.Net.Mail.Attachment file = null, string body = "", params string[] addresses)
        {
            if ("Development".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase) ||
                "PERF".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
                return;

            if (addresses.Length == 0)
            {
                addresses = _settings.DELL_OPS_EMAIL_ADDRESS.Split(',');
            }

            var message = new MailMessage
            {
                Subject = subject,
                Body = body,
                ToList = addresses,
                IsBodyHtml = true,
                File = file,
                OperatingEnv = _settings.ASPNETCORE_ENVIRONMENT
            };

            _mailService.SendMail(message);
        }
    }
}