﻿using DFS.Banzai.Library.Aura.Models;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Library.Interfaces;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Strategies;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public sealed class MassAuraInvoiceProcessor : MessageProcessor
    {
        #region MemberVariables
        private readonly List<IPipelineEnrichmentStrategy> EnrichmentStrategies = new List<IPipelineEnrichmentStrategy>();
        private string _userEmailAddress = string.Empty;
        private string _incomingMessage = string.Empty;
        public string MessageID { get; set; } = string.Empty;
        #endregion

        /// <summary>
        /// Constructor to initialize Global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassAuraInvoiceProcessor(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) : base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue) => IntializeStrategies();

        /// <summary>
        /// This method initializes stratagies to be applied for enriching incoming message
        /// </summary>
        private void IntializeStrategies() => EnrichmentStrategies.Add(new InvoiceStatusCombosLookup(_settings, _logger, _mailService, _dataContext));

        /// <summary>
        /// This method gets triggered when message arrives in PipelineEnrichedRequests Queue.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool ProcessMassAuraInvoiceRequests(string message)
        {
            _logger.LogDebug("Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.ProcessMassAuraInvoiceRequests");

            _incomingMessage = message;
            var messageDetail = message.Split('|');
            var _messageInfo = messageDetail[1];
            _userEmailAddress = messageDetail[2];

            List<InvoiceExportRequestDto> invoiceExportRequestDtoList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<InvoiceExportRequestDto>>(_messageInfo);

            if (invoiceExportRequestDtoList != null && invoiceExportRequestDtoList.Count > 0)
            {
                foreach (var exportRequest in invoiceExportRequestDtoList)
                {
                    (PipelineEnrichedRequest pipelineEnrichedRequest, var invoiceExportRequestDto) = ValidateInvoiceExportRequest(exportRequest);

                    if (invoiceExportRequestDto != null)
                        NotifyAuraAndUpdateStatus(pipelineEnrichedRequest, invoiceExportRequestDto);
                    else if (pipelineEnrichedRequest != null)
                        UnLockPipelineEnrichedRequest(pipelineEnrichedRequest.Id);
                }
            }

            _logger.LogDebug("Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.ProcessMassAuraInvoiceRequests");

            return true;
        }

        /// <summary>
        /// This method notifies Aura about invoice notifications and also updates the status once exported
        /// </summary>
        /// <param name="invoiceExportRequestDto"></param>
        private (PipelineEnrichedRequest, InvoiceExportRequestDto) ValidateInvoiceExportRequest(InvoiceExportRequestDto invoiceExportRequestDto)
        {
            var builder = Builders<PipelineEnrichedRequest>.Filter;

            var invoiceFilter = builder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo.Equals(invoiceExportRequestDto.InvoiceNo));
            invoiceFilter &= Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, "CHANNEL");

            if (!string.IsNullOrEmpty(invoiceExportRequestDto.BuId))
                invoiceFilter &= Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, invoiceExportRequestDto.BuId);

            if (!string.IsNullOrEmpty(invoiceExportRequestDto.VendorId))
                invoiceFilter &= Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, invoiceExportRequestDto.VendorId);

            var pipelineEnrichedRequest = GetPipelineEnrichedRequest(invoiceFilter).previousEnrichedRequest;

            if (pipelineEnrichedRequest == null)
                return (null, null);
            else if ("C".Equals(pipelineEnrichedRequest.Common.DFSOrphanFlag, StringComparison.InvariantCultureIgnoreCase))
                return (pipelineEnrichedRequest, null);

            foreach (var pipelineInvoice in pipelineEnrichedRequest?.InvoiceStage?.Invoices)
            {
                if (!pipelineInvoice.InvoiceNo.Equals(invoiceExportRequestDto.InvoiceNo, StringComparison.InvariantCultureIgnoreCase))
                    continue;

                if (("INV-EXP-SENT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
                    || "INV-EXP-ACCEPT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
                    && ValidStatusHistoryCodes(pipelineInvoice.StatusHistory))
                    return (pipelineEnrichedRequest, null);

                if ("INV-ACCEPT".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase) || ValidateStatusHistoryForAcceptStatus(pipelineInvoice.StatusHistory))
                {
                    return (pipelineEnrichedRequest, new InvoiceExportRequestDto
                    {
                        InvoiceNo = pipelineInvoice.InvoiceNo,
                        BuId = pipelineEnrichedRequest?.Common?.SourceBusinessUnit,
                        PipelineSource = pipelineEnrichedRequest?.Common?.PipelineSource,
                        VendorId = invoiceExportRequestDto.VendorId,
                        NotificationType = "Invoice Export"
                    });
                }
            }

            return (pipelineEnrichedRequest, null);
        }

        /// <summary>
        /// Validation of StatusHistory for set of status codes
        /// </summary>
        /// <param name="StatusHistory"></param>
        private bool ValidStatusHistoryCodes(List<Status> StatusHistory)
        {
            if (StatusHistory == null)
                return false;

            List<KeyValuePair<string, DateTime>> statusCodeAndDateTime = new List<KeyValuePair<string, DateTime>>();
            foreach (var status in StatusHistory)
            {
                if ("INV-EXP-SENT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
                        || "INV-EXP-ACCEPT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase)
                        || "INV-EXP-REJECT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
                    statusCodeAndDateTime.Add(new KeyValuePair<string, DateTime>(status.BanzaiStatusCode.ToString(),
                                        Convert.ToDateTime(status.BanzaiStatusCreateDateTime)));
            }

            var findStatusCodeExpSent = statusCodeAndDateTime.ToList().Find(x => "INV-EXP-SENT".Equals(x.Key, StringComparison.InvariantCultureIgnoreCase));
            var findStatusCodeAccept = statusCodeAndDateTime.ToList().Find(x => "INV-EXP-ACCEPT".Equals(x.Key, StringComparison.InvariantCultureIgnoreCase));

            if (!string.IsNullOrEmpty(findStatusCodeExpSent.Key) || !string.IsNullOrEmpty(findStatusCodeAccept.Key))
            {
                var statusHistoryDate = statusCodeAndDateTime.OrderByDescending(x => x.Value).FirstOrDefault();
                if ("INV-EXP-REJECT".Equals(statusHistoryDate.Key, StringComparison.InvariantCultureIgnoreCase))
                    return false;
            }

            if (!string.IsNullOrEmpty(findStatusCodeExpSent.Key) && !string.IsNullOrEmpty(findStatusCodeAccept.Key))
                return true;

            return false;
        }

        /// <summary>
        /// Validate Status History For Status Code Check
        /// </summary>
        /// <param name="StatusHistory"></param>
        /// <returns></returns>
        private bool ValidateStatusHistoryForAcceptStatus(List<Status> StatusHistory)
        {
            if (StatusHistory != null)
            {
                foreach (var status in StatusHistory)
                {
                    if ("INV-ACCEPT".Equals(status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
                        return true;
                }
            }
            return false;
        }
        /// <summary>
        /// This method notifies Aura about invoice notifications and also updates the status once exported
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <param name="invoiceExportRequestDto"></param>
        private void NotifyAuraAndUpdateStatus(PipelineEnrichedRequest pipelineEnrichedRequest, InvoiceExportRequestDto invoiceExportRequestDto)
        {
            var message = new JObject
            {
                { "pipelineSource", invoiceExportRequestDto.PipelineSource },
                { "invoiceNo", invoiceExportRequestDto.InvoiceNo},
                { "buid", invoiceExportRequestDto.BuId},
                { "vendorId", invoiceExportRequestDto.VendorId},
                { "notificationType", invoiceExportRequestDto.NotificationType}
            };

            bool isProceed = UpdateStatusToExported(pipelineEnrichedRequest, invoiceExportRequestDto);

            if (isProceed)
                _rabbitMQueuePublisher.Publish(message: $"{message}", exchange: _auraInvoiceExchange.Exchange,
                    routingKey: _auraInvoiceExchange.RoutingKey, type: _auraInvoiceExchange.Type);
        }

        /// <summary>
        /// This method updates pipeline enriched request based on given inoice no
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <param name="invoiceExportRequestDto"></param>
        /// <returns></returns>
        private bool UpdateStatusToExported(PipelineEnrichedRequest pipelineEnrichedRequest, InvoiceExportRequestDto invoiceExportRequestDto)
        {
            if (pipelineEnrichedRequest.Common == null)
                pipelineEnrichedRequest.Common = new Common();

            pipelineEnrichedRequest.Common.UserLastModifiedBy = _userEmailAddress;
            pipelineEnrichedRequest.Common.UserLastModifiedDate = DateTime.UtcNow;
            pipelineEnrichedRequest.Common.BanzaiLastModifiedDateTime = DateTime.UtcNow;

            var inv = (from invoice in pipelineEnrichedRequest?.InvoiceStage?.Invoices
                       where invoice.InvoiceNo.Equals(invoiceExportRequestDto.InvoiceNo, StringComparison.InvariantCultureIgnoreCase)
                       select invoice)?.FirstOrDefault();

            if (inv != null)
            {
                if (inv.StatusHistory == null)
                    inv.StatusHistory = new List<Status>();

                inv.StatusHistory.Add(inv.Status);

                var statusComboFilter = Builders<StatusCombo>.Filter.Eq(u => u.PipelineSource, invoiceExportRequestDto.PipelineSource)
                & Builders<StatusCombo>.Filter.Eq(u => u.BanzaiStatusCode, "INV-EXP-SENT")
                & Builders<StatusCombo>.Filter.Eq(u => u.Active, true)
                & Builders<StatusCombo>.Filter.Eq(u => u.PipelineStage, "INVOICE");

                inv.Status = GetMatchingStatusFromStatusCombo(statusComboFilter);
            }

            SaveToEnrichmentStore(pipelineEnrichedRequest);

            return true;
        }

        /// <summary>
        /// This method retreives matching status from status combos
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        private Status GetMatchingStatusFromStatusCombo(FilterDefinition<StatusCombo> filter)
        {
            var statusCombo = _dataContext.StatusCombos.Find(filter)?.FirstOrDefault();

            if (statusCombo != null)
            {
                return new Status()
                {
                    BanzaiStatusCreateDateTime = DateTime.UtcNow,
                    BanzaiStatusCode = statusCombo.BanzaiStatusCode,
                    BanzaiStatusSequence = statusCombo.BanzaiStatusSequence,
                    BanzaiUnbookedExposureFlag = statusCombo.BanzaiUnbookedExposureFlag,
                    DecisionSource = GetNtAccount(_userEmailAddress),
                    DecisionSourceDateTime = DateTime.UtcNow,
                    DecisionSourceStatusCode = statusCombo.DecisionSourceStatusCode,
                    DFSCustomer = statusCombo.DFSCustomer,
                    Discard = statusCombo.Discard,
                    SourceStatusCode = statusCombo.SourceStatusCode,
                    SourceStatusCodeDateTime = DateTime.UtcNow
                };
            }

            return null;
        }

        /// <summary>
        /// To Get the NT Account Details from User Mail Id
        /// </summary>
        /// <param name="userEmail"></param>
        /// <returns></returns>
        private string GetNtAccount(string userEmail)
        {
            if (!string.IsNullOrEmpty(userEmail))
            {
                MailAddress addr = new MailAddress(userEmail);
                return addr.User;
            }
            return null;
        }
        /// <summary>
        /// This method gets triggered when message arrives from Aura Invoice Request processing.
        /// </summary>		
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool ProcessAuraInvoiceRequest(string message)
        {
            _logger.LogDebug("Entered DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.ProcessAuraInvoiceRequest");

            _incomingMessage = message;
            var messageDetail = message.Split('|');
            MessageID = messageDetail[1];

            var filter = Builders<PipelineAuraInvoiceRequestDto>.Filter.Eq(u => u.Id, MessageID);
            var pipelineAuraInvoiceRequest = _dataContext.PipelineAuraInvoiceRequests.Find(filter)?.FirstOrDefault();

            if (pipelineAuraInvoiceRequest == null)
            {
                _logger.LogWarning($"Banzai.Pipeline.Channel AuraInvoiceRequest for MessageID {MessageID} does not exist.");
                return true;
            }

            _logger.LogDebug("Exited DFS.Banzai.Pipeline.Streaming.Channel EnrichmentRequestsProcessor ProcessAuraInvoiceRequest");

            return EnrichAuraInvoiceRequestAndSave(pipelineAuraInvoiceRequest);
        }

        /// <summary>
        /// This method enriches aura invoice requests
        /// </summary>
        /// <param name="pipelineAuraInvoiceRequestDto"></param>
        private bool EnrichAuraInvoiceRequestAndSave(PipelineAuraInvoiceRequestDto pipelineAuraInvoiceRequestDto)
        {
            PipelineEnrichedRequest currentEnrichedRequest;
            PipelineEnrichedRequest previousEnrichedRequest = null;
            bool ignore;

            try
            {
                if (string.IsNullOrEmpty(pipelineAuraInvoiceRequestDto.Buid) || string.IsNullOrEmpty(pipelineAuraInvoiceRequestDto.InvoiceNumber))
                    return true;

                FilterDefinition<PipelineEnrichedRequest> invoiceFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, pipelineAuraInvoiceRequestDto.Buid)
                 & Builders<PipelineEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo.Equals(pipelineAuraInvoiceRequestDto.InvoiceNumber))
                 & Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, pipelineAuraInvoiceRequestDto.PipelineSource);

                if (!string.IsNullOrEmpty(pipelineAuraInvoiceRequestDto.VendorID))
                    invoiceFilter &= Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, pipelineAuraInvoiceRequestDto.VendorID);

                (previousEnrichedRequest, currentEnrichedRequest, ignore) = GetPipelineEnrichedRequest(invoiceFilter);

                if (ignore)
                    return true;

                if (currentEnrichedRequest == null)
                {
                    var body = $"The following Aura notification was received in Banzai.Pipeline.Channel but a matching InvoiceNo-BUID-VendorId is not found.<br />" +
                        $"PipelineSource: Channel<br />" +
                        $"InvoiceNo: {pipelineAuraInvoiceRequestDto.InvoiceNumber}<br />" +
                        $"Buid: {pipelineAuraInvoiceRequestDto.Buid}<br />" +
                        $"VendorId: {pipelineAuraInvoiceRequestDto.VendorID}<br />" +
                        $"MessageId: {pipelineAuraInvoiceRequestDto.Id}";

                    SendMail(body, $"Matching {pipelineAuraInvoiceRequestDto.InvoiceNumber}-{pipelineAuraInvoiceRequestDto.Buid} not found for Aura notification");

                    return true;
                }

                RunStrategies(pipelineAuraInvoiceRequestDto, previousEnrichedRequest, currentEnrichedRequest);
            }
            catch (Exception e)
            {
                UnLockPipelineEnrichedRequest(previousEnrichedRequest?.Id);
                _logger.LogError($"Banzai.Pipeline.Channel Error in EnrichAuraInvoiceRequestAndSave method for Message - {_incomingMessage}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
                throw;
            }

            return true;
        }

        /// <summary>
        /// This method fetches existing pipeline enriched request based on given invoice filter
        /// </summary>
        /// <param name="pipelineAuraInvoiceRequestDto"></param>
        /// <param name="invoiceFilter"></param>
        /// <returns></returns>
        private (PipelineEnrichedRequest previousEnrichedRequest,
            PipelineEnrichedRequest currentEnrichedRequest,
            bool ignore)
            GetPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> invoiceFilter)
        {
            PipelineEnrichedRequest currentEnrichedRequest = null;
            PipelineEnrichedRequest previousEnrichedRequest = LockPipelineEnrichedRequest(invoiceFilter);

            if (previousEnrichedRequest != null)
            {
                if (previousEnrichedRequest.IsLocked)
                {
                    for (var i = 1; i <= 20; i++)
                    {
                        System.Threading.Thread.Sleep(1000);
                        previousEnrichedRequest = LockPipelineEnrichedRequest(invoiceFilter);

                        if (!previousEnrichedRequest.IsLocked)
                            break;

                        if (i == 20)
                        {
                            UnLockPipelineEnrichedRequest(previousEnrichedRequest.Id);

                            _rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);

                            return (null, null, true);
                        }
                    }
                }
                currentEnrichedRequest = previousEnrichedRequest.Clone() as PipelineEnrichedRequest;
            }

            return (previousEnrichedRequest, currentEnrichedRequest, false);
        }

        /// <summary>
        /// This method execute list of strategies to enrich contract request received from leasewave
        /// </summary>
        /// <param name="inputInvoice"></param>
        /// <param name="pipelineAuraInvoiceRequestDto"></param>
        /// <param name="previousEnrichedRequest"></param>
        /// <param name="currentEnrichedRequest"></param>
        private void RunStrategies(PipelineAuraInvoiceRequestDto pipelineAuraInvoiceRequestDto,
            PipelineEnrichedRequest previousEnrichedRequest, PipelineEnrichedRequest currentEnrichedRequest)
        {
            currentEnrichedRequest = CreateInvoiceStatus(pipelineAuraInvoiceRequestDto, currentEnrichedRequest);

            foreach (var strategy in EnrichmentStrategies)
            {
                strategy.EnrichmentType = EnrichmentType.Invoice;
                strategy.PipelineEnrichedRequest = currentEnrichedRequest;
                strategy.PipelineMessageID = MessageID;

                if (string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Production", StringComparison.OrdinalIgnoreCase) == 0
                    || string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Development", StringComparison.OrdinalIgnoreCase) == 0)
                    strategy.RetryRequired = true;

                currentEnrichedRequest = strategy.Run();

                if (!string.IsNullOrEmpty(strategy.ErrorMessage))
                {
                    UnLockPipelineEnrichedRequest(previousEnrichedRequest?.Id);
                    _logger.LogWarning($"Banzai.Pipeline.Channel Error in EnrichAuraInvoiceRequestAndSave RunStrategies method for strategy {strategy.GetType()} " +
                        $"failed with an error {strategy.ErrorMessage} for Message {MessageID}.");
                    return;
                }
            }

            ProcessCurrentStatusAndLatency(ref previousEnrichedRequest, ref currentEnrichedRequest, pipelineAuraInvoiceRequestDto.InvoiceNumber);

            bool isSaved = SaveToEnrichmentStore(currentEnrichedRequest);

            if (isSaved && currentEnrichedRequest != null) _rabbitMQueuePublisher.Publish(currentEnrichedRequest.Id, _rollupRequestsQueue.QueueName);
        }

        /// <summary>
        /// This method create new status for invoice
        /// </summary>
        /// <param name="pipelineAuraInvoiceRequestDto"></param>
        /// <param name="currentEnrichedRequest"></param>
        /// <returns></returns>
        private PipelineEnrichedRequest CreateInvoiceStatus(PipelineAuraInvoiceRequestDto pipelineAuraInvoiceRequestDto,
            PipelineEnrichedRequest currentEnrichedRequest)
        {
            var invoice = (from inv in currentEnrichedRequest?.InvoiceStage?.Invoices
                           where inv.InvoiceNo.Equals(pipelineAuraInvoiceRequestDto.InvoiceNumber, StringComparison.InvariantCultureIgnoreCase)
                           select inv)?.FirstOrDefault();

            if (invoice != null)
            {
                var status = new Status
                {
                    BanzaiStatusCreateDateTime = DateTime.UtcNow,
                    MessageType = "AuraInvoiceRequest",
                    MessageID = MessageID,
                    MessageReceivedDateTime = pipelineAuraInvoiceRequestDto.LastModifiedDateTime,

                    DecisionSourceStatusCode = "SUCCESS".Equals(pipelineAuraInvoiceRequestDto.InfoMessage, StringComparison.InvariantCultureIgnoreCase) ?
                    "EXP-ACCEPT" : "EXP-REJECT"
                };

                invoice.Status = status;
            }

            return currentEnrichedRequest;
        }

        /// <summary>
        /// This method processes CurrentStatus and latency of CurrentDocument.
        /// </summary>
        /// <param name="previousEnrichedRequest">Previous document received from DB store.</param>
        /// <param name="currentEnrichedRequest">Current document received from Queue.</param>
        /// <param name="invoiceNo"></param>
        private void ProcessCurrentStatusAndLatency(ref PipelineEnrichedRequest previousEnrichedRequest,
            ref PipelineEnrichedRequest currentEnrichedRequest, string invoiceNo)
        {
            if (currentEnrichedRequest?.InvoiceStage?.Invoices != null && previousEnrichedRequest?.InvoiceStage?.Invoices != null)
            {
                var currentInvoice = (from invoice in currentEnrichedRequest?.InvoiceStage?.Invoices
                                      where invoice.InvoiceNo.Equals(invoiceNo, StringComparison.InvariantCultureIgnoreCase)
                                      select invoice)?.FirstOrDefault();

                Library.Entities.Invoice previousInvoice = null;

                if (currentInvoice != null)
                {
                    previousInvoice = (from x in previousEnrichedRequest?.InvoiceStage?.Invoices
                                       where x.InvoiceNo.Equals(currentInvoice.InvoiceNo, StringComparison.InvariantCultureIgnoreCase)
                                       select x).FirstOrDefault();
                }

                var isInvoiceLatent = UpdateInvoicesStatusHistory(ref previousInvoice, ref currentInvoice);

                currentEnrichedRequest.InvoiceStage.Invoices = isInvoiceLatent ? previousEnrichedRequest.InvoiceStage?.Invoices : currentEnrichedRequest.InvoiceStage?.Invoices;
            }
        }

        /// <summary>
        /// This method is called from ProcessCurrentStatus to update StatusHistory on Invoices
        /// based on CurrentStatus of CurrentDocument.
        /// </summary>	
        /// <param name="previousInvoice"></param>
        /// <param name="currentInvoice"></param>        
        /// <returns></returns>
        /// <remarks>Status history of CurrentDocument is formed from PreviousDocument's CurrentStatus.</remarks>
        private bool UpdateInvoicesStatusHistory(ref Library.Entities.Invoice previousInvoice, ref Library.Entities.Invoice currentInvoice)
        {
            if (previousInvoice?.Status == null || currentInvoice?.Status == null)
                return currentInvoice?.Status != null && currentInvoice.Status.LatentTransaction;

            if (currentInvoice.Status.BanzaiStatusSequence != 0 && previousInvoice.Status.BanzaiStatusSequence != 0
                && ((currentInvoice.Status.BanzaiStatusSequence < previousInvoice.Status.BanzaiStatusSequence) ||
                (Convert.ToDateTime(currentInvoice.Status.DecisionSourceDateTime) <= Convert.ToDateTime(previousInvoice.Status.DecisionSourceDateTime) &&
                currentInvoice.Status.BanzaiStatusSequence == previousInvoice.Status.BanzaiStatusSequence)))
            {
                currentInvoice.Status.LatentTransaction = true;
                previousInvoice.StatusHistory ??= new List<Status>();
                previousInvoice.StatusHistory.Add(currentInvoice.Status);
            }

            if (!currentInvoice.Status.LatentTransaction)
            {
                currentInvoice.StatusHistory ??= new List<Status>();
                currentInvoice.StatusHistory.Add(previousInvoice.Status);
            }

            return currentInvoice.Status != null && currentInvoice.Status.LatentTransaction;
        }

        /// <summary>
        /// This method saves current enriched request to enrichment store.
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <remarks/>
        /// This process will not save the document to store if the current enriched request's
        /// revision is lesser or equal to existing document in store. We are ignoring these transactions.
        private bool SaveToEnrichmentStore(PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            pipelineEnrichedRequest.Revision += 1;

            pipelineEnrichedRequest.IsLocked = false;

            var builder = Builders<PipelineEnrichedRequest>.Filter;

            var latentFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id) & (builder.Eq(u => u.Revision, pipelineEnrichedRequest.Revision) | builder.Gt(u => u.Revision, pipelineEnrichedRequest.Revision));

            var filterResult = _dataContext.PipelineEnrichedRequestsV2.Find(latentFilter)?.FirstOrDefault();

            if (filterResult == null)
            {
                var updateFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id);

                _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(
                    updateFilter,
                    pipelineEnrichedRequest);

                return true;
            }
            else
            {
                // republish as the revision updated in other instance
                _rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);
                return false;
            }
        }

        /// <summary>
        /// This method applies lock on EnrichedRequests for given ID
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        private PipelineEnrichedRequest LockPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter) =>
            _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true), ReturnDocument.Before);
        
        /// <summary>
        /// This method sends email
        /// </summary>        
        /// <param name="message"></param>
        /// <param name="subject"></param>
        private void SendMail(string body, string subject)
        {
            if ("Development".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase) ||
                "PERF".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
                return;

            var to = _settings.EMAIL_BUZ_ADMIN.Split(',').ToList();
            var mailMessage = new Banzai.Library.Entities.MailMessage
            {
                Subject = subject,
                Body = body,
                ToList = to,
                IsBodyHtml = true,
                OperatingEnv = _settings.ASPNETCORE_ENVIRONMENT
            };
            _mailService.SendMail(mailMessage);
        }
    }
}
