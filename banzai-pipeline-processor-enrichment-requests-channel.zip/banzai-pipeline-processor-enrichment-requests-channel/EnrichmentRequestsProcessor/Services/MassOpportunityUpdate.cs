﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.XMLManager;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public sealed class MassOpportunityUpdate : MessageProcessor
    {
        #region MemberVariables
        private string _LastModifiedUser;
        private const string MassUpdate_Opportunity = "SFDCOpptyId";
        #endregion

        /// <summary>
        /// Constructor to initialize Global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassOpportunityUpdate(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) : base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue)
        {            
        }

        /// <summary>
        /// This method processes mass opportunity updates
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool Process(XDocument message)
        {
            _logger.LogDebug($"Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassOpportunityUpdate - {message}");

            var messageType = string.Empty;
            try
            {
                var invoiceNoBuidVendorIdList = DocId?.Split(",");
                if (invoiceNoBuidVendorIdList == null || invoiceNoBuidVendorIdList.Length < 1)
                    return true;
                var fileAttributes = XmlHelper.GetXPathValue(message?.Root, "FileAttributes").Split('#');
                messageType = XmlHelper.GetXPathValue(message?.Root, "MessageType");
                DataTable[] auditTable = { MassOpportunityUpdateAuditTableSetup() };
                _LastModifiedUser = fileAttributes.ElementAt(0);
                Array.ForEach(invoiceNoBuidVendorIdList, invoiceNoBuidVedorId =>
                {
                    if (string.IsNullOrEmpty(invoiceNoBuidVedorId)) return;
                    var auditRow = auditTable[0].NewRow();
                    if (MassUpdate_Opportunity.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
                        UpdateOpportunityId(invoiceNoBuidVedorId, ref auditRow, fileAttributes.ElementAt(0));
                    auditTable[0].Rows.Add(auditRow);
                });
                if (MassUpdate_Opportunity.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
                {
                    var attachment = new System.Net.Mail.Attachment(GenerateAuditReport(auditTable[0], "SFDCOpportunityID_MassUploadAuditReport"), $"SFDCOpportunityID_MassUploadAuditReport_{fileAttributes.ElementAt(1)}_{fileAttributes.ElementAt(2)}.xlsx", "application/vnd.ms-excel");
                    SendEmail("Banzai SFCDOpportunityID Update Mass Upload Completed", attachment, $"Please find attached the Audit log for the SFDC Opportunity ID Mass Upload performed at {fileAttributes.ElementAt(2)} for input file - {fileAttributes.ElementAt(1)} ", fileAttributes.ElementAt(3));
                }
                _logger.LogDebug("Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassOpportunityUpdate");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassOpportunityUpdate Processor. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
            return true;
        }

        /// <summary>
        /// Initializing Audit trail table
        /// </summary>
        private static DataTable MassOpportunityUpdateAuditTableSetup()
        {
            var auditTable = new DataTable();
            auditTable.Columns.Add("PipeLine Source", typeof(string));
            auditTable.Columns.Add("Invoice No", typeof(string));
            auditTable.Columns.Add("Buid", typeof(string));
            auditTable.Columns.Add("Vendor ID", typeof(string));
            auditTable.Columns.Add("SFDC Opportunity ID", typeof(string));
            auditTable.Columns.Add("Current SFDC Opportunity ID", typeof(string));
            auditTable.Columns.Add("Audit Status", typeof(string));
            auditTable.Columns.Add("Error", typeof(string));
            return auditTable;
        }

        /// <summary>
        /// This method updates opportunity id
        /// </summary>
        /// <param name="input"></param>
        /// <param name="auditRow"></param>
        /// <param name="user"></param>
        private void UpdateOpportunityId(string input, ref DataRow auditRow, string user)
        {
            var id = input?.Split(":");
            var opptyUpdateDto = new UpdateStatusOverrideDto()
            {
                PipelineSource = id?[0],
                Id = id?[1],
                BuId = id?[2],
                VendorId = id?[3],
                CurrentStatus = id?[4],
                UserLastModifiedBy = _LastModifiedUser,
            };

            // Initialize default values
            auditRow["Pipeline Source"] = $"{opptyUpdateDto.PipelineSource}";
            auditRow["Invoice No"] = $"{opptyUpdateDto.Id}";
            auditRow["Buid"] = $"{opptyUpdateDto.BuId}";
            auditRow["Vendor ID"] = $"{opptyUpdateDto.VendorId}";
            auditRow["SFDC Opportunity ID"] = $"{opptyUpdateDto.CurrentStatus}";
            auditRow["Current SFDC Opportunity ID"] = "";
            try
            {
                (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) = ValidateInput(opptyUpdateDto, ref auditRow);

                if (!isProceed)
                    return;
                var invoice = docBeforeUpdate.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo.Trim().ToUpper() == opptyUpdateDto.Id);
                auditRow["Current SFDC Opportunity ID"] = invoice.DFSOpportunityID ?? "";
                if (!EnrichedRequestUpdateSFDCOppty(opptyUpdateDto, user, docBeforeUpdate))
                {
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);

                    UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, Stage, ID, and Current Status");
                    _logger.LogCritical($"BanzaiStatusCodeUpdate({id}) - Error updating enriched document for revision {docBeforeUpdate.Revision}");
                    return;
                }
                UpdateAuditRow(ref auditRow, "Found", string.Empty);
                _rabbitMQueuePublisher.Publish(docBeforeUpdate.Id, _rollupRequestsQueue.QueueName);
                return;
            }
            catch (Exception e)
            {
                _logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassOpportunityUpdate Banzai status code update Error for {opptyUpdateDto.PipelineStage}: {opptyUpdateDto.Id}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }

        /// <summary>
        /// This method validates input for status update
        /// </summary>
        /// <param name="statusUpdateDto"></param>
        /// <param name="auditRow"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) ValidateInput(UpdateStatusOverrideDto statusUpdateDto,
            ref DataRow auditRow)
        {
            if (string.IsNullOrEmpty(statusUpdateDto.Id)
                    || string.IsNullOrEmpty(statusUpdateDto.BuId)
                    || string.IsNullOrEmpty(statusUpdateDto.CurrentStatus))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.Id))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.BuId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.VendorId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (!ValidateOpptyRegEx(statusUpdateDto.CurrentStatus))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "SFDC Opportunity ID is invalid");
                return (false, null);
            }
            var docBeforeUpdate = LockPipelineEnrichedRequest(statusUpdateDto);
            if (docBeforeUpdate == null)
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                return (false, null);
            }
            return (true, docBeforeUpdate);
        }

        /// <summary>
        /// matches given expresssion to find current status
        /// </summary>
        /// <param name="currentStatus"></param>
        /// <returns></returns>
        private bool ValidateOpptyRegEx(string currentStatus)
        {
            Regex reg = new Regex(@"^[0-9]{7,10}$");
            return reg.IsMatch(currentStatus);
        }

        /// <summary>
        /// This method removes lock on PipelineEnrichedRequest for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockPipelineEnrichedRequest(string id)
        {
            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
        }

        /// <summary>
        /// This method applies locks on EnrichedRequests for given ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private PipelineEnrichedRequest LockPipelineEnrichedRequest(UpdateStatusOverrideDto statusUpdateDto)
        {
            var enrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
            FilterDefinition<PipelineEnrichedRequest> filter = null;

            filter = enrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo == statusUpdateDto.Id) & enrichedRequestBuilder.Eq(x => x.IsLocked, false);

            filter &= enrichedRequestBuilder.Eq(x => x.IsLocked, false);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, statusUpdateDto.BuId);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.PipelineSource, statusUpdateDto.PipelineSource);

            if (!string.IsNullOrEmpty(statusUpdateDto.VendorId))
                filter &= enrichedRequestBuilder.Eq(x => x.Common.VendorId, statusUpdateDto.VendorId);

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
                    Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
                    ReturnDocument.Before);
            return result;
        }

        /// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="docBeforeUpdate"></param>
		/// <returns></returns>
		private bool EnrichedRequestUpdateSFDCOppty(UpdateStatusOverrideDto statusUpdateDto, string user, PipelineEnrichedRequest docBeforeUpdate)
        {
            var docAfterUpdate = UpdateOpptyIdInvoice(statusUpdateDto, docBeforeUpdate);

            if (docAfterUpdate != null)
            {   
                docAfterUpdate.Common.UserLastModifiedDate = DateTime.UtcNow;
                docAfterUpdate.Common.UserLastModifiedBy = user;
                return SaveEnrichedRequest(docAfterUpdate);
            }
            return false;
        }

        /// <summary>
		/// This method status update for invoice
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest UpdateOpptyIdInvoice(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            var invoice = pipelineEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo.Trim().ToUpper() == statusUpdateDto.Id);
            if (invoice == null)
                return null;
            invoice.DFSOpportunityID = statusUpdateDto.CurrentStatus;
            return pipelineEnrichedRequest;
        }

        /// <summary>
        /// This method saved document to enrichment store
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <returns></returns>
        private bool SaveEnrichedRequest(PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            if (pipelineEnrichedRequest == null) return false;

            pipelineEnrichedRequest.IsLocked = false;
            pipelineEnrichedRequest.Revision++;

            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var updateFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id);

            _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(updateFilter, pipelineEnrichedRequest);

            return true;
        }

        /// <summary>
        /// Generic function to update audit rows
        /// </summary>
        private void UpdateAuditRow(ref DataRow auditRow, string status, string remarks)
        {
            auditRow["Audit Status"] = status;
            auditRow["Error"] = remarks;
        }
    }
}