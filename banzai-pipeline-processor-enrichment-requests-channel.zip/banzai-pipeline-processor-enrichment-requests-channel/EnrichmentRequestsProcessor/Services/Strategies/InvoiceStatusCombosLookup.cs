using DFS.Banzai.Invoice.Library.Entities;
using DFS.Banzai.Library;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.Generic;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Library.Interfaces;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Strategies
{    
    public class InvoiceStatusCombosLookup : IPipelineEnrichmentStrategy
	{
		#region MemeberVariables
		private readonly ILogger _logger;
		private readonly IDataContext _dataContext;
		private readonly Settings _settings;
		private readonly IMailService _mail;
		private string _guid;
		private int _retryCount;
		#endregion

		#region Properties
		public EnrichmentType EnrichmentType { get; set; }
		public XElement Message { get; set; }
		public string DocID { get; set; }
		public PipelineEnrichedRequest PipelineEnrichedRequest { get; set; }
		public string ErrorMessage { get; set; }
		public bool RetryRequired { get; set; }
		public string PipelineMessageID { get; set; }
		#endregion

		/// <summary>
		/// Constructor to initialize class members
		/// </summary>
		/// <param name="settings"></param>
		/// <param name="logger"></param>
		/// <param name="mail"></param>
		/// <param name="dataContext"></param>
		public InvoiceStatusCombosLookup(Settings settings, ILogger logger, IMailService mail, IDataContext dataContext)
		{
			_dataContext = dataContext;
			_logger = logger;
			_settings = settings;
			_mail = mail;

			_guid = Guid.NewGuid().ToString();
		}

		/// <summary>
		/// This method calls banzaiStatus service to apply enrichment on CurrentStatus
		/// </summary>
		/// <returns>EnrichedMetadata</returns>
		public PipelineEnrichedRequest Run()
		{
			_logger.LogDebug("Entered Banzai.Pipeline InvoiceStatusCombosLookup Strategy");
			try
			{
				_retryCount = 0;
				_guid = Guid.NewGuid().ToString();
				ErrorMessage = string.Empty;
				PipelineEnrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();

				var invoices = PipelineEnrichedRequest.InvoiceStage?.Invoices;

				if (invoices != null)
				{
					foreach (var invoice in invoices)
					{
						SetBanzaiInvoiceStatusElements(PipelineEnrichedRequest.Common?.PipelineSource, PipelineEnrichedRequest.InvoiceStage?.PipelineStage, invoice.Status);
					}
				}
			}
			catch (Exception e)
			{
				PipelineEnrichedRequest.BanzaiStatusInSync = InvoiceEnrichmentStatus.Fail.ToString();
				_logger.LogError($"Trouble processing Banzai.Pipeline InvoiceStatusCombosLookup strategy for MessageId {PipelineMessageID}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				throw;
			}

			_logger.LogDebug("Exited Banzai.Pipeline InvoiceStatusCombosLookup Strategy");

			return PipelineEnrichedRequest;
		}

		/// <summary>
		/// This method is used to set the banzai status elements for Invoices to the current status in transaction data.
		/// </summary>
		private void SetBanzaiInvoiceStatusElements(string pipelineSource, string pipelineStage, Status currentStatus)
		{

			if (string.IsNullOrEmpty(pipelineSource) || string.IsNullOrEmpty(pipelineStage) || string.IsNullOrEmpty(currentStatus.DecisionSourceStatusCode))
				return;

			var utility = new Utility(_settings, _mail, _dataContext, _logger);
			var isIgnore = IgnoreRetry(utility);
			if (isIgnore)
				return;

			StatusCombo banzaiStatus = GetStatusCombo(pipelineSource, pipelineStage, currentStatus.DecisionSourceStatusCode);

			if (RetryRequired && banzaiStatus == null)
			{
				var subject = $"Banzai.Pipeline - InvoiceStatusCombosLookup strategy not available while processing MessageID {PipelineMessageID}";
				var message = $"Banzai.Pipeline - InvoiceStatusCombosLookup strategy not available for " +
							  $"PipelineSource {pipelineSource}, PipelineStage {pipelineStage} " +
							  $"and DecisionSourceStatusCode {currentStatus.DecisionSourceStatusCode}" +
							  $"<br /><br />Reattempt # {_retryCount + 1}<br /><br />CacheKey: {_guid}<br /><br />";

				if (!string.IsNullOrEmpty(PipelineMessageID))
					message += $"Incoming Message ID {PipelineMessageID}<br /><br />";

				utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, message); //Trigger a mail to IT about the failure
				utility.TriggerWait(ref _retryCount); //Wait before next process

				SetBanzaiInvoiceStatusElements(pipelineSource, pipelineStage, currentStatus);
			}

			SuccessNotification(utility);

			if (banzaiStatus == null) return;

			currentStatus.DecisionSource = banzaiStatus.DecisionSource;
			currentStatus.Discard = banzaiStatus.Discard;
			currentStatus.DFSCustomer = banzaiStatus.DFSCustomer;
			currentStatus.BanzaiStatusCode = banzaiStatus.BanzaiStatusCode;
			currentStatus.BanzaiStatusSequence = banzaiStatus.BanzaiStatusSequence;
			currentStatus.BanzaiUnbookedExposureFlag = banzaiStatus.BanzaiUnbookedExposureFlag;
		}

		/// <summary>
		/// This code works on ignoring a message when it is no longer requried for retry 
		/// </summary>
		/// <param name="utility"></param>
		/// <returns></returns>
		[ExcludeFromCodeCoverage]
		private bool IgnoreRetry(Utility utility)
		{
			if (_retryCount >= 3)
			{
				var key = $"{CacheKeys.EnrichFailureTracker}{_guid}";
				var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
				var count = _dataContext.IgnoreRetry.Find(filter)?.Count() ?? 0;

				if (count > 0)
				{
					_dataContext.IgnoreRetry.DeleteOne(filter);

					RetryRequired = false; //Overwriting the flag to avoid infinite loop
					PipelineEnrichedRequest.BanzaiStatusInSync = InvoiceEnrichmentStatus.Fail.ToString();

					ErrorMessage = "StatusComboLookup - external interruption";
					_retryCount = 0; //Suppress the success notification

					var subject = $"Banzai.Pipeline - InvoiceStatusCombosLookup strategy for MessageID {PipelineMessageID} ignored";
					var message =
						$"Banzai.Pipeline - InvoiceStatusCombosLookup strategy with Cache Key {_guid} is ignored due to external interruption";

					if (!string.IsNullOrEmpty(PipelineMessageID))
						message += $"<br /><br />Incoming Message ID {PipelineMessageID}";

					utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, message);

					return true; //Ignore the message
				}
			}

			return false;
		}

		/// <summary>
		/// This method fetches status combo
		/// </summary>
		/// <param name="pipelineSource"></param>
		/// <param name="pipelineStage"></param>
		/// <param name="decisionSourceStatusCode"></param>
		/// <returns></returns>
		private StatusCombo GetStatusCombo(string pipelineSource, string pipelineStage, string decisionSourceStatusCode)
		{
			var statusComboList = _dataContext.StatusCombos.GetAll()?.ToList();
			if (statusComboList != null && statusComboList.Any())
			{

				return (from x in statusComboList
						where
							x.DecisionSourceStatusCode != null &&
							x.DecisionSourceStatusCode.Equals(decisionSourceStatusCode, StringComparison.InvariantCultureIgnoreCase) &&
							x.PipelineSource != null && x.PipelineSource.Equals(pipelineSource, StringComparison.InvariantCultureIgnoreCase) &&
							x.PipelineStage != null && x.PipelineStage.Equals(pipelineStage, StringComparison.InvariantCultureIgnoreCase) &&
							x.Active
						select x).FirstOrDefault();
			}
			return null;
		}

		/// <summary>
		/// This method sends success notifications
		/// </summary>
		/// <param name="utility"></param>
		[ExcludeFromCodeCoverage]
		private void SuccessNotification(Utility utility)
		{
			if (_retryCount > 0)
			{
				var subject = $"Banzai.Pipeline - InvoiceStatusCombosLookup strategy for MessageID {PipelineMessageID} lookup success notification";
				var body =
					$"Banzai.Pipeline - InvoiceStatusCombosLookup strategy successful after {_retryCount} attempts.<br /><br />" +
					$"CacheKey: {_guid}<br /><br />";

				if (!string.IsNullOrEmpty(PipelineMessageID))
					body += $"Incoming Message ID {PipelineMessageID}<br /><br />";

				utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, body);

				_retryCount = 0; //Suppress the success notification
			}
		}
	}
}