using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.XMLManager;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public class MassStatusOverride : MessageProcessor
	{
		#region MemberVariables
		private StatusCombo _banzaiStatus;
		private List<StatusCombo> _statusCombos;
		private const string STATUS_OVERRIDE = "StatusOverride";
		private const string STATUS_OVERRIDE_MESSAGE = "Status Override Mass Upload";
        #endregion

        /// <summary>
        /// Constructor to initialize global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassStatusOverride(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
			IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) :
			base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue)
		{		
        }

        /// <summary>
        /// This method processes message from StatusOverride and pipelinesource Channel.
        /// </summary>
        /// <param name="message">UI#BanzaiMassUpload_Template#1/4/2018 1:20:07 AM(UTC)</param>
        /// <returns>true/false -processing completed/not completed</returns>
       
		public bool Process(XDocument message)
		{
			_logger.LogDebug($"Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusOverride - {message}");
			
			try
			{
				var invoiceNoBuidList = DocId?.Split(",");
				if (invoiceNoBuidList == null || invoiceNoBuidList.Length < 1)
					return true;

				var fileAttributes = XmlHelper.GetXPathValue(message?.Root, "FileAttributes").Split('#');
				var messageType = XmlHelper.GetXPathValue(message?.Root, "MessageType");
				DataTable[] auditTable = { StatusOverrideAuditTableSetup() };
				_statusCombos = _dataContext.StatusCombos.GetAll().ToList();
				Array.ForEach(invoiceNoBuidList, invoiceNoBuid =>
				{
					if (string.IsNullOrEmpty(invoiceNoBuid)) return;

					var auditRow = auditTable[0].NewRow();
					StatusOverrideUser(invoiceNoBuid, ref auditRow, fileAttributes.ElementAt(0));

					auditTable[0].Rows.Add(auditRow);
				});

				if (STATUS_OVERRIDE.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
				{
					var attachment = new System.Net.Mail.Attachment(GenerateAuditReport(auditTable[0], "StatusOverride_MassUploadAuditReport"), $"StatusOverride_MassUploadAuditReport_{fileAttributes.ElementAt(1)}_{fileAttributes.ElementAt(2)}.xlsx", "application/vnd.ms-excel");

					SendEmail("Banzai StatusOverride Mass Upload Completed", attachment, $"Please find attached the Audit log for the Status Override Mass Upload performed at {fileAttributes.ElementAt(2)} for input file - {fileAttributes.ElementAt(1)} ", fileAttributes.ElementAt(3));
				}

				_logger.LogDebug("Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusOverride");
			}
			catch (Exception ex)
			{
				_logger.LogError($"Error in Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusOverride Processor. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
			}

			return true;
		}

		/// <summary>
		/// Initializing Audit trail table
		/// </summary>
		private static DataTable StatusOverrideAuditTableSetup()
		{
			var auditTable = new DataTable();
            auditTable.Columns.Add("PipeLine Source", typeof(string));
            auditTable.Columns.Add("Pipeline Stage", typeof(string));
            auditTable.Columns.Add("ID", typeof(string));
            auditTable.Columns.Add("Buid", typeof(string));
            auditTable.Columns.Add("Vendor ID", typeof(string));
            auditTable.Columns.Add("Current Status", typeof(string));
            auditTable.Columns.Add("Status Override", typeof(string));
            auditTable.Columns.Add("Note", typeof(string));
            auditTable.Columns.Add("Audit Status", typeof(string));
            auditTable.Columns.Add("Error", typeof(string));

            return auditTable;
		}

		/// <summary>
		/// Overriding each Order/Invoice
		/// Validating input, executing business rules
		/// </summary>
		/// <param name="input">DPID</param>
		/// <param name="auditRow">Audit Row</param>
		/// <param name="user">Login or requested user for audit trail update</param>
		private void StatusOverrideUser(string input, ref DataRow auditRow, string user)
		{
            var id = input?.Split(":");
            UpdateAuditRow(ref auditRow, string.Empty, string.Empty);
            var statusOverrideDto = new UpdateStatusOverrideDto()
            {
                PipelineSource = id?[0],
                PipelineStage = id?[1],
                Id = id?[2],
                CurrentStatus = id?[3],
                BanzaiStatusOverrideCode = id?[4],
                Note = id?[5],
                BuId = id?[6],
                VendorId = id?[7],
				UserLastModifiedBy = user
            };

            // Initialize default values.
            auditRow["Pipeline Source"] = $"{statusOverrideDto.PipelineSource}";
            auditRow["Pipeline Stage"] = $"{statusOverrideDto.PipelineStage}";
            auditRow["ID"] = $"{statusOverrideDto.Id}";
            auditRow["Current Status"] = $"{statusOverrideDto.CurrentStatus}";
            auditRow["Status Override"] = $"{statusOverrideDto.BanzaiStatusOverrideCode}";
            auditRow["Note"] = $"{statusOverrideDto.Note}";
            auditRow["Buid"] = $"{statusOverrideDto.BuId}";
            auditRow["Vendor ID"] = $"{statusOverrideDto.VendorId}";

            List<string> statusCombos = GetBanzaiStatusForUserOverride(statusOverrideDto.PipelineStage);

            try
            {
                (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) = ValidateInput(statusOverrideDto, ref auditRow);

                if (!isProceed)
                    return;

                var docBeforeUpdateStatus = string.Empty;

                if (statusOverrideDto.PipelineStage.Equals("INVOICE", StringComparison.InvariantCultureIgnoreCase))
                {
                    docBeforeUpdateStatus = (from invoice in docBeforeUpdate?.InvoiceStage?.Invoices
                                             where invoice != null &&
                                             invoice.InvoiceNo.ToUpper() == statusOverrideDto.Id.ToUpper()
                                             select invoice.Status).FirstOrDefault().BanzaiStatusCode ?? string.Empty;
                }                

                if (!string.IsNullOrEmpty(docBeforeUpdateStatus) &&
                    !docBeforeUpdateStatus.Equals(statusOverrideDto.CurrentStatus))
                {
                    UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, " +
                        "Stage, ID, and Current Status");
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                    return;
                }
                if (string.IsNullOrEmpty(statusOverrideDto.CurrentStatus) || !statusCombos.Contains(statusOverrideDto.CurrentStatus))
                {
                    UpdateAuditRow(ref auditRow, "Not Found", "Current Status not found on Banzai Status Combo where Active and UserOverride = True");
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                    return;
                }
                if (string.IsNullOrEmpty(statusOverrideDto.BanzaiStatusOverrideCode) || !statusCombos.Contains(statusOverrideDto.BanzaiStatusOverrideCode))
                {
                    UpdateAuditRow(ref auditRow, "Not Found", "Status Override not found on Banzai Status Combo where Active and UserOverride = True");
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                    return;
                }

                _banzaiStatus = GetBanzaiStatus(statusOverrideDto.PipelineSource, statusOverrideDto.PipelineStage, statusOverrideDto.BanzaiStatusOverrideCode);

                if (!EnrichedRequestStatusOverride(statusOverrideDto, user, docBeforeUpdate))
                {
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);

                    UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, " +
                        "Stage, ID, and Current Status");

                    _logger.LogCritical($"OverrideBanzaiStatus({id}) - Error updating enriched document for revision {docBeforeUpdate.Revision}");

                    return;
                }

                UpdateAuditRow(ref auditRow, "Found", string.Empty);

                _rabbitMQueuePublisher.Publish(docBeforeUpdate.Id, _rollupRequestsQueue.QueueName);

                return;
            }
            catch (Exception e)
            {
                UpdateAuditRow(ref auditRow, "Not Found", e.Message);

                _logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusOverride Banzai status Error for {statusOverrideDto.PipelineStage}: {statusOverrideDto.Id}. " +
                    $"{e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }

        /// <summary>
        /// This method gets status combo for given pipelinestage
        /// </summary>
        /// <param name="pipelineStage"></param>
        /// <returns></returns>
        private List<string> GetBanzaiStatusForUserOverride(string pipelineStage)
        {
            List<string> statusCombos;
            statusCombos = _statusCombos.Any() ?
                (from x in _statusCombos
                 where
                 x.PipelineSource != null && x.PipelineSource.ToUpper().Equals("CHANNEL") &&
                 x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(pipelineStage?.ToUpper()) &&
                 x.UserOverride && x.Active
                 select x.BanzaiStatusCode).ToList() : null;
            return statusCombos;
        }

        /// <summary>
        /// This method validates input for status override
        /// </summary>
        /// <param name="statusOverrideDto"></param>
        /// <param name="auditRow"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) ValidateInput(UpdateStatusOverrideDto statusOverrideDto,
            ref DataRow auditRow)
        {
            if (string.IsNullOrEmpty(statusOverrideDto.PipelineSource)
               || string.IsNullOrEmpty(statusOverrideDto.PipelineStage)
               || string.IsNullOrEmpty(statusOverrideDto.Id)
               || string.IsNullOrEmpty(statusOverrideDto.BuId)
               || string.IsNullOrEmpty(statusOverrideDto.CurrentStatus)
               || string.IsNullOrEmpty(statusOverrideDto.BanzaiStatusOverrideCode))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusOverrideDto.PipelineSource) || statusOverrideDto.PipelineSource != "CHANNEL")
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Pipeline Source Cell is not CHANNEL");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusOverrideDto.PipelineStage)
                || !new List<string>() { "INVOICE", "ORDER", "VOR" }.Contains(statusOverrideDto.PipelineStage))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Pipeline Stage is invalid");
                return (false, null);
            }
            if (statusOverrideDto.PipelineSource.Equals("CHANNEL", StringComparison.InvariantCultureIgnoreCase) && 
                    string.IsNullOrEmpty(statusOverrideDto.VendorId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }

            var docBeforeUpdate = LockPipelineEnrichedRequest(statusOverrideDto);

            if (docBeforeUpdate == null)
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                return (false, null);
            }

            return (true, docBeforeUpdate);
        }

        /// <summary>
        /// This method removes lock on EnrichedRequests for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockPipelineEnrichedRequest(string id)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var filter = builder.Eq(u => u.Id, id)
						 & builder.Eq(u => u.IsLocked, true);

			_dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
		}

		/// <summary>
		/// This method overrides status for EnrichedRequests/Invoice Enriched Requests collection
		/// </summary>
		/// <param name="statusOverrideDto"></param>
		/// <param name="user"></param>
		/// <param name="docBeforeUpdate"></param>
		/// <returns></returns>
		private bool EnrichedRequestStatusOverride(UpdateStatusOverrideDto statusOverrideDto, string user, PipelineEnrichedRequest docBeforeUpdate)
		{
			var docAfterUpdate = new PipelineEnrichedRequest();
			if (statusOverrideDto.PipelineStage.ToUpper().Equals("INVOICE", StringComparison.InvariantCultureIgnoreCase))
				docAfterUpdate = OverrideInvoiceStatus(statusOverrideDto, docBeforeUpdate);

			if (docAfterUpdate != null)
			{
				docAfterUpdate.IsLocked = false;
				docAfterUpdate.Revision++;
				docAfterUpdate.Common.UserLastModifiedDate = DateTime.UtcNow;
				docAfterUpdate.Common.UserLastModifiedBy = user;

				return SaveEnrichedRequest(docAfterUpdate);
			}
			return false;
		}

		/// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="invoiceEnrichedRequest"></param>
		/// <returns></returns>
		private bool SaveEnrichedRequest(PipelineEnrichedRequest invoiceEnrichedRequest)
		{
			if (invoiceEnrichedRequest == null) return false;

			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var updateFilter = builder.Eq(u => u.Id, invoiceEnrichedRequest.Id);

			_dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(updateFilter, invoiceEnrichedRequest);

			return true;
		}

		/// <summary>
		/// This method overrides invoice status
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="invoiceEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest OverrideInvoiceStatus(UpdateStatusOverrideDto statusOverrideDto, PipelineEnrichedRequest invoiceEnrichedRequest)
		{
			var invoice = invoiceEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo.ToUpper() == statusOverrideDto.Id.ToUpper());

            if (invoice == null)
				return null;

			var previousStatus = invoice.Clone() is Library.Entities.Invoice ? (invoice.Clone() as Library.Entities.Invoice).Status : new Status();
            if (_banzaiStatus != null)
			{
				invoice.Status.BanzaiStatusCode = _banzaiStatus.BanzaiStatusCode;
				invoice.Status.BanzaiStatusSequence = _banzaiStatus.BanzaiStatusSequence;
				invoice.Status.BanzaiUnbookedExposureFlag = _banzaiStatus.BanzaiUnbookedExposureFlag;
				invoiceEnrichedRequest.BanzaiStatusInSync = "Pass";
			}
			else
			{
				invoiceEnrichedRequest.BanzaiStatusInSync = "Fail";
				return invoiceEnrichedRequest;
			}
			//update current invoice status
			invoice.Status.BanzaiStatusCreateDateTime = DateTime.UtcNow;
			invoice.Status.DecisionSource = statusOverrideDto.UserLastModifiedBy;
			invoice.Status.DecisionSourceStatusCode = null;
			invoice.Status.DecisionSourceDateTime = DateTime.UtcNow;
			invoice.Status.SourceStatusCode = null;
			invoice.Status.SourceStatusCodeDateTime = null;
			invoice.Status.MessageType = STATUS_OVERRIDE_MESSAGE;
			invoice.Status.MessageID = null;
			invoice.Status.MessageSourceDateTime = null;
			invoice.Status.MessageReceivedDateTime = null;
			invoice.Status.LatentTransaction = false;
			invoice.Status.Note = statusOverrideDto.Note;

			//update status history		
			invoice.StatusHistory ??= new List<Status>();
			invoice.StatusHistory.Add(previousStatus);

			return invoiceEnrichedRequest;
		}

		/// <summary>
		/// This method applies lock on EnrichedRequests for given ID
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest LockPipelineEnrichedRequest(UpdateStatusOverrideDto statusOverrideDto)
		{
			var invoiceEnrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
			FilterDefinition<PipelineEnrichedRequest> filter = null;
			filter = invoiceEnrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo.ToUpper() == statusOverrideDto.Id.ToUpper());
			filter &= invoiceEnrichedRequestBuilder.Eq(x => x.IsLocked, false);

            if (!string.IsNullOrEmpty(statusOverrideDto.BuId))
				filter &= invoiceEnrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, statusOverrideDto.BuId);

            if (!string.IsNullOrEmpty(statusOverrideDto.VendorId))
                filter &= invoiceEnrichedRequestBuilder.Eq(x => x.Common.VendorId, statusOverrideDto.VendorId);

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
					Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
					ReturnDocument.Before);

			return result;
		}

		/// <summary>
		/// Generic function to update audit rows
		/// </summary>
		private void UpdateAuditRow(ref DataRow auditRow, string status, string remarks)
		{
			auditRow["Audit Status"] = status;
			auditRow["Error"] = remarks;
		}

		/// <summary>
		/// This method searches status combo repository for a given override info
		/// </summary>
		/// <param name="statusOverrideInfo"></param>
		/// <returns></returns>
		private StatusCombo GetBanzaiStatus(string pipelineSource, string stage, string statusOverride)
		{
			return _statusCombos.Any() ?
				(from x in _statusCombos
				 where
				 x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusOverride?.ToUpper()) &&
				 x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(pipelineSource?.ToUpper()) &&
				 x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(stage?.ToUpper()) &&
				 x.Active
				 select x).FirstOrDefault() : null;
		}
	}
}
