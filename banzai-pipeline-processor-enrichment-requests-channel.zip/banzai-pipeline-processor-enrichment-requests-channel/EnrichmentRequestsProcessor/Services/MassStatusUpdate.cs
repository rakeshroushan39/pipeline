﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.XMLManager;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
	public class MassStatusUpdate : MessageProcessor
	{
		#region MemberVariables
		private StatusCombo _banzaiStatus;
		private List<StatusCombo> _statusCombos;
		private bool _banzaiCurrentCode;
		private bool _banzaiStatusUpdate;
		private bool _isLatent;
		private const string STATUS_UPDATE = "StatusUpdate";
		private const string STATUS_UPDATE_MESSAGE = "Banzai Status Update Mass Upload";
        #endregion

        /// <summary>
        /// Constructor to initialize global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassStatusUpdate(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
			IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) :
			base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue)
        {		
        }

		/// <summary>
		/// This method processes message from StatusUpdate.
		/// </summary>
		/// <param name="message">UI#BanzaiMassUpload_Template#1/4/2018 1:20:07 AM(UTC)</param>
		/// <returns>true/false - processing completed/not completed</returns>
		
		public bool Process(XDocument message)
		{
			_logger.LogDebug($"Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusUpdate - {message}");
			
			try
			{
				var invoiceNoBuidList = DocId?.Split(",");
				if (invoiceNoBuidList == null || invoiceNoBuidList.Length < 1)
					return true;
				var fileAttributes = XmlHelper.GetXPathValue(message?.Root, "FileAttributes").Split('#');
				var messageType = XmlHelper.GetXPathValue(message?.Root, "MessageType");
				
				DataTable[] auditTable = { StatusCodeUpdateAuditTableSetup() };
				_statusCombos = _dataContext.StatusCombos.GetAll().ToList();
				Array.ForEach(invoiceNoBuidList, invoiceNoBuid =>
				{
					if (string.IsNullOrEmpty(invoiceNoBuid)) return;

					var auditRow = auditTable[0].NewRow();

					if (STATUS_UPDATE.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
						StatusCodeUpdate(invoiceNoBuid, ref auditRow, fileAttributes.ElementAt(0));
					auditTable[0].Rows.Add(auditRow);
				});

				if (STATUS_UPDATE.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
				{
					var attachment = new System.Net.Mail.Attachment(GenerateAuditReport(auditTable[0], "StatusCodeUpdate_MassUploadAuditReport"), $"StatusCodeUpdate_MassUploadAuditReport_{fileAttributes.ElementAt(1)}_{fileAttributes.ElementAt(2)}.xlsx", "application/vnd.ms-excel");

					SendEmail("Banzai Status Code Update Mass Upload Completed", attachment, $"Please find attached the Audit log for the Status Code Update Mass Upload performed at {fileAttributes.ElementAt(2)} for input file - {fileAttributes.ElementAt(1)} ", fileAttributes.ElementAt(3));
				}

				_logger.LogDebug("Exited Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusUpdate");
			}
			catch (Exception ex)
			{
				_logger.LogError($"Error in Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusUpdate Processor. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
			}
			return true;
		}

		/// <summary>
		/// This method applies locks on InvoiceEnrichedRequests for given ID
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest LockPipelineEnrichedRequest(UpdateStatusOverrideDto statusUpdateDto)
		{
			var invoiceEnrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
			FilterDefinition<PipelineEnrichedRequest> filter = null;
			filter = invoiceEnrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo.ToUpper() == statusUpdateDto.Id.ToUpper());
			filter &= invoiceEnrichedRequestBuilder.Eq(x => x.IsLocked, false);

			if (!string.IsNullOrEmpty(statusUpdateDto.BuId))
				filter &= invoiceEnrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, statusUpdateDto.BuId);

            if (!string.IsNullOrEmpty(statusUpdateDto.VendorId))
                filter &= invoiceEnrichedRequestBuilder.Eq(x => x.Common.VendorId, statusUpdateDto.VendorId);

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
						Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
						ReturnDocument.Before);
			return result;

		}

		/// <summary>
		/// This method applies status code update
		/// </summary>
		/// <param name="id"></param>
		/// <param DataRow="auditRow"></param>
		/// <param string="User"></param>
		/// <returns></returns>
		
		private void StatusCodeUpdate(string input, ref DataRow auditRow, string user)
		{
			var id = input?.Split(":");
			var statusUpdateDto = new UpdateStatusOverrideDto()
			{
				PipelineSource = id?[0],
				PipelineStage = id?[1],
				Id = id?[2],
				CurrentStatus = id?[3],
				BanzaiStatusOverrideCode = id?[4],
				Note = id?[5],
				BuId = id?[6],
                VendorId = id?[7],
				UserLastModifiedBy = user
            };
			// Initialize default values
			auditRow["Pipeline Source"] = $"{statusUpdateDto.PipelineSource}";
			auditRow["Pipeline Stage"] = $"{statusUpdateDto.PipelineStage}";
			auditRow["ID"] = $"{statusUpdateDto.Id}";
			auditRow["Current Status"] = $"{statusUpdateDto.CurrentStatus}";
			auditRow["Status Code Update"] = $"{statusUpdateDto.BanzaiStatusOverrideCode}";
			auditRow["Note"] = $"{statusUpdateDto.Note}";
			auditRow["Buid"] = $"{statusUpdateDto.BuId}";
            auditRow["Vendor ID"] = $"{statusUpdateDto.VendorId}";
            GetStatusValidation(statusUpdateDto);
			try
			{
                (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) = ValidateInput(statusUpdateDto, ref auditRow);

                if (!isProceed)
                    return;

                if (!string.IsNullOrEmpty(statusUpdateDto.CurrentStatus) && !string.IsNullOrEmpty(statusUpdateDto.BanzaiStatusOverrideCode))
				{
					_banzaiStatus = GetBanzaiStatus(statusUpdateDto);
				}
				if (!InvoiceEnrichedRequestStatusUpdate(statusUpdateDto, user, docBeforeUpdate))
				{
					UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);

					UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, Stage, ID, and Current Status");
					_logger.LogCritical($"BanzaiStatusCodeUpdate({id}) - Error updating enriched document for revision {docBeforeUpdate.Revision}");
					return;
				}
				if (_isLatent)
				{
					UpdateAuditRow(ref auditRow, "Not Found", "Record is Latent");
					return;
				}
				UpdateAuditRow(ref auditRow, "Found", string.Empty);

                _rabbitMQueuePublisher.Publish(docBeforeUpdate.Id, _rollupRequestsQueue.QueueName);
				return;
			}
			catch (Exception e)
			{
				_logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassStatusUpdate status code update Error for {statusUpdateDto.PipelineStage}: {statusUpdateDto.Id}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
			}
		}

        /// <summary>
        /// This method validates input for status update
        /// </summary>
        /// <param name="statusUpdateDto"></param>
        /// <param name="auditRow"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) ValidateInput(UpdateStatusOverrideDto statusUpdateDto,
            ref DataRow auditRow)
        {
            if (string.IsNullOrEmpty(statusUpdateDto.PipelineSource)
                    || string.IsNullOrEmpty(statusUpdateDto.PipelineStage)
                    || string.IsNullOrEmpty(statusUpdateDto.Id)
                    || string.IsNullOrEmpty(statusUpdateDto.CurrentStatus)
                    || string.IsNullOrEmpty(statusUpdateDto.BanzaiStatusOverrideCode))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.Id))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.PipelineSource) || statusUpdateDto.PipelineSource != "CHANNEL")
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Pipeline Source Cell is not CHANNEL");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.PipelineStage)
                || !new List<string>() { "INVOICE", "ORDER", "VOR" }.Contains(statusUpdateDto.PipelineStage))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Pipeline Stage is invalid");
                return (false, null);
            }
            if (statusUpdateDto.PipelineSource.Equals("CHANNEL", StringComparison.InvariantCultureIgnoreCase) &&
                string.IsNullOrEmpty(statusUpdateDto.VendorId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }

            var docBeforeUpdate = LockPipelineEnrichedRequest(statusUpdateDto);
            if (docBeforeUpdate == null)
            {
                _logger.LogWarning($"UpdateBanzaiStatus - Record is locked or not found in InvoiceEnrichedRequests collection.");
                UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                return (false, null);
            }
            if (GetCurrentStatusCodeValidation(statusUpdateDto, docBeforeUpdate))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, Stage, ID, and Current Status");
                UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.CurrentStatus) || !_banzaiCurrentCode )
            {
                UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                UpdateAuditRow(ref auditRow, "Not Found", "Current Status not found on Banzai Status Combo where Active and UserUpdateCurrent = True");
                return (false, null);
            }
            else if (string.IsNullOrEmpty(statusUpdateDto.BanzaiStatusOverrideCode) || !_banzaiStatusUpdate)
            {
                UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                UpdateAuditRow(ref auditRow, "Not Found", "Status Update not found on Banzai Status Combo where Active and UserUpdateFuture = True");
                return (false, null);
            }

            return (true, docBeforeUpdate);
        }

        /// <summary>
        /// Generic function to update audit rows
        /// </summary>
        private void UpdateAuditRow(ref DataRow auditRow, string status, string remarks)
		{
			auditRow["Audit Status"] = status;
			auditRow["Error"] = remarks;
		}

		/// <summary>
		/// This method Get Status Code Validation using Status combos collections
		/// </summary>
		/// <param name="statusUpdateDto"></param>		
		/// <returns></returns>
		private void GetStatusValidation(UpdateStatusOverrideDto statusUpdateDto)
		{
			_banzaiStatusUpdate = false;
			_banzaiCurrentCode = false;
			if (statusUpdateDto.CurrentStatus != null)
			{
				var statusValidation = (from x in _statusCombos
										where
										x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusUpdateDto.CurrentStatus?.ToUpper()) &&
										x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(statusUpdateDto.PipelineSource?.ToUpper()) &&
										x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(statusUpdateDto.PipelineStage?.ToUpper()) &&
										x.Active &&
										x.UserUpdateCurrent
										select x.UserUpdateCurrent)?.FirstOrDefault();
				_banzaiCurrentCode = Convert.ToBoolean(statusValidation);
			}
			if (statusUpdateDto.BanzaiStatusOverrideCode != null)
			{
				var statusValidation = (from x in _statusCombos
										where
										x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusUpdateDto.BanzaiStatusOverrideCode?.ToUpper()) &&
										x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(statusUpdateDto.PipelineSource?.ToUpper()) &&
										x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(statusUpdateDto.PipelineStage?.ToUpper()) &&
										x.Active &&
										x.UserUpdateFuture
										select x.UserUpdateFuture)?.FirstOrDefault();
				_banzaiStatusUpdate = Convert.ToBoolean(statusValidation);
			}
		}

		/// <summary>
		/// This method removes lock on InvoiceEnrichedRequests for given ID
		/// </summary>
		/// <param name="id"></param>
		private void UnlockPipelineEnrichedRequest(string id)
		{
			var builder = Builders<PipelineEnrichedRequest>.Filter;
			var filter = builder.Eq(u => u.Id, id)
						 & builder.Eq(u => u.IsLocked, true);

			_dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));

		}

		/// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="docBeforeUpdate"></param>
		/// <returns></returns>
		private bool InvoiceEnrichedRequestStatusUpdate(UpdateStatusOverrideDto statusUpdateDto, string user, PipelineEnrichedRequest docBeforeUpdate)
		{
			var docAfterUpdate = new PipelineEnrichedRequest();
			if (statusUpdateDto.PipelineStage.ToUpper().Equals("INVOICE", StringComparison.InvariantCultureIgnoreCase))
				docAfterUpdate = StatusUpdateInvoice(statusUpdateDto, docBeforeUpdate);

			if (docAfterUpdate != null)
			{
				docAfterUpdate.IsLocked = false;
				docAfterUpdate.Revision++;
				docAfterUpdate.Common.UserLastModifiedDate = DateTime.UtcNow;
				docAfterUpdate.Common.UserLastModifiedBy = user;
				return SaveInvoiceEnrichedRequest(docAfterUpdate);
			}

			return false;
		}

		/// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="invoiceEnrichedRequest"></param>
		/// <returns></returns>
		private bool SaveInvoiceEnrichedRequest(PipelineEnrichedRequest invoiceEnrichedRequest)
		{
			if (invoiceEnrichedRequest == null) return false;
			var builder = Builders<PipelineEnrichedRequest>.Filter;
			var updateFilter = builder.Eq(u => u.Id, invoiceEnrichedRequest.Id);
			_dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(updateFilter, invoiceEnrichedRequest);
			return true;
		}

		/// <summary>
		/// This method status update for invoice
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="invoiceEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest StatusUpdateInvoice(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest invoiceEnrichedRequest)
		{
			Library.Entities.Invoice invoice = invoiceEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo.ToUpper() == statusUpdateDto.Id.ToUpper());
			if (invoice == null)
				return null;

			var previousStatus = invoice.Clone() is Library.Entities.Invoice ? (invoice.Clone() as Library.Entities.Invoice).Status : new Status();
			var newStatus = CreateNewStatusRecordInvoice(statusUpdateDto);
			if (newStatus == null)
			{
				return null;
			}

			invoiceEnrichedRequest.BanzaiStatusInSync = "Pass";
			invoice.StatusHistory ??= new List<Status>();

			if (newStatus.BanzaiStatusSequence < invoice?.Status?.BanzaiStatusSequence)
			{
				newStatus.LatentTransaction = true;
				invoice.StatusHistory.Add(newStatus);
				_isLatent = true;
			}
			else
			{
				invoice.StatusHistory.Add(previousStatus);
				invoice.Status = newStatus;
			}
			return invoiceEnrichedRequest;
		}

		/// <summary>
		/// This method searches status combo repository for a given status update future
		/// </summary>
		/// <param name="statusUpdateFutureInfo"></param>
		/// <returns></returns>
		private StatusCombo GetBanzaiStatus(UpdateStatusOverrideDto statusOverrideInfo)
		{
			_banzaiStatus = null;

			return _statusCombos.Any() ?
			(from x in _statusCombos
			 where
			 x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals(statusOverrideInfo.BanzaiStatusOverrideCode?.ToUpper()) &&
			 x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(statusOverrideInfo.PipelineSource?.ToUpper()) &&
			 x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(statusOverrideInfo.PipelineStage?.ToUpper()) &&
			 x.Active &&
			 x.UserUpdateFuture
			 select x).FirstOrDefault() : null;
		}

		/// <summary>
		/// This method implements the Current Status availabity in respective collection
		/// </summary>
		/// <param name="statusUpdateDto"></param>		
		/// <returns></returns>
		private bool GetCurrentStatusCodeValidation(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest docBeforeUpdate)
		{
			var docBeforeUpdateStatus = string.Empty;

			if (statusUpdateDto.PipelineStage.Equals("INVOICE", StringComparison.InvariantCultureIgnoreCase))
			{
				docBeforeUpdateStatus = (from invoice in docBeforeUpdate?.InvoiceStage?.Invoices
										 where invoice != null &&
										 invoice.InvoiceNo.ToUpper() == statusUpdateDto.Id.ToUpper()
										 select invoice.Status).FirstOrDefault().BanzaiStatusCode ?? string.Empty;
			}

			if (string.IsNullOrEmpty(docBeforeUpdateStatus) || docBeforeUpdateStatus != statusUpdateDto.CurrentStatus)
				return true;

			return false;
		}

		/// <summary>
		/// Initializing Audit trail table
		/// </summary>
		private static DataTable StatusCodeUpdateAuditTableSetup()
		{
			var auditTable = new DataTable();
            auditTable.Columns.Add("PipeLine Source", typeof(string));
            auditTable.Columns.Add("Pipeline Stage", typeof(string));
            auditTable.Columns.Add("ID", typeof(string));
            auditTable.Columns.Add("Buid", typeof(string));
            auditTable.Columns.Add("Vendor ID", typeof(string));
            auditTable.Columns.Add("Current Status", typeof(string));
            auditTable.Columns.Add("Status Code Update", typeof(string));
            auditTable.Columns.Add("Note", typeof(string));
            auditTable.Columns.Add("Audit Status", typeof(string));
            auditTable.Columns.Add("Error", typeof(string));

            return auditTable;
		}

		/// <summary>
		/// This method Creates New Status Record Invoice
		/// </summary>
		/// <param name="statusUpdateDto"></param>		
		/// <returns></returns>
		private Status CreateNewStatusRecordInvoice(UpdateStatusOverrideDto statusUpdateDto)
		{
			var newStatus = new Status
			{
				BanzaiStatusCreateDateTime = DateTime.UtcNow,
				DecisionSource = statusUpdateDto.UserLastModifiedBy,
				DecisionSourceStatusCode = null,
				DecisionSourceDateTime = DateTime.UtcNow,
				SourceStatusCode = null,
				SourceStatusCodeDateTime = null,
				MessageType = STATUS_UPDATE_MESSAGE,
				MessageID = null,
				MessageSourceDateTime = null,
				MessageReceivedDateTime = null,
				Note = statusUpdateDto.Note,
				BanzaiStatusCode = _banzaiStatus.BanzaiStatusCode,
				BanzaiStatusSequence = _banzaiStatus.BanzaiStatusSequence,
				BanzaiUnbookedExposureFlag = _banzaiStatus.BanzaiUnbookedExposureFlag,
				LatentTransaction = false
			};

			return newStatus;
		}
	}
}
