using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.XMLManager;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using Novell.Directory.Ldap;
using Novell.Directory.Ldap.Controls;
using System.Text;
using System.Collections;
using DFS.Banzai.Pipeline.Library.Entities;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
   public class MassDfsOpsRepUpdate : MessageProcessor
    {
        #region MemberVariables
        private string _loginUserID = string.Empty;
        private string[] _fileAttributes;
        private string _fullname = string.Empty;
        #endregion

        /// <summary>
        /// Constructor to initialize Global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassDfsOpsRepUpdate(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) :
            base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue)
        {
        }
        
        /// <summary>
        /// This method gets triggered when message arrives in PipelineEnrichedRequests Queue.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool Process(XDocument message)
        {
            _logger.LogDebug($"Entered Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassDFSOpsRepUpdate - {message}");
            return ProcessMassDFSOpsRepUpdate(message);
        }

        /// <summary>
		/// Processes Mass DFS Ops repo information by performing active directpory search
		/// </summary>
        /// <param name="message"></param>
		/// <returns>Boolean - Success/True , Failure/False</returns>
        private bool ProcessMassDFSOpsRepUpdate(XDocument message)
        {
            DataRow auditRow = null;
            _fileAttributes = XmlHelper.GetXPathValue(message?.Root, "FileAttributes").Split('#');

            try
            {
                var DFSOpsRep = DocId?.Split(",");

                if (DFSOpsRep != null && DFSOpsRep.Length > 0)
                {
                    DataTable[] auditTable = { MassDFSOpsRepUpdateAuditTableSetup() };

                    _loginUserID = _fileAttributes.ElementAt(0);

                    Array.ForEach(DFSOpsRep, objDFSOpsRep =>
                    {
                        auditRow = auditTable[0].NewRow();
                        EnrichAndSave(objDFSOpsRep, ref auditRow);
                        auditTable[0].Rows.Add(auditRow);
                    });

                    PrepareEmail(auditTable[0]);
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Error in Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassDFSOpsRepUpdate Mass upload processing - {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }

            return true;
        }

        /// <summary>
        /// Initializing Audit trail table
        /// </summary>
        private static DataTable MassDFSOpsRepUpdateAuditTableSetup()
        {
            var auditTable = new DataTable();
            auditTable.Columns.Add("Pipeline Source", typeof(string));
            auditTable.Columns.Add("Pipeline Stage", typeof(string));
            auditTable.Columns.Add("ID", typeof(string));
            auditTable.Columns.Add("BUID", typeof(string));
            auditTable.Columns.Add("Vendor ID", typeof(string));
            auditTable.Columns.Add("DFS Ops Rep Email", typeof(string));
            auditTable.Columns.Add("Audit Status", typeof(string));
            auditTable.Columns.Add("Error", typeof(string));
            return auditTable;
        }

        /// <summary>
        /// Initializing Audit Log table
        /// </summary>
        /// <param name="auditRow"></param>
        /// <param name="DFSOpsRepUpdateDto"></param>
        private void SetDFSOpsRepAuditlog(ref DataRow auditRow, ref UpdateStatusOverrideDto DFSOpsRepUpdateDto)
        {
            // Initialize default values
            auditRow["Pipeline Source"] = $"{DFSOpsRepUpdateDto.PipelineSource}";
            auditRow["Pipeline Stage"] = $"{DFSOpsRepUpdateDto.PipelineStage}";
            auditRow["ID"] = $"{DFSOpsRepUpdateDto.Id}";
            auditRow["Buid"] = $"{DFSOpsRepUpdateDto.BuId}";
            auditRow["Vendor ID"] = $"{DFSOpsRepUpdateDto.VendorId}";
            auditRow["DFS Ops Rep Email"] = $"{DFSOpsRepUpdateDto.CurrentStatus}";

        }

        /// <summary>
        /// This method sets DFSOpsRep audit log
        /// </summary>
        /// <param name="DFSOpsRep"></param>        
        private UpdateStatusOverrideDto SetDFSOpsRepUpdateDto(string DFSOpsRep)
        {
            var splitDFSOpsRep = DFSOpsRep?.Split(":");
            UpdateStatusOverrideDto DFSOpsRepUpdateDto = new UpdateStatusOverrideDto();
            DFSOpsRepUpdateDto.PipelineSource = "CHANNEL";
            DFSOpsRepUpdateDto.PipelineStage = splitDFSOpsRep?[0];
            DFSOpsRepUpdateDto.Id = splitDFSOpsRep?[1];
            DFSOpsRepUpdateDto.BuId = splitDFSOpsRep?[2];
            DFSOpsRepUpdateDto.VendorId = splitDFSOpsRep?[3];
            DFSOpsRepUpdateDto.CurrentStatus = splitDFSOpsRep?[4];
            DFSOpsRepUpdateDto.UserLastModifiedBy = _loginUserID;
            return DFSOpsRepUpdateDto;
        }

        /// <summary>
        /// This method enriches and audits
        /// </summary>
        /// <param name="DFSOpsRep"></param>
        /// <param name="auditTable"></param>
        private void EnrichAndSave(string DFSOpsRep, ref DataRow auditRow)
        {
            var DFSOpsRepUpdateDto = SetDFSOpsRepUpdateDto(DFSOpsRep);

            try
            {
                SetDFSOpsRepAuditlog(ref auditRow, ref DFSOpsRepUpdateDto);
                bool isProceed = ValidateInput(DFSOpsRepUpdateDto, ref auditRow);

                if (!isProceed)
                {
                    return;
                }
                else
                {
                    var objPipelineEnrichedRequest = LockPipelineEnrichedRequest(DFSOpsRepUpdateDto);
                    if (objPipelineEnrichedRequest == null)
                    {

                        UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                        return;
                    }
                    else
                    {
                        if (!EnrichedRequestUpdateDFSOpsRep(DFSOpsRepUpdateDto, objPipelineEnrichedRequest))
                        {
                            UnlockPipelineEnrichedRequest(objPipelineEnrichedRequest.Id);

                            UpdateAuditRow(ref auditRow, "Not Found", "Banzai Current Status Record NOT Found for the values entered in cells Pipeline Source, Stage, ID, and Current Status");

                            _logger.LogError($"BanzaiStatusCodeUpdate({DFSOpsRep}) - Error updating enriched document for revision {objPipelineEnrichedRequest.Revision}");
                        }
                        else
                        {
                            UpdateAuditRow(ref auditRow, "Found", string.Empty);
                        }
                        _rabbitMQueuePublisher.Publish(objPipelineEnrichedRequest.Id, _rollupRequestsQueue.QueueName);
                        return;

                    }

                }

            }
            catch (Exception e)
            {
                _logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassDFSOpsRepUpdate Banzai status code update Error for {DFSOpsRepUpdateDto.PipelineStage}: {DFSOpsRepUpdateDto.Id}. " +
                    $"{e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }

        /// <summary>
        /// This method validates input for status update
        /// </summary>
        /// <param name="DFSOpsRepUpdateDto"></param>
        /// <param name="auditRow"></param>
        /// <returns></returns>
        private bool ValidateInput(UpdateStatusOverrideDto DFSOpsRepUpdateDto, ref DataRow auditRow)
        {
            if (string.IsNullOrEmpty(DFSOpsRepUpdateDto.Id)
                    || string.IsNullOrEmpty(DFSOpsRepUpdateDto.BuId)
                    || string.IsNullOrEmpty(DFSOpsRepUpdateDto.PipelineStage)
                    || string.IsNullOrEmpty(DFSOpsRepUpdateDto.CurrentStatus)
                    || string.IsNullOrEmpty(DFSOpsRepUpdateDto.VendorId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return false;
            }
            if (DFSOpsRepUpdateDto.PipelineStage.ToUpper() != "VOR" && DFSOpsRepUpdateDto.PipelineStage.ToUpper() != "ORDER" && DFSOpsRepUpdateDto.PipelineStage.ToUpper() != "INVOICE")
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Pipeline Stage is not VOR/Order/Invoice");
                return false;
            }
           
            if (!ValidateemailRegEx(DFSOpsRepUpdateDto.CurrentStatus))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Invalid email address");
                return false;
            }
            if (string.IsNullOrEmpty(GetEmaildetailsfromAD(DFSOpsRepUpdateDto.CurrentStatus)))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Invalid email address");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Generic method to update audit rows
        /// </summary>
        /// <param name="auditRow"></param>
        /// <param name="status"></param>
        /// <param name="remarks"></param>
        private void UpdateAuditRow(ref DataRow auditRow, string status, string remarks)
        {
            auditRow["Audit Status"] = status;
            auditRow["Error"] = remarks;
        }

        /// <summary>
        /// Validate Email Format
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        private bool ValidateemailRegEx(string email)
        {
            var isValid = new System.ComponentModel.DataAnnotations.EmailAddressAttribute().IsValid(email);
            return isValid;

        }

        /// <summary>
        /// Validate EmailID and get First name and last name from AD
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        private string GetEmaildetailsfromAD(string email)
        {
            if (!string.IsNullOrEmpty(email))
            {
                _fullname = string.Empty;
                String searchFilter = "(&(objectClass=user)(mail=" + email + "))";
                string searchBase = "DC=amer,DC=dell,DC=com";
                string[] searchAttributes = new string[] { "mail", "sn", "givenname" };
                int searchScope = 2;
                string Validateemail = "";
                try
                {
                    using (var connection = new LdapConnection { SecureSocketLayer = true })
                    {
                        connection.Connect(_settings.LDAP_SERVER_AMER, LdapConnection.DefaultSslPort);
                        connection.Bind(_settings.SERVICE_ACCOUNT, _settings.SERVICE_ACCOUNT_PASS);
                        if (connection.Bound)
                        {
                            var result = connection.Search(searchBase, searchScope,
                               searchFilter,
                               searchAttributes,
                               false);
                            var user = result.Next();
                            if (user != null)
                            {
                                Validateemail = user.GetAttribute("mail").StringValue;
                                _fullname = user.GetAttribute("givenname").StringValue + " " + user.GetAttribute("sn").StringValue;
                            }
                        }
                        return Validateemail;
                    }

                }
                catch (Exception e)
                {
                    _logger.LogError($"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor.MassDFSOpsRepUpdate error at GetEmaildetailsfromAD - {e.Message}");
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// This method removes lock on PipelineEnrichedRequest for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockPipelineEnrichedRequest(string id)
        {
            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
        }

        /// <summary>
        /// This method applies locks on EnrichedRequests based on provided filter
        /// </summary>
        /// <param name="statusUpdateDto"></param>
        /// <returns></returns>
        private PipelineEnrichedRequest LockPipelineEnrichedRequest(UpdateStatusOverrideDto statusUpdateDto)
        {
            var enrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
            FilterDefinition<PipelineEnrichedRequest> filter = null;

            if (statusUpdateDto.PipelineStage.ToUpper() == "VOR")
            {
                filter = enrichedRequestBuilder.Eq(x => x.VorID, statusUpdateDto.Id);
            }
            else if (statusUpdateDto.PipelineStage.ToUpper() == "ORDER")
            {
                filter = enrichedRequestBuilder.ElemMatch(x => x.OrderStage.Orders, u => u.OrderNo == statusUpdateDto.Id);
            }
            else if (statusUpdateDto.PipelineStage.ToUpper() == "INVOICE")
            {
                filter = enrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo == statusUpdateDto.Id);
            }
            filter &= enrichedRequestBuilder.Eq(x => x.IsLocked, false);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, statusUpdateDto.BuId);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.PipelineSource, statusUpdateDto.PipelineSource);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.VendorId, statusUpdateDto.VendorId);

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
                    Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
                    ReturnDocument.Before);
            return result;
        }

        /// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="DFSOpsRepUpdateDto"></param>
		/// <param name="PipelineEnrichedRequest"></param>
		/// <returns></returns>
        private bool EnrichedRequestUpdateDFSOpsRep(UpdateStatusOverrideDto DFSOpsRepUpdateDto, PipelineEnrichedRequest PipelineEnrichedRequest)
        {

            if (PipelineEnrichedRequest != null)
            {
                if (!string.IsNullOrEmpty(PipelineEnrichedRequest.Common.DirectOpsRep) || !string.IsNullOrEmpty(PipelineEnrichedRequest.Common.DFSOpsRepName))
                {
                    PipelineEnrichedRequest.IsLocked = false;
                    PipelineEnrichedRequest.Revision++;
                    PipelineEnrichedRequest.Common.DirectOpsRep = DFSOpsRepUpdateDto.CurrentStatus;
                    PipelineEnrichedRequest.Common.DFSOpsRepName = _fullname;
                    PipelineEnrichedRequest.Common.DFSOpsRepOrphan = false;
                    return SaveEnrichedRequest(PipelineEnrichedRequest);
                }
                else
                {
                    PipelineEnrichedRequest.IsLocked = false;
                    PipelineEnrichedRequest.Revision++;
                    PipelineEnrichedRequest.Common.DFSOpsRepOrphan = true;
                    return SaveEnrichedRequest(PipelineEnrichedRequest);
                }
            }
            return false;
        }

        /// <summary>
        /// This method updates opportunity id
        /// </summary>
        /// <param name="DFSOpsRepUpdateDto"></param>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <returns></returns>


        /// <summary>
        /// This method saved document to enrichment store
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <returns></returns>
        private bool SaveEnrichedRequest(PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            if (pipelineEnrichedRequest == null) return false;

            pipelineEnrichedRequest.IsLocked = false;
            pipelineEnrichedRequest.Revision++;

            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var updateFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id);

            _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(updateFilter, pipelineEnrichedRequest);

            return true;
        }

        /// <summary>
        /// This method to prepare email format
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <returns></returns>
        private void PrepareEmail(DataTable auditTable)
        {
            if (auditTable != null && auditTable.Rows.Count > 0)
            {
                var attachment = new System.Net.Mail.Attachment(GenerateAuditReport(auditTable, "DFSOpsRep_MassUploadAuditReport"), $"DFSOpsRep_MassUploadAuditReport_{_fileAttributes.ElementAt(1)}_{_fileAttributes.ElementAt(2)}.xlsx", "application/vnd.ms-excel");
                SendEmail("Mass DFSOpsRep upload completed, please review audit Logs.", attachment, $"Please find attached the Audit log for the Mass DFSOpsRep upload performed at {_fileAttributes[2]} for input file - {_fileAttributes[1]}", _fileAttributes[3]);
            }
            else
            {
                SendEmail($"Mass DFSOpsRep upload process failed for the upload performed at {_fileAttributes[2]} for input file - {_fileAttributes[1]}.", null, "", _fileAttributes[3]);
            }
        }
    }
}
