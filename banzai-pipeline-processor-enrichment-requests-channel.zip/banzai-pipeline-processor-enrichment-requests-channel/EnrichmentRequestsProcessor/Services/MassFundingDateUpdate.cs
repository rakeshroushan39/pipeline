﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.Enrichments;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.XMLManager;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;


namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public sealed class MassFundingDateUpdate : MessageProcessor
    {
        #region MemberVariables
        private string _LastModifiedUser;
        private const string MassUpdate_FundingDate = "FundingDate";
        private const string STATUS_UPDATE_MESSAGE = "Funding Date Mass Upload";
        private StatusCombo _banzaiStatus;
        #endregion

        /// <summary>
        /// Constructor to initialize Global class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mailService"></param>
        /// <param name="dataContext"></param>
        /// <param name="queueRepository"></param>
        public MassFundingDateUpdate(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) : base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue)
        {

        }

        /// <summary>
        /// This method processes mass funding date updates
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool Process(XDocument message)
        {
            _logger.LogDebug($"Entered MassFundingDateUpdate - {message}");

            var messageType = string.Empty;
            try
            {
                var invoiceNoBuidVendorIdList = DocId?.Split(",");
                if (invoiceNoBuidVendorIdList == null || invoiceNoBuidVendorIdList.Length < 1)
                    return true;
                var fileAttributes = XmlHelper.GetXPathValue(message?.Root, "FileAttributes").Split('#');
                messageType = XmlHelper.GetXPathValue(message?.Root, "MessageType");
                DataTable[] auditTable = { MassFundingDateUpdateAuditTableSetup() };
                _LastModifiedUser = fileAttributes.ElementAt(0);
                Array.ForEach(invoiceNoBuidVendorIdList, invoiceNoBuidVedorId =>
                {
                    if (string.IsNullOrEmpty(invoiceNoBuidVedorId)) return;
                    var auditRow = auditTable[0].NewRow();
                    if (MassUpdate_FundingDate.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
                        UpdateFundingDate(invoiceNoBuidVedorId, ref auditRow, fileAttributes.ElementAt(0));
                    auditTable[0].Rows.Add(auditRow);
                });
                if (MassUpdate_FundingDate.Equals(messageType, StringComparison.InvariantCultureIgnoreCase))
                {
                    var attachment = new System.Net.Mail.Attachment(GenerateAuditReport(auditTable[0], "FundingDate_MassUploadAuditReport"), $"FundingDate_MassUploadAuditReport_Channel_{fileAttributes.ElementAt(1)}_{fileAttributes.ElementAt(2)}.xlsx", "application/vnd.ms-excel");
                    SendEmail("Channel Banzai Funding Date Update Mass Upload Completed", attachment, $"Please find attached the Audit log for the Funding Date Mass Upload performed at {fileAttributes.ElementAt(2)} for input file - {fileAttributes.ElementAt(1)} ", fileAttributes.ElementAt(3));
                }
                _logger.LogDebug("Exited DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.MassFundingDateUpdate");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in Channel MassFundingDateUpdate Processor. {ex.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
            return true;
        }

        /// <summary>
        /// Initializing Audit trail table
        /// </summary>
        private DataTable MassFundingDateUpdateAuditTableSetup()
        {
            var auditTable = new DataTable();
            auditTable.Columns.Add("PipeLine Source", typeof(string));
            auditTable.Columns.Add("Invoice", typeof(string));
            auditTable.Columns.Add("BUID", typeof(string));
            auditTable.Columns.Add("Vendor ID", typeof(string));
            auditTable.Columns.Add("Funding Date", typeof(string));
            auditTable.Columns.Add("Audit", typeof(string));
            auditTable.Columns.Add("Error", typeof(string));
            return auditTable;
        }

        /// <summary>
        /// This updates opporunity id
        /// </summary>
        /// <param name="input"></param>
        /// <param name="auditRow"></param>
        /// <param name="user"></param>
        private void UpdateFundingDate(string input, ref DataRow auditRow, string user)
        {
            var id = input?.Split(":");
            var fundingDateUpdateDto = new UpdateStatusOverrideDto()
            {
                PipelineSource = id?[0],
                Id = id?[1],
                BuId = id?[2],
                VendorId = id?[3],
                CurrentStatus = id?[4],
                UserLastModifiedBy = _LastModifiedUser,
                PipelineStage = "Invoice"
            };

            // Initialize default values
            auditRow["Pipeline Source"] = $"{fundingDateUpdateDto.PipelineSource}";
            auditRow["Invoice"] = $"{fundingDateUpdateDto.Id}";
            auditRow["BUID"] = $"{fundingDateUpdateDto.BuId}";
            auditRow["Vendor ID"] = $"{fundingDateUpdateDto.VendorId}";
            auditRow["Funding Date"] = $"{fundingDateUpdateDto.CurrentStatus}";
            try
            {
                (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) = ValidateInput(fundingDateUpdateDto, ref auditRow);

                if (!isProceed && docBeforeUpdate != null)
                {
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                    return;
                }
                if (!isProceed) return;
                _banzaiStatus = GetBanzaiStatus(fundingDateUpdateDto);                
                if (!EnrichedRequestUpdateFundingDate(fundingDateUpdateDto, user, docBeforeUpdate))
                {
                    UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                    UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                    _logger.LogCritical($"BanzaiMassUploadFundingDate({id}) - Error updating enriched document for revision {docBeforeUpdate.Revision}");
                    return;
                }
                UpdateAuditRow(ref auditRow, "Found", string.Empty);
                UnlockPipelineEnrichedRequest(docBeforeUpdate.Id);
                _rabbitMQueuePublisher.Publish(docBeforeUpdate.Id, _rollupRequestsQueue.QueueName);
                return;
            }
            catch (Exception e)
            {
                _logger.LogError($"Banzai status code update Error for {fundingDateUpdateDto.PipelineStage}: {fundingDateUpdateDto.Id}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }

        /// <summary>
        /// This method validates input for status update of funding date
        /// </summary>
        /// <param name="statusUpdateDto"></param>
        /// <param name="auditRow"></param>
        /// <returns></returns>
        private (bool isProceed, PipelineEnrichedRequest docBeforeUpdate) ValidateInput(UpdateStatusOverrideDto statusUpdateDto,
            ref DataRow auditRow)
        {
            if (string.IsNullOrEmpty(statusUpdateDto.Id)
                    || string.IsNullOrEmpty(statusUpdateDto.BuId)
                    || string.IsNullOrEmpty(statusUpdateDto.CurrentStatus))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.Id))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.BuId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (string.IsNullOrEmpty(statusUpdateDto.VendorId))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "1-or-more cells BLANK on Upload Row");
                return (false, null);
            }
            if (!ValidatefundingDate(statusUpdateDto.CurrentStatus))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Funding Date format should be mm/dd/yyyy");
                return (false, null);
            }            
            var docBeforeUpdate = LockPipelineEnrichedRequest(statusUpdateDto);
            if (docBeforeUpdate == null)
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Record is locked or NOT FOUND");
                return (false, null);
            }
            if (!ValidatefundingDateBNF(docBeforeUpdate))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Booking not confirmed for Invoice");
                return (false, docBeforeUpdate);
            }
            if (!ValidatefundingDateBeforeBNF(statusUpdateDto.CurrentStatus, docBeforeUpdate))
            {
                UpdateAuditRow(ref auditRow, "Not Found", "Funding date before BNF Status date");
                return (false, docBeforeUpdate);
            }
            return (true, docBeforeUpdate);
        }

        /// <summary>
		/// This method saved document to enrichment store
		/// </summary>
		/// <param name="statusUpdateDto"></param>
		/// <param name="docBeforeUpdate"></param>
		/// <returns></returns>
		private bool EnrichedRequestUpdateFundingDate(UpdateStatusOverrideDto statusUpdateDto, string user, PipelineEnrichedRequest docBeforeUpdate)
        {
            var docAfterUpdate = UpdateFundingDateInvoice(statusUpdateDto, docBeforeUpdate);

            if (docAfterUpdate != null)
            {
                docAfterUpdate.IsLocked = false;
                docAfterUpdate.Revision++;
                docAfterUpdate.Common.UserLastModifiedDate = DateTime.UtcNow;
                docAfterUpdate.Common.UserLastModifiedBy = user;
                return SaveEnrichedRequest(docAfterUpdate);
            }
            return false;
        }

        /// <summary>
        /// This method applies locks on EnrichedRequests for given ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private PipelineEnrichedRequest LockPipelineEnrichedRequest(UpdateStatusOverrideDto statusUpdateDto)
        {
            var enrichedRequestBuilder = Builders<PipelineEnrichedRequest>.Filter;
            FilterDefinition<PipelineEnrichedRequest> filter = null;

            filter = enrichedRequestBuilder.ElemMatch(x => x.InvoiceStage.Invoices, u => u.InvoiceNo == statusUpdateDto.Id) & enrichedRequestBuilder.Eq(x => x.IsLocked, false);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.SourceBusinessUnit, statusUpdateDto.BuId);
            filter &= enrichedRequestBuilder.Eq(x => x.Common.PipelineSource, statusUpdateDto.PipelineSource);

            if (!string.IsNullOrEmpty(statusUpdateDto.VendorId))
                filter &= enrichedRequestBuilder.Eq(x => x.Common.VendorId, statusUpdateDto.VendorId);

            var result = _dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter,
                    Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true),
                    ReturnDocument.Before);
            return result;
        }

        /// <summary>
        /// This method removes lock on PipelineEnrichedRequest for given ID
        /// </summary>
        /// <param name="id"></param>
        private void UnlockPipelineEnrichedRequest(string id)
        {
            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var filter = builder.Eq(u => u.Id, id)
                         & builder.Eq(u => u.IsLocked, true);

            _dataContext.PipelineEnrichedRequestsV2.UpdateOne(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, false));
        }

        /// <summary>
        /// This method saved document to enrichment store
        /// </summary>
        /// <param name="pipelineEnrichedRequest"></param>
        /// <returns></returns>
        private bool SaveEnrichedRequest(PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            if (pipelineEnrichedRequest == null)
                return false;
            var builder = Builders<PipelineEnrichedRequest>.Filter;
            var updateFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id);
            _dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(updateFilter, pipelineEnrichedRequest);
            return true;
        }

        /// <summary>
		/// This method status update for invoice
		/// </summary>
		/// <param name="invoiceNo"></param>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest UpdateFundingDateInvoice(UpdateStatusOverrideDto statusUpdateDto, PipelineEnrichedRequest pipelineEnrichedRequest)
        {
            var invoice = pipelineEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(x => x.InvoiceNo.ToUpper() == statusUpdateDto.Id.ToUpper());
            if (invoice == null)
                return null;
            var previousStatus = invoice.Clone() is Library.Entities.Invoice ? (invoice.Clone() as Library.Entities.Invoice)?.Status : new Status();

            var newStatus = CreateNewStatusRecord(statusUpdateDto);
            if (newStatus == null)
                return null;
            invoice.StatusHistory ??= new List<Status>();

            if (newStatus.BanzaiStatusSequence < invoice?.Status?.BanzaiStatusSequence &&
                (Convert.ToDateTime(previousStatus.DecisionSourceDateTime) <= Convert.ToDateTime(newStatus.DecisionSourceDateTime)))
            {
                newStatus.LatentTransaction = true;
                invoice.StatusHistory.Add(newStatus);
            }
            else
            {
                invoice.StatusHistory.Add(previousStatus);
                invoice.Status = newStatus;
            }
            return pipelineEnrichedRequest;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="statusUpdateDto"></param>
        /// <returns></returns>
        private Status CreateNewStatusRecord(UpdateStatusOverrideDto statusUpdateDto)
        {
            var newStatus = new Status
            {
                BanzaiStatusCreateDateTime = DateTime.UtcNow,
                DecisionSource = _LastModifiedUser,
                DecisionSourceStatusCode = "Funded",
                DecisionSourceDateTime = DateTime.ParseExact(statusUpdateDto.CurrentStatus, "MM/dd/yyyy", CultureInfo.InvariantCulture).AddHours(23).AddMinutes(59),
                SourceStatusCode = null,
                SourceStatusCodeDateTime = null,
                MessageType = STATUS_UPDATE_MESSAGE,
                MessageID = null,
                MessageSourceDateTime = null,
                MessageReceivedDateTime = null,
                Note = statusUpdateDto.Note,
                BanzaiStatusCode = _banzaiStatus.BanzaiStatusCode,
                BanzaiStatusSequence = _banzaiStatus.BanzaiStatusSequence,
                BanzaiUnbookedExposureFlag = _banzaiStatus.BanzaiUnbookedExposureFlag,
                LatentTransaction = false
            };
            return newStatus;
        }
        /// <summary>
        /// This method searches status combo repository for a given status update funded
        /// </summary>
        /// <param name="statusUpdateFutureInfo"></param>
        /// <returns></returns>
        private StatusCombo GetBanzaiStatus(UpdateStatusOverrideDto fundingDateUpdateDto)
        {
            _banzaiStatus = null;
            var _statusCombos = _dataContext.StatusCombos.GetAll().ToList();
            return _statusCombos.Any() ?
            (from x in _statusCombos
             where
             x.BanzaiStatusCode != null && x.BanzaiStatusCode.ToUpper().Equals("FND") &&
             x.PipelineSource != null && x.PipelineSource.ToUpper().Equals(fundingDateUpdateDto.PipelineSource?.ToUpper()) &&
             x.PipelineStage != null && x.PipelineStage.ToUpper().Equals(fundingDateUpdateDto.PipelineStage?.ToUpper()) &&
             x.Active
             select x).FirstOrDefault() : null;
        }
        /// <summary>
        /// matches given expresssion to find current status
        /// </summary>
        /// <param name="currentStatus"></param>
        /// <returns></returns>
        private bool ValidatefundingDate(string currentStatus)
        {
            var valid = DateTime.TryParseExact(currentStatus, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime validDate);
            return valid;
        }

        /// <summary>
        /// Validating Funding Date BNF
        /// </summary>
        /// <param name="currentStatus"></param>
        /// <returns></returns>
        private bool ValidatefundingDateBNF(PipelineEnrichedRequest docBeforeUpdate)
        {
            foreach (var pipelineInvoice in docBeforeUpdate?.InvoiceStage?.Invoices)
            {
                if ("BNF".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
                    return true;
                if (pipelineInvoice.StatusHistory != null)
                { 
                    var banzaiStatusCode = (from status in pipelineInvoice.StatusHistory
                                 where !string.IsNullOrEmpty(status.BanzaiStatusCode) 
                                 && status.BanzaiStatusCode.Equals("BNF", StringComparison.InvariantCultureIgnoreCase)
                                 select status)?.FirstOrDefault()?.BanzaiStatusCode ?? string.Empty;
                    if ("BNF".Equals(banzaiStatusCode, StringComparison.InvariantCultureIgnoreCase))
                        return true;
                }
            }
            return false; 
         }

        /// <summary>
        /// Validating Funding Date before BNF
        /// </summary>
        /// <param name="currentStatus"></param>
        /// <returns></returns>
        private bool ValidatefundingDateBeforeBNF(string currentStatus, PipelineEnrichedRequest docBeforeUpdate)
        {
            DateTime currentFundingDate = DateTime.ParseExact(currentStatus, "MM/dd/yyyy", null);
            foreach (var pipelineInvoice in docBeforeUpdate?.InvoiceStage?.Invoices)
            {
                if ("BNF".Equals(pipelineInvoice.Status.BanzaiStatusCode, StringComparison.InvariantCultureIgnoreCase) &&(currentFundingDate >= pipelineInvoice.Status.DecisionSourceDateTime))
                    return true;
                if (pipelineInvoice.StatusHistory != null)
                { 
                    var banzaiStatusCode = (from status in pipelineInvoice.StatusHistory
                                            where !string.IsNullOrEmpty(status.BanzaiStatusCode) && status.BanzaiStatusCode.Equals("BNF", StringComparison.InvariantCultureIgnoreCase)
                                            select status)?.FirstOrDefault()?.DecisionSourceDateTime;
                    if (currentFundingDate >= banzaiStatusCode)                
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Generic function to update audit rows
        /// </summary>
        private void UpdateAuditRow(ref DataRow auditRow, string status, string remarks)
        {
            auditRow["Audit"] = status;
            auditRow["Error"] = remarks;
        }
        
    }
}
