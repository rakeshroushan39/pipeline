using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using DFS.Banzai.Pipeline.Library.Interfaces;
using DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Strategies;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
	public sealed class LeaseWaveContractProcessor : MessageProcessor
	{
		#region MemberVariables
		private readonly List<IPipelineEnrichmentStrategy> EnrichmentStrategies = new List<IPipelineEnrichmentStrategy>();
		
		private string _messageID = string.Empty;
		private string _incomingMessage = string.Empty;
		#endregion

		/// <summary>
		/// Constructor to initialize Global class members
		/// </summary>
		/// <param name="settings"></param>
		/// <param name="logger"></param>
		/// <param name="mailService"></param>
		/// <param name="dataContext"></param>
		/// <param name="queueRepository"></param>
		public LeaseWaveContractProcessor(IOptions<Settings> settings, ILogger<StartupProcessor> logger,
			IMailService mailService, IDataContext dataContext,
            IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue) : base(settings, logger, mailService, dataContext, rabbitMQueuePublisher, publisherQueue) => IntializeStrategies();

		/// <summary>
		/// This method initializes stratagies to be applied for enriching incoming message
		/// </summary>
		private void IntializeStrategies() =>EnrichmentStrategies.Add(new InvoiceStatusCombosLookup(_settings, _logger, _mailService, _dataContext));

		/// <summary>
		/// This method gets triggered when message arrives from LeaseWave Contract event.
		/// </summary>		
		/// <param name="message"></param>
		/// <returns>Boolean - Success/True , Failure/False</returns>
		public new bool Process(string message)
		{
			_logger.LogDebug("Entered DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.LeaseWaveContractProcessor");

			_incomingMessage = message;
			var messageDetail = message.Split('|');
			_messageID = messageDetail[1];

			var filter = Builders<PipelineLeaseWaveContractRequestDto>.Filter.Eq(u => u.Id, _messageID);
			var pipelineLWContractRequest = _dataContext.PipelineLeaseWaveContractRequests.Find(filter)?.FirstOrDefault();

			if (pipelineLWContractRequest == null)
			{
				_logger.LogWarning($"LeaseWaveContractRequest for MessageID {_messageID} does not exist.");
				return true;
			}

			_logger.LogDebug("Exited DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.LeaseWaveContractProcessor");

			if (pipelineLWContractRequest.Invoices?.Count > 0)
				return EnrichContractRequestsAndSave(pipelineLWContractRequest);

			return false;
		}

		/// <summary>
		/// This method enriches lease wave contract requests
		/// </summary>
		/// <param name="PipelineLeaseWaveContractRequestDto"></param>
		private bool EnrichContractRequestsAndSave(PipelineLeaseWaveContractRequestDto pipelineLeaseWaveContractRequestDto)
		{
			foreach (var inputInvoice in pipelineLeaseWaveContractRequestDto.Invoices)
			{
				PipelineEnrichedRequest currentEnrichedRequest;
				PipelineEnrichedRequest previousEnrichedRequest = null;
				bool ignore;

				try
				{
					if (string.IsNullOrEmpty(inputInvoice.PipelineSource) || string.IsNullOrEmpty(inputInvoice.SourceBusinessUnit) || string.IsNullOrEmpty(inputInvoice.InvoiceNo) || string.IsNullOrEmpty(inputInvoice.VendorID))
						continue;

					(previousEnrichedRequest, currentEnrichedRequest, ignore) = GetPipelineEnrichedRequest(inputInvoice);

					if (ignore)
						continue;

					if (currentEnrichedRequest == null)
					{
						_logger.LogWarning($"The following Contract request was received in Banzai.Pipeline.Channel but a matching PipelineSource-InvoiceNo-BUID is not found.<br />" +
							$"PipelineSource: {inputInvoice.PipelineSource}<br />" +
							$"InvoiceNo: {inputInvoice.InvoiceNo}<br />" +
							$"Buid: {inputInvoice.SourceBusinessUnit}<br />"+
							$"VendorId: {inputInvoice.VendorID}<br />");

						continue;
					}

					RunStrategies(inputInvoice, pipelineLeaseWaveContractRequestDto, previousEnrichedRequest, currentEnrichedRequest);
				}
				catch (Exception e)
				{
					UnLockPipelineEnrichedRequest(previousEnrichedRequest?.Id);
					_logger.LogError($"Error in EnrichContractRequestsAndSave method for Message - {_incomingMessage}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
				}
			}

			return true;
		}

		/// <summary>
		/// This method fetches existing pipeline enriched request based on given invoice filter
		/// </summary>
		/// <param name="invoice"></param>
		/// <returns></returns>
		private (PipelineEnrichedRequest previousEnrichedRequest, PipelineEnrichedRequest currentEnrichedRequest, bool ignore) GetPipelineEnrichedRequest(ContractInvoiceDto invoice)
		{
			PipelineEnrichedRequest currentEnrichedRequest = null;
			PipelineEnrichedRequest previousEnrichedRequest = null;
			FilterDefinition<PipelineEnrichedRequest> invoiceFilter = Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.PipelineSource, invoice.PipelineSource)
				& Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.SourceBusinessUnit, invoice.SourceBusinessUnit)
				& Builders<PipelineEnrichedRequest>.Filter.ElemMatch(x => x.InvoiceStage.Invoices, c => c.InvoiceNo == invoice.InvoiceNo);

			if (!string.IsNullOrEmpty(invoice.VendorID))
				invoiceFilter &= Builders<PipelineEnrichedRequest>.Filter.Eq(u => u.Common.VendorId, invoice.VendorID);

			previousEnrichedRequest = LockPipelineEnrichedRequest(invoiceFilter);

			if (previousEnrichedRequest != null)
			{
				if (previousEnrichedRequest.IsLocked)
				{
					for (var i = 1; i <= 20; i++)
					{
						System.Threading.Thread.Sleep(1000);
						previousEnrichedRequest = LockPipelineEnrichedRequest(invoiceFilter);

						if (!previousEnrichedRequest.IsLocked)
							break;

                        if (i == 20)
                        {
                            UnLockPipelineEnrichedRequest(previousEnrichedRequest.Id);

                            _rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);

                            return (null, null, true);
                        }
					}
				}
				currentEnrichedRequest = previousEnrichedRequest.Clone() as PipelineEnrichedRequest;
			}

			return (previousEnrichedRequest, currentEnrichedRequest, false);
		}

		/// <summary>
		/// This method execute list of strategies to enrich contract request received from leasewave
		/// </summary>
		/// <param name="inputInvoice"></param>
		/// <param name="pipelineLeaseWaveContractRequestDto"></param>
		/// <param name="previousEnrichedRequest"></param>
		/// <param name="currentEnrichedRequest"></param>
		private void RunStrategies(ContractInvoiceDto inputInvoice, PipelineLeaseWaveContractRequestDto pipelineLeaseWaveContractRequestDto,
			PipelineEnrichedRequest previousEnrichedRequest, PipelineEnrichedRequest currentEnrichedRequest)
		{
			currentEnrichedRequest = CreateInvoiceStatus(inputInvoice, pipelineLeaseWaveContractRequestDto, currentEnrichedRequest);
			currentEnrichedRequest = EnrichCommon(pipelineLeaseWaveContractRequestDto, currentEnrichedRequest);
			currentEnrichedRequest = EnrichInvoiceContractNum(inputInvoice, pipelineLeaseWaveContractRequestDto, currentEnrichedRequest);
			foreach (var strategy in EnrichmentStrategies)
			{
				strategy.EnrichmentType = EnrichmentType.Invoice;
				strategy.PipelineEnrichedRequest = currentEnrichedRequest;
				strategy.PipelineMessageID = _messageID;

				if (string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Production", StringComparison.OrdinalIgnoreCase) == 0
					|| string.Compare(_settings.ASPNETCORE_ENVIRONMENT, "Development", StringComparison.OrdinalIgnoreCase) == 0)
					strategy.RetryRequired = true;

				currentEnrichedRequest = strategy.Run();

				if (!string.IsNullOrEmpty(strategy.ErrorMessage))
				{
					UnLockPipelineEnrichedRequest(previousEnrichedRequest?.Id);
					_logger.LogWarning($"Error in EnrichContractRequestsAndSave method for strategy {strategy.GetType()} " +
						$"failed with an error {strategy.ErrorMessage} for Message {_messageID}.");
					return;
				}
			}

			ProcessCurrentStatusAndLatency(ref previousEnrichedRequest, ref currentEnrichedRequest, inputInvoice.InvoiceNo);

			bool isSaved = SaveToEnrichmentStore(currentEnrichedRequest);

			if (isSaved && currentEnrichedRequest != null)
                _rabbitMQueuePublisher.Publish(currentEnrichedRequest.Id, _rollupRequestsQueue.QueueName);
		}

		/// <summary>
		/// This method create new status for invoice
		/// </summary>
		/// <param name="inputInvoice"></param>
		/// <param name="pipelineLeaseWaveContractRequestDto"></param>
		/// <param name="currentEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest CreateInvoiceStatus(ContractInvoiceDto inputInvoice,
			PipelineLeaseWaveContractRequestDto pipelineLeaseWaveContractRequestDto, PipelineEnrichedRequest currentEnrichedRequest)
		{
			var invoice = (from inv in currentEnrichedRequest?.InvoiceStage?.Invoices
						   where inv.InvoiceNo == inputInvoice.InvoiceNo
						   select inv)?.FirstOrDefault();

			if (invoice != null)
			{
				Status status = new Status
				{
					BanzaiStatusCreateDateTime = DateTime.UtcNow,
					MessageType = "LeaseWaveContractRequest",
					MessageID = _messageID,
					DecisionSourceDateTime = pipelineLeaseWaveContractRequestDto.DecisionDateTime,
					MessageSourceDateTime = pipelineLeaseWaveContractRequestDto.MessageCreateDateTime,
					MessageReceivedDateTime = pipelineLeaseWaveContractRequestDto.LastModifiedDateTime,
					DecisionSourceStatusCode = pipelineLeaseWaveContractRequestDto.StatusCode
				};

				invoice.Status = status;
			}

			return currentEnrichedRequest;
		}

		/// <summary>
		/// Updating the common section in Enrichment reqeust
		/// </summary>
		/// <param name="pipelineLeaseWaveContractRequestDto"></param>
		/// <param name="currentEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest EnrichCommon(PipelineLeaseWaveContractRequestDto pipelineLeaseWaveContractRequestDto, PipelineEnrichedRequest currentEnrichedRequest)
		{
			currentEnrichedRequest.Common.DirectOpsRep = pipelineLeaseWaveContractRequestDto.EmailID;

			if (string.IsNullOrEmpty(pipelineLeaseWaveContractRequestDto.EmployeeFirstName) && string.IsNullOrEmpty(pipelineLeaseWaveContractRequestDto.EmployeeLastName))
				currentEnrichedRequest.Common.DFSOpsRepName = null;
			else if(string.IsNullOrEmpty(pipelineLeaseWaveContractRequestDto.EmployeeFirstName))
				currentEnrichedRequest.Common.DFSOpsRepName = pipelineLeaseWaveContractRequestDto.EmployeeLastName;
			else if (string.IsNullOrEmpty(pipelineLeaseWaveContractRequestDto.EmployeeLastName))
				currentEnrichedRequest.Common.DFSOpsRepName = pipelineLeaseWaveContractRequestDto.EmployeeFirstName;
			else
				currentEnrichedRequest.Common.DFSOpsRepName = $"{pipelineLeaseWaveContractRequestDto.EmployeeFirstName} {pipelineLeaseWaveContractRequestDto.EmployeeLastName}";

			if (string.IsNullOrEmpty(currentEnrichedRequest.Common.DFSOpsRepName) && string.IsNullOrEmpty(currentEnrichedRequest.Common.DirectOpsRep))
				currentEnrichedRequest.Common.DFSOpsRepOrphan = true;
			else
				currentEnrichedRequest.Common.DFSOpsRepOrphan = false;
            if (!string.IsNullOrEmpty(pipelineLeaseWaveContractRequestDto.MLANumber))
                currentEnrichedRequest.Common.DFSCustomerMLAFlag = true;
            else
                currentEnrichedRequest.Common.DFSCustomerMLAFlag = false;
            return currentEnrichedRequest;
		}
		/// <summary>
		/// Updating the Contract num  in Enrichment reqeust
		/// </summary>
		/// <param name="inputInvoice"></param>
		/// <param name="pipelineLeaseWaveContractRequestDto"></param>
		/// <param name="currentEnrichedRequest"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest EnrichInvoiceContractNum(ContractInvoiceDto inputInvoice, PipelineLeaseWaveContractRequestDto pipelineLeaseWaveContractRequestDto, PipelineEnrichedRequest currentEnrichedRequest)
		{
			if (currentEnrichedRequest?.InvoiceStage?.Invoices != null)
			{
				var currentInvoice = (from invoice in currentEnrichedRequest?.InvoiceStage?.Invoices
									  where invoice.InvoiceNo == inputInvoice.InvoiceNo
									  select invoice)?.FirstOrDefault();
				if (currentInvoice != null)
					currentInvoice.ContractNum = pipelineLeaseWaveContractRequestDto.ContractNumber;

			}
			return currentEnrichedRequest;
		}
		/// <summary>
		/// This method processes CurrentStatus and latency of CurrentDocument.
		/// </summary>
		/// <param name="previousEnrichedRequest">Previous document received from DB store.</param>
		/// <param name="currentEnrichedRequest">Current document received from Queue.</param>
		/// <param name="pipelineLeaseWaveContractRequestDto"></param>
		private void ProcessCurrentStatusAndLatency(ref PipelineEnrichedRequest previousEnrichedRequest, ref PipelineEnrichedRequest currentEnrichedRequest,
			string invoiceNo)
		{
			if (currentEnrichedRequest?.InvoiceStage?.Invoices != null && previousEnrichedRequest?.InvoiceStage?.Invoices != null)
			{
				var currentInvoice = (from invoice in currentEnrichedRequest?.InvoiceStage?.Invoices
									  where invoice.InvoiceNo == invoiceNo
									  select invoice)?.FirstOrDefault();

				var previousInvoice = (from x in previousEnrichedRequest.InvoiceStage.Invoices
									   where x.InvoiceNo.Equals(currentInvoice.InvoiceNo)
									   select x).FirstOrDefault();

				var isInvoiceLatent = UpdateInvoicesStatusHistory(ref previousInvoice, ref currentInvoice);

				currentEnrichedRequest.InvoiceStage.Invoices = isInvoiceLatent ? previousEnrichedRequest.InvoiceStage?.Invoices : currentEnrichedRequest.InvoiceStage?.Invoices;
			}
		}

		/// <summary>
		/// This method is called from ProcessCurrentStatus to update StatusHistory on Invoices
		/// based on CurrentStatus of CurrentDocument.
		/// </summary>	
		/// <param name="previousInvoice"></param>
		/// <param name="currentInvoice"></param>        
		/// <returns></returns>
		/// <remarks>Status history of CurrentDocument is formed from PreviousDocument's CurrentStatus.</remarks>
		private bool UpdateInvoicesStatusHistory(ref Library.Entities.Invoice previousInvoice, ref Library.Entities.Invoice currentInvoice)
		{
			if (previousInvoice?.Status == null || currentInvoice?.Status == null)
				return currentInvoice?.Status != null && currentInvoice.Status.LatentTransaction;

			if (currentInvoice.Status.BanzaiStatusSequence != 0 && previousInvoice.Status.BanzaiStatusSequence != 0
				&& ((currentInvoice.Status.BanzaiStatusSequence < previousInvoice.Status.BanzaiStatusSequence) ||
				(Convert.ToDateTime(currentInvoice.Status.DecisionSourceDateTime) <= Convert.ToDateTime(previousInvoice.Status.DecisionSourceDateTime) &&
				currentInvoice.Status.BanzaiStatusSequence == previousInvoice.Status.BanzaiStatusSequence)))
			{
				currentInvoice.Status.LatentTransaction = true;
				previousInvoice.StatusHistory ??= new List<Status>();
				previousInvoice.StatusHistory.Add(currentInvoice.Status);
			}

			if (!currentInvoice.Status.LatentTransaction)
			{
				currentInvoice.StatusHistory ??= new List<Status>();
				currentInvoice.StatusHistory.Add(previousInvoice.Status);
			}

			return currentInvoice.Status != null && currentInvoice.Status.LatentTransaction;
		}
		
		/// <summary>
		/// This method saves current enriched request to enrichment store.
		/// </summary>
		/// <param name="pipelineEnrichedRequest"></param>
		/// <remarks/>
		/// This process will not save the document to store if the current enriched request's
		/// revision is lesser or equal to existing document in store. We are ignoring these transactions.
		private bool SaveToEnrichmentStore(PipelineEnrichedRequest pipelineEnrichedRequest)
		{
			pipelineEnrichedRequest.Revision += 1;

			pipelineEnrichedRequest.IsLocked = false;

			if (pipelineEnrichedRequest.Common != null)
				pipelineEnrichedRequest.Common.BanzaiLastModifiedDateTime = DateTime.UtcNow;

			var builder = Builders<PipelineEnrichedRequest>.Filter;

			var latentFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id) & (builder.Eq(u => u.Revision, pipelineEnrichedRequest.Revision) | builder.Gt(u => u.Revision, pipelineEnrichedRequest.Revision));

			var filterResult = _dataContext.PipelineEnrichedRequestsV2.Find(latentFilter)?.FirstOrDefault();

			if (filterResult == null)
			{
				var updateFilter = builder.Eq(u => u.Id, pipelineEnrichedRequest.Id);

				_dataContext.PipelineEnrichedRequestsV2.FindOneAndReplace(
					updateFilter,
					pipelineEnrichedRequest);

				return true;
			}
			else
			{
				// republish as the revision updated in other instance
				_rabbitMQueuePublisher.Publish(_incomingMessage, _channelEnrichmentQueue.QueueName);
				return false;
			}
		}

		/// <summary>
		/// This method applies lock on EnrichedRequests for given ID
		/// </summary>
		/// <param name="filter"></param>
		/// <returns></returns>
		private PipelineEnrichedRequest LockPipelineEnrichedRequest(FilterDefinition<PipelineEnrichedRequest> filter) =>
			_dataContext.PipelineEnrichedRequestsV2.FindOneAndUpdate(filter, Builders<PipelineEnrichedRequest>.Update.Set(u => u.IsLocked, true), ReturnDocument.Before);
	}
}
