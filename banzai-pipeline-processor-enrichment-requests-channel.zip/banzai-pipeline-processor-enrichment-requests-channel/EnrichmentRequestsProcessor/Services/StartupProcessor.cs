using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Linq;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services
{
    public class StartupProcessor : IMessageProcessor
	{
        #region MemberVariables
        private readonly ILogger<StartupProcessor> _logger;
        private readonly IOptions<Settings> _settings;		
		private readonly IMailService _mailService;
		private readonly IDataContext _dataContext;
		private readonly MessageProcessor _messageProcessor;
		private readonly MassStatusOverride _massStatusOverrideChannel;
		private readonly MassStatusUpdate _massStatusUpdateChannel;        
        private readonly LeaseWaveContractProcessor _leaseWaveContractProcessor;
        private readonly MassAuraInvoiceProcessor _massAuraInvoiceProcessor;
		private string _incomingMessage;
		private string _originalMessageDocID;
		private string _processName;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly IPublisherQueue _publisherQueue;
        #endregion

        /// <summary>
        /// Constructor to initialize MessageStore and enrichment processors.
        /// </summary>
        public StartupProcessor(
			IOptions<Settings> settings,
			ILogger<StartupProcessor> logger,
			IMailService mailService,
			IDataContext mongoDataContext,
            IPublisher rabbitMQueuePublisher,
            IPublisherQueue publisherQueue)
		{
			_settings = settings;
			_logger = logger;
			_mailService = mailService;
			_dataContext = mongoDataContext;
			_rabbitMQueuePublisher = rabbitMQueuePublisher;
            _publisherQueue = publisherQueue;

            _messageProcessor = new MessageProcessor(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue);
            _massStatusOverrideChannel = new MassStatusOverride(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue);
            _massStatusUpdateChannel = new MassStatusUpdate(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue);
            _massAuraInvoiceProcessor = new MassAuraInvoiceProcessor(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue);
            _leaseWaveContractProcessor = new LeaseWaveContractProcessor(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue);
        }

        /// <summary>
        /// This method gets triggered when message arrives in Channel enrichment Queue.
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool Process(string message)
		{
			_logger.LogDebug($"Entered DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.StartupProcessor.Process" +
                $" for processing message : {message}");

			try
			{
				_incomingMessage = message;
				var messageDetail = message.Split('|');
				_originalMessageDocID = messageDetail[0];

				switch (_originalMessageDocID)
				{
					case "StatusOverride":
						ProcessStatusOverride(messageDetail);
						break;
					case "StatusUpdate":
						ProcessStatusUpdate(messageDetail);
						break;
                    case "ClassafiInvoiceRequest":
                        ProcessClassafiInvoiceRequest();
                        break;
                    case "AuraInvoiceRequests":
						ProcessMassAuraInvoiceRequests();
						break;
					case "AuraInvoiceRequest":
						ProcessAuraInvoiceRequest();
						break;
					case "LeaseWaveContractRequest":
						ProcessLeaseWaveContractRequest();
						break;
                    case "SFDCOpptyId":
                        ProcessMassUpdateSfdcIdRequest(messageDetail);
                        break;
                    case "DFSOpsRep":
                        ProcessMassUpdateDFSOpsRepRequest(messageDetail);
                        break;
                    case "FundingDate":
                        ProcessMassUpdateFundingDate(messageDetail);
                        break;
                    default:
						ProcessInvoiceRequest();
						break;
				}
            }
            catch (MongoException e)
            {
                var errorMsg = $"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor MongoException message processing failed {_processName} " +
                    $"for an incoming message - {message}";
                _logger.LogError($"{errorMsg}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                NotifyFailureAdmin(e, errorMsg);

				return IgnoreRetry($"Pipeline_Channel_EnrichmentRequestsProcessor_Mongo_{e.Message}");
			}
            catch (Exception e)
            {
                var errorMsg = $"Banzai.Pipeline.Channel.EnrichmentRequestsProcessor GenericException message processing failed {_processName} " +
                    $"for an incoming message - {message}";
                _logger.LogError($"{errorMsg}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                NotifyFailureAdmin(e, errorMsg);
                HandleFailure(e, errorMsg, message);

                return true;
            }

            _logger.LogDebug($"Exited DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.StartupProcessor.Process");
                
            return true;
		}

        /// <summary>
        /// This method processes classafi invoice requests
        /// </summary>
        /// <returns></returns>
        private void ProcessClassafiInvoiceRequest()
        {
            _processName = "ClassafiInvoiceRequest";
            _messageProcessor.Process(_incomingMessage);
        }

        /// <summary>
        /// This method overrides enriched document status
        /// </summary>
        /// <param name="messageDetail"></param>
        /// <returns></returns>
        private void ProcessMassUpdateDFSOpsRepRequest(string[] messageDetail)
        {
            _processName = "DFSOpsRep";
            var message = XDocument.Parse("<Message></Message>");
            message.Root?.Add(new XElement("MessageType", messageDetail[0]));
            message.Root?.Add(new XElement("FileAttributes", messageDetail[2]));

            var massOpportunityUpdate = new MassDfsOpsRepUpdate(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue)
            {
                DocId = messageDetail[1],
            };
            massOpportunityUpdate.Process(message);
        }

        /// <summary>
        /// This method overrides enriched document status
        /// </summary>
        /// <param name="messageDetail"></param>
        /// <returns></returns>
        private void ProcessMassUpdateFundingDate(string[] messageDetail)
        {
            _processName = "FundingDate";
            var message = XDocument.Parse("<Message></Message>");
            message.Root?.Add(new XElement("MessageType", messageDetail[0]));
            message.Root?.Add(new XElement("FileAttributes", messageDetail[2]));
            var massFundingDateUpdate = new MassFundingDateUpdate(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue)
            {
                DocId = messageDetail[1]
            };
            massFundingDateUpdate.Process(message);
        }
        /// <summary>
        /// This method overrides enriched document status
        /// </summary>
        /// <param name="messageDetail"></param>
        /// <returns></returns>
        private void ProcessStatusOverride(string[] messageDetail)
		{
            _processName = "StatusOverride";
            var docId = messageDetail[1];
			var message = XDocument.Parse("<Message></Message>");
			message.Root?.Add(new XElement("MessageType", messageDetail[0]));
			message.Root?.Add(new XElement("FileAttributes", messageDetail[2]));

            _massStatusOverrideChannel.DocId = docId;
			_massStatusOverrideChannel.Process(message);
		}
		
		/// <summary>
		/// This method updates the status enriched document Channel Invoices
		/// </summary>
		/// <param name="messageDetail"></param>
		/// <returns></returns>
		private void ProcessStatusUpdate(string[] messageDetail)
		{
            _processName = "StatusUpdate";
            var docId = messageDetail[1];
			var message = XDocument.Parse("<Message></Message>");
			message.Root?.Add(new XElement("MessageType", messageDetail[0]));
			message.Root?.Add(new XElement("FileAttributes", messageDetail[2]));

            _massStatusUpdateChannel.DocId = docId;
			_massStatusUpdateChannel.Process(message);
		}

		/// <summary>
		/// This method processes invoice requests
		/// </summary>
		/// <returns></returns>
		private void ProcessInvoiceRequest()
		{
			_processName = "InvoiceRequest";
            _messageProcessor.DocId = _originalMessageDocID;
			_messageProcessor.Process(_incomingMessage);
		}

		/// <summary>
		/// This method processes aura invoice requests coming from Banzai UI
		/// </summary>
		/// <returns></returns>
		private void ProcessMassAuraInvoiceRequests()
		{
			_processName = "MassAuraInvoiceRequests";
			_massAuraInvoiceProcessor.ProcessMassAuraInvoiceRequests(_incomingMessage);
		}

		/// <summary>
		/// This method processes aura invoice request coming from Aura
		/// </summary>
		/// <returns></returns>
		private void ProcessAuraInvoiceRequest()
		{
			_processName = "AuraInvoiceRequest";
			_massAuraInvoiceProcessor.ProcessAuraInvoiceRequest(_incomingMessage);
		}

        /// <summary>
		/// This method processes LeaseWave contract request
		/// </summary>
		/// <returns></returns>
		private void ProcessLeaseWaveContractRequest()
        {
            _processName = "LeaseWaveContractRequest";
            _leaseWaveContractProcessor.Process(_incomingMessage);
        }

        /// <summary>
        /// This method overrides enriched document status
        /// </summary>
        /// <param name="messageDetail"></param>
        /// <returns></returns>
		private void ProcessMassUpdateSfdcIdRequest(string[] messageDetail)
        {
            _processName = "SFDCOpptyId";           
            var message = XDocument.Parse("<Message></Message>");
            message.Root?.Add(new XElement("MessageType", messageDetail[0]));
            message.Root?.Add(new XElement("FileAttributes", messageDetail[2]));

            var massOpportunityUpdate = new MassOpportunityUpdate(_settings, _logger, _mailService, _dataContext, _rabbitMQueuePublisher, _publisherQueue)
            {
                DocId = messageDetail[1]
            };

            massOpportunityUpdate.Process(message);
        }

        /// <summary>
        /// This method works on ignoring all mongo exceptions when requested
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        private bool IgnoreRetry(string key)
        {
            if ("prod".Equals(_settings.Value.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase)
                || "production".Equals(_settings.Value.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
            {
                var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
                var count = _dataContext.IgnoreRetry.Find(filter)?.Count() ?? 0;

                if (count > 0)
                {
                    _dataContext.IgnoreRetry.DeleteOne(filter);
                    return true; //Ignore the message
                }

                return false;
            }

            return true;
        }

        /// <summary>
        /// Notify IT admin thru email for failures
        /// </summary>
        /// <param name="e"></param>
        /// <param name="errorMessage"></param>
        private void NotifyFailureAdmin(Exception e, string errorMessage)
        {
            if ("Development".Equals(_settings.Value.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase) ||
                "PERF".Equals(_settings.Value.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
                return;

            var to = _settings.Value.EMAIL_IT_TEAM.Split(',').ToList();
            var body = $"{errorMessage}<br /><br />Exception Message: '{e.Message}'.<br /><br />.Exception Details: {e}.";
            var mailMessage = new MailMessage
            {
                Subject = "Banzai.Pipeline.Channel.EnrichmentRequestsProcessor message processing failure notification",
                Body = body,
                ToList = to,
                IsBodyHtml = true,
                OperatingEnv = _settings.Value.ASPNETCORE_ENVIRONMENT
            };
            _mailService.SendMail(mailMessage);
        }

        /// <summary>
        /// Logging the exception into Mongo Collection for further processing
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="errorMessage"></param>
        /// <param name="message"></param>
        protected void HandleFailure(Exception ex, string errorMessage, string message)
        {
            try
            {
                var errorLog = new ErrorLog()
                {
                    Processor = "Banzai.Pipeline.Channel.EnrichmentRequestsProcessor",
                    Message = message,
                    ErrorDetails = $"{errorMessage}. Exception: {ex}"
                };

                _dataContext.ErrorLogs.InsertOneAsync(errorLog);
            }
            catch (Exception e)
            {
                _logger.LogError($"ErrorLogs - for incoming message - {message}. " +
                    $"{e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }
    }
}