using DFS.Banzai.Invoice.Library.Models.InvoiceEnrichments;
using DFS.Banzai.Library;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Enums;
using DFS.Banzai.Library.ExternalServices;
using DFS.Banzai.Library.Generic;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.Models.InvoiceEnrichments;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Xml.Linq;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor.Services.Enrichments
{
    public class InvoiceNotificationEnrichment
    {
        #region Member Variables
        private readonly Settings _settings;
        private readonly ILogger _logger;
        private readonly IMailService _mail;
        private readonly IDataContext _dataContext;
        private string _guid;
        private int _retryCount;
        private bool _isLatent = false;
        private readonly List<string> _excludedProperties;
        private List<StatusCombo> _statusComboList;
        private readonly GetBanzaiInvoiceService _getBanzaiInvoiceService;
        #endregion

        #region Properties
        public EnrichmentType EnrichmentType { get; set; }
        public XElement Message { get; set; }
        public string DocId { get; set; }
        public PipelineEnrichedRequest CurrentEnrichedRequest { get; set; }
        public PipelineEnrichedRequest PreviousEnrichedRequest { get; set; }
        public string ErrorMessage { get; set; }
        public bool RetryRequired { get; set; }
        public string PipelineMessageID { get; set; }
        public PipelineInvoiceInboundNotification PipelineInvoiceInboundNotification { get; set; }
        #endregion

        /// <summary>
        /// Constructor to initialize class members
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="logger"></param>
        /// <param name="mail"></param>
        /// <param name="database"></param>
        /// <param name="getBanzaiInvoiceService"></param>
        public InvoiceNotificationEnrichment(Settings settings, ILogger logger, IMailService mail, IDataContext database, GetBanzaiInvoiceService getBanzaiInvoiceService)
        {
            _settings = settings;
            _logger = logger;
            _mail = mail;
            _dataContext = database;
            _getBanzaiInvoiceService = getBanzaiInvoiceService;

            // Excluded properties that should not be overwritten in to Pipeline enriched request when pulling from Banzai.Invoice
            _excludedProperties = new List<string>();
            _excludedProperties.Add("DFSCustomerReassignedFlag");
            _excludedProperties.Add("BanzaiCreateDateTime");
            _excludedProperties.Add("UserLastModifiedBy");
            _excludedProperties.Add("UserLastModifiedDate");
        }

        /// <summary>
        /// This method enriches enrichred request based on incoming invoicenotification request
        /// </summary>
        /// <returns>EnrichedRequest</returns>
        public PipelineEnrichedRequest Run()
        {
            _logger.LogDebug("Entered InvoiceNotificationLookup Strategy");

            _retryCount = 0;
            _guid = Guid.NewGuid().ToString();
            _isLatent = false;
            CurrentEnrichedRequest.BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.NA.ToString();
            _statusComboList = _dataContext.StatusCombos.GetAll()?.ToList();
            CurrentEnrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString();
            CurrentEnrichedRequest.BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.Fail.ToString();

            EnrichInvoice();

            CurrentEnrichedRequest.BanzaiInvoiceGetInvoiceServiceInSync = PipelineEnrichmentStatus.Pass.ToString();
            
            _logger.LogDebug("Exited InvoiceNotificationLookup Strategy");

            return CurrentEnrichedRequest;
        }        
        
        /// <summary>
        /// This method enriches invoice section of enrichred request
        /// </summary>
        private void EnrichInvoice()
        {
            Library.Entities.Invoice previousInvoice = null;

            if (PreviousEnrichedRequest?.InvoiceStage?.Invoices != null)
                previousInvoice = PreviousEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(o => o.InvoiceNo.ToUpper()== PipelineInvoiceInboundNotification.InvoiceNo.ToUpper());
        
            Library.Entities.Invoice currentInvoice = null;

            if (CurrentEnrichedRequest?.InvoiceStage?.Invoices != null)
                currentInvoice = CurrentEnrichedRequest.InvoiceStage?.Invoices?.FirstOrDefault(o => o.InvoiceNo.ToUpper() == PipelineInvoiceInboundNotification.InvoiceNo.ToUpper());
                
            if (previousInvoice == null)
            {
                CurrentEnrichedRequest.InvoiceStage = CurrentEnrichedRequest.InvoiceStage ?? new InvoiceStage();
                CurrentEnrichedRequest.InvoiceStage.Invoices = CurrentEnrichedRequest.InvoiceStage.Invoices ?? new List<Library.Entities.Invoice>();
                currentInvoice = new Library.Entities.Invoice();
                currentInvoice.InvoiceNo = PipelineInvoiceInboundNotification.InvoiceNo;
                CurrentEnrichedRequest.InvoiceStage.Invoices.Add(currentInvoice);
            }

            var invoiceRequestDto = CreateInvoiceRequest();

            var result = _getBanzaiInvoiceService.Execute(invoiceRequestDto, PipelineMessageID);

            if ("IgnoreRetry".Equals(result.ErrorMessage) || "ServiceError".Equals(result.ErrorMessage))
                throw new TimeoutException($"{result.ErrorMessage}|Banzai.Invoice GetChannelInvoice service call failed.");

            var invoiceResponse = RetreiveInvoiceRepsonse(result.Response);

            UpdatePipelineInvoice(invoiceResponse, previousInvoice, currentInvoice);
        }

        /// <summary>
        /// This method retrieves invoice from response
        /// </summary>
        /// <param name="invoiceResponseDto"></param>
        /// <returns></returns>
        private InvoiceResponse RetreiveInvoiceRepsonse(InvoiceResponseDto invoiceResponseDto)
        {
            if (invoiceResponseDto != null && invoiceResponseDto.Invoices?.Count > 0)
            {
                foreach (var response in invoiceResponseDto.Invoices)
                {
                    if (response.Invoice != null &&
                        PipelineInvoiceInboundNotification.InvoiceNo.Equals(response.Invoice.InvoiceNo, StringComparison.InvariantCultureIgnoreCase))
                            return response;
                }
            }

            return null;
        }

        /// <summary>
        /// This method applies Banzai.Invoice details to Pipeline.Invoice
        /// </summary>
        /// <param name="invoiceResponse"></param>
        /// <param name="previousInvoice"></param>
        /// <param name="currentInvoice"></param>
        private void UpdatePipelineInvoice(InvoiceResponse invoiceResponse, Library.Entities.Invoice previousInvoice, Library.Entities.Invoice currentInvoice)
        {
            UpdateCommon(invoiceResponse);

            PopulateInvoiceHeaderElements(currentInvoice, invoiceResponse);

            PrepareInvoiceStatus(PipelineInvoiceInboundNotification.PipelineSource, "INVOICE", currentInvoice);

            if (previousInvoice != null)
            {
                ProcessLatencyAndUpdateStatusHistoryForInvoice(previousInvoice, currentInvoice);

                if (_isLatent)
                    CurrentEnrichedRequest.InvoiceStage.Invoices = PreviousEnrichedRequest.InvoiceStage.Invoices;
            }
        }

        /// <summary>
        /// This method creates invoice request to be used fetch Banzai Invoice details
        /// </summary>
        /// <returns></returns>
        private InvoiceRequestDto CreateInvoiceRequest() => new InvoiceRequestDto()
        {
            ClientName = "Banzai.Pipeline.Channel",
            PipelineSource = PipelineInvoiceInboundNotification.PipelineSource,
            SearchBy = "InvoiceNo",
            SearchValue = PipelineInvoiceInboundNotification.InvoiceNo,
            SourceBusinessUnit = PipelineInvoiceInboundNotification.SourceBusinessUnit,
            VendorId = PipelineInvoiceInboundNotification.VendorID,
        };

        /// <summary>
        /// This method enriches common section of enriched request.
        /// <paramref name="invoiceResponse"/>>
        /// </summary>
        private void UpdateCommon(InvoiceResponse invoiceResponse)
        {
            var pipelineStageStart = CurrentEnrichedRequest?.Common?.PipelineStageStart;
            var pipelineStageStartField = CurrentEnrichedRequest?.Common?.PipelineStageStartField;

            if (CurrentEnrichedRequest.Common == null)
            {
                CurrentEnrichedRequest.Common = new Common();
                CurrentEnrichedRequest.Common.BanzaiCreateDateTime = DateTime.UtcNow;
            }

            if (invoiceResponse?.Common != null)
                invoiceResponse.Common.CopyPropertiesTo(CurrentEnrichedRequest.Common, _excludedProperties);

            if (!string.IsNullOrEmpty(pipelineStageStart))
                CurrentEnrichedRequest.Common.PipelineStageStart = pipelineStageStart;

            if (!string.IsNullOrEmpty(pipelineStageStartField))
                CurrentEnrichedRequest.Common.PipelineStageStartField = pipelineStageStartField;

            CurrentEnrichedRequest.Common.BanzaiLastModifiedDateTime = DateTime.UtcNow;
        }

        /// <summary>
        /// This method populates invoice header elements
        /// </summary>
        /// <param name="currentInvoice"></param>
        /// <param name="invoiceResponse"></param>
        private void PopulateInvoiceHeaderElements(Library.Entities.Invoice currentInvoice, InvoiceResponse invoiceResponse)
        {
            CurrentEnrichedRequest.InvoiceStage.PipelineStage = "INVOICE";

            if (invoiceResponse?.Invoice != null)
                invoiceResponse.Invoice.CopyPropertiesTo(currentInvoice, new List<string>() { "Status" });
        }

        /// <summary>
        /// This method is used to set the banzai status elements to the current status in transaction data.
        /// </summary>
        /// <param name="pipelineSource"></param>
        /// <param name="pipelineStage"></param>
        /// <param name="currentInvoice"></param>        
        private void PrepareInvoiceStatus(string pipelineSource, string pipelineStage, Library.Entities.Invoice currentInvoice)
        {
            currentInvoice.Status = currentInvoice?.Status ?? new Status();

            DocId = PipelineInvoiceInboundNotification.InvoiceNo;

            if (string.IsNullOrEmpty(pipelineSource) || string.IsNullOrEmpty(pipelineStage) ||
                string.IsNullOrEmpty(PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSourceStatusCode))
                return;

            var utility = new Utility(_settings, _mail, _dataContext, _logger);

            var isIgnore = BanzaiStatusIgnoreRetry(utility, "InvoiceNo");

            if (isIgnore)
                return;

            StatusCombo banzaiStatus = GetBanzaiStatus(pipelineStage);

            if (RetryRequired && banzaiStatus == null)
            {
                var subject = $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup not found for InvoiceNo {DocId}";
                var message = $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup not available for InvoiceNo {DocId}, " +
                              $"PipelineSource - {pipelineSource}, PipelineStage - {pipelineStage} " +
                              $"and DecisionSourceStatusCode - {PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSourceStatusCode?.ToUpper()}" +
                              $"<br /><br />Reattempt # {_retryCount + 1}<br /><br />CacheKey: {_guid}<br /><br />";

                if (!string.IsNullOrEmpty(PipelineMessageID))
                    message += $"Incoming Message ID - {PipelineMessageID}<br /><br />";

                utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, message); //Trigger a mail to IT about the failure
                utility.TriggerWait(ref _retryCount); //Wait before next process

                PrepareInvoiceStatus(pipelineSource, pipelineStage, currentInvoice);
            }

            if (_retryCount > 0)
            {
                var subject = $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup for InvoiceNo {DocId} lookup success notification";
                var body =
                    $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup successful for InvoiceNo {DocId} after {_retryCount} attempts.<br /><br />" +
                    $"CacheKey: {_guid}<br /><br />";

                if (!string.IsNullOrEmpty(PipelineMessageID))
                    body += $"Incoming Message ID - {PipelineMessageID}<br /><br />";

                utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, body);

                _retryCount = 0; //Suppress the success notification
            }

            if (banzaiStatus != null)
                SetInvoiceStatus(banzaiStatus, currentInvoice);
        }

        /// <summary>
        /// This method ignores retries
        /// </summary>
        /// <param name="utility"></param>
       [ExcludeFromCodeCoverage]
        private bool BanzaiStatusIgnoreRetry(Utility utility, string statusMessage)
        {
            if (_retryCount >= 3)
            {
                var key = $"{CacheKeys.EnrichFailureTracker}{_guid}";
                var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
                var count = _dataContext.IgnoreRetry.Find(filter)?.Count() ?? 0;

                if (count > 0)
                {
                    _dataContext.IgnoreRetry.DeleteOne(filter);

                    RetryRequired = false; //Overwriting the flag to avoid infinite loop
                    CurrentEnrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Fail.ToString();

                    ErrorMessage = "StatusComboLookup - external interruption";
                    _retryCount = 0; //Suppress the success notification

                    var subject = $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup for {statusMessage} {DocId} ignored";
                    var message =
                        $"Banzai.Pipeline.Channel - InvoiceNotificationEnrichment - StatusComboLookup for {statusMessage} {DocId} with Cache Key {_guid} is ignored due to external interruption";

                    if (!string.IsNullOrEmpty(PipelineMessageID))
                        message += $"<br /><br />Incoming Message ID - {PipelineMessageID}";

                    utility.NotifyEmail(_settings.EMAIL_BUZ_ADMIN, subject, message);

                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// This method gets banzai status combo
        /// </summary>
        /// <returns></returns>
        private StatusCombo GetBanzaiStatus(string pipelineStage)
        {
            if (_statusComboList != null && _statusComboList.Any())
            {
                return (from x in _statusComboList
                        where
                            x.DecisionSourceStatusCode != null &&
                            x.DecisionSourceStatusCode.Equals(PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSourceStatusCode, StringComparison.InvariantCultureIgnoreCase) &&
                            x.PipelineSource != null && x.PipelineSource.Equals(PipelineInvoiceInboundNotification.PipelineSource, StringComparison.InvariantCultureIgnoreCase) &&
                            x.PipelineStage != null && x.PipelineStage.Equals(pipelineStage, StringComparison.InvariantCultureIgnoreCase) &&
                            x.Active
                        select x).FirstOrDefault();
            }

            return null;
        }

        /// <summary>
        /// This mwethod sets Invoice status.
        /// </summary>
        /// <param name="banzaiStatus"></param>
        /// <param name="status"></param>
        private void SetInvoiceStatus(StatusCombo banzaiStatus, Library.Entities.Invoice currentInvoice)
        {
            var currentStatus = currentInvoice?.Status;

            if (currentStatus != null)
            {
                currentStatus.Discard = banzaiStatus.Discard;
                currentStatus.DFSCustomer = banzaiStatus.DFSCustomer;
                currentStatus.BanzaiStatusCode = banzaiStatus.BanzaiStatusCode;
                currentStatus.BanzaiStatusSequence = banzaiStatus.BanzaiStatusSequence;
                currentStatus.BanzaiUnbookedExposureFlag = banzaiStatus.BanzaiUnbookedExposureFlag;
                currentStatus.DecisionSource = PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSource;
                currentStatus.DecisionSourceStatusCode = PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSourceStatusCode;
                currentStatus.SourceStatusCode = PipelineInvoiceInboundNotification.MostRecentStatusRecord.SourceStatusCode;
                currentStatus.Note = string.Empty;
                currentStatus.MessageID = PipelineMessageID;
                currentStatus.MessageType = "InvoiceNotification";
                currentStatus.BanzaiStatusCreateDateTime = DateTime.UtcNow;
                currentStatus.DecisionSourceDateTime = PipelineInvoiceInboundNotification.MostRecentStatusRecord.DecisionSourceDateTime;
                currentStatus.SourceStatusCodeDateTime = PipelineInvoiceInboundNotification.MostRecentStatusRecord.SourceStatusCodeDateTime;
                currentStatus.MessageSourceDateTime = PipelineInvoiceInboundNotification.MostRecentStatusRecord.MessageSourceDateTime;
                currentStatus.MessageReceivedDateTime = PipelineInvoiceInboundNotification.LastModifiedDateTime;
            }

            CurrentEnrichedRequest.BanzaiStatusInSync = PipelineEnrichmentStatus.Pass.ToString();
        }

        /// <summary>
        /// This method is called from ProcessCurrentStatusAndLatency to update StatusHistory on Invoices
        /// based on CurrentStatus of CurrentInvoice.
        /// </summary>	
        /// <param name="previousInvoice"></param>
        /// <param name="currentInvoice"></param>        
        /// <returns></returns>
        /// <remarks>Status history of CurrentDocument is formed from PreviousDocument's CurrentStatus.</remarks>
        private void ProcessLatencyAndUpdateStatusHistoryForInvoice(Library.Entities.Invoice previousInvoice, Library.Entities.Invoice currentInvoice)
        {
            if (currentInvoice?.Status == null)
                return;

            if (currentInvoice.Status.BanzaiStatusSequence != 0 && previousInvoice.Status.BanzaiStatusSequence != 0 && 
               (currentInvoice.Status.BanzaiStatusSequence < previousInvoice.Status.BanzaiStatusSequence ||
               currentInvoice.Status.BanzaiStatusSequence == previousInvoice.Status.BanzaiStatusSequence &&
               Convert.ToDateTime(currentInvoice.Status.DecisionSourceDateTime) < Convert.ToDateTime(previousInvoice.Status.DecisionSourceDateTime)))
            {
                currentInvoice.Status.LatentTransaction = true;
                _isLatent = true;
                previousInvoice.StatusHistory = previousInvoice.StatusHistory ?? new List<Status>();

                previousInvoice.StatusHistory.Add(currentInvoice.Status);
            }

            if (!currentInvoice.Status.LatentTransaction)
            {
                currentInvoice.StatusHistory = currentInvoice.StatusHistory ?? new List<Status>();
                currentInvoice.StatusHistory.Add(previousInvoice.Status);
            }
        }
    }
}
