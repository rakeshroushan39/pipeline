using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Steeltoe.Common.Hosting;
using Steeltoe.Extensions.Configuration.CloudFoundry;
using Steeltoe.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace DFS.Banzai.Pipeline.Streaming.Channel.EnrichmentRequestsProcessor
{
    [ExcludeFromCodeCoverage]
    public static class Program
	{
		public static void Main(string[] args)
		{
			var host = new WebHostBuilder()
				.UseKestrel()
				.UseCloudHosting()
				.UseContentRoot(Directory.GetCurrentDirectory())
				.UseIISIntegration()
				.UseStartup<Startup>()
				.ConfigureAppConfiguration((builderContext, config) =>
				{
					config.SetBasePath(builderContext.HostingEnvironment.ContentRootPath)
						.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
						.AddJsonFile($"appsettings.{builderContext.HostingEnvironment.EnvironmentName}.json", optional: false, reloadOnChange: true)
						.AddCloudFoundry()
						.AddEnvironmentVariables();
				})
				.ConfigureLogging((builderContext, loggingBuilder) =>
				{
					loggingBuilder.AddConfiguration(builderContext.Configuration.GetSection("Logging"));
					loggingBuilder.AddDynamicConsole();
				})
				.Build();

			host.Run();
		}
	}
}
