using DFS.Banzai.Library.Entities;
using DFS.Banzai.Pipeline.Library.Entities;
using System;
using System.Collections.Generic;
using Xunit;

namespace DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.UnitTest
{
    public class MessageProcessorTest_1 : IClassFixture<CoreFixture>
    {
        private readonly CoreFixture _coreFixture;
        public MessageProcessorTest_1(CoreFixture coreFixture) => _coreFixture = coreFixture;

        #region MessageProcessorTest

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ProcessIncomingMessage_When_GAAPValidMessage()
        {
            //Arrange    
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','Id':'5e821d62b5504d0010c11bd6','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'GAAP','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act       

            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineClassafiInvoiceRequest()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ProcessIncomingMessage_When_COGSValidMessage()
        {
            //Arrange    
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','Id':'5e821d62b5504d0010c11bd6','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act       

            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineClassafiInvoiceRequest()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }       

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ProcessIncomingMessage_When_606ValidMessage()
        {
            //Arrange    
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','Id':'5e821d62b5504d0010c11bd6','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'606','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act       

            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineClassafiInvoiceRequest()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldNotProcessIncomingMessage_When_InValidMessage()
        {
            //Arrange    
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','Id'':''5e821d62b5504d0010c11bd6','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'606','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineClassafiInvoiceRequest()));
            _coreFixture.MongoDataContext.Setup(x => x.MessageValidationErrors.InsertOneAsync(MessageValidationError()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldNotProcessIncomingMessage_When_ValidMessageInvalidLink()
        {
            //Arrange               
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'links': [{'Rel':'Rel_1', 'Uri': 'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestWithLink()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldNotProcessIncomingMessage_When_ValidMessageWithValidLinks()
        {
            //Arrange               
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'links': [{'rel':'Rel_1','uri':'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestWithLink()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ProcessIncomingMessage_When_evtDateTimeNull()
        {
            //Arrange    
            var message = "{'bookingId':'5e821d62b5504d0010c11b62','Id':'5e821d62b5504d0010c11bd6','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':null}";

            //Act       

            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineClassafiInvoiceRequest()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldProcessIncomingMessage_When_ValidLinks()
        {
            //Arrange               
            var message = "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGS', 'classificationType': 'EMC', 'vendorId': '230', 'pipelineSource': 'EMC', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestWithLink()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldProcessAndPublish_PipelineSource_Dell()
        {
            //Arrange               
            var message = "{ 'Id': '5e821d62b5504d0010c11b12', 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGS', 'classificationType': 'DELL', 'vendorId': '230', 'pipelineSource': 'DELL', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestDell()));
            _coreFixture.MessageProcessor.IsTestCaseExecution = true;
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldProcessAndPublish_PipelineSource_EMC()
        {
            //Arrange               
            var message = "{ 'Id': '5e821d62b5504d0010c11b13', 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGS', 'classificationType': 'EMC', 'vendorId': '230', 'pipelineSource': 'EMC', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestEMC()));
            _coreFixture.MessageProcessor.IsTestCaseExecution = true;
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldProcessAndPublish_PipelineSource_Channel()
        {
            //Arrange               
            var message = "{ 'Id': '5e821d62b5504d0010c11b14', 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGS', 'classificationType': 'Channel', 'vendorId': '230', 'pipelineSource': 'CHANNEL', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestChannel()));
            _coreFixture.MessageProcessor.IsTestCaseExecution = true;
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldNotProcessAndPublish_When_Invalid_NotificationType()
        {
            //Arrange               
            var message = "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGGSSSS', 'classificationType': 'Channel', 'vendorId': '230', 'pipelineSource': 'EMC', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(PipelineRequestWithLink()));            
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }

        [Trait("MessageProcessor", "MessageProcessorTest")]
        [Fact]
        public void Should_ShouldNotProcessAndPublish_When_InvalidRequest()
        {
            //Arrange               
            var message = "{ 'bookingId': '5e821d62b5504d0010c11b62', 'invoiceNumber': '5331085364', 'businessUnitID': '707', 'notificationType': 'COGGSSSS', 'classificationType': 'Channel', 'vendorId': '230', 'pipelineSource': 'EMC', correlationId: '711123ae-7b1c-4162-94ca-d4af5794f313', 'links': [ { 'rel': 'Rel_1', 'link': 'Uri_1' } ], 'eventDateTime': '2020-03-30T16:25:09.1029939+00:00' }";

            //Act       
            _coreFixture.MongoDataContext.Setup(x => x.PipelineClassafiInvoiceRequests.InsertOne(InvalidRequest()));
            var result = _coreFixture.MessageProcessor.Process(message);

            //Assert
            Assert.True(result);
        }
        
        #endregion MessageProcessorTest

        #region PrivateMethods

        private PipelineClassafiInvoiceRequest InvalidRequest()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "$%%&&**"
            };
        }
        private PipelineClassafiInvoiceRequest PipelineClassafiInvoiceRequest()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "5edf39559956929ba4689dd6",
                PipelineSource = "EMC",
                VendorID = "230",
                InvoiceNo = "5331085364",
                SourceBusinessUnit = "707",
                NotificationType = "GAAP",
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                DecisionSourceDateTime = DateTime.UtcNow,
                Message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}",
                LastModifiedDateTime = DateTime.UtcNow
            };
        }
        private PipelineClassafiInvoiceRequest PipelineRequestWithLink()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "5edf39559956929ba4689dd6",
                PipelineSource = "EMC",
                VendorID = "230",
                InvoiceNo = "5331085364",
                SourceBusinessUnit = "707",
                NotificationType = "GAAP",
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                DecisionSourceDateTime = DateTime.UtcNow,
                Message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'Links': [{'Rel':'Rel_1', 'Uri': 'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}",
                LastModifiedDateTime = DateTime.UtcNow,
                Links = LstLink()

            };
        }

        private PipelineClassafiInvoiceRequest PipelineRequestDell()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "5edf39559956929ba4689dd6",
                PipelineSource = "DELL",
                VendorID = "230",
                InvoiceNo = "5331085364",
                SourceBusinessUnit = "707",
                NotificationType = "GAAP",
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                DecisionSourceDateTime = DateTime.UtcNow,
                Message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'Links': [{'Rel':'Rel_1', 'Uri': 'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}",
                LastModifiedDateTime = DateTime.UtcNow,
                Links = LstLink()

            };
        }

        private PipelineClassafiInvoiceRequest PipelineRequestEMC()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "5edf39559956929ba4689dd6",
                PipelineSource = "EMC",
                VendorID = "230",
                InvoiceNo = "5331085364",
                SourceBusinessUnit = "707",
                NotificationType = "GAAP",
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                DecisionSourceDateTime = DateTime.UtcNow,
                Message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'Links': [{'Rel':'Rel_1', 'Uri': 'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}",
                LastModifiedDateTime = DateTime.UtcNow,
                Links = LstLink()

            };
        }

        private PipelineClassafiInvoiceRequest PipelineRequestChannel()
        {
            return new PipelineClassafiInvoiceRequest
            {
                Id = "5edf39559956929ba4689dd6",
                PipelineSource = "CHANNEL",
                VendorID = "230",
                InvoiceNo = "5331085364",
                SourceBusinessUnit = "707",
                NotificationType = "GAAP",
                CorrelationID = "711123ae-7b1c-4162-94ca-d4af5794f313",
                DecisionSourceDateTime = DateTime.UtcNow,
                Message = "{'bookingId':'5e821d62b5504d0010c11b62','invoiceNumber':'5331085364','businessUnitID':'707','notificationType':'COGS','classificationType':'EMC','vendorId':'230','pipelineSource':'EMC', correlationId:'711123ae-7b1c-4162-94ca-d4af5794f313' ,'Links': [{'Rel':'Rel_1', 'Uri': 'Uri_1'}],'eventDateTime':'2020-03-30T16:25:09.1029939+00:00'}",
                LastModifiedDateTime = DateTime.UtcNow,
                Links = LstLink()

            };
        }

        private List<Link> LstLink()
        {
            var lstLinks = new List<Link>
            {
                new Link { Rel = "rel1", Uri = "uri1" },
                new Link { Rel = "rel1_1", Uri = "uri_1" }
            };
            return lstLinks;
        }
        private MessageValidationError MessageValidationError()
        {
            return new MessageValidationError
            {
                Id = "5d8c5e8b08f227273431d951",
                Error = "Found Error While Processing ClassafiInvoiceRequest",
                Content = "Error has been detected while Processing ClassafiInvoiceRequest",
                TimeStamp = DateTime.UtcNow
            };
        }

        #endregion PrivateMethods
    }
}
