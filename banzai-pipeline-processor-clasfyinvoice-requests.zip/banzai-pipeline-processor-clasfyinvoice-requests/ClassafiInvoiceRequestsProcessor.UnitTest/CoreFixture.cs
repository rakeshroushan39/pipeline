﻿using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;

namespace DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.UnitTest
{
    public class CoreFixture : IDisposable
    {
        public readonly MessageProcessor MessageProcessor;
        public readonly Mock<IDataContext> MongoDataContext;
        
        public CoreFixture()
        {
            MongoDataContext = new Mock<IDataContext>();
            var settings = new Mock<IOptions<Settings>>();
            var mailService = new Mock<IMailService>();
            var rmqPublisher = new Mock<IPublisher>();
            var logger = new Mock<ILogger<MessageProcessor>>();
            
            var queues = new Queue[3] { new Queue() { QueueName = "q.banzai.pipeline.dell.enrichment" },
            new Queue() { QueueName = "q.banzai.pipeline.emc.enrichment" },
            new Queue() { QueueName = "q.banzai.pipeline.channel.enrichment" }};            

            var publisherQueue = new Mock<IPublisherQueue>();
            publisherQueue.Setup(x=>x.Queues).Returns(queues);

            Settings getSettings = new Settings() 
            {
                EMAIL_IT_TEAM = "DFS_IT_Originations_Banzai_DEV@dell.com",
                ASPNETCORE_ENVIRONMENT = "Dev"
                
            };
            settings.Setup(x => x.Value).Returns(() => getSettings);

            MessageProcessor = new MessageProcessor(logger.Object, settings.Object, mailService.Object,
                MongoDataContext.Object, rmqPublisher.Object, publisherQueue.Object);

        }
        public void Dispose()
        {
            //Cleanup
            //Mapper.Reset();
        }
    }
}
