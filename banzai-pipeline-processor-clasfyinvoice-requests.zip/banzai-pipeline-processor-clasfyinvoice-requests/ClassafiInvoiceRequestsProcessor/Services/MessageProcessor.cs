using DFS.Banzai.Library;
using DFS.Banzai.Library.Entities;
using DFS.Banzai.Library.Interfaces;
using DFS.Banzai.Library.RabbitMQ;
using DFS.Banzai.Library.RabbitMQ.Publisher;
using DFS.Banzai.Pipeline.Library.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.Services
{
    public class MessageProcessor : IMessageProcessor
    {
        #region MemberVariables
        private readonly ILogger _logger;
        private readonly IDataContext _dataContext;
        private readonly Settings _settings;
        private readonly IMailService _mailService;
        private readonly IPublisher _rabbitMQueuePublisher;
        private readonly Queue _dellInvoiceEnrichmentQueue;
        private readonly Queue _emcInvoiceEnrichmentQueue;
        private readonly Queue _channelInvoiceEnrichmentQueue;
        public bool IsTestCaseExecution;
        #endregion

        /// <summary>
        /// Constructor to initialize global fields
        /// </summary>
        public MessageProcessor(ILogger<MessageProcessor> logger, IOptions<Settings> settings,
            IMailService mailService, IDataContext dataContext, IPublisher rabbitMQueuePublisher, IPublisherQueue publisherQueue)
        {
            _logger = logger;
            _settings = settings.Value;
            _mailService = mailService;
            _dataContext = dataContext;
            _rabbitMQueuePublisher = rabbitMQueuePublisher;

            //Setup Queues for Invoice.Enrichment
            _dellInvoiceEnrichmentQueue = publisherQueue.Queues[0];
            _emcInvoiceEnrichmentQueue = publisherQueue.Queues[1];
            _channelInvoiceEnrichmentQueue = publisherQueue.Queues[2];
        }

        /// <summary>
        /// This method processes incoming messages arrived in 
        /// dfs external rabbitmq "q.classafi.enrich.invoice.notifications.progress.banzai.pipeline"
        /// </summary>
        /// <param name="message"></param>
        /// <returns>Boolean - Success/True , Failure/False</returns>
        public bool Process(string message)
        {
            _logger.LogDebug($"Entered method DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.Services.MessageProcessor.Process - {message}");

            try
            {
                var messageRequest = GenerateMessageRequest(message);

                if (messageRequest.ignore)
                    return true;

                if (messageRequest.IsWellFormed)
                {
                    _dataContext.PipelineClassafiInvoiceRequests.InsertOne(messageRequest.PipelineClassafiInvoiceRequest);

                    if (IsTestCaseExecution)
                        messageRequest.PipelineClassafiInvoiceRequest.Id = $"{(JsonConvert.DeserializeObject(message) as dynamic).Id.Value}";

                    if (!string.IsNullOrEmpty(messageRequest.PipelineClassafiInvoiceRequest.Id)
                        && !string.IsNullOrEmpty(messageRequest.PipelineClassafiInvoiceRequest.PipelineSource))
                    {
                        if ("DELL".Equals(messageRequest.PipelineClassafiInvoiceRequest.PipelineSource, StringComparison.InvariantCultureIgnoreCase))
                            _rabbitMQueuePublisher.Publish($"ClassafiInvoiceRequest|{messageRequest.PipelineClassafiInvoiceRequest.Id}", _dellInvoiceEnrichmentQueue.QueueName);

                        else if ("EMC".Equals(messageRequest.PipelineClassafiInvoiceRequest.PipelineSource, StringComparison.InvariantCultureIgnoreCase))
                            _rabbitMQueuePublisher.Publish($"ClassafiInvoiceRequest|{messageRequest.PipelineClassafiInvoiceRequest.Id}", _emcInvoiceEnrichmentQueue.QueueName);

                        else if ("CHANNEL".Equals(messageRequest.PipelineClassafiInvoiceRequest.PipelineSource, StringComparison.InvariantCultureIgnoreCase))
                            _rabbitMQueuePublisher.Publish($"ClassafiInvoiceRequest|{messageRequest.PipelineClassafiInvoiceRequest.Id}", _channelInvoiceEnrichmentQueue.QueueName);
                    }
                }
                else
                {
                    var messageValidationError = new MessageValidationError
                    {
                        Error = "Non-well-formed message received",
                        Content = message
                    };

                    SaveToErrorsStore(messageValidationError);
                }
            }
            catch (MongoException e)
            {
                var errorMsg = $"Banzai.Pipeline.ClassafiInvoiceRequestsProcessor MongoException message processing failed {message}";
                _logger.LogError($"{errorMsg}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                NotifyFailureAdmin(e, errorMsg);

                return IgnoreRetry($"ClassafiInvoiceRequestsProcessor_Mongo_{e.Message}");
            }
            catch (Exception e)
            {
                var errorMsg = $"Banzai.Pipeline.ClassafiInvoiceRequestsProcessor GenericException message processing failed {message}";
                _logger.LogError($"{errorMsg}. {e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");

                NotifyFailureAdmin(e, errorMsg);
                HandleFailure(e, errorMsg, message);

                return true;
            }

            _logger.LogDebug($"Exited method DFS.Banzai.Pipeline.Streaming.ClassafiInvoiceRequestsProcessor.Services.MessageProcessor.Process.");

            return true;
        }        

        /// <summary>
        /// This method gets called if received xml document is not wellformed.
        /// </summary>
        /// <param name="messageValidationErrors"></param>
        private void SaveToErrorsStore(MessageValidationError messageValidationError)
        {
            _logger.LogWarning($"Non-well-formed message received {messageValidationError?.Content}.");
            _dataContext.MessageValidationErrors.InsertOneAsync(messageValidationError);
        }

        /// <summary>
        /// This method evaluates if the incoming message is Json document.
        /// </summary>
        /// <returns>Document</returns>
        private (PipelineClassafiInvoiceRequest PipelineClassafiInvoiceRequest, bool IsWellFormed, bool ignore) GenerateMessageRequest(string message)
        {
            PipelineClassafiInvoiceRequest pipelineClassafiInvoiceRequest = null;
            var isWellFormed = false;
            try
            {
                if (message.ValidateJSON())
                {
                    dynamic messageObj = JsonConvert.DeserializeObject(message);

                    if (!"GAAP".Equals(messageObj?.notificationType?.Value, StringComparison.InvariantCultureIgnoreCase)
                        &&
                        !"COGS".Equals(messageObj?.notificationType?.Value, StringComparison.InvariantCultureIgnoreCase)
                        &&
                        !"606".Equals(messageObj?.notificationType?.Value, StringComparison.InvariantCultureIgnoreCase))
                    {
                        return (null, false, true);
                    }

                    pipelineClassafiInvoiceRequest = new PipelineClassafiInvoiceRequest
                    {
                        PipelineSource = $"{messageObj.pipelineSource.Value}",
                        VendorID = $"{messageObj.vendorId.Value}",
                        InvoiceNo = $"{messageObj.invoiceNumber.Value}",
                        SourceBusinessUnit = $"{messageObj.businessUnitID.Value}",
                        NotificationType = $"{messageObj.notificationType.Value}",
                        CorrelationID = $"{messageObj.correlationId.Value}",
                        Message = message
                    };

                    var decisionsourceDt = $"{messageObj?.eventDateTime?.Value}";
                    if (!string.IsNullOrEmpty(decisionsourceDt))
                        pipelineClassafiInvoiceRequest.DecisionSourceDateTime =
                            Convert.ToDateTime($"{decisionsourceDt}");
                    else
                        pipelineClassafiInvoiceRequest.DecisionSourceDateTime = null;

                    if (messageObj.links != null)
                    {
                        var links = new List<Link>();
                        foreach (var link in messageObj.links)
                            links.Add(new Link() { Rel = $"{link.rel.Value}", Uri = $"{link.link.Value}" });

                        pipelineClassafiInvoiceRequest.Links = links;
                    }

                    isWellFormed = true;
                }
            }
            catch (Exception e)
            {
                _logger.LogError($"Banzai.Pipeline.ClassafiInvoiceRequestsProcessor invalid message format. " +
                    $"{e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }

            return (pipelineClassafiInvoiceRequest, isWellFormed, false);
        }

        /// <summary>
        /// This method works on ignoring all mongo exceptions when requested
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>       
        [ExcludeFromCodeCoverage]
        private bool IgnoreRetry(string key)
        {
            if ("prod".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase)
                || "production".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
            {
                var filter = Builders<IgnoreRetry>.Filter.Eq(u => u.Guid, key);
                var count = _dataContext.IgnoreRetry.Find(filter)?.Count() ?? 0;

                if (count > 0)
                {
                    _dataContext.IgnoreRetry.DeleteOne(filter);
                    return true; //Ignore the message
                }

                return false;
            }

            return true;
        }

        /// <summary>
        /// Notify IT admin thru email for failures
        /// </summary>
        /// <param name="e"></param>
        /// <param name="errorMsg"></param>
        private void NotifyFailureAdmin(Exception e, string errorMsg)
        {
            if ("Development".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase) ||
                "PERF".Equals(_settings.ASPNETCORE_ENVIRONMENT, StringComparison.InvariantCultureIgnoreCase))
                return;

            var to = _settings.EMAIL_IT_TEAM.Split(',').ToList();
            var body = $"{errorMsg}<br /><br />Exception Message: '{e.Message}'.<br /><br />.Exception Details: {e}.";
            var mailMessage = new MailMessage
            {
                Subject = "Banzai.Pipeline.ClassafiInvoiceRequestsProcessor message processing failure notification",
                Body = body,
                ToList = to,
                IsBodyHtml = true,
                OperatingEnv = _settings.ASPNETCORE_ENVIRONMENT
            };
            _mailService.SendMail(mailMessage);
        }

        /// <summary>
        /// Logging the exception into Mongo Collection for further processing
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="errorMessage"></param>
        /// <param name="message"></param>
        protected void HandleFailure(Exception ex, string errorMessage, string message)
        {
            try
            {
                var errorLog = new ErrorLog()
                {
                    Processor = "Banzai.Pipeline.ClassafiInvoiceRequestsProcessor",
                    Message = message,
                    ErrorDetails = $"{errorMessage}. Exception: {ex}"
                };

                _dataContext.ErrorLogs.InsertOneAsync(errorLog);
            }
            catch (Exception e)
            {
                _logger.LogError($"ErrorLogs - for incoming message - {message}. " +
                    $"{e.ToString().Replace("\r\n", "").Replace("\n", "").Replace("\r", "")}");
            }
        }
    }
}